
/* =========================================================
   Optics: renderer, post pipeline, exposure, focus, player
   ========================================================= */
const BASE_EXP = 1.9;
const G = { renderer:null, scene:null, cam:null, post:null, postScene:null, postCam:null, rtLive:null, halfFloat:true };
const Player = { x:0, z:30, y:1.65, yaw:Math.PI, pitch:0, roll:0, vx:0, vz:0, speed:0, crouch:0, raise:0, raised:false, bob:0, zoomF:24, breath:1, breathing:false, lensSwap:0 };
const Cam = { focus:5, afTarget:5, afLock:false, afHit:null, skyFrac:0, skyT:0, exp:null, meterOff:0 };

const POST_VS = `varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }`;
const POST_FS = `
#include <packing>
uniform sampler2D tColor; uniform sampler2D tDepth;
uniform float cNear; uniform float cFar; uniform float exposure; uniform float cocK; uniform float focusD; uniform float maxR; uniform float dofOn;
uniform vec2 texel; uniform float outScale; uniform int taps;
uniform float tint; uniform float soft; uniform float accW; uniform vec2 sunUv; uniform float shaft; uniform vec3 shaftCol;
uniform float sat; uniform float con; uniform float mono; uniform float warm; uniform float fade; uniform float vig;
varying vec2 vUv;
float viewDist(vec2 uv){ float d = texture2D(tDepth, uv).x; return -perspectiveDepthToViewZ(d, cNear, cFar); }
float cocOf(float D){ return min(maxR, soft + cocK*abs(D - focusD)/max(D,0.01)); }
vec3 aces(vec3 x){ return clamp((x*(2.51*x+0.03))/(x*(2.43*x+0.59)+0.14),0.0,1.0); }
void main(){
  vec3 col;
  if (dofOn > 0.5){
    float cd = viewDist(vUv); float cr = cocOf(cd);
    vec3 acc = texture2D(tColor, vUv).rgb; float ws = 1.0;
    for (int i=0;i<72;i++){
      if (i>=taps) break;
      float fi = float(i); float r = sqrt((fi+0.5)/float(taps))*maxR;
      vec2 off = vec2(cos(fi*2.39996), sin(fi*2.39996))*r;
      vec2 uv = vUv + off*texel*outScale;
      float sd = viewDist(uv); float sr = cocOf(sd);
      float eff = sd > cd ? min(sr, cr) : sr;
      float w = clamp(eff - r + 1.0, 0.0, 1.0);
      acc += texture2D(tColor, uv).rgb*w; ws += w;
    }
    col = acc/ws;
  } else if (outScale > 1.01) {
    vec2 h = texel*0.5*outScale;
    col = (texture2D(tColor, vUv+vec2(-h.x,-h.y)).rgb + texture2D(tColor, vUv+vec2(h.x,-h.y)).rgb + texture2D(tColor, vUv+vec2(-h.x,h.y)).rgb + texture2D(tColor, vUv+vec2(h.x,h.y)).rgb)*0.25;
  } else col = texture2D(tColor, vUv).rgb;
  if (shaft > 0.001){ vec2 dl = (sunUv - vUv)/28.0; vec2 uv = vUv; float acc = 0.0;
    for (int i=0;i<28;i++){ uv += dl; if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) break; acc += step(0.99999, texture2D(tDepth, uv).x); }
    acc /= 28.0; float fall = exp(-length((sunUv - vUv)*vec2(texel.y/texel.x, 1.0))*1.4); col += shaftCol*acc*fall*shaft; }
  col *= exposure;
  col = aces(col);
  col = pow(col, vec3(1.0/2.2));
  float l = dot(col, vec3(0.299,0.587,0.114));
  col = mix(vec3(l), col, sat);
  col = (col-0.5)*con + 0.5;
  col.r += warm - tint*0.5; col.g += warm*0.35 + tint; col.b -= warm + tint*0.5;
  float m = dot(col, vec3(0.30,0.59,0.11));
  col = mix(col, vec3(m), mono);
  col = fade + col*(1.0-fade);
  vec2 q = vUv-0.5; col *= 1.0 - vig*dot(q,q)*1.6;
  gl_FragColor = vec4(clamp(col,0.0,1.0)*accW, 1.0);
}`;
const DEPTH_FS = `
#include <packing>
uniform sampler2D tDepth; uniform float cNear; uniform float cFar; varying vec2 vUv;
void main(){ float d = texture2D(tDepth, vUv).x; float v = -perspectiveDepthToViewZ(d, cNear, cFar); float n = clamp(v/400.0, 0.0, 0.99999);
  float hi = floor(n*255.0)/255.0; float lo = fract(n*255.0); gl_FragColor = vec4(hi, lo, 0.0, 1.0); }`;

function makeRT(w,h){
  const opts = { type: G.halfFloat ? THREE.HalfFloatType : THREE.UnsignedByteType, minFilter:THREE.LinearFilter, magFilter:THREE.LinearFilter, depthBuffer:true };
  const rt = new THREE.WebGLRenderTarget(w,h,opts);
  rt.depthTexture = new THREE.DepthTexture(w,h); rt.depthTexture.type = THREE.UnsignedIntType;
  return rt;
}
function initRenderer(){
  const canvas = $("#view");
  const r = new THREE.WebGLRenderer({ canvas, antialias:false, powerPreference:"high-performance", preserveDrawingBuffer:false });
  r.physicallyCorrectLights = true; r.shadowMap.enabled = true; r.shadowMap.type = THREE.PCFSoftShadowMap;
  r.outputEncoding = THREE.LinearEncoding; r.toneMapping = THREE.NoToneMapping;
  const gl = r.getContext(); G.halfFloat = r.capabilities.isWebGL2 ? !!(gl.getExtension("EXT_color_buffer_float") || gl.getExtension("EXT_color_buffer_half_float")) : !!gl.getExtension("EXT_color_buffer_half_float");
  G.renderer = r; G.scene = new THREE.Scene();
  G.cam = new THREE.PerspectiveCamera(70, innerWidth/innerHeight, 0.1, 2200); G.cam.rotation.order = "YXZ";
  G.scene.add(G.cam);
  G.post = new THREE.ShaderMaterial({ vertexShader:POST_VS, fragmentShader:POST_FS, depthTest:false, depthWrite:false, uniforms:{
    tColor:{value:null}, tDepth:{value:null}, cNear:{value:0.08}, cFar:{value:3000}, exposure:{value:1}, cocK:{value:0}, focusD:{value:5}, maxR:{value:8}, dofOn:{value:0},
    texel:{value:new THREE.Vector2()}, outScale:{value:1}, taps:{value:24}, tint:{value:0}, soft:{value:0}, accW:{value:1}, sunUv:{value:new THREE.Vector2()}, shaft:{value:0}, shaftCol:{value:new THREE.Color()}, sat:{value:1}, con:{value:1}, mono:{value:0}, warm:{value:0}, fade:{value:0}, vig:{value:0} } });
  G.depthMat = new THREE.ShaderMaterial({ vertexShader:POST_VS, fragmentShader:DEPTH_FS, depthTest:false, depthWrite:false, uniforms:{ tDepth:{value:null}, cNear:{value:0.08}, cFar:{value:3000} } });
  G.postScene = new THREE.Scene(); G.postCam = new THREE.OrthographicCamera(-1,1,1,-1,0,1);
  G.quad = new THREE.Mesh(new THREE.PlaneGeometry(2,2), G.post); G.quad.frustumCulled = false; G.postScene.add(G.quad);
  resize();
  addEventListener("resize", resize);
}
function resize(){
  const q = (S && S.custom && S.custom.renderQuality) || "balanced", r = G.renderer, dpr = devicePixelRatio||1;
  const pr = q === "ultra" ? Math.min(dpr, 2) : Math.min(dpr, q === "cinematic" ? 1.75 : q === "balanced" ? 1.25 : 1.0) * (q === "performance" ? 0.85 : 1);
  // Ultra renders the scene above screen resolution (1.5x–2x) and the post pass downsamples it: supersampled anti-aliasing.
  const rs = q === "ultra" ? Math.min(2, Math.max(1.5, dpr)) : pr;
  r.setPixelRatio(pr); r.setSize(innerWidth, innerHeight, false);
  const w = Math.floor(innerWidth*rs), h = Math.floor(innerHeight*rs);
  if (G.rtLive) G.rtLive.dispose(); G.rtLive = makeRT(w,h);
  G.cam.aspect = innerWidth/innerHeight; G.cam.updateProjectionMatrix();
  layoutVF();
}

/* ---------- viewfinder geometry ---------- */
const VF = { w:0, h:0, x:0, y:0 };
function layoutVF(){
  const W = innerWidth, Hh = innerHeight;
  const asp = S ? fmtAspect() : 1.5, side = S && S.custom && S.custom.sideCamera !== "off" && W > 900 ? 470 : 0; const h = Math.min(Hh*0.74, Math.min(W*0.86, W - side)/asp), w = h*asp;
  VF.w = w; VF.h = h; VF.x = (W-w)/2; VF.y = (Hh-h)/2 - Hh*0.02;
  const win = $("#vfwin"); Object.assign(win.style, { left:VF.x+"px", top:VF.y+"px", width:w+"px", height:h+"px" });
  $("#vfinfo").style.top = (VF.y + h + 10) + "px";
  $("#focusscale").style.top = (VF.y + h + 44) + "px";
  $("#level").style.top = (VF.y - 16) + "px";
  $("#breath").style.top = (VF.y - 30) + "px";
  Object.assign($("#vfleft").style, { left: Math.max(8, VF.x - 150)+"px", top: VF.y+"px", width:"140px" });
  Object.assign($("#vfright").style, { left: (VF.x + w + 10)+"px", top: VF.y+"px", width:"140px" });
  const g = $("#vfgrid"); g.width = Math.round(w); g.height = Math.round(h); drawGrid();
}
function drawGrid(){
  const g = $("#vfgrid"), c = g.getContext("2d"), w = g.width, h = g.height; c.clearRect(0,0,w,h);
  if (!S) return; const type = S.custom.grid; c.strokeStyle = "rgba(255,255,255,0.35)"; c.lineWidth = 1;
  const ln = (x0,y0,x1,y1)=>{ c.beginPath(); c.moveTo(x0,y0); c.lineTo(x1,y1); c.stroke(); };
  if (type==="thirds"){ for (const f of [1/3,2/3]){ ln(w*f,0,w*f,h); ln(0,h*f,w,h*f); } }
  else if (type==="golden"){ for (const f of [0.382,0.618]){ ln(w*f,0,w*f,h); ln(0,h*f,w,h*f); } }
  else if (type==="diagonal"){ ln(0,0,w,h); ln(w,0,0,h); ln(0,h,h,0); ln(w,h,w-h,0); }
}

/* ---------- light shafts (golden hour, fog) ---------- */
const _sv = new THREE.Vector3();
function setShafts(u, cam){
  const T = World.timeDef; if (!T || !World.sunDir || S.rain){ u.shaft.value = 0; return; }
  const amt = (({ morning:0.55, noon:0.07, golden:0.4, blue:0, night:0 })[T.id] || 0) * (S.fog ? 1.6 : 1);
  if (amt <= 0 || World.sunDir.y < -0.05){ u.shaft.value = 0; return; }
  cam.updateMatrixWorld(); _sv.setFromMatrixPosition(cam.matrixWorld).addScaledVector(World.sunDir, 800).project(cam);
  const fwd = new THREE.Vector3(0,0,-1).transformDirection(cam.matrixWorld);
  const facing = fwd.dot(World.sunDir); if (facing < 0.05){ u.shaft.value = 0; return; }
  u.sunUv.value.set(_sv.x*0.5+0.5, _sv.y*0.5+0.5); u.shaft.value = amt*Math.min(1, facing*2); u.shaftCol.value.copy(lin(T.sun)).multiplyScalar(0.9);
}
/* ---------- lens & exposure math ---------- */
function fmtAspect(){ const f = curFormat(); return f.w/f.h; }
function lensFocal(){ const L = curLens(); if (!L) return 50; return L.f2 ? clamp(Player.zoomF, L.f, L.f2) : L.f; }
function fmtDiag(){ const f = curFormat(); return Math.hypot(f.w, f.h); }
function feqReal(){ return lensFocal() * 43.27 / fmtDiag(); }
function vfovLens(){ return 2*Math.atan(curFormat().h/2/lensFocal()); }
function apertures(){ const L = curLens(), b = curBody(); if (b.fx) return [b.fx[0]]; if (!L) return [5.6]; const mn = L.min || 16; return [L.a].concat(APERTURES.filter(a => a > L.a + 0.05 && a <= mn + 0.01)); }
function snapA(n){ const as = apertures(); let best = as[0]; for (const a of as) if (Math.abs(Math.log(a/n)) < Math.abs(Math.log(best/n))) best = a; return best; }
const THIRD_T = [8000,4000,3200,2500,2000,1600,1250,1000,800,640,500,400,320,250,200,160,125,100,80,60,50,40,30,25,20,15,13,10,8,6,5,4,3,2.5,2,1.6,1.3,1].map(x=>1/x).concat([1.3,1.6,2]);
function snapT(t){ let best = THIRD_T[0]; for (const v of THIRD_T) if (Math.abs(Math.log(v/t)) < Math.abs(Math.log(best/t))) best = v; return best; }
function sceneEV(){ return (World.timeDef? World.timeDef.ev : 12) - (S.fog ? 0.8 : 0) - (S.rain ? 1.5 : 0); }
function modesFor(body){ return body.md.split(""); }
function pushRange(){ return [-1, 1 + sk("night")]; }
function computeExposure(){
  const b = curBody(), st = S.set, modes = modesFor(b), film = curFilm();
  if (!modes.includes(st.mode)) st.mode = modes[0];
  const roll_ = curRoll(); if (roll_.push === undefined) roll_.push = st.push || 0; st.push = clamp(roll_.push, ...pushRange());
  const iso = Math.round(film.iso * Math.pow(2, st.push));
  const meter = sceneEV() + Cam.skyFrac*1.3;
  const target = meter - st.ev;
  const feqv = feqReal(), tHand = 1/Math.max(30, feqv*1.6);
  const aList = apertures(), aMin = aList[0], aMax = aList[aList.length-1];
  const tMin = 1/b.ts, tMax = 1;
  const evIso = Math.log2(iso*Math.pow(2, -(typeof filterStops === "function" ? filterStops() : 0))/100);
  const solveT = N_ => N_*N_ / Math.pow(2, target + evIso);
  let N, t, warn = false;
  if (b.fx){ N = b.fx[0]; t = b.fx[1]; }
  else if (st.mode === "P"){
    N = snapA(clamp(1.41*Math.pow(2,(target + evIso - 6)/4), aMin, Math.min(11, aMax)));
    t = solveT(N);
    if (t > tHand && N > aMin){ N = aMin; t = solveT(N); }
    if (t < tMin){ N = snapA(Math.min(aMax, N*Math.sqrt(tMin/t))); t = solveT(N); }
  } else if (st.mode === "A"){ N = snapA(st.A); t = solveT(N); }
  else if (st.mode === "S"){ t = st.T; N = Math.sqrt(t*Math.pow(2, target + evIso)); if (N < aMin*0.95 || N > aMax*1.05) warn = true; N = snapA(clamp(N, aMin, aMax)); }
  else { N = snapA(st.A); t = st.T; }
  if (!b.fx){ if (st.mode === "P" || st.mode === "A"){ if (t > tMax || t < tMin) warn = true; t = clamp(t, tMin, tMax); t = snapT(t); } else t = clamp(t, tMin, 1); }
  const camEV = Math.log2(N*N/t) - evIso;
  const offset = sceneEV() - camEV;
  const meterDiff = meter - camEV;
  const fl = curFlash();
  const flashOn = st.flashOn && fl.gn > 0;
  const syncWarn = flashOn && t < 1/b.sync - 1e-6;
  Cam.exp = { N, t, iso, push:st.push, camEV, offset, meterDiff, warn: warn && !!b.mt, flashOn, syncWarn, mult: Math.pow(2, offset), meter:!!b.mt };
  return Cam.exp;
}
function cocMM(){ return fmtDiag()/1500; }
function hyperfocal(N){ const f = lensFocal(); return f*f/(N*cocMM())/1000; }
function dofRange(s, N){ const Hf = hyperfocal(N); const near = Hf*s/(Hf+s); const far = s >= Hf ? Infinity : Hf*s/(Hf-s); return [near, far, Hf]; }
function cocPx(D, s, N, W){ const fAct = lensFocal()/1000, sw = curFormat().w/1000; const c = (fAct*fAct/N)*Math.abs(D-s)/(D*Math.max(s - fAct, 0.01)); return 0.5*(c/sw)*W; }
function cocK(s, N, W){ const fAct = lensFocal()/1000, sw = curFormat().w/1000; return 0.5*((fAct*fAct/N)/Math.max(s-fAct,0.01)/sw)*W; }
function focusKind(){ const b = curBody(); if (b.ff) return "fixed"; if (b.af && S.set.af) return "af"; if (b.zone) return "zone"; return b.t==="Rangefinder"||b.t==="Panoramic"||(b.m==="M7") ? "rf" : "mf"; }

/* ---------- focus ---------- */
const _o = new THREE.Vector3(), _d = new THREE.Vector3();
function centerRay(){ G.cam.getWorldPosition(_o); G.cam.getWorldDirection(_d); return [_o.clone(), _d.clone()]; }
function updateFocus(dt){
  const b = curBody();
  const [o,d] = centerRay();
  const w = rayWorld(o,d,400), l = rayLife(o,d,w);
  Cam.afTarget = clamp(l.dist, 0.4, 400); Cam.afHit = l.hit;
  const fk = focusKind();
  if (fk === "fixed"){ Cam.focus = b.ff; Cam.afLock = false; }
  else if (fk === "af"){
    if (Player.raise > 0.5){ const k = 1 - Math.exp(-dt*b.af*(1+0.5*sk("quick"))*(1+0.35*famOf())); Cam.focus = Math.exp(lerp(Math.log(Cam.focus), Math.log(Cam.afTarget), k)); }
    Cam.afLock = Math.abs(Math.log(Cam.focus/Cam.afTarget)) < 0.05;
  } else {
    if (Cam.mfTarget){ const k = 1 - Math.exp(-dt*(5+3*sk("quick"))*(1+0.9*famOf())); S.set.focus = Math.exp(lerp(Math.log(S.set.focus), Math.log(Cam.mfTarget), k)); if (Math.abs(Math.log(S.set.focus/Cam.mfTarget)) < 0.01) Cam.mfTarget = null; }
    Cam.focus = S.set.focus; Cam.afLock = Math.abs(Math.log(Cam.focus/Cam.afTarget)) < 0.06;
  }
  Cam.skyT -= dt;
  if (Cam.skyT <= 0){
    Cam.skyT = 0.2; const vf = vfovLens(); let sky = 0; const rays = [[0,0],[0,vf*0.3],[0,-vf*0.3],[vf*0.4,0],[-vf*0.4,0]];
    const q = G.cam.quaternion;
    for (const [yx,px] of rays){ const dir = new THREE.Vector3(Math.sin(yx), Math.sin(px), -1).normalize().applyQuaternion(q); if (rayWorld(o, dir, 400) >= 399) sky++; }
    Cam.skyFrac = sky/5;
  }
}

/* ---------- held camera model: the camera you chose, in two gloved-in-reality hands ---------- */
const CAM_LOOK = {   // top plate, body covering, lens barrel, accent
  disp:["#f2c230","#f2c230","#1d1d1c","#c0362c"], holga:["#2b2b2b","#1a1a1a","#2b2b2b","#9a9a9a"], diana:["#3f8f8a","#1a1a1a","#2b2b2b","#e9e6de"], lca:["#2a2a2a","#1c1c1c","#303030","#9a9a9a"],
  pen:["#c9c9c4","#2a2522","#c9c9c4","#1a1a1a"], demi:["#c9c9c4","#1c1c1c","#c9c9c4","#1a1a1a"], mju:["#d8cdb5","#d8cdb5","#c9bea3","#1a1a1a"], t2:["#b9b1a0","#b9b1a0","#2a2a2a","#1a1a1a"], t3:["#b9b1a0","#b9b1a0","#2a2a2a","#1a1a1a"],
  t4:["#1d1d1c","#1d1d1c","#2a2a2a","#9a9a9a"], gr1v:["#1a1a1a","#1a1a1a","#1f1f1f","#9a9a9a"], ti35:["#b9b1a0","#b9b1a0","#2a2a2a","#1a1a1a"], bigmini:["#1d1d1c","#1d1d1c","#2a2a2a","#9a9a9a"],
  tc1:["#c9c9c4","#c9c9c4","#2a2a2a","#1a1a1a"], minilux:["#b9b1a0","#b9b1a0","#2a2a2a","#1a1a1a"], hexar:["#1d1d1c","#1d1d1c","#2a2a2a","#9a9a9a"], klasse:["#d8cdb5","#d8cdb5","#2a2a2a","#1a1a1a"],
  rollei35:["#c9c9c4","#1c1c1c","#c9c9c4","#1a1a1a"], xa:["#1d1d1c","#1d1d1c","#2a2a2a","#c0362c"], ql17:["#c9c9c4","#1c1c1c","#c9c9c4","#1a1a1a"], gsn:["#c9c9c4","#1c1c1c","#c9c9c4","#1a1a1a"],
  m3:["#cfcfc9","#1b1b1a","#cfcfc9","#c0362c"], m6:["#1b1b1a","#1b1b1a","#1b1b1a","#c0362c"], mp:["#1b1b1a","#1b1b1a","#1b1b1a","#c9a24a"], bessa:["#1d1d1c","#1d1d1c","#1d1d1c","#9a9a9a"],
  cle:["#1d1d1c","#1d1d1c","#1d1d1c","#9a9a9a"], canonp:["#cfcfc9","#1b1b1a","#cfcfc9","#1a1a1a"], zm:["#c9c9c4","#1b1b1a","#1b1b1a","#9a9a9a"],
  k1000:["#c9c9c4","#1c1c1c","#1c1c1c","#9a9a9a"], mx:["#c9c9c4","#1c1c1c","#1c1c1c","#9a9a9a"], lx:["#1d1d1c","#1d1d1c","#1d1d1c","#9a9a9a"], ae1:["#c9c9c4","#1c1c1c","#1c1c1c","#c0362c"],
  f1:["#1d1d1c","#1d1d1c","#1d1d1c","#9a9a9a"], nikonf:["#cfcfc9","#1b1b1a","#1b1b1a","#9a9a9a"], f2:["#cfcfc9","#1b1b1a","#1b1b1a","#9a9a9a"], fm2:["#cfcfc9","#1b1b1a","#1b1b1a","#9a9a9a"],
  f3:["#1d1d1c","#1d1d1c","#1d1d1c","#c0362c"], f100:["#1a1a1a","#1a1a1a","#1a1a1a","#9a9a9a"], om1:["#cfcfc9","#1b1b1a","#1b1b1a","#9a9a9a"], om2:["#cfcfc9","#1b1b1a","#1b1b1a","#9a9a9a"],
  mtl5:["#1d1d1c","#1d1d1c","#1d1d1c","#9a9a9a"], zenit:["#cfcfc9","#1b1b1a","#cfcfc9","#9a9a9a"], spotmatic:["#cfcfc9","#1b1b1a","#1b1b1a","#9a9a9a"],
  hassy:["#cfcfc9","#1b1b1a","#1b1b1a","#9a9a9a"], rb67:["#1d1d1c","#1d1d1c","#1d1d1c","#9a9a9a"], p67:["#cfcfc9","#1b1b1a","#1b1b1a","#9a9a9a"], m7:["#1d1d1c","#1d1d1c","#1d1d1c","#9a9a9a"],
  m645:["#1d1d1c","#1d1d1c","#1d1d1c","#9a9a9a"], rolleiflex:["#cfcfc9","#1b1b1a","#1b1b1a","#9a9a9a"], yashicamat:["#cfcfc9","#1b1b1a","#1b1b1a","#9a9a9a"], gw690:["#8e8f8c","#1d1d1c","#1d1d1c","#9a9a9a"],
  xpan:["#b0aca2","#b0aca2","#1d1d1c","#1a1a1a"], sx70cam:["#cfcfc9","#6b4a2e","#1b1b1a","#9a9a9a"],
};
let heldCam = null;
function buildHeldCam(){
  if (heldCam){ G.cam.remove(heldCam); heldCam = null; }
  const g = new THREE.Group(), b = curBody(), L = curLens(), t = b.t;
  let look = CAM_LOOK[S.body] || ["#c9c9c4","#1c1c1c","#1c1c1c","#9a9a9a"];
  const fin = S.custom.finish; if (fin && fin !== "original"){ look = { black:["#1d1d1c","#1d1d1c","#1d1d1c",look[3]], silver:["#c9c9c4","#262624","#c9c9c4",look[3]], olive:["#556048","#262624","#262624",look[3]], cream:["#e6dcc6","#6b4a2e","#c9c9c4",look[3]] }[fin] || look; }
  const M_ = (c, r=0.5, m=0.2) => new THREE.MeshStandardMaterial({ color:lin(c), roughness:r, metalness:m });
  const chrome = h => { const c = new THREE.Color(h); return c.r > 0.5 && Math.abs(c.r - c.b) < 0.1; };
  const mTop = M_(look[0], chrome(look[0]) ? 0.28 : 0.45, chrome(look[0]) ? 0.85 : 0.2), mBody = M_(look[1], 0.9, 0.02), mLens = M_(look[2], chrome(look[2]) ? 0.3 : 0.55, chrome(look[2]) ? 0.85 : 0.2), mAcc = M_(look[3], 0.5, 0.2), glass = M_("#0b1216", 0.05, 0.7), dark = M_("#141414", 0.7, 0.1);
  const add = (geo, mat, x, y, z, rx=0, ry=0, rz=0) => { const m = new THREE.Mesh(geo, mat); m.position.set(x,y,z); m.rotation.set(rx,ry,rz); g.add(m); return m; };
  const rbox = (w,h,d,mat,x,y,z) => add(new THREE.BoxGeometry(w,h,d), mat, x, y, z);
  const cyl = (r,len,mat,x,y,z) => add(new THREE.CylinderGeometry(r,r,len,28).rotateX(Math.PI/2), mat, x, y, z);
  let w = 0.14, h = 0.085, dep = 0.04, lensX = 0, lensY = -0.004;
  if (t === "Disposable"){ w = 0.11; h = 0.06; dep = 0.035; rbox(w,h,dep, mBody, 0,0,0); rbox(w+0.002,0.028,dep+0.002, mAcc, 0,-0.012,0); cyl(0.009,0.006,glass, 0.02,0.008,-0.02); rbox(0.03,0.012,0.004, M_("#f4f4ee",0.2,0), -0.03,0.016,-0.019); lensX = 0.02; }
  else if (t === "TLR"){ w = 0.08; h = 0.14; dep = 0.08; rbox(w,h,dep, mBody, 0,0,0); rbox(w+0.002,0.03,dep+0.002, mTop, 0,0.085,0); for (const yy of [0.03,-0.03]){ cyl(0.022,0.03,mTop, 0,yy,-0.05); cyl(0.017,0.002,glass,0,yy,-0.066); } lensY = -0.03; }
  else if (t === "Instant"){ w = 0.1; h = 0.1; rbox(0.1,0.03,0.17, mBody, 0,-0.02,0); const top = rbox(0.1,0.1,0.02, mTop, 0,0.03,-0.05); top.rotation.x = -0.5; cyl(0.014,0.02,glass, 0,0.03,-0.07); }
  else {
    const mf = t === "Medium format", pns = t === "Point & shoot" || (t === "Toy" && b.fmt === "135");
    w = mf ? 0.12 : pns ? 0.115 : t==="Panoramic" ? 0.16 : 0.14; h = mf ? 0.11 : pns ? 0.064 : 0.085; dep = mf ? 0.1 : pns ? 0.036 : 0.04;
    if (pns){ rbox(w, h, dep, mTop, 0, 0, 0); rbox(w*0.35, h*0.9, dep*1.05, mBody, -w*0.28, 0, 0); }
    else { rbox(w,h*0.64,dep, mBody, 0,-h*0.18,0); rbox(w,h*0.36,dep*1.02, mTop, 0,h*0.32,0); }
    if (t === "SLR"){ const pr = add(new THREE.CylinderGeometry(0.018, 0.03, 0.035, 4).rotateY(Math.PI/4), mTop, 0, h*0.62, 0); pr.scale.set(1.3, 1, 0.9); }
    if (t === "Rangefinder" || t === "Panoramic"){ rbox(0.016,0.012,0.002, glass, -w*0.36,h*0.33,-dep/2-0.001); rbox(0.012,0.012,0.002, glass, w*0.22,h*0.33,-dep/2-0.001); }
    lensX = (t==="Rangefinder" || pns) ? w*0.1 : 0;
    const lensLen = pns ? 0.012 : clamp(0.02 + lensFocal()/2500 + (mf?0.03:0), 0.02, 0.14), lr = pns ? 0.017 : 0.026 + (L && L.a < 2 ? 0.006 : 0) + (mf?0.015:0);
    const lens = cyl(lr, lensLen, mLens, lensX, lensY, -dep/2 - lensLen/2); g.userData.lens = lens; g.userData.lensLen = lensLen; g.userData.dep = dep; g.userData.f0 = lensFocal();
    cyl(lr*1.04, 0.006, dark, lensX, lensY, -dep/2 - lensLen*0.35); cyl(lr*0.78, 0.001, glass, lensX, lensY, -dep/2 - lensLen - 0.001);
    add(new THREE.CylinderGeometry(0.009,0.009,0.008,20), mTop, w*0.3, h*0.5 + 0.004, 0);
    add(new THREE.CylinderGeometry(0.004,0.004,0.006,12), mAcc, w*0.36, h*0.5 + 0.009, -0.006);
    if (look[3] === "#c0362c" && t === "Rangefinder") add(new THREE.CylinderGeometry(0.004,0.004,0.002,12).rotateX(Math.PI/2), mAcc, -w*0.28, h*0.3, -dep/2 - 0.002);
  }
  const fl = FLASHES[S.flash]; if (S.set.flashOn && fl && fl.gn){ rbox(0.05, fl.gn>30?0.07:0.03, 0.035, M_("#222",0.6,0.1), 0, h/2 + 0.03, 0); }
  // hands: a relaxed two-handed grip, sleeves leaving the frame at the bottom
  const skin = M_(S.custom.skin || "#c68b62", 0.62, 0), sleeve = M_(S.custom.sleeve || "#2d3033", 0.95, 0);
  const cap = (r, len, mat, x, y, z, rx, ry, rz) => { const m = add(new THREE.CylinderGeometry(r, r*0.92, len, 12), mat, x, y, z, rx, ry, rz); const e1 = new THREE.Mesh(new THREE.SphereGeometry(r*0.95, 10, 8), mat); e1.position.y = len/2; m.add(e1); const e2 = e1.clone(); e2.position.y = -len/2; m.add(e2); return m; };
  const blob = (sx, sy, sz, x, y, z, rx=0, ry=0, rz=0) => { const m = add(new THREE.SphereGeometry(1, 16, 12), skin, x, y, z, rx, ry, rz); m.scale.set(sx, sy, sz); return m; };
  const R_ = w/2, V3 = (x_,y_,z_) => new THREE.Vector3(x_,y_,z_);
  const limb = (p0, p1, r0, r1, mat) => { const d = p1.clone().sub(p0), len = d.length(), m = new THREE.Mesh(new THREE.CylinderGeometry(r1, r0, len, 14), mat); m.position.copy(p0).addScaledVector(d, 0.5); m.quaternion.setFromUnitVectors(V3(0,1,0), d.normalize()); g.add(m); const e = new THREE.Mesh(new THREE.SphereGeometry(r1, 10, 8), mat); e.position.copy(p1); g.add(e); return m; };
  // right hand: fingertips curl round the front of the grip, the index finger rests by the release
  const wr = V3(R_ + 0.02, -h*0.32, 0.018);
  blob(0.013, Math.min(0.03, h*0.38), 0.026, R_ + 0.008, -h*0.06, 0.004, 0, 0, -0.08);
  for (let k=0;k<3;k++) limb(V3(R_ + 0.006, -h*0.05 - k*0.014, -dep/2 + 0.006), V3(R_ - 0.012, -h*0.05 - k*0.014, -dep/2 - 0.004), 0.0058, 0.0052, skin);
  limb(V3(R_ + 0.004, h*0.36, -0.004), V3(R_ - 0.018, h/2 + 0.004, -0.008), 0.0056, 0.005, skin);
  limb(V3(R_ + 0.006, h*0.1, dep/2 + 0.004), V3(R_ - 0.014, h*0.2, dep/2 + 0.006), 0.0062, 0.0056, skin);
  limb(wr, V3(R_ + 0.16, -0.26, 0.3), 0.021, 0.03, sleeve);
  // left hand: palm under the lens, thumb up the near side
  const lz = g.userData.lens ? g.userData.lens.position.z : -dep/2 - 0.01;
  blob(0.026, 0.009, 0.03, lensX - 0.002, -h/2 - 0.008, lz + 0.006);
  for (let k=0;k<3;k++) limb(V3(lensX + 0.02, -h/2 - 0.006, lz - 0.01 + k*0.011), V3(lensX + 0.03, -h/2 + 0.012, lz - 0.01 + k*0.011), 0.0055, 0.005, skin);
  limb(V3(lensX - 0.022, -h/2 - 0.004, lz + 0.008), V3(lensX - 0.028, -h/2 + 0.016, lz - 0.004), 0.006, 0.0055, skin);
  limb(V3(lensX - 0.006, -h/2 - 0.016, lz + 0.03), V3(lensX - 0.14, -0.27, 0.32), 0.021, 0.03, sleeve);
  g.userData.dims = { w, h, dep, lensX, t, look };
  g.position.set(0.12,-0.185,-0.42); g.rotation.set(-0.25,-0.12,0);
  g.traverse(o=>{ if (o.isMesh){ o.castShadow = false; o.receiveShadow = false; o.renderOrder = 10; } });
  heldCam = g; G.cam.add(g);
}
