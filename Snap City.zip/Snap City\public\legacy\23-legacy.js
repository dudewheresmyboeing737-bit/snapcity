
/* =========================================================
   Contact Sheet v9 — manual film advance, filters, crosswalk signals, daily rhythm, wind, neon & lights.
   ========================================================= */
/* ---------- 1. manual film advance ---------- */
const MOTOR = new Set(["mju","t2","t3","t4","gr1v","ti35","bigmini","tc1","minilux","hexar","klasse","f100","sx70cam","xpan"]);
const NO_DEP = new Set(["holga","diana","disp"]);   // no double-exposure prevention: the shutter fires anyway
const WIND = { x:0.6, z:0.1, gust:0, base:0.6, dir:0.4, t:0 };
const MANUAL_WIND = new Set(["rollei35","xa","ql17","gsn","pen","demi","lca","holga","diana","disp"]);
function advanceMode(){ const b = curBody(); if (S.custom.filmAdvance === "auto") return "motor"; if (MOTOR.has(S.body) || ((b.af > 0 || b.t === "Instant" || b.t === "Panoramic" || b.t === "Point & shoot") && !MANUAL_WIND.has(S.body))) return "motor"; return "manual"; }
function vfMono(){ return S && S.custom.vfPreview !== "optical" && Player.raise > 0.6 && isMono(curFilm()) ? 1 : 0; }
function isCocked(){ S.cocked = S.cocked || {}; return S.cocked[S.body] !== false; }
function windOn(){
  if (advanceMode() === "motor"){ toast("This camera winds itself.", 900); return; }
  if (isCocked()) { toast("Already wound.", 700); return; }
  if (GP.winding) return; GP.winding = true;
  const dur = (curBody().t === "Medium format" || curBody().t === "TLR" ? 0.9 : 0.45) * (1 - 0.35*famOf());
  Audio.advance(); setTimeout(() => { S.cocked[S.body] = true; GP.winding = false; UI.hudT = 0; }, dur*1000);
}
(function(){ const base = captureShot; captureShot = async function(...a){
  const b = curBody(); S.cocked = S.cocked || {};
  if (GP.winding && advanceMode() === "manual"){ toast("Still winding…", 600); return null; }
  if (advanceMode() === "motor"){ S.cocked[S.body] = true; GP.winding = false; }
  if (!isCocked()){
    if (NO_DEP.has(S.body) && CAP.rtPrev){ GP.multi = 2; const r = await base(...a); if (r){ curRoll().left += 1; r.meta.accidental = true; toast("Oops: you didn't wind on. Two exposures on one frame.", 2400); } return r; }
    SND.init && SND.play("click", Player.x, Player.z, 0.3); toast(advanceMode() === "manual" ? "The shutter won't fire. Wind on first (Y)." : "The motor is still advancing…", 1400); return null; }
  const rec = await base(...a);
  if (rec && curRoll().left > 0){
    if (NO_DEP.has(S.body)){ try { if (!CAP.rtPrev || CAP.rtPrev.width !== CAP.W || CAP.rtPrev.height !== CAP.H){ if (CAP.rtPrev) CAP.rtPrev.dispose(); CAP.rtPrev = new THREE.WebGLRenderTarget(CAP.W, CAP.H, { depthBuffer:false }); } if (!FILM.copy) FILM.copy = new THREE.ShaderMaterial({ vertexShader:POST_VS, depthTest:false, depthWrite:false, uniforms:{ t:{value:null} }, fragmentShader:`uniform sampler2D t; varying vec2 vUv; void main(){ gl_FragColor = texture2D(t, vUv); }` }); FILM.copy.uniforms.t.value = CAP.rtFinal.texture; quadPass(FILM.copy, CAP.rtPrev); G.renderer.setRenderTarget(null); G.quad.material = G.post; } catch(e){} }
    if (advanceMode() === "motor"){ setTimeout(() => { SND.play("motor", Player.x, Player.z, 0.35); }, 30); }
    else S.cocked[S.body] = false;
  }
  return rec; }; })();

/* ---------- 2. filters ---------- */
const LENS_FILTERS = {
  none:{ n:"No filter", stops:0, p:0 }, uv:{ n:"UV / haze", stops:0, p:12, d:"Protects the front element. Does almost nothing else, which is the point.", col:[1,1,1.0], bw:[1,1,0.98] },
  yellow:{ n:"Yellow K2", stops:1, p:18, d:"Classic black-and-white filter: skies a shade darker, clouds pop.", col:[1.25,1.1,0.35], bw:[1.18,1.08,0.4] },
  orange:{ n:"Orange 21", stops:1.5, p:20, d:"Stronger sky, smoother skin, more drama.", col:[1.6,0.95,0.2], bw:[1.55,0.95,0.2] },
  red:{ n:"Red 25A", stops:3, p:24, d:"Near-black skies and glowing reds. Only makes sense on black and white.", col:[2.4,0.45,0.15], bw:[2.3,0.45,0.1] },
  green:{ n:"Green X1", stops:2, p:22, d:"Darker lips and reds, lighter foliage. Portrait trick for black and white.", col:[0.6,1.45,0.7], bw:[0.55,1.4,0.75] },
  polar:{ n:"Circular polarizer", stops:1.5, p:60, pol:true, d:"Deepens blue skies and cuts reflections. Shop windows turn transparent.", col:[1,1,1], bw:[1,1,1] },
  nd8:{ n:"ND8 (3 stops)", stops:3, p:40, d:"Slower shutters in daylight: motion blur and ghosts at noon.", col:[1,1,1], bw:[1,1,1] },
  nd64:{ n:"ND64 (6 stops)", stops:6, p:65, d:"Crowds dissolve into streaks. Brace yourself or use a tripod-steady hand.", col:[1,1,1], bw:[1,1,1] },
  warm:{ n:"Warming 81A", stops:0.33, p:16, d:"A touch of late-afternoon gold on any light.", col:[1.08,1.0,0.86], bw:[1,1,1] },
  cool:{ n:"Cooling 80A", stops:2, p:18, d:"Corrects tungsten light, or makes day look like a cold dawn.", col:[0.78,0.97,1.3], bw:[1,1,1] },
  star:{ n:"Star cross", stops:0.33, p:22, star:true, d:"Every streetlight becomes a four-pointed star. Kitsch, glorious.", col:[1,1,1], bw:[1,1,1] },
  soft:{ n:"Soft focus / diffusion", stops:0.5, p:30, soft:true, d:"Halos around highlights and forgiving skin. Very 1978.", col:[1,1,1], bw:[1,1,1] },
};
for (const k in LENS_FILTERS){ const f = LENS_FILTERS[k]; if (f.col){ const l = f.col[0]*0.3 + f.col[1]*0.59 + f.col[2]*0.11; f.col = f.col.map(v=>v/l); } if (f.bw){ const l = f.bw[0]*0.3 + f.bw[1]*0.59 + f.bw[2]*0.11; f.bw = f.bw.map(v=>v/l); } }
function filterStops(){ const f = LENS_FILTERS[S && S.filter || "none"]; return f ? f.stops : 0; }
function cycleFilter(dir=1){ const own = ["none"].concat((S.owned.filters||[]).filter(k=>LENS_FILTERS[k])); const i = own.indexOf(S.filter||"none"); S.filter = own[(i + dir + own.length) % own.length]; saveState(); UI.hudT = 0; toast(S.filter === "none" ? "Filter off." : `${LENS_FILTERS[S.filter].n} on (${LENS_FILTERS[S.filter].stops} stop${LENS_FILTERS[S.filter].stops === 1 ? "" : "s"}).`, 1500); applyPolarizer(); if (typeof buildHeldCam === "function") buildHeldCam(); }
function applyPolarizer(){ const pol = LENS_FILTERS[S.filter||"none"] && LENS_FILTERS[S.filter||"none"].pol; if (World.mats && World.mats.glass){ World.mats.glass.envMapIntensity = pol ? 0.08 : (({ clear:0.25, balanced:0.45, reflective:0.8 })[S.custom.windowGlass] || 0.45); } if (INT.u) INT.u.uBright.value = (pol ? 1.35 : 1) * (({ clear:1.25, balanced:1, reflective:0.75 })[S.custom.windowGlass] || 1); }
(function(){ const base = menuGear; menuGear = function(){ S.owned.filters = S.owned.filters || (S.free ? Object.keys(LENS_FILTERS) : []);
  const items = Object.entries(LENS_FILTERS).filter(([k])=>k !== "none").map(([k, f]) => { const own = S.owned.filters.includes(k), eq = S.filter === k;
    return `<div class="item ${eq?"equipped":""}"><div class="camhead"><span class="kind">Filter · ${f.stops} stop${f.stops===1?"":"s"}</span></div><h4>${f.n}</h4><div class="desc">${f.d}</div><div class="foot"><span class="price">${own ? "Owned" : "$"+f.p}</span>${eq ? `<button class="btn small alt" data-filt="none">Remove</button>` : own ? `<button class="btn small" data-filt="${k}">Screw on</button>` : `<button class="btn small" data-fbuy="${k}" ${(!S.free && S.money < f.p) ? "disabled" : ""}>Buy</button>`}</div></div>`; }).join("");
  return base() + `<div class="sectionhead">Filters <span class="spec">F-keys: [ ⟲ ] cycle with the 🝖 dial button · the meter compensates on metered cameras; on meterless ones you add the stops yourself</span></div><div class="grid">${items}</div>`; }; })();
addEventListener("click", ev => { const f = ev.target.closest && ev.target.closest("[data-filt],[data-fbuy]"); if (!f) return; ev.preventDefault(); ev.stopPropagation();
  if (f.dataset.fbuy){ const k = f.dataset.fbuy, F = LENS_FILTERS[k]; if (!S.free){ if (S.money < F.p) return; S.money -= F.p; } S.owned.filters = (S.owned.filters||[]).concat(k); S.filter = k; }
  else S.filter = f.dataset.filt; saveState(); applyPolarizer(); buildHeldCam(); renderMenu(); }, true);
(function(){ const base = buildHeldCam; buildHeldCam = function(){ base(); const F = LENS_FILTERS[S.filter||"none"]; if (!heldCam || !F || S.filter === "none" || S.filter === undefined || !heldCam.userData.lens) return;
  const L = heldCam.userData.lens, c = F.col ? new THREE.Color(Math.min(1, F.col[0]*0.5), Math.min(1, F.col[1]*0.5), Math.min(1, F.col[2]*0.5)) : new THREE.Color(0.2,0.2,0.2);
  const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.029, 0.029, 0.008, 24).rotateX(Math.PI/2), new THREE.MeshStandardMaterial({ color:0x111111, roughness:0.4, metalness:0.6 }));
  const glass = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.026, 0.002, 24).rotateX(Math.PI/2), new THREE.MeshStandardMaterial({ color:c, roughness:0.05, metalness:0.3, transparent:true, opacity:0.75 }));
  ring.position.copy(L.position); ring.position.z -= L.geometry.parameters.height/2 + 0.004; glass.position.copy(ring.position); glass.position.z -= 0.004; heldCam.add(ring, glass); }; })();

/* ---------- 3. crosswalk signals: traffic stops, crowds bunch at the curb and surge across ---------- */
const SIG = { t:0, phase:"carsX", len:{ carsX:32, walkZ:20 }, heads:[], mats:null };
function signalLimit(c, dirx){
  if (SIG.phase !== "walkZ" && !(SIG.phase === "carsX" && SIG.t > SIG.len.carsX - 3)) return 99;
  const RHs = 5, k0 = Math.floor(c.x/P - 0.5); let best = 99;
  for (let k = k0 - 1; k <= k0 + 2; k++){ const xs = (k + 0.5)*P, line = xs - dirx*(RHs + 3.2), d = (line - c.x)*dirx; if (d > -0.5 && d < 40) best = Math.min(best, Math.max(0, d - 0.6)*0.9); }
  return c.bus && SIG.phase === "carsX" ? 99 : best;
}
function maybeCross(p){
  if (p.pool || p.stationary || p.performer || p.noCross) return;
  const a = p.a, L = 2*a, t = ((p.s % L) + L) % L, near = p.dir > 0 ? L - t : t;
  if (near > 0.35){ p.lastCorner = null; return; }
  const cid = Math.round(p.s / L); if (p.lastCorner === cid) return; p.lastCorner = cid;
  if (Math.random() > 0.55) return;
  const r = rectPos(a, p.s + p.dir*0.4), dx = Math.round(r[2]*p.dir), dz = Math.round(r[3]*p.dir);
  const cx = Math.round(p.cx/P), cz = Math.round(p.cz/P), nx = cx + dx, nz = cz + dz; if (Math.abs(nx) > NB || Math.abs(nz) > NB) return;
  const corner = { x: p.cx + Math.sign(r[0])*a, z: p.cz + Math.sign(r[1])*a };
  const curb = HALF + 3.75, gap = P - 2*curb;
  const wait = { x: dx ? p.cx + dx*curb : corner.x, z: dz ? p.cz + dz*curb : corner.z };
  const far = { x: wait.x + dx*gap, z: wait.z + dz*gap }, join = { x: corner.x + dx*(P - 2*a), z: corner.z + dz*(P - 2*a) };
  p.cross = { st:"toCurb", wait, far, join, dx, dz, axis: dz ? "walkZ" : "carsX", ncx: nx*P, ncz: nz*P, jit: rand(-0.6, 0.6) };
}
function crossUpdate(p, dt){
  const c = p.cross, sp = p.speed || 1.2, mv = (tx, tz, s) => { const dx = tx - p.x, dz = tz - p.z, d = Math.hypot(dx, dz); if (d < 0.15) return true; const st = Math.min(d, s*dt); p.x += dx/d*st; p.z += dz/d*st; p.heading = angLerp(p.heading, Math.atan2(dx, dz), Math.min(1, dt*6)); return false; };
  const side = { x: c.dz ? c.jit : 0, z: c.dx ? c.jit : 0 };
  if (c.st === "toCurb"){ if (mv(c.wait.x + side.x, c.wait.z + side.z, sp)) c.st = "wait"; p.act = "walk"; return 1; }
  if (c.st === "wait"){ p.heading = angLerp(p.heading, Math.atan2(c.dx, c.dz), Math.min(1, dt*4)); const go = SIG.phase === c.axis && SIG.t < SIG.len[c.axis] - 4; if (!go){ p.act = Math.random() < dt*0.05 ? "phone" : p.act; return 0; } c.st = "go"; p.act = "walk"; return 0; }
  if (c.st === "go"){ const late = SIG.phase !== c.axis || SIG.t > SIG.len[c.axis] - 5; if (mv(c.far.x + side.x, c.far.z + side.z, sp*(late ? 1.7 : 1.08))) c.st = "join"; return 1; }
  if (c.st === "join"){ if (mv(c.join.x, c.join.z, sp)){ p.cx = c.ncx; p.cz = c.ncz; const a = p.a; const lx = Math.sign(p.x - p.cx), lz = Math.sign(p.z - p.cz);
      const s0 = lx < 0 && lz < 0 ? 0 : lx > 0 && lz < 0 ? 2*a : lx > 0 && lz > 0 ? 4*a : 6*a; p.s = s0 + p.dir*0.05; p.cross = null; p.lastCorner = Math.round(p.s/(2*a)); } return 1; }
  return 0;
}
function buildSignals(){
  const mk = (c) => new THREE.MeshStandardMaterial({ color:lin("#111"), emissive:lin(c), emissiveIntensity:0 });
  SIG.mats = { walk:mk("#f2f6ff"), hand:mk("#ff7a1c"), red:mk("#ff2a1a"), amber:mk("#ffb21c"), green:mk("#2aff8a") };
  const head = new THREE.BoxGeometry(0.34, 0.34, 0.18), lamp = new THREE.PlaneGeometry(0.22, 0.22), pole = new THREE.CylinderGeometry(0.05, 0.05, 3.3, 8), dark = new THREE.MeshStandardMaterial({ color:lin("#2a2c2e"), roughness:0.6, metalness:0.5 });
  const g = new THREE.Group();
  for (let i=-NB;i<NB;i++) for (let j=-NB;j<NB;j++){ const xs = (i+0.5)*P, zs = (j+0.5)*P; if (Math.abs(xs - CABLE_X) < 1) {}
    for (const [sx, sz] of [[-1,-1],[1,-1],[1,1],[-1,1]]){ const x = xs + sx*(5 + 1.2), z = zs + sz*(5 + 1.2), y = groundY(x, z);
      const pl = new THREE.Mesh(pole, dark); pl.position.set(x, y + 1.65, z); g.add(pl);
      for (const [fx, fz, axis] of [[-sx, 0, "carsX"], [0, -sz, "walkZ"]]){ const hb = new THREE.Mesh(head, dark), ry = Math.atan2(fx, fz); hb.position.set(x, y + 2.9, z); hb.rotation.y = ry; g.add(hb);
        for (const [m, dy] of [["walk", 0.09], ["hand", -0.09]]){ const l = new THREE.Mesh(lamp, SIG.mats[m]); l.userData.axis = axis; l.userData.kind = m; l.scale.setScalar(0.6); l.position.set(x + fx*0.1, y + 2.9 + dy, z + fz*0.1); l.rotation.y = ry; g.add(l); SIG.heads.push(l); } }
      if ((sx + sz) === 0){ const th = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.9, 0.25), dark); th.position.set(x, y + 3.6, z); g.add(th); for (const [m, dy] of [["red",0.28],["amber",0],["green",-0.28]]){ const l = new THREE.Mesh(new THREE.CircleGeometry(0.1, 14), SIG.mats[m]); l.position.set(x - sx*0.14, y + 3.6 + dy, z); l.rotation.y = Math.atan2(-sx, 0); g.add(l); } } } }
  World.scene.add(g);
}
function updateSignals(dt){
  SIG.t += dt; if (SIG.t > SIG.len[SIG.phase]){ SIG.t = 0; SIG.phase = SIG.phase === "carsX" ? "walkZ" : "carsX"; if (SIG.phase === "walkZ") SND.play("chirp", Player.x, Player.z, 0.15); }
  if (!SIG.mats) return; const blink = Math.floor(SIG.t*2) % 2, left = SIG.len[SIG.phase] - SIG.t;
  // two phases share the same lamps: the walk man for whoever may cross now, a flashing then solid hand otherwise
  SIG.mats.walk.emissiveIntensity = 3; SIG.mats.hand.emissiveIntensity = 3;
  for (const l of SIG.heads){ const on = SIG.phase === l.userData.axis && left > 4; l.visible = l.userData.kind === "walk" ? on : (!on && (SIG.phase !== l.userData.axis || blink)); }
  const carsGo = SIG.phase === "carsX"; SIG.mats.green.emissiveIntensity = carsGo && left > 3 ? 4 : 0; SIG.mats.amber.emissiveIntensity = carsGo && left <= 3 ? 4 : 0; SIG.mats.red.emissiveIntensity = carsGo ? 0 : 4;
}

/* ---------- 4. daily rhythm ---------- */
const RHYTHM = { name:"", t:0 };
function rhythmNow(){ const h = S.clock ?? 12, day = (S.day || 0) % 7, weekend = day >= 5;
  if (h >= 7 && h < 9.5) return weekend ? { n:"a slow weekend morning", dens:0.45, speed:0.9, traffic:0.5 } : { n:"the morning rush", dens:1, speed:1.3, traffic:1, cups:true };
  if (h >= 11.8 && h < 13.6) return { n:"the lunch crowd", dens:1, speed:0.95, traffic:0.8, linger:true };
  if (h >= 15 && h < 16.3) return { n:"school's out", dens:0.9, speed:1.15, traffic:0.7, young:true };
  if (h >= 17 && h < 19) return { n:"the evening commute", dens:1, speed:1.2, traffic:1 };
  if (h >= 22 || h < 1.5) return { n:"bar hours", dens:0.5, speed:0.85, traffic:0.45, tipsy:0.18 };
  if (h >= 1.5 && h < 5.5) return { n:"the dead of night", dens:0.15, speed:0.8, traffic:0.2, tipsy:0.3 };
  return { n:"an ordinary afternoon", dens:0.8, speed:1, traffic:0.75 }; }
(function(){ const base = densityHide; densityHide = function(p, i){ if (base(p, i)) return true; if (p.pool || p.stationary || p.performer || p.cross) return false; const r = RHYTHM.cur; return r && ((i*7919 + 13) % 100)/100 > r.dens; }; })();
function updateRhythm(dt){
  const r = rhythmNow(); RHYTHM.cur = r; if (r.n !== RHYTHM.name){ const first = !RHYTHM.name; RHYTHM.name = r.n; if (!first) toast(`It's ${r.n}.`, 2200); }
  for (const p of Life.people){ if (p.stationary || p.pool) continue; if (p.baseSpeed === undefined) p.baseSpeed = p.speed; p.speed = p.baseSpeed*r.speed; p.tipsy = r.tipsy ? ((Life.people.indexOf(p)*37) % 100)/100 < r.tipsy : false; }
  const c0 = RHYTHM.lastClock ?? S.clock; if (S.clock < c0 - 12) S.day = (S.day || 0) + 1; RHYTHM.lastClock = S.clock;
}
(function(){ const base = posePerson; posePerson = function(p, i, moving, dist, pl, aware, t){ if (p.tipsy && moving){ p.heading += Math.sin(t*1.3 + i)*0.02; } return base(p, i, moving, dist, pl, aware, t); }; })();

/* ---------- 5. wind: gusts, swaying trees, drifting smoke and rain, flags, blown litter, hats and umbrellas ---------- */
const FLAGS = []; const LITTER = { mesh:null, list:[] };
function buildWindThings(){
  const fm = World.mats && World.mats.foliage;
  if (fm){ fm.onBeforeCompile = sh => { sh.uniforms.uWindT = { value:0 }; sh.uniforms.uWindA = { value:0.05 }; fm.userData.sh = sh;
      sh.vertexShader = sh.vertexShader.replace("#include <common>", "#include <common>\nuniform float uWindT; uniform float uWindA;").replace("#include <begin_vertex>", "#include <begin_vertex>\nvec3 wp = (modelMatrix*vec4(transformed,1.0)).xyz; transformed.x += sin(uWindT*1.7 + wp.x*0.35 + wp.z*0.2)*uWindA + sin(uWindT*4.3 + wp.y*2.0)*uWindA*0.25; transformed.z += cos(uWindT*1.3 + wp.z*0.3)*uWindA*0.6;"); }; fm.needsUpdate = true; }
  const designs = [["#e40303","#ff8c00","#ffed00","#008026","#004dff","#750787"], ["#b22234","#f2efe6","#b22234","#f2efe6","#3c3b6e"], ["#1e3a8a","#e8b82e"], ["#26231f","#f2efe6","#26231f"], ["#c0362c","#f2efe6"]];
  const roofs = (World.roofs||[]).filter((r, k) => k % 9 === 0).slice(0, 28);
  for (const rf of roofs){ const d = designs[(Math.random()*designs.length)|0], c = document.createElement("canvas"); c.width = 96; c.height = 64; const x = c.getContext("2d"); d.forEach((col, k) => { x.fillStyle = col; x.fillRect(0, k*64/d.length, 96, 64/d.length + 1); });
    const geo = new THREE.PlaneGeometry(1.4, 0.9, 12, 4).translate(0.7, 0, 0), mat = new THREE.MeshStandardMaterial({ map:new THREE.CanvasTexture(c), side:THREE.DoubleSide, roughness:0.9 });
    mat.onBeforeCompile = sh => { sh.uniforms.uT = { value:0 }; sh.uniforms.uA = { value:0.2 }; mat.userData.sh = sh; sh.vertexShader = sh.vertexShader.replace("#include <common>", "#include <common>\nuniform float uT; uniform float uA;").replace("#include <begin_vertex>", "#include <begin_vertex>\ntransformed.z += sin(uT*6.0 - position.x*4.0)*uA*(position.x/1.4) + sin(uT*9.0 - position.x*7.0)*uA*0.3*(position.x/1.4);"); };
    const flag = new THREE.Mesh(geo, mat), g = new THREE.Group(); const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 1.8, 6), new THREE.MeshStandardMaterial({ color:0xdddddd, metalness:0.8, roughness:0.3 })); pole.rotation.z = Math.PI/2 - 0.6; pole.position.x = 0.7; g.add(pole); flag.position.set(1.1, 0.6, 0); g.add(flag);
    const y = groundY(rf.fx, rf.fz) + 6.2; g.position.set(rf.fx + rf.n[0]*0.1, y, rf.fz + rf.n[1]*0.1); g.rotation.y = Math.atan2(rf.n[0], rf.n[1]) - Math.PI/2; World.scene.add(g); FLAGS.push({ g, mat, flag }); }
  const lg = new THREE.PlaneGeometry(0.28, 0.2); LITTER.mesh = new THREE.InstancedMesh(lg, new THREE.MeshStandardMaterial({ color:0xffffff, side:THREE.DoubleSide, roughness:0.9 }), 24); LITTER.mesh.frustumCulled = false; World.scene.add(LITTER.mesh);
  const cols = ["#f2efe6","#e9d9b0","#c0362c","#2f7fc1","#dfe3e6","#e8b82e"]; for (let k=0;k<24;k++){ LITTER.list.push({ x:Player.x + rand(-30,30), z:Player.z + rand(-30,30), y:0, vx:0, vz:0, vy:0, rot:0, spin:rand(-4,4) }); LITTER.mesh.setColorAt(k, lin(cols[k % cols.length])); }
  LITTER.mesh.instanceColor.needsUpdate = true;
}
const HAT_FLIGHT = { fly:null };
function updateWind(dt){
  WIND.t += dt; const storm = (S.rain ? 1.6 : 1) * (S.fog ? 1.3 : 1) * (({ calm:0.4, breezy:1, gale:2.2 })[S.custom.windStrength] ?? 1);
  if (Math.random() < dt*0.08) WIND.gust = rand(0.8, 2.2)*storm; WIND.gust = Math.max(0, WIND.gust - dt*0.35); WIND.dir += Math.sin(WIND.t*0.03)*dt*0.02;
  const sp = (WIND.base + WIND.gust)*storm; WIND.x = Math.cos(WIND.dir)*sp; WIND.z = Math.sin(WIND.dir)*sp;
  const fm = World.mats && World.mats.foliage; if (fm && fm.userData.sh){ fm.userData.sh.uniforms.uWindT.value = WIND.t; fm.userData.sh.uniforms.uWindA.value = 0.02 + sp*0.035; }
  for (const f of FLAGS){ if (f.mat.userData.sh){ f.mat.userData.sh.uniforms.uT.value = WIND.t*(0.6 + sp*0.4); f.mat.userData.sh.uniforms.uA.value = 0.06 + sp*0.08; } }
  if (Rain.mesh) Rain.mesh.material.uniforms.uWind.value.set(WIND.x*0.8, WIND.z*0.8);
  if (typeof Audio.setAmb === "function") Audio.setAmb(0.1 + sp*0.08);
  if (LITTER.mesh){ const m = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler();
    LITTER.list.forEach((l, k) => { const gY = groundY(l.x, l.z); if (Math.hypot(l.x - Player.x, l.z - Player.z) > 40){ l.x = Player.x + rand(-30,30); l.z = Player.z + rand(-30,30); l.y = groundY(l.x, l.z); }
      const lift = WIND.gust > 1 ? (WIND.gust - 1)*0.8 : 0; l.vx += (WIND.x*1.6 - l.vx)*dt*0.8; l.vz += (WIND.z*1.6 - l.vz)*dt*0.8; l.vy += (lift*4 - 9.8)*dt; l.y = Math.max(gY + 0.01, l.y + l.vy*dt); if (l.y <= gY + 0.011) l.vy = 0; l.x += l.vx*dt*(l.y > gY + 0.05 ? 1 : 0.35); l.z += l.vz*dt*(l.y > gY + 0.05 ? 1 : 0.35); l.rot += l.spin*dt*(0.3 + sp*0.4);
      e.set(l.y > gY + 0.05 ? l.rot : -Math.PI/2, l.rot*0.7, l.y > gY + 0.05 ? l.rot*0.5 : 0); q.setFromEuler(e); m.compose(new THREE.Vector3(l.x, l.y, l.z), q, new THREE.Vector3(1,1,1)); LITTER.mesh.setMatrixAt(k, m); });
    LITTER.mesh.instanceMatrix.needsUpdate = true; }
  // a strong gust steals someone's hat; they chase it
  if (WIND.gust > 1.6 && !HAT_FLIGHT.fly && Math.random() < dt*0.5){ const v = Life.people.find(p => !p.hidden && !p.pool && !p.stationary && p.look.hat && !p.hatGone && Math.hypot(p.x - Player.x, p.z - Player.z) < 30);
    if (v){ v.hatGone = true; const hm = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.13, 0.12, 12), new THREE.MeshStandardMaterial({ color:lin(v.look.hatColor || "#26231f") })); const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.015, 16), hm.material); brim.position.y = -0.05; hm.add(brim);
      hm.position.set(v.x, v.y + v.look.h + 0.05, v.z); World.scene.add(hm); HAT_FLIGHT.fly = { m:hm, v, vx:WIND.x*2.2, vz:WIND.z*2.2, vy:2.2, t:0 }; v.pause = 6; toast("", 1); } }
  if (HAT_FLIGHT.fly){ const h = HAT_FLIGHT.fly, gY = groundY(h.m.position.x, h.m.position.z); h.t += dt; h.vy -= 6*dt; h.m.position.x += h.vx*dt; h.m.position.z += h.vz*dt; h.m.position.y = Math.max(gY + 0.07, h.m.position.y + h.vy*dt); h.m.rotation.x += dt*6; h.m.rotation.z += dt*4; if (h.m.position.y <= gY + 0.071){ h.vx *= 0.9; h.vz *= 0.9; }
    const v = h.v; if (h.t > 0.6){ v.pause = 1; v.evPose = "run"; const dx = h.m.position.x - v.x, dz = h.m.position.z - v.z, d = Math.hypot(dx, dz); v.heading = Math.atan2(dx, dz); if (d > 0.6){ v.x += dx/d*Math.min(d, 3.8*dt); v.z += dz/d*Math.min(d, 3.8*dt); v.evMoving = true; v.evSpeed = 3.8; } else { World.scene.remove(h.m); v.hatGone = false; v.evPose = null; v.evMoving = false; v.noCross = false; HAT_FLIGHT.fly = null; } } }
  // umbrellas turn inside out in the rain gusts
  if (S.rain && WIND.gust > 1.8){ for (const p of Life.people){ if (p.umbrella && !p.inverted && Math.random() < dt*0.3 && Math.hypot(p.x - Player.x, p.z - Player.z) < 40){ p.inverted = 3; } } }
  for (const p of Life.people){ if (p.inverted){ p.inverted -= dt; p.evPose = p.inverted > 0 ? "handsup" : null; if (p.inverted <= 0) p.inverted = 0; } }
}
(function(){ const base = spM; spM = function(name, idx, m){ if (name === "canopy"){ const p = Life.people[idx]; if (p && p.inverted > 0){ m = m.clone().multiply(new THREE.Matrix4().makeScale(1, -1.2, 1)); } } if (name.startsWith("t_")){ const p = Life.people[idx]; if (p && p.hatGone) return; } return base(name, idx, m); }; })();

/* ---------- 6. neon and lights: flickering signs, stuttering street lamps, festoon lights ---------- */
const NEON = { signs:[], strings:[] };
function buildNeon(){
  const words = ["OPEN","BAR","HOTEL","LIQUOR","COCKTAILS","PIZZA","TATTOO","DINER","ROOMS","ARCADE","NOODLES","LIVE MUSIC","VACANCY","COFFEE","24 HRS","KARAOKE"], cols = ["#ff3b6b","#39e6ff","#ffd84a","#7cff5a","#ff7a1c","#c77dff"];
  const shops = (World.shops||[]).slice(); for (let k = shops.length - 1; k > 0; k--){ const j = (Math.random()*(k+1))|0; [shops[k], shops[j]] = [shops[j], shops[k]]; }
  for (const sh of shops.slice(0, 46)){ const w = words[(Math.random()*words.length)|0], col = cols[(Math.random()*cols.length)|0], c = document.createElement("canvas"); c.width = 256; c.height = 96; const x = c.getContext("2d");
    x.font = `${Math.random() < 0.5 ? "italic " : ""}700 ${w.length > 8 ? 42 : 58}px ${Math.random() < 0.5 ? "Georgia, serif" : "Arial Narrow, sans-serif"}`; x.textAlign = "center"; x.textBaseline = "middle"; x.shadowColor = col; x.shadowBlur = 18; x.fillStyle = col; x.fillText(w, 128, 50); x.shadowBlur = 6; x.fillStyle = "#fff"; x.globalAlpha = 0.7; x.fillText(w, 128, 50);
    const mat = new THREE.MeshBasicMaterial({ map:new THREE.CanvasTexture(c), transparent:true, blending:THREE.AdditiveBlending, depthWrite:false, color:new THREE.Color(1,1,1) });
    const m = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 0.56), mat); const inward = 0.05, sx = rand(-sh.w*0.3, sh.w*0.3);
    m.position.set(sh.x + sh.n[1]*sx + sh.n[0]*inward, sh.gy + rand(2.2, 2.9), sh.z - sh.n[0]*sx + sh.n[1]*inward); m.rotation.y = Math.atan2(sh.n[0], sh.n[1]); World.scene.add(m);
    NEON.signs.push({ m, mat, mode: Math.random() < 0.25 ? "broken" : Math.random() < 0.35 ? "blink" : "steady", ph: Math.random()*10, x:m.position.x, z:m.position.z }); }
  // festoon string lights across some streets
  const bulbs = new THREE.InstancedMesh(new THREE.SphereGeometry(0.06, 6, 5), new THREE.MeshBasicMaterial({ color:0xffd9a0 }), 600); bulbs.frustumCulled = false; let bi = 0;
  const wire = new THREE.MeshBasicMaterial({ color:0x111111 }), m4 = new THREE.Matrix4();
  for (let s=0; s<16 && bi < 580; s++){ const i = ((Math.random()*2*NB)|0) - NB, j = ((Math.random()*2*NB)|0) - NB, alongX = Math.random() < 0.5; const xs = (i + 0.5)*P, zs = (j + 0.5)*P;
    const a = alongX ? { x: i*P + rand(-20,20), z: zs - 7.6 } : { x: xs - 7.6, z: j*P + rand(-20,20) }, b = alongX ? { x: a.x + rand(-4,4), z: zs + 7.6 } : { x: xs + 7.6, z: a.z + rand(-4,4) };
    const ya = groundY(a.x, a.z) + 6.4, yb = groundY(b.x, b.z) + 6.4;
    for (let k=0;k<=30 && bi < 600;k++){ const u = k/30, y = lerp(ya, yb, u) - Math.sin(u*Math.PI)*1.1; m4.makeTranslation(lerp(a.x, b.x, u), y, lerp(a.z, b.z, u)); bulbs.setMatrixAt(bi++, m4); } }
  bulbs.count = bi; World.scene.add(bulbs); NEON.bulbs = bulbs;
}
function updateNeon(dt, t){
  const T = World.timeDef || TIMES[2], night = clamp((T.lamps || 0), 0, 1), blackout = !!World.blackout;
  for (const s of NEON.signs){ let on = night*(blackout ? 0 : 1);
    if (s.mode === "broken"){ const f = Math.sin(t*23 + s.ph)*Math.sin(t*7.1 + s.ph*2); on *= f > 0.35 ? 1 : f > -0.2 ? 0.3 : 0.05; }
    else if (s.mode === "blink"){ on *= Math.floor(t*1.2 + s.ph) % 2 ? 1 : 0.15; }
    s.mat.opacity = 0.05 + on*0.9; s.mat.color.setScalar(0.2 + on*0.7); }
  if (NEON.bulbs){ NEON.bulbs.visible = night > 0.15 && !blackout; NEON.bulbs.material.color.setRGB(1.6*night + 0.2, 1.3*night + 0.18, 0.9*night + 0.12); }
  // a few street lamps stutter
  if (Player.lamps || true){ const L = Game.lampLights || []; L.forEach((l, k) => { if (k % 3 === 1 && l.intensity > 0){ const f = Math.sin(t*17 + k*3.7)*Math.sin(t*5.3 + k); if (f < -0.55) l.intensity *= 0.25; } }); }
  // neon hum when you are close
  NEON.humT = (NEON.humT || 0) - dt; if (NEON.humT <= 0 && night > 0.3){ NEON.humT = 2.5; const n = NEON.signs.find(s => Math.hypot(s.x - Player.x, s.z - Player.z) < 6); if (n) SND.play("hum", n.x, n.z, 0.12); }
}

/* ---------- wiring, sounds, keys, settings ---------- */
(function(){ const base = SND.play; SND.play = function(kind, x, z, vol=1){ if (!this.init()) return; const c = this.ctx, t0 = c.currentTime;
  if (kind === "click"){ const o = this.node(x, z, vol), e = c.createGain(); e.connect(o); this.env(e, t0, 0.3, 0.05); this.noise(e, t0, 0.05, "highpass", 2500, 1); return; }
  if (kind === "motor"){ const o = this.node(x, z, vol), e = c.createGain(); e.connect(o); e.gain.setValueAtTime(0.0001, t0); e.gain.exponentialRampToValueAtTime(0.15, t0 + 0.03); e.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.34); const os = this.osc(e, t0, 0.34, "sawtooth", 220); os.frequency.linearRampToValueAtTime(330, t0 + 0.3); return; }
  return base.call(this, kind, x, z, vol); }; })();
(function(){ const base = onKey; onKey = function(ev){ if (Game.started && !UI.open && !ev.repeat){ if (ev.code === "KeyY"){ windOn(); return; } if (ev.code === "Semicolon"){ cycleFilter(1); return; } } base(ev); }; })();
BINDABLE.push(["KeyY","Wind film on"], ["Semicolon","Cycle filter"]);
Object.assign(V7_DEFAULTS, { filmAdvance:"manual", windStrength:"breezy" });
(function(){ const base = menuSettings; menuSettings = function(){ const c = S.custom, seg = (key, opts) => `<div class="seg" data-seg="${key}">${opts.map(([v,l])=>`<button data-v="${v}" aria-pressed="${c[key]===v}">${l}</button>`).join("")}</div>`;
  return base() + `<div class="sectionhead">Film & weather</div>
    <div class="formrow"><label>Film advance</label>${seg("filmAdvance",[["manual","Wind it myself"],["auto","Always automatic"]])}<span class="spec">Manual cameras need Y (or the ⟳ dial button) between frames. Point-and-shoots, the F100, the XPan and the SX-70 have motors. Holga, Diana and the disposable will happily double-expose if you forget.</span></div>
    <div class="formrow"><label>Wind</label>${seg("windStrength",[["calm","Calm"],["breezy","Breezy"],["gale","Gale"]])}</div>`; }; })();
(function(){ const base = buildQuickDial; buildQuickDial = function(){ base(); const d = $("#quickDial"); if (!d || d.querySelector('[data-q="wind"]')) return;
  const w = document.createElement("button"); w.dataset.q = "wind"; w.className = "qd-mode"; w.title = "Wind on"; w.textContent = "⟳"; d.appendChild(w);
  const f = document.createElement("button"); f.dataset.q = "filter"; f.className = "qd-mode"; f.title = "Filter"; f.textContent = "FLT"; d.appendChild(f);
  d.addEventListener("click", ev => { const b = ev.target.closest("[data-q]"); if (!b) return; if (b.dataset.q === "wind"){ ev.stopPropagation(); windOn(); } if (b.dataset.q === "filter"){ ev.stopPropagation(); cycleFilter(1); } }, true); }; })();
(function(){ const base = updateQuickDial; updateQuickDial = function(){ base(); const d = $("#quickDial"); if (!d) return; const w = d.querySelector('[data-q="wind"]'), f = d.querySelector('[data-q="filter"]');
  if (w){ const auto = advanceMode() === "motor", ok = auto || isCocked(); w.style.display = auto ? "none" : ""; w.classList.toggle("on", !ok); w.textContent = ok ? "⟳" : "WIND"; }
  if (f){ const F = LENS_FILTERS[S.filter||"none"]; f.textContent = S.filter && S.filter !== "none" ? F.n.split(" ")[0].toUpperCase().slice(0, 6) : "FLT"; f.classList.toggle("on", !!(S.filter && S.filter !== "none")); } }; })();
(function(){ const base = updateHUD; updateHUD = function(dt){ base(dt); if (Player.raise > 0.3 && !isCocked() && advanceMode() === "manual" && !GP.winding){ const vr = $("#vfright"); if (vr && !vr.querySelector(".windme")) vr.insertAdjacentHTML("afterbegin", `<div class="windme" style="color:var(--amber);font-weight:700;letter-spacing:.14em">WIND ON ⟳</div>`); } }; })();
(function(){ const base = gameplayUpdate; gameplayUpdate = function(dt){ base(dt); if (!Game.started) return; updateSignals(dt); updateRhythm(dt); updateWind(dt); updateNeon(dt, WIND.t);
  const r = RHYTHM.cur; if (r){ const k = r.traffic; for (const c of Life.cars){ if (!c.bus && ((((c.x*7 + c.z*3)|0) % 100 + 100) % 100)/100 > k) c.g.visible = false; } } }; })();
(function(){ const base = boot; boot = async function(){ await base(); S.owned.filters = S.owned.filters || (S.free ? Object.keys(LENS_FILTERS) : []); S.cocked = S.cocked || {}; buildSignals(); buildWindThings(); buildNeon(); applyPolarizer(); }; })();
(function(){ const base = judgePhoto; judgePhoto = function(rec){ const res = base(rec); const m = rec.meta || {}; if (res && res.critique && m.filter && m.filter !== "none"){ const F = LENS_FILTERS[m.filter]; if (F && m.mono && (m.filter === "red" || m.filter === "orange")) res.critique[0] = res.critique[0] + ` The ${F.n} turned the sky to slate.`; if (m.filter === "polar" && m.glass) res.critique[0] += " The polarizer cut straight through the glare."; } if (m.accidental && res && res.critique) res.critique[0] += " An accidental double exposure: happy or not, it's unrepeatable."; return res; }; })();
(function(){ const base = analyzeFrame; analyzeFrame = function(...a){ const m = base(...a); m.filter = S.filter || "none"; return m; }; })();
