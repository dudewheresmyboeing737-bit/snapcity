
/* =========================================================
   Capture: multi-subframe render, flash, shake, noise,
   subject analysis, JPEG + storage
   ========================================================= */
// Per-time normalization so a "correct" exposure lands on a sensible mid-tone (calibrated from test renders)
const TIME_NORM = { morning:1, noon:1, golden:1.35, blue:1.7, night:1.8 };
const FOG_NORM = 1;
const RAIN_NORM = 1.1;
function expoScale(mult){ return BASE_EXP * (World.timeNorm || TIME_NORM[S.time] || 1) * (S.fog? FOG_NORM : 1) * (S.rain? RAIN_NORM : 1) * mult; }

const CAP = { W:1500, H:1000, SS:1.5, rtHi:null, rtOut:null, rtDepth:null, busy:false, flash:null, lastId:null, key:"" };
function capTargets(){
  const asp = fmtAspect(), fine=S.custom.captureQuality==="detail", edge=fine?1500:1080;
  if (asp >= 1){ CAP.W = asp > 2 ? Math.round(edge*1.2) : edge; CAP.H = Math.round(CAP.W/asp); } else { CAP.H = edge; CAP.W = Math.round(edge*asp); }
  const key = CAP.W+"x"+CAP.H+"@"+CAP.SS;
  if (CAP.key !== key){
    if (CAP.rtHi) for (const k of ["rtHi","rtAcc","rtFinal","rtB1","rtB2"]) CAP[k].dispose();
    CAP.rtHi = makeRT(Math.round(CAP.W*CAP.SS), Math.round(CAP.H*CAP.SS));
    const ft = G.halfFloat ? THREE.HalfFloatType : THREE.UnsignedByteType, lin_ = { minFilter:THREE.LinearFilter, magFilter:THREE.LinearFilter, depthBuffer:false };
    CAP.rtAcc = new THREE.WebGLRenderTarget(CAP.W, CAP.H, Object.assign({ type:ft }, lin_));
    CAP.rtFinal = new THREE.WebGLRenderTarget(CAP.W, CAP.H, Object.assign({ type:THREE.UnsignedByteType }, lin_));
    CAP.rtB1 = new THREE.WebGLRenderTarget(Math.ceil(CAP.W/8), Math.ceil(CAP.H/8), Object.assign({ type:ft }, lin_));
    CAP.rtB2 = CAP.rtB1.clone();
    CAP.px = new Uint8Array(CAP.W*CAP.H*4);
    CAP.key = key;
  }
  if (!CAP.rtDepth) CAP.rtDepth = new THREE.WebGLRenderTarget(300, 200, { type:THREE.UnsignedByteType, depthBuffer:false });
}
const FILM_LOOKS = {
  gold200:{ sh:[0,-0.005,-0.02], hi:[0.03,0.02,-0.03], toe:0.02, sho:0.15 }, ultramax:{ sh:[-0.01,0,0.012], hi:[0.03,0.015,-0.02], toe:0.01, sho:0.1 },
  colorplus:{ sh:[0.02,0.01,-0.02], hi:[0.03,0.02,-0.02], toe:0.045, sho:0.22, gch:1.4 }, portra160:{ sh:[0,-0.005,0.006], hi:[0.02,0.01,-0.01], toe:0.02, sho:0.32, gch:0.6 },
  portra400:{ sh:[0.006,0,0], hi:[0.025,0.012,-0.015], toe:0.03, sho:0.36, gch:0.7 }, portra800:{ sh:[0.012,0,-0.012], hi:[0.03,0.015,-0.02], toe:0.035, sho:0.3 },
  ektar:{ sh:[-0.012,-0.01,0.022], hi:[0.03,0,-0.02], toe:-0.005, sho:0.05, gch:0.5 }, superia:{ sh:[-0.02,0.022,0.02], hi:[0,0.02,0], toe:0.012, sho:0.1, gch:1.2 },
  c200:{ sh:[-0.015,0.016,0.01], hi:[0.01,0.02,-0.01], toe:0.02, sho:0.12 }, lomo800:{ sh:[0.022,-0.02,0.045], hi:[0.035,0,0.02], toe:0.02, sho:0.08, gch:1.6 },
  cine800:{ sh:[-0.035,0.012,0.045], hi:[0.035,0.012,-0.03], toe:0.02, sho:0.2 }, cine50:{ sh:[-0.012,0,0.02], hi:[0.02,0.01,0], toe:0.01, sho:0.18 },
  aero:{ sh:[0.02,-0.02,0.03], hi:[0.03,0,0], toe:0.02, sho:0.1 }, e100:{ sh:[-0.012,0,0.022], hi:[0,0.01,0.02], toe:-0.02, sho:0.04 },
  velvia:{ sh:[0,-0.012,0.035], hi:[0.02,0,0.03], toe:-0.03, sho:0.03 }, provia:{ sh:[0,0,0.012], hi:[0,0,0], toe:-0.015, sho:0.05 },
  trix:{ toe:-0.025, sho:0.1 }, hp5:{ toe:0.03, sho:0.22 }, tmax100:{ toe:0, sho:0.08 }, delta3200:{ toe:0.05, sho:0.15 }, fp4:{ toe:0.01, sho:0.15 },
  panf:{ toe:-0.04, sho:0.05 }, xp2:{ toe:0.045, sho:0.4 }, foma:{ toe:0.06, sho:0.22 },
  sx70:{ sh:[0.022,0,0.045], hi:[0.045,0.03,-0.01], toe:0.08, sho:0.3, gch:0.6 }, sx70bw:{ toe:0.065, sho:0.3 },
};
/* ---------- GPU film pipeline: bright pass, blur, halation, grain, leaks ---------- */
const FILM = {};
function filmMats(){
  if (FILM.film) return;
  const VS = POST_VS;
  FILM.bright = new THREE.ShaderMaterial({ vertexShader:VS, depthTest:false, depthWrite:false, uniforms:{ t:{value:null}, texel:{value:new THREE.Vector2()} },
    fragmentShader:`uniform sampler2D t; uniform vec2 texel; varying vec2 vUv;
      float L(vec2 o){ vec3 c = texture2D(t, vUv + o*texel).rgb; return dot(c, vec3(0.3,0.59,0.11)); }
      void main(){ float m = max(max(L(vec2(-2.,-2.)), L(vec2(2.,-2.))), max(max(L(vec2(-2.,2.)), L(vec2(2.,2.))), L(vec2(0.)))); gl_FragColor = vec4(vec3(max(0.0, m-0.72)*7.0), 1.0); }` });
  FILM.blur = new THREE.ShaderMaterial({ vertexShader:VS, depthTest:false, depthWrite:false, uniforms:{ t:{value:null}, dir:{value:new THREE.Vector2()} },
    fragmentShader:`uniform sampler2D t; uniform vec2 dir; varying vec2 vUv;
      void main(){ vec3 c = texture2D(t,vUv).rgb*0.2270; c += (texture2D(t,vUv+dir*1.3846).rgb + texture2D(t,vUv-dir*1.3846).rgb)*0.3162; c += (texture2D(t,vUv+dir*3.2308).rgb + texture2D(t,vUv-dir*3.2308).rgb)*0.0703; gl_FragColor = vec4(c,1.0); }` });
  FILM.film = new THREE.ShaderMaterial({ vertexShader:VS, depthTest:false, depthWrite:false,
    uniforms:{ uFilt:{value:new THREE.Vector3(1,1,1)}, uPol:{value:0}, uStar:{value:0}, uSoft:{value:0}, uSh:{value:new THREE.Vector3()}, uHi:{value:new THREE.Vector3()}, uToe:{value:0}, uSho:{value:0}, uGch:{value:1}, uCA:{value:0}, uDist:{value:0}, uSwirl:{value:0}, uEdge:{value:0}, glass:{value:0}, tPrev:{value:null}, uMulti:{value:0}, tAcc:{value:null}, tBloom:{value:null}, hc:{value:new THREE.Vector3()}, mono:{value:0}, ir:{value:0}, leak:{value:new THREE.Vector4()}, grain:{value:0}, gs:{value:1}, seed:{value:0}, res:{value:new THREE.Vector2()} },
    fragmentShader:`uniform sampler2D tAcc; uniform sampler2D tBloom; uniform vec3 hc; uniform float mono; uniform float ir; uniform vec4 leak; uniform float grain; uniform float gs; uniform float seed; uniform vec2 res; uniform float glass; uniform sampler2D tPrev; uniform float uMulti; uniform vec3 uSh; uniform vec3 uHi; uniform float uToe; uniform float uSho; uniform float uGch; uniform float uCA; uniform float uDist; uniform float uSwirl; uniform float uEdge; uniform vec3 uFilt; uniform float uPol; uniform float uStar; uniform float uSoft; varying vec2 vUv;
      float h(vec2 p){ return fract(sin(dot(p, vec2(12.9898,78.233)) + seed)*43758.5453); }
      float g4(vec2 p){ return (h(p) + h(p+17.3) + h(p+41.7) + h(p+73.1) - 2.0)*1.2247; }
      void main(){
        vec2 q = vUv - 0.5; float r2 = dot(q, q);
        vec2 uv = 0.5 + q*(1.0 + uDist*r2*1.6);                       // lens distortion
        if (uSwirl > 0.0){ float a = uSwirl*r2*1.8; uv = 0.5 + mat2(cos(a), -sin(a), sin(a), cos(a))*(uv - 0.5); }
        vec2 ca = (uv - 0.5)*uCA*r2*4.0;                                // lateral chromatic aberration
        vec3 c = vec3(texture2D(tAcc, uv + ca).r, texture2D(tAcc, uv).g, texture2D(tAcc, uv - ca).b);
        if (uEdge > 0.0){ vec2 tg = vec2(-q.y, q.x)*uEdge*r2*0.02 + q*uEdge*r2*0.012; c = (c*2.0 + texture2D(tAcc, uv + tg).rgb + texture2D(tAcc, uv - tg).rgb)/4.0; }
        float b = texture2D(tBloom, vUv).r;
        c += (mono > 0.5 ? vec3((hc.x+hc.y+hc.z)/3.0) : hc)*b;
        if (uStar > 0.0){ float st = 0.0; for (int k = 1; k < 7; k++){ float d = float(k)*0.012; st += (texture2D(tBloom, vUv + vec2(d, d)).r + texture2D(tBloom, vUv - vec2(d, d)).r + texture2D(tBloom, vUv + vec2(d, -d)).r + texture2D(tBloom, vUv - vec2(d, -d)).r)*(1.0 - float(k)/7.0); } c += vec3(st*0.18*uStar); }
        if (uSoft > 0.0){ c = mix(c, c + b*0.5 + vec3(0.03), uSoft*0.6); }
        c *= uFilt;
        if (uPol > 0.0){ float lp = dot(c, vec3(0.3,0.59,0.11)); c = mix(vec3(lp), c, 1.0 + 0.22*uPol); c.b -= 0.04*uPol*smoothstep(0.4, 0.9, c.b - c.r + 0.5); }
        if (ir > 0.5){ if (c.g > c.r*1.03 && c.g > c.b*0.95){ float k = clamp((c.g - max(c.r, c.b*0.9))*6.0, 0.0, 1.0); c = mix(c, vec3(min(1.0, c.g*1.35+0.08), c.r*0.55, c.b*0.9+c.g*0.25), k); } else if (c.b > c.r && c.b > c.g){ c.b *= 1.05; c.g *= 0.95; } }
        if (leak.z > 0.0){ float ex = leak.x > 0.5 ? 1.0 - vUv.x : vUv.x; float ey = abs((1.0 - vUv.y) - leak.y); float f = exp(-ex/leak.w)*exp(-ey*ey*3.0)*leak.z; c += vec3(f, f*0.42, f*0.08); }
        if (uMulti > 0.5){ vec3 pv = texture2D(tPrev, vUv).rgb; c = 1.0 - (1.0 - c*0.85)*(1.0 - pv*0.85); }
        if (glass > 0.0){ float band = smoothstep(0.0, 0.08, abs(fract(vUv.x*0.6 + vUv.y*0.35 + seed*0.01) - 0.5) - 0.3); c = c*0.9 + vec3(0.05,0.055,0.06)*(0.4 + 0.6*vUv.y) + vec3(0.09)*(1.0 - band)*0.6; c = mix(c, c*vec3(0.95,1.0,0.98), 0.5); }
        { float l = clamp(dot(c, vec3(0.3,0.59,0.11)), 0.0, 1.0);             // the stock's own curve and colour
          c += uSh*(1.0 - l)*(1.0 - l)*3.0 + uHi*l*l*3.0;
          c += uToe*(1.0 - l)*(1.0 - l);
          c = c*(1.0 + uSho)/(1.0 + uSho*max(c, vec3(0.0))); }
        if (grain > 0.0){ vec2 cell = floor(vUv*res/gs); float lum = clamp(dot(c, vec3(0.3,0.59,0.11)), 0.0, 1.0); float amp = grain*(0.45 + sin(lum*3.14159)*0.9);
          float n = g4(cell)*amp; if (mono > 0.5) c += n; else c += vec3(n + g4(cell+5.1)*amp*0.25*uGch, n, n + g4(cell+9.7)*amp*0.3*uGch); }
        if (mono > 0.5) c = vec3(dot(c, vec3(0.3, 0.59, 0.11)));   // black and white stays black and white
        gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0); }` });
}
function quadPass(mat, target){ G.quad.material = mat; G.renderer.setRenderTarget(target); G.renderer.render(G.postScene, G.postCam); }
// how a given film renders an exposure error: negatives swallow overexposure, slides don't
function filmOffset(off, film){
  if (film.k === "slide" || film.k === "instant") return off;
  if (off > 0) return off * (film.k === "bw" ? 0.45 : 0.3);
  return off;
}
function initFlashLight(){
  // permanently in scene (intensity 0) so shader programs don't recompile at the moment of capture
  CAP.flash = new THREE.PointLight(0xfff4e8, 0, 0, 2); CAP.flash.castShadow = false; G.scene.add(CAP.flash);
}

function setPostUniforms(cam, exp, opts){
  const u = G.post.uniforms, film = curFilm(), L = curLens() || {};
  u.cNear.value = cam.near; u.cFar.value = cam.far; setShafts(u, cam);
  u.exposure.value = expoScale(Math.pow(2, filmOffset(exp.offset, film))) * (opts.expExtra||1);
  u.dofOn.value = opts.dof ? 1 : 0;
  u.cocK.value = opts.cocK || 0; u.focusD.value = Cam.focus; u.maxR.value = opts.maxR || 14; u.taps.value = opts.taps || 48;
  u.outScale.value = opts.outScale || 1;
  const under = Math.max(0, -exp.offset);
  u.sat.value = isMono(film) ? 0 : (film.sat ?? 1); u.con.value = (film.con ?? 1) + 0.06*(exp.push||0) - (film.k==="neg" ? 0.05*under : 0);
  u.mono.value = isMono(film) ? 1 : 0; u.warm.value = (film.warm||0) + (L.warm||0); u.tint.value = film.tint||0;
  u.fade.value = (film.fade||0) + (film.k==="neg" ? 0.025*under : 0);
  u.soft.value = opts.dof ? (1 - (L.sh ?? 0.9))*4.5*(CAP.W/1500) : 0;
  u.vig.value = opts.vig !== undefined ? opts.vig : clamp((L.vig ?? 0.2)*clamp(1.5*(L.a||2.8)/exp.N, 0.35, 1.25) + 0.04, 0.03, 1.1);
}

function shutterLoudness(){ return ({ mech:1, leaf:0.45, digital:0.6, silent:0 })[S.custom.sound] ?? 1; }

async function captureShot(){
  /* v14.6: do not pause the whole world while the shutter is processing */
  if (CAP.busy) return null;
  const b = curBody(), roll = curRoll(), film = curFilm();
  if (!curLens()){ toast("There's no lens on this camera. Mount one from the camera bag."); return; }
  if (roll.left <= 0){ toast(b.film ? `This one's finished. Press L for a new ${b.n} ($${b.p}).` : `Out of film. Press L to load ${film.n} ($${reloadCost()}).`, 2600); return; }
  if (Player.lensSwap > 0){ toast("Still changing lenses"); return; }
  if (GP.loadT > 0){ toast("Still loading the film…", 900); return; }
  CAP.busy = true; capTargets();
  const exp = computeExposure();
  const hip = Player.raise < 0.5;
  const r = G.renderer;
  Audio.shutter(b.snd, exp.t);

  // ---- capture camera ----
  const cam = new THREE.PerspectiveCamera(vfovLens()*180/Math.PI, CAP.W/CAP.H, 0.1, 2200);
  G.cam.updateMatrixWorld(true);
  const basePos = new THREE.Vector3(), baseQ = new THREE.Quaternion(), sc_ = new THREE.Vector3();
  G.cam.matrixWorld.decompose(basePos, baseQ, sc_);
  let extraRoll = 0, extraPitch = 0;
  if (hip){ extraRoll = rand(-8,8)*Math.PI/180; extraPitch = rand(-9,-2)*Math.PI/180; }
  const hipQ = new THREE.Quaternion().setFromEuler(new THREE.Euler(extraPitch, rand(-0.05,0.05)*(hip?1:0), extraRoll, "YXZ"));
  baseQ.multiply(hipQ);

  // shake: angular rate (rad/s)
  let omega = 0.035 * Math.pow(0.7, sk("steady")) * (0.75 + (b.wt||0.5)*0.4) * (b.snd==="mech" && (b.t==="SLR"||b.t==="Medium format") ? 1.25 : 1);
  omega *= (1 - 0.3*famOf()) * (Player.speed < 0.1 ? 1 - 0.15*sk("patience") : 1);
  if (Player.breathing) omega *= 0.5;
  if (hip) omega *= 1.6;
  omega *= 1 + Player.speed*0.9;
  const shakeDir = rand(0, Math.PI*2);
  const shakeAng = omega * exp.t; // total sweep during exposure (rad)
  const walkV = new THREE.Vector3(Player.vx||0, (typeof PLAYX !== "undefined" && PLAYX.air) ? PLAYX.vy : 0, Player.vz||0);

  /* v14.6: shutter speed should affect the photo, not hitch gameplay; keep sampling lightweight */
  const N = clamp(Math.round(exp.t*12), 1, S.custom.captureQuality==="detail"?3:2);
  filmMats(); const rainLen = Rain.len; Rain.len = clamp(9*exp.t, 0.03, 1.4); if (Rain.mesh) Rain.mesh.material.uniforms.uLen.value = Rain.len;
  const px = CAP.px, autoClear = r.autoClear; r.autoClear = false;
  const flashFrame = exp.flashOn ? N-1 : -1; // rear-curtain-ish
  const fl = curFlash();
  if (heldCam) heldCam.visible = false;
  const W = CAP.W;
  const cockK = cocK(Cam.focus, exp.N, W);
  let depthPx = null, subjects = null, firstCam = null;

  if (exp.flashOn){ $("#flashfx").style.transition = "none"; $("#flashfx").style.opacity = 0.85; requestAnimationFrame(()=>{ $("#flashfx").style.transition = "opacity .35s"; $("#flashfx").style.opacity = 0; }); }
  const sfx = $("#shutterfx"); sfx.style.transition = "none"; sfx.style.opacity = 0.24;

  for (let k=0;k<N;k++){
    /* v14.6: do not advance or freeze the simulated street during a long exposure */
    const f = N>1 ? (k/(N-1) - 0.5) : 0;
    const q = baseQ.clone().multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(Math.sin(shakeDir)*shakeAng*f, Math.cos(shakeDir)*shakeAng*f, 0, "YXZ")));
    cam.position.copy(basePos).addScaledVector(walkV, exp.t*f);
    cam.quaternion.copy(q); cam.updateMatrixWorld(true);
    if (k===0){ firstCam = cam.clone(); subjects = lifeSubjects().map(s=>Object.assign({}, s, { ref:undefined, birds:undefined, _ref:s.ref })); }
    // flash
    if (k === flashFrame){
      const X = expoScale(exp.mult);
      const I = 1.571 * fl.gn*fl.gn * (exp.iso/100) / (exp.N*exp.N) / Math.max(X, 1e-4) * N;
      CAP.flash.intensity = I; CAP.flash.position.copy(cam.position).add(new THREE.Vector3(0, fl.soft?0:0.12, 0).applyQuaternion(q));
      CAP.flash.color.set(fl.soft ? 0xfffaf2 : 0xfff1dc);
    } else CAP.flash.intensity = 0;
    if (k===0) Refl.render(cam); r.setRenderTarget(CAP.rtHi); r.clear(); r.render(G.scene, cam);
    CAP.flash.intensity = 0;
    G.quad.material = G.post;
    const u = G.post.uniforms; u.tColor.value = CAP.rtHi.texture; u.tDepth.value = CAP.rtHi.depthTexture;
    u.texel.value.set(1/CAP.rtHi.width, 1/CAP.rtHi.height);
    setPostUniforms(cam, exp, { dof:true, cocK:cockK, outScale:CAP.SS, taps: S.custom.captureQuality==="detail"?32:16, maxR:16 });
    G.post.uniforms.accW.value = 1/N; G.post.blending = THREE.AdditiveBlending;
    r.setRenderTarget(CAP.rtAcc); if (k === 0){ r.setClearColor(0x000000, 0); r.clear(true, false, false); } r.render(G.postScene, G.postCam);
    G.post.blending = THREE.NormalBlending; G.post.uniforms.accW.value = 1;
    if (k===0){
      G.quad.material = G.depthMat; const du = G.depthMat.uniforms; du.tDepth.value = CAP.rtHi.depthTexture; du.cNear.value = cam.near; du.cFar.value = cam.far;
      r.setRenderTarget(CAP.rtDepth); r.clear(); r.render(G.postScene, G.postCam);
      const dp = new Uint8Array(300*200*4); r.readRenderTargetPixels(CAP.rtDepth, 0,0,300,200, dp);
      depthPx = new Float32Array(300*200);
      for (let y=0;y<200;y++) for (let x=0;x<300;x++){ const i = ((199-y)*300+x)*4; depthPx[y*300+x] = (dp[i] + dp[i+1]/255)/255*400; }
      G.quad.material = G.post;
    }
  }
  r.setRenderTarget(null);
  if (heldCam) heldCam.visible = true;
  requestAnimationFrame(()=>{ sfx.style.transition = "opacity .08s"; sfx.style.opacity = 0; });

  // ---- film on the GPU: halation/bloom, infrared, light leaks, grain ----
  const cv = document.createElement("canvas"); cv.width = CAP.W; cv.height = CAP.H;
  const ctx = cv.getContext("2d");
  const Wd = CAP.W, Hd = CAP.H, fmt = curFormat(), L = curLens(), mono = isMono(film), under = Math.max(0, -exp.offset);
  const grainAmp = film.grain * 7.5 * Math.sqrt(864/(fmt.w*fmt.h)) * Math.pow(1.45, Math.max(0, exp.push)*(1 - 0.3*sk("night"))) * (1 + (film.k==="neg"||film.k==="bw" ? under*0.45 : 0));
  const gs = film.gs || 1, hal = film.hal || 0, pullK = exp.push < 0 ? 0.8 : 1, glow = (L && L.glow) || 0;
  const leak = (S.custom.lightLeaks !== "off" && ((b.leak && Math.random() < b.leak) || (S.custom.lightLeaks === "always" && b.leak))) ? { side: Math.random()<0.5 ? 0 : 1, y0: Math.random(), amt: rand(0.5,1.1), w: rand(0.12,0.3) } : null;
  FILM.bright.uniforms.t.value = CAP.rtAcc.texture; FILM.bright.uniforms.texel.value.set(1/Wd, 1/Hd); quadPass(FILM.bright, CAP.rtB1);
  for (let it=0; it<2; it++){ const bw_ = CAP.rtB1.width, bh_ = CAP.rtB1.height;
    FILM.blur.uniforms.t.value = CAP.rtB1.texture; FILM.blur.uniforms.dir.value.set((1+it)/bw_, 0); quadPass(FILM.blur, CAP.rtB2);
    FILM.blur.uniforms.t.value = CAP.rtB2.texture; FILM.blur.uniforms.dir.value.set(0, (1+it)/bh_); quadPass(FILM.blur, CAP.rtB1); }
  const fu = FILM.film.uniforms;
  fu.tAcc.value = CAP.rtAcc.texture; fu.tBloom.value = CAP.rtB1.texture;
  fu.hc.value.set((hal*1.0 + glow*0.9), hal*0.28 + glow*0.85, hal*0.12 + glow*0.8).multiplyScalar(0.37*(({ off:0, normal:1, strong:2 })[S.custom.halation] ?? 1));
  { const F = LENS_FILTERS[S.filter || "none"] || LENS_FILTERS.none, mono_ = isMono(film), fc = mono_ ? F.bw : F.col; fu.uFilt.value.set(...(fc || [1,1,1])); fu.uPol.value = F.pol ? 1 : 0; fu.uStar.value = F.star ? 1 : 0; fu.uSoft.value = F.soft ? 1 : 0; }
  fu.glass.value = glassAmount() * ((LENS_FILTERS[S.filter||"none"]||{}).pol ? 0.35 : 1); { const lk = FILM_LOOKS[curRoll().stock] || {}, LL = curLens() || {}; fu.uSh.value.set(...(lk.sh || [0,0,0])); fu.uHi.value.set(...(lk.hi || [0,0,0])); fu.uToe.value = lk.toe || 0; fu.uSho.value = lk.sho || 0.12; fu.uGch.value = lk.gch ?? 1;
    const f_ = lensFocal(); fu.uCA.value = 0.0008 + (1 - (LL.sh ?? 0.9))*0.004 + (LL.f2 ? 0.001 : 0); fu.uDist.value = f_ < 24 ? 0.07 : f_ < 30 ? 0.035 : f_ > 100 ? -0.012 : 0.008; fu.uSwirl.value = LL.swirl ? 0.9 : 0; fu.uEdge.value = (1 - (LL.sh ?? 0.9))*1.4; } fu.mono.value = mono ? 1 : 0; fu.ir.value = film.ir ? 1 : 0; fu.grain.value = grainAmp*pullK/255*(({ off:0, light:0.5, normal:1, heavy:1.8 })[S.custom.grainAmt] ?? 1); fu.gs.value = gs; fu.seed.value = Math.random()*100; fu.res.value.set(Wd, Hd);
  fu.leak.value.set(leak ? leak.side : 0, leak ? leak.y0 : 0, leak ? leak.amt : 0, leak ? leak.w : 1);
  { const mu = (typeof GP !== "undefined" && GP.multi === 2 && CAP.rtPrev && CAP.rtPrev.width === Wd && CAP.rtPrev.height === Hd); fu.uMulti.value = mu ? 1 : 0; fu.tPrev.value = mu ? CAP.rtPrev.texture : null; }
  quadPass(FILM.film, CAP.rtFinal);
  if (typeof GP !== "undefined" && GP.multi === 1){
    if (!CAP.rtPrev || CAP.rtPrev.width !== Wd || CAP.rtPrev.height !== Hd){ if (CAP.rtPrev) CAP.rtPrev.dispose(); CAP.rtPrev = new THREE.WebGLRenderTarget(Wd, Hd, { depthBuffer:false }); }
    if (!FILM.copy) FILM.copy = new THREE.ShaderMaterial({ vertexShader:POST_VS, depthTest:false, depthWrite:false, uniforms:{ t:{value:null} }, fragmentShader:`uniform sampler2D t; varying vec2 vUv; void main(){ gl_FragColor = texture2D(t, vUv); }` });
    FILM.copy.uniforms.t.value = CAP.rtFinal.texture; quadPass(FILM.copy, CAP.rtPrev);
    r.setRenderTarget(null); r.autoClear = autoClear; G.quad.material = G.post; Rain.len = rainLen; GP.multi = 2; CAP.busy = false;
    toast("First exposure is on the film. Recompose and shoot again to lay the second one over it.", 3200); return null;
  }
  r.readRenderTargetPixels(CAP.rtFinal, 0, 0, Wd, Hd, px);
  r.setRenderTarget(null); r.autoClear = autoClear; G.quad.material = G.post; Rain.len = rainLen;
  const img = ctx.createImageData(Wd, Hd), src32 = new Uint32Array(px.buffer), dst32 = new Uint32Array(img.data.buffer);
  for (let y=0;y<Hd;y++) dst32.set(src32.subarray((Hd-1-y)*Wd, (Hd-y)*Wd), y*Wd);
  ctx.putImageData(img, 0, 0);

  // ---- analysis ----
  const meta = analyzeFrame(firstCam, subjects, depthPx, exp, { hip, shakeAng, omega, walk:walkV.length(), noiseSig:grainAmp, grain:grainAmp, leak:!!leak, roll:(Player.roll+extraRoll)*180/Math.PI, yaw:Player.yaw, pitch:Player.pitch+extraPitch });
  // the loud shutter gets noticed
  const loud = ({ mech:1, leaf:0.45, quiet:0.2 })[b.snd] ?? 1;
  if (loud > 0) for (const p of Life.people){ if (p.performer) continue; const d = Math.hypot(p.x-basePos.x, p.z-basePos.z); if (d < 3.2*loud + (exp.flashOn? 6 : 0)) p.aware = Math.max(p.aware||0, 2.5); }

  // ---- encode & store ----
  try{ if (window.SnapCity && SnapCity.finishPhoto) SnapCity.finishPhoto(cv); }catch(e){} // date stamp / border
  const blob = await new Promise(res => cv.toBlob(res, "image/jpeg", 0.9));
  const stats = imageStats(cv);
  meta.stats = stats;
  { const pr = primaryOf(meta.subjects); meta.primaryKey = pr ? pr.key : null; }
  S.frameCount++; roll.left = Math.max(0, roll.left-1); Audio.advance(); famBump();
  const rec = { id: "p"+Date.now().toString(36)+Math.random().toString(36).slice(2,6), ts:Date.now(), frameNo:S.frameCount, orig:blob, edited:null, thumb:makeThumb(cv), editedThumb:null, meta, edit:null, score:null, judged:false };
  await DB.put(rec);
  CAP.lastId = rec.id;
  S.shotLog.push({ id:rec.id, ts:rec.ts, prim: meta.primaryKey || null, yaw: Player.yaw }); if (S.shotLog.length > 60) S.shotLog.shift();
  saveState();
  CAP.busy = false; if (typeof GP !== "undefined" && GP.multi === 2){ GP.multi = 0; if (rec && rec.meta) rec.meta.multi = true; }
  if (roll.left === 0) toast(b.film ? "That was the last frame. Press L to buy another." : "End of the roll. Press L to reload, or choose a different film in the camera bag.", 3000);
  else if (S.frameCount === 1) toast("Frame saved. Press P to see your contact sheet, B to develop the last shot.", 3200);
  if (typeof onShotTaken === "function") onShotTaken(rec);
  return rec;
}

function makeThumb(src){
  const c = document.createElement("canvas"); const s = 360/Math.max(src.width, src.height);
  c.width = Math.round(src.width*s); c.height = Math.round(src.height*s);
  c.getContext("2d").drawImage(src, 0, 0, c.width, c.height);
  return c.toDataURL("image/jpeg", 0.78);
}

/* ---------- image statistics (from a canvas) ---------- */
function imageStats(src){
  const w = 150, h = Math.max(1, Math.round(150*src.height/src.width));
  const c = document.createElement("canvas"); c.width = w; c.height = h; const x = c.getContext("2d");
  x.drawImage(src, 0, 0, w, h); const d = x.getImageData(0,0,w,h).data;
  let sum=0, sum2=0, hi=0, lo=0, satSum=0, n=w*h, maxC = 0;
  const hueBins = new Float32Array(12); const lum = new Float32Array(n);
  for (let i=0, p=0;i<d.length;i+=4, p++){
    const r=d[i]/255, g=d[i+1]/255, b=d[i+2]/255, l = 0.2126*r+0.7152*g+0.0722*b; lum[p]=l;
    sum+=l; sum2+=l*l; if (l>0.97) hi++; if (l<0.025) lo++;
    const mx=Math.max(r,g,b), mn=Math.min(r,g,b), sat = mx>0.001 ? (mx-mn)/mx : 0; satSum += sat*Math.min(1, mx*2);
    if (sat > 0.15 && mx > 0.12){ let hh; const dd = mx-mn; if (mx===r) hh = ((g-b)/dd+6)%6; else if (mx===g) hh = (b-r)/dd+2; else hh = (r-g)/dd+4; hueBins[Math.floor(hh*2)%12] += sat*mx; }
  }
  const mean = sum/n, sd = Math.sqrt(Math.max(0, sum2/n - mean*mean));
  // edge energy (a crude sharpness/detail measure)
  let e = 0; for (let y=1;y<h-1;y++) for (let xx=1;xx<w-1;xx++){ const p=y*w+xx; e += Math.abs(4*lum[p]-lum[p-1]-lum[p+1]-lum[p-w]-lum[p+w]); }
  const hs = Array.from(hueBins), ht = hs.reduce((a,b)=>a+b,0);
  // thirds luminance for balance
  let left=0,right=0; for (let y=0;y<h;y++) for (let xx=0;xx<w;xx++){ const l = lum[y*w+xx]; if (xx < w/2) left += l; else right += l; }
  return { mean, sd, hi:hi/n, lo:lo/n, sat:satSum/n, hue:hs.map(v=>ht>0? v/ht : 0), colorAmt: ht/n, edge:e/n, balance:(left-right)/(left+right+1e-6) };
}

/* ---------- subject analysis at capture ---------- */
function analyzeFrame(cam, subjects, depth, exp, extra){
  const W = CAP.W, meta = { subjects:[], landmarks:[], W:CAP.W, H:CAP.H };
  const b = curBody(), L = curLens(), film = curFilm(), fmt = curFormat();
  cam.updateMatrixWorld(true); cam.updateProjectionMatrix();
  const view = cam.matrixWorldInverse;
  const v = new THREE.Vector3(), vv = new THREE.Vector3();
  const proj = (x,y,z) => { v.set(x,y,z).project(cam); vv.set(x,y,z).applyMatrix4(view); return { u:(v.x+1)/2, v:(1-v.y)/2, z:-vv.z }; };
  const depthAt = (u,vv_) => { const x = clamp(Math.floor(u*300),0,299), y = clamp(Math.floor(vv_*200),0,199); return depth[y*300+x]; };
  { let ne = 0, nc = 0, te = 0, tc = 0; for (let y=0;y<200;y+=4) for (let x=0;x<300;x+=4){ const u = x/300, v = y/200, d = depth[y*300+x], edge = u < 0.22 || u > 0.78 || v < 0.18; if (edge){ te++; if (d < 2.6) ne++; } else { tc++; if (d < 2.6) nc++; } }
    meta.fgEdge = ne/Math.max(1,te); meta.fgCenter = nc/Math.max(1,tc); }
  const camPos = cam.position;
  const fwd = new THREE.Vector3(0,0,-1).applyQuaternion(cam.quaternion);
  const pxPerRad = W / (2*Math.atan(Math.tan(cam.fov*Math.PI/360)*cam.aspect));
  for (const s of subjects){
    const dx = s.x - camPos.x, dz = s.z - camPos.z, dist = Math.hypot(dx, dz);
    if (dist > 160) continue;
    // extents
    let hx = s.r, hz = s.r; if (s.kind==="car"){ hx = s.len/2; hz = 0.95; } if (s.kind==="cablecar"){ hx = 1.3; hz = s.len/2; }
    const pts = []; for (const ax of [-hx,hx]) for (const az of [-hz,hz]) for (const ay of [0, s.h]) pts.push(proj(s.x+ax, s.y+ay, s.z+az));
    if (pts.every(p=>p.z < 0.3)) continue;
    const front = pts.filter(p=>p.z > 0.3); if (front.length < 4) continue;
    let u0=Infinity,u1=-Infinity,v0=Infinity,v1=-Infinity; for (const p of front){ u0=Math.min(u0,p.u); u1=Math.max(u1,p.u); v0=Math.min(v0,p.v); v1=Math.max(v1,p.v); }
    if (u1 < 0 || u0 > 1 || v1 < 0 || v0 > 1) continue;
    const area = (u1-u0)*(v1-v0); if (area < 0.00008) continue;
    const cu0 = clamp(u0,0,1), cu1 = clamp(u1,0,1), cv0 = clamp(v0,0,1), cv1 = clamp(v1,0,1);
    const inArea = (cu1-cu0)*(cv1-cv0), clipped = 1 - inArea/Math.max(area,1e-9);
    const c = proj(s.x, s.y + s.h*0.55, s.z);
    // occlusion: sample a grid inside the visible box
    let vis = 0, tot = 0;
    for (let a=0.2;a<=0.81;a+=0.2) for (let bb=0.15;bb<=0.86;bb+=0.175){ const uu = lerp(cu0,cu1,a), vvv = lerp(cv0,cv1,bb); tot++; if (depthAt(uu,vvv) > c.z - Math.max(hx,hz)*1.3 - 0.4) vis++; }
    const visible = vis/tot * (1-clipped);
    if (visible < 0.12) continue;
    // motion on the sensor during exposure
    const fut = proj(s.x + (s.vx||0)*exp.t, s.y + s.h*0.55, s.z + (s.vz||0)*exp.t);
    let motionPx = Math.hypot(fut.u - c.u, fut.v - c.v) * W;
    if (s.kind === "birds") motionPx = Math.max(motionPx, 5.5*exp.t/(c.z||1)*pxPerRad);
    if (s.kind === "person" && s.stride > 0) motionPx = Math.max(motionPx, 0.9*exp.t*s.stride/Math.max(c.z,0.5)*pxPerRad*0.5);
    const coc = cocPx(Math.max(c.z,0.3), Cam.focus, exp.N, W);
    // direction of travel on screen (lead room)
    let dirU = 0; const sp = Math.hypot(s.vx||0, s.vz||0);
    if (sp > 0.25){ const ahead = proj(s.x + (s.vx||0), s.y + s.h*0.55, s.z + (s.vz||0)); dirU = Math.sign(ahead.u - c.u) * Math.min(1, Math.abs(ahead.u-c.u)*8); }
    else if (s.heading !== undefined && s.kind !== "birds"){ const ahead = proj(s.x + Math.sin(s.heading), s.y + s.h*0.55, s.z + Math.cos(s.heading)); dirU = Math.sign(ahead.u - c.u)*0.6; }
    // facing the camera?
    let facing = 0; if (s.heading !== undefined){ const tx = -dx/dist, tz = -dz/dist; facing = Math.sin(s.heading)*tx + Math.cos(s.heading)*tz; }
    const flashLit = exp.flashOn ? clamp(Math.pow((curFlash().gn*Math.sqrt(exp.iso/100)/exp.N) / Math.max(c.z,0.3), 2), 0, 4) : 0;
    const key = s.kind + ":" + (s._ref && s._ref.id !== undefined ? s._ref.id : Math.round(s.x)+","+Math.round(s.z));
    meta.subjects.push({ kind:s.kind, key, box:[cu0,cv0,cu1,cv1], raw:[u0,v0,u1,v1], cu:c.u, cv:c.v, dist:c.z, area:inArea, clipped, vis:visible,
      eye:!!s.eye, gesture:s.gesture||null, gpeak:s.gpeak||0, ev:s.ev||null, occ: clamp(1 - vis/tot, 0, 1),
      coc, motion:motionPx, dirU, facing, speed:sp, aware:!!s.aware, umbrella:!!s.umbrella, vivid:!!s.vivid, hat:!!s.hat, dog:!!s.dog, phone:!!s.phone,
      watcher:!!s.watcher, stride:s.stride||0, taxi:!!s.taxi, count:s.count||0, flashLit, color:s.color||null });
  }
  meta.subjects.sort((a,b)=>b.area - a.area); meta.subjects = meta.subjects.slice(0, 16);
  for (const lm of World.landmarks){
    const p = proj(lm.pos.x, lm.pos.y, lm.pos.z); if (p.z < 1 || p.u < 0.03 || p.u > 0.97 || p.v < 0.03 || p.v > 0.97) continue;
    const d = depthAt(p.u, p.v); if (d > 390) meta.landmarks.push({ name:lm.name, u:p.u, v:p.v });
  }
  // street alignment → leading lines / vanishing point
  const yaw = Math.atan2(-fwd.x, -fwd.z); const m = ((yaw % (Math.PI/2)) + Math.PI/2) % (Math.PI/2); const off = Math.min(m, Math.PI/2 - m);
  const pitchAbs = Math.abs(Math.asin(clamp(fwd.y,-1,1)));
  meta.streetAlign = clamp(1 - off/(12*Math.PI/180), 0, 1) * clamp(1 - pitchAbs/0.5, 0, 1);
  // is the camera actually standing on a street/sidewalk facing down a corridor (not into a wall)?
  const [o] = [cam.position]; const corridor = rayWorld(o, new THREE.Vector3(fwd.x, 0, fwd.z).normalize(), 200);
  meta.corridor = corridor; if (corridor < 30) meta.streetAlign *= corridor/30;
  const vp = proj(camPos.x + Math.round(fwd.x)*300, camPos.y, camPos.z + Math.round(fwd.z)*300); meta.vp = [vp.u, vp.v];
  // sky fraction from depth
  let skyN = 0; for (let i=0;i<depth.length;i+=7) if (depth[i] > 395) skyN++; meta.sky = skyN/(depth.length/7);
  const loc = locationName(camPos.x, camPos.z);
  const T = World.timeDef;
  Object.assign(meta, {
    body:S.body, bodyName:b.n, lens:L.n, feq:Math.round(feqReal()), fAct:lensFocal(), fmt:b.fmt, fmtName:fmt.n, fmtW:fmt.w, N:exp.N, t:exp.t, iso:exp.iso, push:exp.push, offset:exp.offset, flash:exp.flashOn? curFlash().name : null, syncWarn:exp.syncWarn,
    filmId:curRoll().stock, filmName:film.n, filmKind:film.k, lat:film.lat, mono:isMono(film), film:true, focus:Cam.focus, af:focusKind()==="af", leak:extra.leak, instant:film.k==="instant",
    time:T.id, timeName:T.name, fog:S.fog, rain:!!S.rain, quality:T.quality, clock:S.clock, pitch:Player.pitch, px:Player.x, pz:Player.z, yaw:Player.yaw, glass:glassAmount(), riding: GP.ride ? GP.ride.kind : null, events: activeEventTags(), blackout: !!World.blackout, qname:T.qname, street:loc.street, hood:loc.hood,
    hip:extra.hip, shakePx:extra.shakeAng*pxPerRad, noise:extra.noiseSig, grain:extra.grain, roll:extra.roll, walking:extra.walk > 0.6
  });
  return meta;
}
