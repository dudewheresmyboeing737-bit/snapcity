
/* =========================================================
   Models: geometry merging, cars, reflection environment
   ========================================================= */
// merge [{g, m, c}] into one non-indexed geometry with vertex colours
function mergeParts(parts){
  let n = 0; const prepared = parts.map(p => { const g = p.g.index ? p.g.toNonIndexed() : p.g; n += g.attributes.position.count; return [g, p]; });
  const pos = new Float32Array(n*3), nor = new Float32Array(n*3), col = new Float32Array(n*3);
  const v = new THREE.Vector3(), nm = new THREE.Matrix3(); let o = 0;
  for (const [g, p] of prepared){
    const P = g.attributes.position, N = g.attributes.normal, m = p.m || new THREE.Matrix4(), c = p.c || new THREE.Color(1,1,1);
    nm.getNormalMatrix(m);
    for (let i=0;i<P.count;i++){
      v.fromBufferAttribute(P,i).applyMatrix4(m); pos[o*3]=v.x; pos[o*3+1]=v.y; pos[o*3+2]=v.z;
      v.fromBufferAttribute(N,i).applyMatrix3(nm).normalize(); nor[o*3]=v.x; nor[o*3+1]=v.y; nor[o*3+2]=v.z;
      col[o*3]=c.r; col[o*3+1]=c.g; col[o*3+2]=c.b; o++;
    }
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute("position", new THREE.BufferAttribute(pos,3)); out.setAttribute("normal", new THREE.BufferAttribute(nor,3)); out.setAttribute("color", new THREE.BufferAttribute(col,3));
  out.computeBoundingSphere(); return out;
}
const TM = (x=0,y=0,z=0, rx=0,ry=0,rz=0, sx=1,sy=1,sz=1) => new THREE.Matrix4().compose(new THREE.Vector3(x,y,z), new THREE.Quaternion().setFromEuler(new THREE.Euler(rx,ry,rz,"YXZ")), new THREE.Vector3(sx,sy,sz));

/* ---------------- cars ---------------- */
const CAR_TYPES = {
  sedan:  { L:4.7, W:1.82, clr:0.2, belt:0.98, nose:0.82, tail:0.95, wf:1.42, wr:-1.38, R:0.34, cabin:[[-1.3,0],[-0.72,1],[0.42,1.02],[1.18,0]], ch:0.46 },
  hatch:  { L:4.1, W:1.76, clr:0.19, belt:0.95, nose:0.8, tail:0.95, wf:1.28, wr:-1.25, R:0.32, cabin:[[-1.9,0],[-1.72,1],[0.28,1.02],[0.98,0]], ch:0.52 },
  suv:    { L:4.75, W:1.92, clr:0.3, belt:1.12, nose:1.02, tail:1.1, wf:1.45, wr:-1.45, R:0.4, cabin:[[-2.2,0],[-2.1,1],[0.55,1],[1.15,0]], ch:0.66 },
  van:    { L:5.1, W:1.98, clr:0.24, belt:1.05, nose:1.0, tail:1.05, wf:1.72, wr:-1.55, R:0.36, cabin:[[-2.52,0],[-2.5,1],[1.05,1],[1.75,0]], ch:1.05, win:"van" },
  pickup: { L:5.3, W:1.95, clr:0.32, belt:1.1, nose:1.05, tail:1.08, wf:1.7, wr:-1.6, R:0.4, cabin:[[-0.95,0],[-0.9,1],[0.7,1],[1.25,0]], ch:0.66, bed:true },
  bus:    { L:11.2, W:2.55, clr:0.32, belt:1.25, nose:1.3, tail:1.3, wf:3.7, wr:-3.2, R:0.5, cabin:[[-5.45,0],[-5.45,1],[5.2,1],[5.5,0]], ch:1.35, win:"bus" },
  beetle: { L:4.05, W:1.62, clr:0.2, belt:0.8, nose:0.66, tail:0.72, wf:1.2, wr:-1.2, R:0.33, cabin:[[-1.15,0],[-0.5,1],[0.2,1],[0.92,0]], ch:0.62, bev:0.2, round:true },
  mini:   { L:3.15, W:1.56, clr:0.15, belt:0.8, nose:0.72, tail:0.8, wf:1.02, wr:-1.02, R:0.28, cabin:[[-1.48,0],[-1.42,1],[0.52,1],[0.72,0]], ch:0.58, bev:0.1 },
  wagon:  { L:4.95, W:1.82, clr:0.2, belt:0.92, nose:0.8, tail:0.92, wf:1.5, wr:-1.5, R:0.33, cabin:[[-2.38,0],[-2.32,1],[0.45,1],[1.15,0]], ch:0.52, wood:true },
  coupe:  { L:4.55, W:1.82, clr:0.14, belt:0.8, nose:0.66, tail:0.8, wf:1.45, wr:-1.35, R:0.33, cabin:[[-1.55,0],[-0.35,1],[0.35,1],[0.98,0]], ch:0.42, bev:0.1 },
  vintage:{ L:5.35, W:1.96, clr:0.2, belt:0.86, nose:0.8, tail:0.92, wf:1.72, wr:-1.62, R:0.36, cabin:[[-1.05,0],[-0.62,1],[0.42,1],[0.92,0]], ch:0.5, chromeBumpers:true, fins:true },
  boxtruck:{ L:6.4, W:2.2, clr:0.3, belt:1.15, nose:1.1, tail:1.15, wf:2.2, wr:-1.9, R:0.42, cabin:[[1.35,0],[1.4,1],[2.35,0.95],[2.85,0]], ch:0.9, box:true },
  convertible:{ L:4.6, W:1.8, clr:0.16, belt:0.84, nose:0.72, tail:0.84, wf:1.42, wr:-1.36, R:0.33, cabin:[[-0.2,0],[0.25,1],[0.3,1],[0.95,0]], ch:0.38, open:true },
  classic:{ L:5.0, W:1.9, clr:0.2, belt:0.9, nose:0.78, tail:0.85, wf:1.62, wr:-1.52, R:0.35, cabin:[[-1.1,0],[-0.55,1],[0.35,1],[0.95,0]], ch:0.46, chromeBumpers:true },
};
const CAR_TYPE_WEIGHTS = [["sedan",4],["hatch",3],["suv",2.5],["van",1],["pickup",1],["classic",1],["beetle",1],["mini",1],["wagon",1.2],["coupe",1],["vintage",0.8],["boxtruck",0.5],["convertible",0.5]];
const CAR_PALETTES = { vintage:["#b3d9c9","#9cc3e0","#e8c56a","#e8dcc0","#c0362c","#f2efe6","#2f5a3a"], beetle:["#9cc3e0","#e8b82e","#c0362c","#f2efe6","#3aa06b","#e36f2d","#6f8a5c"], mini:["#2f5a3a","#c0362c","#e8dcc0","#1e3a5f","#e8b82e"], wagon:["#6b4a2e","#8a3b32","#d8c9a3","#3f5e7a","#2d4a3c"], convertible:["#c0362c","#f2efe6","#1e3a5f","#e8b82e"], boxtruck:["#f2f2ee","#e9e6de","#d8d2c0"] };
function pickCarType(r){ let t = 0; for (const [,w] of CAR_TYPE_WEIGHTS) t += w; let x = r()*t; for (const [k,w] of CAR_TYPE_WEIGHTS){ if ((x -= w) < 0) return k; } return "sedan"; }
function extrudeX(shape, width, bevel){
  const g = new THREE.ExtrudeGeometry(shape, { depth: Math.max(0.01, width - 2*bevel), bevelEnabled: bevel > 0, bevelThickness: bevel, bevelSize: bevel, bevelSegments: 2, curveSegments: 5, steps:1 });
  g.translate(0,0,-(width - 2*bevel)/2); g.rotateY(-Math.PI/2); return g.toNonIndexed();
}
// returns part lists by material: paint, glass, trim, chrome, head, tail. Car faces +z, ground at y=0
function carParts(type, paint, opts={}){
  const T = CAR_TYPES[type], L = T.L, W = T.W, R = T.R, out = { paint:[], glass:[], trim:[], chrome:[], head:[], tail:[] };
  const pc = paint, dark = lin("#15171a"), rubber = lin("#111111"), plate = lin("#e9e6da");
  // lower body profile (z along x of the shape)
  const s = new THREE.Shape(), clr = T.clr, fz = L/2, rz = -L/2, ar = R + 0.07;
  s.moveTo(rz + 0.1, clr);
  s.lineTo(rz, clr + 0.22); s.lineTo(rz + 0.02, T.tail - 0.08); s.quadraticCurveTo(rz + 0.05, T.tail, rz + 0.3, T.tail);
  const cb = T.cabin[0][0], cf = T.cabin[3][0];
  if (T.bed){ s.lineTo(cb - 0.05, T.tail); s.lineTo(cb - 0.05, T.belt); }
  else s.lineTo(cb - 0.1, T.belt);
  s.lineTo(cf + 0.1, T.belt);
  s.quadraticCurveTo(fz - 0.6, T.nose + 0.06, fz - 0.12, T.nose); s.quadraticCurveTo(fz, T.nose - 0.02, fz, T.nose - 0.18);
  s.lineTo(fz, clr + 0.2); s.lineTo(fz - 0.12, clr);
  s.lineTo(T.wf + ar, clr); s.absarc(T.wf, clr, ar, 0, Math.PI, false);
  s.lineTo(T.wr + ar, clr); s.absarc(T.wr, clr, ar, 0, Math.PI, false);
  s.lineTo(rz + 0.1, clr);
  const bev = T.bev || 0.07; out.paint.push({ g: extrudeX(s, W, bev), c: pc });
  const pc2 = opts.twoTone || pc;
  // cabin glass
  const ch = T.ch, cab = new THREE.Shape(); const cp = T.cabin.map(([z,f])=>[z, T.belt - 0.01 + f*ch]);
  cab.moveTo(cp[0][0], cp[0][1]); for (let i=1;i<cp.length;i++) cab.lineTo(cp[i][0], cp[i][1]); cab.lineTo(cp[0][0], cp[0][1]);
  if (!T.open) out.glass.push({ g: extrudeX(cab, W - 0.2, T.round ? 0.14 : 0.05) });
  else { out.glass.push({ g: new THREE.BoxGeometry(W - 0.25, 0.36, 0.02).toNonIndexed(), m: TM(0, T.belt + 0.18, T.cabin[3][0] - 0.05, -0.5) }); for (const zz of [-0.3, -1.2]) out.trim.push({ g: new THREE.BoxGeometry(W - 0.4, 0.5, 0.45).toNonIndexed(), m: TM(0, T.belt + 0.05, zz), c: lin(opts.seat || "#5a3a26") }); }
  // roof panel and pillars in paint
  const rf = new THREE.Shape(); rf.moveTo(cp[1][0]-0.02, cp[1][1]-0.05); rf.lineTo(cp[1][0]+0.04, cp[1][1]+0.035); rf.lineTo(cp[2][0]-0.02, cp[2][1]+0.035); rf.lineTo(cp[2][0]+0.05, cp[2][1]-0.05);
  if (!T.open) out.paint.push({ g: extrudeX(rf, W - 0.14, T.round ? 0.12 : 0.04), c: pc2 });
  const pillar = (z0,y0,z1,y1) => { const len = Math.hypot(z1-z0,y1-y0); for (const sx of [-1,1]) out.paint.push({ g: new THREE.BoxGeometry(0.05, len, 0.09).toNonIndexed(), m: TM(sx*(W/2-0.1), (y0+y1)/2, (z0+z1)/2, Math.atan2(z1-z0, y1-y0)), c: pc }); };
  if (!T.open){ pillar(cp[3][0], cp[3][1], cp[2][0], cp[2][1]); pillar(cp[0][0], cp[0][1], cp[1][0], cp[1][1]); }
  if (!T.win){ const bz = (cp[1][0] + cp[2][0])/2 - 0.1; pillar(bz, T.belt, bz, cp[1][1]); }
  else if (T.win === "bus"){ for (let f=0.1; f<0.95; f+=0.11){ const bz = lerp(cp[1][0], cp[2][0], f); pillar(bz, T.belt, bz, cp[1][1]); } }
  else { for (const f of [0.3, 0.62]){ const bz = lerp(cp[1][0], cp[2][0], f); pillar(bz, T.belt, bz, cp[1][1]); } }
  // pickup bed
  if (T.bed){ const bl = cb - 0.1 - rz; out.trim.push({ g: new THREE.BoxGeometry(W-0.24, 0.05, bl-0.3).toNonIndexed(), m: TM(0, T.tail-0.35, rz + bl/2 + 0.1), c: dark }); }
  // bumpers, grille, plates
  const bumperC = T.chromeBumpers ? null : dark;
  for (const [z, dir] of [[fz, 1], [rz, -1]]){
    const g = new THREE.BoxGeometry(W - 0.06, 0.2, 0.16).toNonIndexed(), m = TM(0, clr + 0.2, z - dir*0.02);
    if (bumperC) out.trim.push({ g, m, c: bumperC }); else out.chrome.push({ g, m });
    out.trim.push({ g: new THREE.BoxGeometry(0.52, 0.12, 0.02).toNonIndexed(), m: TM(0, clr + 0.34, z + dir*0.02), c: plate });
  }
  out.trim.push({ g: new THREE.BoxGeometry(W*0.46, 0.16, 0.04).toNonIndexed(), m: TM(0, T.nose - 0.3, fz + 0.005), c: T.chromeBumpers ? lin("#9ea3a6") : dark });
  // lights
  for (const sx of [-1,1]){
    out.head.push({ g: new THREE.BoxGeometry(0.36, 0.13, 0.05).toNonIndexed(), m: TM(sx*(W/2-0.3), T.nose - 0.26, fz - 0.01) });
    out.tail.push({ g: new THREE.BoxGeometry(0.3, 0.14, 0.05).toNonIndexed(), m: TM(sx*(W/2-0.25), T.tail - 0.22, rz + 0.02) });
    // mirrors
    out.paint.push({ g: new THREE.BoxGeometry(0.18, 0.1, 0.1).toNonIndexed(), m: TM(sx*(W/2+0.05), T.belt + 0.08, cp[3][0] - 0.25), c: pc });
    // door handles & belt trim
    out.trim.push({ g: new THREE.BoxGeometry(0.012, 0.04, W>1.85?4:3).toNonIndexed(), m: TM(sx*(W/2+0.005), T.belt - 0.03, (cb+cf)/2, 0,0,0, 1,1,(cf-cb)/3.5), c: dark });
  }
  // wheels
  const tire = new THREE.CylinderGeometry(R, R, 0.24, 14).rotateZ(Math.PI/2).toNonIndexed();
  const rim = new THREE.CylinderGeometry(R*0.62, R*0.62, 0.25, 10).rotateZ(Math.PI/2).toNonIndexed();
  const hub = new THREE.CylinderGeometry(R*0.2, R*0.2, 0.27, 8).rotateZ(Math.PI/2).toNonIndexed();
  const ww = new THREE.CylinderGeometry(R*0.82, R*0.82, 0.245, 18).rotateZ(Math.PI/2).toNonIndexed();
  for (const z of [T.wf, T.wr]) for (const sx of [-1,1]){
    const x = sx*(W/2 - 0.15);
    out.trim.push({ g: tire, m: TM(x, R, z), c: rubber }); if (opts.whitewall) out.trim.push({ g: ww, m: TM(x + Math.sign(x)*0.004, R, z), c: lin("#f2efe6") }); if (opts.darkRims) out.trim.push({ g: rim, m: TM(x, R, z), c: lin("#2a2c2e") }); else out.chrome.push({ g: rim, m: TM(x, R, z) }); out.trim.push({ g: hub, m: TM(x, R, z), c: lin("#2a2c2e") });
  }
  // character: wood panels, tail fins, cargo box, roof racks, antennas, stickers
  if (T.wood) for (const sx of [-1,1]) out.trim.push({ g: new THREE.BoxGeometry(0.02, 0.26, L*0.72).toNonIndexed(), m: TM(sx*(W/2 + 0.004), T.belt - 0.28, -0.1), c: lin("#7a4a28") });
  if (T.fins) for (const sx of [-1,1]) out.paint.push({ g: new THREE.BoxGeometry(0.06, 0.22, 1.1).toNonIndexed(), m: TM(sx*(W/2 - 0.08), T.tail + 0.06, rz + 0.6, -0.18), c: pc });
  if (T.box){ out.paint.push({ g: new THREE.BoxGeometry(W, 2.45, L*0.66).toNonIndexed(), m: TM(0, clr + 0.3 + 1.22, rz + L*0.33), c: opts.boxCol || lin("#f2f2ee") }); out.trim.push({ g: new THREE.BoxGeometry(W*0.9, 0.05, 0.02).toNonIndexed(), m: TM(0, clr + 1.2, rz - 0.01), c: lin("#555") }); }
  if (opts.rack && !T.open && !T.box){ for (const zz of [-0.5, 0.4]) out.chrome.push({ g: new THREE.BoxGeometry(W - 0.3, 0.03, 0.04).toNonIndexed(), m: TM(0, cp[1][1] + 0.09, (cp[1][0]+cp[2][0])/2 + zz) }); for (const sx of [-1,1]) out.trim.push({ g: new THREE.BoxGeometry(0.03, 0.05, 1.3).toNonIndexed(), m: TM(sx*(W/2 - 0.2), cp[1][1] + 0.06, (cp[1][0]+cp[2][0])/2), c: lin("#1a1a1a") }); if (opts.board) out.trim.push({ g: new THREE.BoxGeometry(0.5, 0.06, 2.2).toNonIndexed(), m: TM(0.1, cp[1][1] + 0.14, (cp[1][0]+cp[2][0])/2), c: lin(opts.board) }); }
  if (opts.antenna) out.trim.push({ g: new THREE.CylinderGeometry(0.004, 0.004, 0.7, 4).toNonIndexed(), m: TM(-W/2 + 0.2, T.belt + 0.35, rz + 0.8, -0.2), c: lin("#111") });
  if (opts.sticker) out.trim.push({ g: new THREE.BoxGeometry(0.28, 0.08, 0.01).toNonIndexed(), m: TM(W*0.22, T.tail - 0.1, rz - 0.005), c: lin(opts.sticker) });
  if (opts.taxi){ out.trim.push({ g: new THREE.BoxGeometry(0.7, 0.2, 0.28).toNonIndexed(), m: TM(0, cp[1][1] + 0.14, (cp[1][0]+cp[2][0])/2), c: lin("#f6f1e0") }); }
  return out;
}
const CarMats = {};
function initCarMats(){
  CarMats.paint = new THREE.MeshPhysicalMaterial({ vertexColors:true, roughness:0.4, metalness:0.2, clearcoat:1, clearcoatRoughness:0.06, envMapIntensity:0.45 });
  CarMats.glass = new THREE.MeshStandardMaterial({ color:lin("#0b1015"), roughness:0.04, metalness:0.9, envMapIntensity:0.8 });
  CarMats.trim = new THREE.MeshStandardMaterial({ vertexColors:true, roughness:0.72, metalness:0.1, envMapIntensity:0.25 });
  CarMats.chrome = new THREE.MeshStandardMaterial({ color:lin("#d4d7da"), roughness:0.18, metalness:1, envMapIntensity:0.8 });
  CarMats.headOff = new THREE.MeshStandardMaterial({ color:lin("#dfe3e6"), roughness:0.1, metalness:0.6 });
  CarMats.tailOff = new THREE.MeshStandardMaterial({ color:lin("#6a1414"), roughness:0.3, metalness:0.2 });
}
function carCharacter(type, rnd = Math.random){
  const o = {}; const r = rnd;
  if (r() < 0.2 && type !== "boxtruck") o.twoTone = lin(["#f2efe6","#1a1a1a","#e8dcc0","#3a3a3a"][(r()*4)|0]);
  if (type === "vintage" || (type === "beetle" && r() < 0.5) || (type === "classic" && r() < 0.6)) o.whitewall = true;
  if (type === "vintage" && !o.twoTone) o.twoTone = lin("#f2efe6");
  if (r() < 0.25 && ["suv","wagon","hatch","pickup","van","beetle"].includes(type)){ o.rack = true; if (r() < 0.35) o.board = ["#e8b82e","#f2efe6","#3aa06b","#e36f2d"][(r()*4)|0]; }
  if (r() < 0.3) o.antenna = true; if (r() < 0.2) o.sticker = ["#c0362c","#2f7fc1","#e8b82e","#f2efe6"][(r()*4)|0];
  if (r() < 0.25 && ["coupe","suv","hatch","sedan"].includes(type)) o.darkRims = true;
  if (type === "boxtruck") o.boxCol = lin(["#f2f2ee","#e9e6de","#c9c9c4","#e8dcc0"][(r()*4)|0]);
  if (type === "convertible") o.seat = ["#5a3a26","#e8dcc0","#1a1a1a"][(r()*3)|0];
  return o;
}
function carPaint(type, rnd = Math.random){ const pal = CAR_PALETTES[type]; const c = lin(pal ? pal[(rnd()*pal.length)|0] : CAR_COLORS[(rnd()*CAR_COLORS.length)|0]); return c.multiplyScalar(0.88 + rnd()*0.14); }
// build a car as a Group (for moving cars), with its own light materials
function buildCarGroup(type, paint, opts, lightMats){
  const parts = carParts(type, paint, opts), g = new THREE.Group();
  for (const k of ["paint","glass","trim","chrome"]){ if (!parts[k].length) continue; const m = new THREE.Mesh(mergeParts(parts[k]), CarMats[k]); m.castShadow = k !== "glass"; m.receiveShadow = true; g.add(m); }
  g.add(new THREE.Mesh(mergeParts(parts.head), lightMats ? lightMats[0] : CarMats.headOff));
  g.add(new THREE.Mesh(mergeParts(parts.tail), lightMats ? lightMats[1] : CarMats.tailOff));
  return g;
}
// push a parked car into the world's merged buffers
function pushCar(x, y, z, ry, pitch, type, paint){
  paint = CAR_PALETTES[type] ? carPaint(type) : paint.clone().multiplyScalar(0.88 + Math.random()*0.14);
  const parts = carParts(type, paint, carCharacter(type)), base = TM(x, y, z, pitch, ry, 0);
  for (const k of ["paint","glass","trim","chrome","head","tail"]){
    const key = "car_" + k;
    for (const p of parts[k]){ const m = base.clone().multiply(p.m || new THREE.Matrix4()); pushGeom(key, p.g, m, p.c || new THREE.Color(1,1,1)); }
  }
}
function buildParkedCarMeshes(){
  buildMesh("car_paint", CarMats.paint, {cast:true}); buildMesh("car_glass", CarMats.glass, {}); buildMesh("car_trim", CarMats.trim, {cast:true});
  buildMesh("car_chrome", CarMats.chrome, {}); buildMesh("car_head", CarMats.headOff, {}); buildMesh("car_tail", CarMats.tailOff, {});
}

/* ---------------- reflection environment ---------------- */
const Env = { pmrem:null, rt:null, cv:null };
function updateEnv(){
  if (!G.renderer) return;
  const T = World.timeDef || TIMES[2];
  if (!Env.pmrem){ Env.pmrem = new THREE.PMREMGenerator(G.renderer); Env.cv = document.createElement("canvas"); Env.cv.width = 512; Env.cv.height = 256; }
  const c = Env.cv, x = c.getContext("2d"), W = 512, H = 256, hz = 128;
  const night = T.id === "night" ? 0.3 : T.id === "blue" ? 0.6 : 1;
  const wet = S && S.rain, gray = T.id==="night" ? "#1c2026" : "#8a9197"; const sky = x.createLinearGradient(0,0,0,hz); sky.addColorStop(0, wet ? mixHex(T.top, gray, 0.85) : T.top); sky.addColorStop(1, wet ? mixHex(T.bot, gray, 0.85) : T.bot); x.fillStyle = sky; x.fillRect(0,0,W,hz);
  // sun glow
  const sx = ((T.azim||200)/360)*W, sy = hz - (T.elev||10)/90*hz;
  if (T.sunI > 0.5 && !wet){ const g = x.createRadialGradient(sx,sy,0,sx,sy,40); g.addColorStop(0, T.sun); g.addColorStop(0.15, T.sun); g.addColorStop(1, "rgba(255,255,255,0)"); x.fillStyle = g; x.fillRect(sx-40,sy-40,80,80); }
  // skyline and street
  x.fillStyle = T.gnd; x.fillRect(0,hz,W,H-hz);
  x.globalAlpha = 0.85; x.fillStyle = "#6f6a66"; for (let i=0;i<W;i+=18){ const h = 8 + ((i*37)%29); x.fillRect(i, hz-h, 16, h+26); } x.globalAlpha = 1;
  x.fillStyle = "rgba(0,0,0,"+(0.55*(2-night)/2)+")"; x.fillRect(0,hz+26,W,H-hz-26);
  if (night < 1){ x.fillStyle = "rgba(0,0,0,"+(1-night)*0.6+")"; x.fillRect(0,0,W,H); x.fillStyle = "#ffd9a0"; for (let i=0;i<60;i++){ x.fillRect((i*83)%W, hz-4-((i*29)%26), 2, 2); } }
  const tex = new THREE.CanvasTexture(c); tex.mapping = THREE.EquirectangularReflectionMapping; tex.encoding = THREE.sRGBEncoding;
  if (Env.rt) Env.rt.dispose();
  Env.rt = Env.pmrem.fromEquirectangular(tex); tex.dispose();
  const envTex = Env.rt.texture;
  const setEnv = (m, i) => { if (!m) return; const first = !m.envMap; m.envMap = envTex; if (i !== undefined) m.envMapIntensity = i; if (first) m.needsUpdate = true; };
  for (const k of ["paint","glass","trim","chrome"]) setEnv(CarMats[k]);
  if (World.mats) setEnv(World.mats.glass, World.mats.glass.envMapIntensity || 0.45);
}
