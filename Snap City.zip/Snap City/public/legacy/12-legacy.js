
/* =========================================================
   Judge: scores composition, subject/moment, light, sharpness,
   colour; writes a critique; pays out money and XP
   ========================================================= */
const ASPECTS = { "orig":0, "3:2":1.5, "1:1":1, "4:5":0.8, "16:9":16/9, "2:3":2/3, "5:4":1.25 };
function defaultEdit(){ return { ex:0, con:0, hi:0, sh:0, temp:0, tint:0, sat:0, vib:0, bw:0, filter:"none", fade:0, vig:0, grain:0, clarity:0, splitHue:30, splitShHue:210, split:0, preset:"none", aspect:"orig", zoom:1, panX:0, panY:0, angle:0 }; }

// crop/straighten geometry: returns mapping from original pixel space to output
function editGeom(e, W, H){
  const a = ASPECTS[e.aspect] || W/H, th = (e.angle||0)*Math.PI/180, c = Math.abs(Math.cos(th)), s = Math.abs(Math.sin(th));
  const hMax = Math.min(W/(a*c + s), H/(a*s + c));
  const h = hMax/Math.max(1, e.zoom||1), w = a*h;
  const ex = w*c + h*s, ey = w*s + h*c;
  const cx = W/2 + clamp(e.panX||0,-1,1)*Math.max(0,(W-ex))/2, cy = H/2 + clamp(e.panY||0,-1,1)*Math.max(0,(H-ey))/2;
  const ow = a >= 1 ? 1500 : Math.round(1500*a), oh = a >= 1 ? Math.round(1500/a) : 1500;
  const sc = ow / w;
  return { a, th, w, h, cx, cy, ow, oh, sc, mag: Math.sqrt((W*H)/(w*h)) };
}
// normalized original (u,v) → normalized output (u,v)
function mapPoint(g, W, H, u, v){
  const px = u*W - g.cx, py = v*H - g.cy, c = Math.cos(g.th), s = Math.sin(g.th);
  const rx = px*c - py*s, ry = px*s + py*c;
  return [ (rx*g.sc + g.ow/2)/g.ow, (ry*g.sc + g.oh/2)/g.oh ];
}
function mapSubjects(meta, edit){
  if (!edit) return { subs: meta.subjects.map(s=>Object.assign({}, s)), mag:1, tilt:meta.roll, vp:meta.vp, landmarks:meta.landmarks };
  const W = meta.W || 1500, H = meta.H || 1000, g = editGeom(edit, W, H);
  const subs = [];
  for (const s0 of meta.subjects){
    const s = Object.assign({}, s0); const [u0,v0,u1,v1] = s.raw;
    const pts = [[u0,v0],[u1,v0],[u0,v1],[u1,v1]].map(([u,v])=>mapPoint(g,W,H,u,v));
    let a0=Infinity,a1=-Infinity,b0=Infinity,b1=-Infinity; for (const [u,v] of pts){ a0=Math.min(a0,u); a1=Math.max(a1,u); b0=Math.min(b0,v); b1=Math.max(b1,v); }
    if (a1 < 0 || a0 > 1 || b1 < 0 || b0 > 1) continue;
    const area = (a1-a0)*(b1-b0), c0=clamp(a0,0,1), c1=clamp(a1,0,1), d0=clamp(b0,0,1), d1=clamp(b1,0,1), inA = (c1-c0)*(d1-d0);
    const origClip = s0.clipped; const newClip = 1 - inA/Math.max(area,1e-9);
    s.box = [c0,d0,c1,d1]; s.area = inA; s.clipped = Math.max(newClip, origClip*0.5);
    s.vis = s0.vis * (1-newClip) / Math.max(0.05, 1-origClip);
    const [cu,cv] = mapPoint(g,W,H,s0.cu,s0.cv); s.cu = cu; s.cv = cv;
    if (s.vis < 0.1) continue;
    subs.push(s);
  }
  const vp = meta.vp ? mapPoint(g,W,H,meta.vp[0],meta.vp[1]) : null;
  const landmarks = (meta.landmarks||[]).map(l=>{ const [u,v]=mapPoint(g,W,H,l.u,l.v); return {name:l.name,u,v}; }).filter(l=>l.u>0.02&&l.u<0.98&&l.v>0.02&&l.v<0.98);
  return { subs, mag:g.mag, tilt: meta.roll + (edit.angle||0), vp, landmarks };
}

function interestOf(s){
  let v = ({ person:1, performer:1.7, dog:1.25, birds:1.3, cablecar:1.75, car:0.3 })[s.kind] ?? 0.5;
  if (s.kind==="birds") v += Math.min(0.5, s.count*0.04);
  if (s.taxi) v += 0.2;
  if (s.umbrella) v += 0.45; if (s.vivid) v += 0.3; if (s.hat) v += 0.1;
  if ((s.kind==="person"||s.kind==="performer") && s.facing > 0.55 && !s.aware) v += 0.25;
  if (s.aware) v -= 0.4; if (s.phone) v -= 0.1; if (s.watcher) v += 0.1;
  if (s.stride > 0.75) v += 0.2;
  return Math.max(0.1, v);
}
function primaryOf(subs){
  let best = null, bw = 0;
  for (const s of subs){ const w = interestOf(s)*Math.sqrt(Math.max(s.area,0))*s.vis*(1 - 0.6*s.clipped); if (w > bw){ bw = w; best = s; } }
  return best && bw > 0.012 ? best : null;
}
const KNAME = { person:"the passer-by", performer:"the busker", dog:"the dog", birds:"the pigeons", cablecar:"the tram", car:"the car" };
function subjName(s){ if (!s) return "the scene"; if (s.kind==="person"){ if (s.umbrella) return "the figure with the umbrella"; if (s.hat) return "the person in the hat"; if (s.vivid) return "the figure in the bright top"; if (s.dog) return "the dog walker"; if (s.watcher) return "the listener"; } if (s.kind==="car" && s.taxi) return "the cab"; return KNAME[s.kind] || "your subject"; }

function judgePhoto(rec, statsOverride){
  const meta = rec.meta, edit = rec.edit, st = statsOverride || meta.stats;
  const M = mapSubjects(meta, edit);
  const subs = M.subs, mag = M.mag, tilt = M.tilt;
  const prim = primaryOf(subs);
  const pos = [], neg = [], tips = [];
  const T = TIMES.find(t=>t.id===meta.time) || TIMES[2];
  const night = meta.time==="night" || meta.time==="blue";
  const mono = st.colorAmt < 0.01 || (meta.mono && !(edit && edit.bw===0 && false)) || (edit && edit.bw);

  /* ---------------- composition ---------------- */
  let comp;
  {
    let placement = 0.4, size = 0.6, lead = 0.75, clipS = 1, bonus = 0;
    if (prim){
      const people = prim.kind==="person"||prim.kind==="performer";
      const pu = prim.cu, pv = people ? lerp(prim.box[1], prim.box[3], 0.18) : lerp(prim.box[1],prim.box[3],0.45);
      const du = Math.min(Math.abs(pu-1/3), Math.abs(pu-2/3)), dv = Math.min(Math.abs(pv-1/3), Math.abs(pv-2/3));
      placement = 0.72*Math.exp(-Math.pow(du/0.085,2)) + 0.28*Math.exp(-Math.pow(dv/0.11,2));
      const centered = Math.abs(pu-0.5) < 0.06;
      if (centered && M.vp && Math.abs(M.vp[0]-0.5) < 0.06 && meta.streetAlign > 0.5){ placement = Math.max(placement, 0.85); pos.push(["comp",`Centering ${subjName(prim)} in the street's vanishing point makes a strong, symmetrical frame.`]); }
      else if (centered){ placement = Math.max(placement, 0.42); if (placement < 0.5) tips.push(`${cap(subjName(prim))} sits dead centre. Try placing them on a third, with space in the direction they're looking or moving.`); }
      else if (placement > 0.75) pos.push(["comp",`${cap(subjName(prim))} lands right on a thirds line.`]);
      const a = prim.area;
      size = a < 0.0025 ? 0.28 : a < 0.01 ? 0.62 : a < 0.5 ? 1 : 0.72;
      if (a < 0.0025) neg.push(["comp",`${cap(subjName(prim))} is tiny in the frame. Get closer or use a longer lens.`, 2]);
      if (a >= 0.5) neg.push(["comp",`${cap(subjName(prim))} crowds the frame; there's no room to breathe.`, 1]);
      if (prim.dirU !== 0){
        const room = prim.dirU > 0 ? 1 - pu : pu;
        lead = room > 0.5 ? 1 : room > 0.36 ? 0.72 : 0.3;
        if (room <= 0.36) neg.push(["comp",`${cap(subjName(prim))} is ${prim.speed>0.25?"walking":"looking"} straight out of the frame. Leave space ahead of them.`, 2]);
        else if (room > 0.55 && Math.abs(prim.dirU) > 0.3) pos.push(["comp",`Good lead room: there's space for ${subjName(prim)} to move into.`]);
      }
      if (prim.clipped > 0.05 && prim.clipped < 0.75){ clipS = 1 - prim.clipped*1.1; neg.push(["comp",`The frame edge cuts through ${subjName(prim)}.`, prim.clipped > 0.25 ? 2 : 1]); }
      let edgeCuts = 0; for (const s of subs){ if (s === prim || s.kind==="car") continue; if (s.clipped > 0.12 && s.clipped < 0.7 && s.area > 0.004) edgeCuts++; }
      if (edgeCuts){ clipS -= Math.min(0.24, edgeCuts*0.08); if (edgeCuts >= 2) neg.push(["comp",`Several people are sliced by the frame edges. Watch the borders before you press.`, 1]); }
    } else {
      placement = 0.35 + meta.streetAlign*0.3; size = 0.45;
      neg.push(["subj", "There's no clear subject here.", 3]);
    }
    // tilt
    const at = Math.abs(tilt); let tiltS = 1;
    if (at >= 0.8 && at < 3){ tiltS = 0.52; neg.push(["comp",`The horizon is ${at.toFixed(1)}° off. Small tilts read as mistakes. Level it in the darkroom.`, 2]); }
    else if (at >= 3 && at < 8){ tiltS = 0.6; neg.push(["comp",`A ${at.toFixed(0)}° tilt looks accidental rather than deliberate.`, 2]); }
    else if (at >= 8 && at < 14){ tiltS = 0.72; }
    else if (at >= 14){ tiltS = 0.85; pos.push(["comp","The strong Dutch angle adds tension."]); }
    else if (meta.streetAlign > 0.4) pos.push(["comp","Verticals are straight and the horizon is level."]);
    // leading lines & layers
    if (meta.streetAlign > 0.55 && M.vp){ const vd = Math.min(Math.abs(M.vp[0]-0.5), Math.abs(M.vp[0]-1/3), Math.abs(M.vp[0]-2/3)); if (vd < 0.08){ bonus += 7*meta.streetAlign; pos.push(["comp","The street's lines pull the eye deep into the frame."]); } else bonus += 3*meta.streetAlign; }
    const bands = new Set(subs.filter(s=>s.vis>0.35 && s.kind!=="car").map(s=> s.dist<5?0: s.dist<14?1: s.dist<35?2:3)); if (bands.size >= 3){ bonus += 7; pos.push(["comp","Subjects at three different depths give the frame real layers."]); }
    if (M.landmarks.length){ bonus += 4; }
    if (Math.abs(st.balance) > 0.35){ bonus -= 4; }
  if (meta.fgEdge !== undefined && (meta.pitch||0) > -0.35){
    if (meta.fgCenter > 0.3){ bonus -= 12; neg.push(["comp", "Something close to the lens blocks the middle of the frame.", 2]); }
    else if (meta.fgEdge > 0.05 && meta.fgEdge < 0.4 && prim){ bonus += 7; pos.push(["comp", "A shape passing close to the lens frames the scene and adds a layer of depth."]); }
  }
  if (meta.glass) pos.push(["comp", "Shooting through the bus window adds reflections and a sense of place."]);
  if (meta.riding && prim && prim.motion > 6) tips.push("From a moving vehicle, a faster shutter keeps passing subjects sharp, or pan with them.");

    comp = clamp(100*(0.34*placement + 0.14*size + 0.14*lead + 0.24*tiltS + 0.14*clamp(clipS,0,1)) + bonus, 3, 100);
  }

  /* ---------------- subject & moment ---------------- */
  let subj;
  {
    let sum = 0, bonus = 0;
    for (const s of subs){ if (s.vis < 0.2) continue; sum += interestOf(s) * s.vis * clamp(Math.sqrt(s.area)/0.22, 0.12, 1) * (s.kind==="car"?0.6:1); }
    const kinds = new Set(subs.filter(s=>s.vis>0.3 && s.area > 0.0015).map(s=>s.kind));
    const has = k => kinds.has(k);
    if ((has("person")||has("performer")) && has("dog")){ bonus += 5; pos.push(["subj","A person and a dog in one frame: an easy story, and a good one."]); }
    if ((has("person")) && has("cablecar")){ bonus += 7; pos.push(["subj","Pairing a pedestrian with the tram says Snap City without spelling it out."]); }
    if (has("performer") && subs.filter(s=>s.watcher && s.vis>0.3).length >= 2){ bonus += 8; pos.push(["subj","The listeners around the busker make it a scene, not a portrait."]); }
    if (has("birds") && (has("person")||has("dog"))){ bonus += 9; pos.push(["subj","Birds in the air and people on the ground: a genuine decisive moment."]); }
    if (subs.some(s=>s.umbrella && s.vis>0.3) && (meta.fog || meta.time==="morning")){ bonus += 5; pos.push(["subj","The umbrella in the fog sets the mood."]); }
    if (prim && prim.stride > 0.75 && (prim.kind==="person")){ bonus += 5; pos.push(["subj",`You caught ${subjName(prim)} mid-stride. The gesture reads.`]); }
    const GEST = { wave:"the wave", pose:"the pose", block:"the hand coming up", turn:"the turn away", laugh:"the laugh", gesture:"the talking hands", drag:"the drag on the cigarette", exhale:"the exhale", watch:"the glance at the watch", scratch:"the head scratch", stretch:"the stretch", hips:"hands on hips", adjust:"the collar adjustment", argue:"the shouting", point:"the pointing finger", shrug:"the hands thrown up", reaction:"hands flying to the face", kneel:"the kneel", hug:"the embrace", clap:"the applause", dance:"the move", band:"the band in full voice", ollie:"the skater in the air" };
    if (prim && prim.gesture && (prim.kind==="person"||prim.kind==="performer")){
      const gn = GEST[prim.gesture] || "the gesture";
      if (prim.gpeak > 0.72){ bonus += 11; pos.push(["subj", `You pressed the shutter at the height of ${gn}. Timing like that is the whole game.`]); }
      else if (prim.gpeak > 0.35){ bonus += 4; pos.push(["subj", `You caught ${gn}, a beat before or after its peak.`]); }
      else tips.push(`${cap(gn)} was just starting or ending. Anticipate: the peak comes a fraction later or earlier.`);
    }
    if (prim && prim.eye && (prim.kind==="person"||prim.kind==="performer") && prim.area > 0.003){
      if (!prim.aware){ bonus += 14; pos.push(["subj", `${cap(subjName(prim))} glanced straight into your lens for a split second. That look carries the photograph.`]); }
      else { bonus += 12; pos.push(["subj", `${cap(subjName(prim))} stares right down the lens. Confrontational, and it has real power.`]); }
    }
    if (prim && prim.occ > 0.4 && prim.area > 0.004){ bonus -= 12; neg.push(["subj", `Something crossed between you and ${subjName(prim)} at the wrong moment and hid half of them.`, 2]); }
    { const evs = new Set([...subs.filter(s=>s.ev && s.vis > 0.25).map(s=>s.ev), ...Object.keys(meta.events||{}).filter(k=>k==="blackout"||k==="storm"||k==="fog")]);
      for (const ev of evs){ const info = EVENTS[ev]; if (!info) continue; bonus += info.bonus; pos.push(["subj", `You were there for ${info.name}${info.rare ? ", something you may never see again" : ""}.`]); } }
    if (prim && prim.aware && !prim.eye){ bonus -= 10; neg.push(["subj",`${cap(subjName(prim))} saw you coming, and the candid moment is gone. Shoot from a distance or be quicker.`, 2]); }
    else if (prim && (prim.kind==="person"||prim.kind==="performer") && prim.facing > 0.55 && prim.area > 0.008) pos.push(["subj",`${cap(subjName(prim))} faces the lens without noticing it: candid and direct.`]);
    if (prim && prim.kind==="car" && !prim.taxi) tips.push("Cars rarely carry a street photo alone. Wait for a person to walk through the frame.");
    if (!prim) sum = 0;
    subj = prim ? clamp(20 + 62*(1 - Math.exp(-sum/1.05)) + bonus, 5, 100) : (M.landmarks.length ? 30 : 15) + meta.streetAlign*8;
    if (!prim && M.landmarks.length) pos.push(["subj",`${cap(M.landmarks[0].name)} anchors the background, but the foreground needs a human.`]);
  }

  /* ---------------- light & exposure ---------------- */
  let light;
  {
    const target = night ? 0.27 : meta.time==="morning" ? 0.48 : 0.41;
    const hs = Math.exp(-Math.pow((st.mean - target)/0.15, 2));
    const hiAllow = night ? 0.05 : 0.02, loAllow = night ? 0.22 : 0.09;
    let clipF = 1;
    if (st.hi > hiAllow){ clipF -= Math.min(0.45, (st.hi-hiAllow)*5); neg.push(["light","Highlights are blown out. Expose for the brightest thing you care about.", st.hi > 0.08 ? 2 : 1]); }
    if (st.lo > loAllow){ clipF -= Math.min(0.35, (st.lo-loAllow)*3); neg.push(["light","Too much of the frame falls into pure black.", 1]); }
    if (st.mean < target - 0.16) neg.push(["light", `The frame is underexposed. Open up, slow the shutter, or raise ASA${meta.film?" (or shoot where there is more light)":""}.`, 2]);
    else if (st.mean > target + 0.17) neg.push(["light", "The frame is overexposed. Stop down or use a faster shutter.", 2]);
    else if (hs > 0.8 && clipF > 0.9) pos.push(["light","Exposure is spot on."]);
    let q = meta.quality + (meta.fog ? 0.08 : 0), bonus = 0;
    if (meta.filmKind === "slide" && Math.abs(meta.offset) > 0.7){ bonus -= 6; neg.push(["light", `Slide film like ${meta.filmName} has almost no latitude; you were ${Math.abs(meta.offset).toFixed(1)} stops ${meta.offset>0?"over":"under"}.`, 2]); }
    else if ((meta.filmKind === "neg" || meta.filmKind === "bw") && meta.offset > 1.2) pos.push(["light", `${meta.filmName} swallowed ${meta.offset.toFixed(1)} stops of overexposure without complaint.`]);
    if (meta.leak) pos.push(["light", "A light leak burned a warm streak across the frame. Happy accident."]);
    if (meta.rain){ bonus += 4; pos.push(["light", meta.time==="night"||meta.time==="blue" ? "Rain-slick streets double every light in the frame." : "The wet street turns into a soft mirror under the overcast."]); }
    if (meta.instant) pos.push(["color", "The instant film gives it a soft, one-of-a-kind glow."]);
    if (meta.time==="golden") pos.push(["light","Golden-hour light rakes across the street and warms every surface."]);
    if (meta.time==="noon" && !meta.fog) neg.push(["light","Midday light is hard and overhead. Look for shade or come back at golden hour.", 1]);
    if (meta.fog) pos.push(["light","The fog flattens the distance into soft layers."]);
    if (prim && meta.flash){
      if (prim.flashLit > 0.45 && prim.flashLit < 2.2){ bonus += night ? 10 : 4; pos.push(["light", night ? `The flash pops ${subjName(prim)} out of the night.` : "A touch of fill flash lifts the shadows on your subject."]); }
      else if (prim.flashLit >= 2.2){ bonus -= 6; neg.push(["light",`The flash burned out ${subjName(prim)}. Step back or stop down.`, 2]); }
      else if (night) tips.push("Your flash didn't reach the subject. Get closer or raise the ASA.");
    }
    if (meta.syncWarn){ bonus -= 5; neg.push(["light","Your shutter was faster than the flash sync speed, so a dark band crept into the frame.", 1]); }
    light = clamp(100*(0.56*hs*clamp(clipF,0.2,1) + 0.44*q) + bonus, 3, 100);
  }

  /* ---------------- sharpness ---------------- */
  let sharp;
  {
    const shake = (meta.shakePx||0);
    let blur, noteSubject = prim;
    if (prim){ blur = Math.hypot(prim.coc*1.4, prim.motion, shake) * mag; }
    else blur = shake*mag;
    let sS = 1/(1 + Math.pow(blur/2.6, 2));
    if (prim){
      if (prim.coc*1.4 > 3 && prim.coc*1.4 >= Math.max(prim.motion, shake)) neg.push(["sharp",`${cap(subjName(prim))} is out of focus (focus was at ${fmtDist(meta.focus)}, they were ${fmtDist(prim.dist)} away).`, 2]);
      else if (prim.motion > 3 && prim.motion >= shake) neg.push(["sharp",`${cap(subjName(prim))} is smeared by motion. Use at least 1/${Math.max(250, Math.round(1/Math.max(meta.t,1e-4)*prim.motion/1.5/10)*10)} for moving people.`, 2]);
      else if (shake > 3) neg.push(["sharp",`Camera shake blurred the whole frame. At ${fmtShutter(meta.t)}${meta.walking?" while walking":""} your hands can't hold steady.`, 2]);
      else if (blur < 1.4) pos.push(["sharp",`${cap(subjName(prim))} is crisp.`]);
      // subject isolation
      const bgCoc = prim.coc < 1.2 ? cocPxMeta(meta, prim.dist*3) : 0;
      if (prim.coc < 1.2 && bgCoc > 6 && prim.area > 0.01){ sS = Math.min(1, sS + 0.06); pos.push(["sharp","Shallow depth of field separates your subject from the busy street."]); }
    } else if (shake > 3) neg.push(["sharp","Camera shake softened the frame.", 1]);
    const nz = (meta.noise||0) * mag;
    let pen = clamp((nz-5)/24, 0, 0.35);
    if (pen > 0.12) neg.push(["sharp",`High-ASA noise (ASA ${meta.iso}) eats the detail${edit&&edit.zoom>1.3?", and the tight crop magnifies it":""}.`, 1]);
    if (meta.film){ pen = clamp((nz-10)/30, 0, 0.3); if (nz > 14 && mono) { pen *= 0.4; pos.push(["sharp","The heavy grain suits black and white."]); } else if (pen > 0.1) neg.push(["sharp",`The grain from ${meta.filmName}${meta.push>0?` pushed ${meta.push} stop${meta.push>1?"s":""}`:""} breaks up the detail.`, 1]); }
    if (edit && edit.grain > 25 && !meta.film) pen += 0.04;
    if (meta.hip) tips.push("Shooting from the hip is quick and discreet, but you can't control framing. Raise the camera when there's time.");
    sharp = clamp(100*sS*(1-pen), 3, 100);
  }

  /* ---------------- colour & tone ---------------- */
  let color;
  {
    const sdT = mono ? 0.24 : 0.2; const conS = Math.exp(-Math.pow((st.sd - sdT)/0.1, 2));
    if (mono){
      color = 100*(0.7*conS + 0.3);
      if (st.sd > 0.2) pos.push(["color","Rich blacks and bright whites give the monochrome real punch."]);
      else neg.push(["color","The black and white is flat and grey. Add contrast.", 1]);
      if (prim && prim.umbrella && prim.vivid) tips.push("That bright umbrella would have sung in colour.");
    } else {
      let satS = st.sat < 0.07 ? 0.55 : st.sat < 0.42 ? 1 : st.sat < 0.55 ? 0.8 : 0.45;
      if (st.sat >= 0.55) neg.push(["color","The colours are cranked too hard and look garish.", 2]);
      const hue = st.hue; let harm = 0.55;
      const top = hue.map((v,i)=>[v,i]).sort((a,b)=>b[0]-a[0]);
      const adj = top[0][0] + hue[(top[0][1]+1)%12] + hue[(top[0][1]+11)%12];
      if (adj > 0.72){ harm = 0.9; pos.push(["color","A tight, harmonious palette."]); }
      for (let i=0;i<12;i++){ const opp = hue[(i+6)%12] + hue[(i+5)%12]*0.5 + hue[(i+7)%12]*0.5; if (hue[i] > 0.14 && opp > 0.16){ harm = Math.max(harm, 0.95); if (!pos.some(p=>p[1].includes("Complementary"))) pos.push(["color","Complementary colours play off each other."]); break; } }
      let bonus = 0;
      if (prim && prim.vivid && st.sat < 0.3){ bonus += 9; pos.push(["color",`The bright colour on ${subjName(prim)} is the only loud note in a quiet palette: exactly where the eye goes.`]); }
      color = clamp(100*(0.38*satS + 0.34*harm + 0.28*conS) + bonus, 3, 100);
      if (conS < 0.4) neg.push(["color", st.sd < sdT ? "Tonally flat. A little more contrast would help." : "The contrast is harsh.", 1]);
    }
  }

  /* ---------------- total ---------------- */
  let total = 0.25*comp + 0.25*subj + 0.2*light + 0.15*sharp + 0.15*color;
  // a frame without a subject can't score highly
  if (!prim) total = Math.min(total, 48);
  // duplicates
  const dup = (S.shotLog||[]).find(l => l.id !== rec.id && l.prim && l.prim === meta.primaryKey && Math.abs(l.ts - rec.ts) < 25000 && l.ts < rec.ts);
  if (dup){ total -= 5; neg.push(["subj","You already shot this moment a few seconds earlier; editors pick one.", 1]); }
  total = Math.round(clamp(total, 1, 99));
  const cats = { comp:Math.round(comp), subj:Math.round(subj), light:Math.round(light), sharp:Math.round(sharp), color:Math.round(color) };
  return { total, cats, critique: writeCritique(total, cats, pos, neg, tips, prim, meta, mono), verdict: verdictFor(total), primary: prim ? subjName(prim) : null };
}
function cap(s){ return s.charAt(0).toUpperCase() + s.slice(1); }
function fmtDist(d){ return d >= 100 ? "infinity" : d < 10 ? d.toFixed(1)+" m" : Math.round(d)+" m"; }
function cocPxMeta(meta, D){ const fAct = (meta.fAct || meta.feq || 50)/1000, sw = (meta.fmtW || 36)/1000; return 0.5*((fAct*fAct/meta.N)*Math.abs(D-meta.focus)/(D*Math.max(meta.focus-fAct,0.01))/sw)*(meta.W||1500); }
function verdictFor(t){ return t >= 86 ? "Portfolio frame." : t >= 74 ? "A keeper." : t >= 62 ? "Almost there." : t >= 47 ? "Contact-sheet filler." : "Walk on."; }
function writeCritique(total, cats, pos, neg, tips, prim, meta, mono){
  const P = [];
  const catNames = { comp:"composition", subj:"subject and moment", light:"light", sharp:"sharpness", color: mono ? "tone" : "colour" };
  const bestCat = Object.entries(cats).sort((a,b)=>b[1]-a[1])[0][0], worstCat = Object.entries(cats).sort((a,b)=>a[1]-b[1])[0][0];
  const open = total >= 74 ? `This one works. Its strength is ${catNames[bestCat]}.` : total >= 55 ? `There's a real photograph in here, held back mostly by ${catNames[worstCat]}.` : `This frame doesn't come together yet; ${catNames[worstCat]} is the weak point.`;
  const posPick = pos.filter((p,i,arr)=>arr.findIndex(q=>q[1]===p[1])===i).sort((a,b)=> (b[0]===bestCat) - (a[0]===bestCat)).slice(0, 3).map(p=>p[1]);
  P.push([open].concat(posPick).join(" "));
  const negPick = neg.sort((a,b)=>b[2]-a[2]).slice(0, 3).map(n=>n[1]);
  if (negPick.length) P.push(negPick.join(" "));
  const tip = tips[0] || (worstCat==="light" ? "Try the same corner at golden hour or in the fog." : worstCat==="comp" ? "Before pressing, check the four corners and the horizon." : worstCat==="subj" ? "Find a good background, then wait for the right person to walk into it." : worstCat==="sharp" ? "Watch the shutter speed readout: faster than 1/250 freezes walkers." : "Consider the palette: a single strong colour against muted surroundings is stronger than many.");
  P.push(tip);
  return P;
}

/* ---------- rewards ---------- */
function payFor(score){ return Math.round(score*score/60); }
function applyJudgement(rec, res){
  const prevBest = rec.bestScore || 0;
  rec.score = res.total; rec.cats = res.cats; rec.critique = res.critique; rec.verdict = res.verdict; rec.judged = true;
  let money = 0, xp = 0;
  if (res.total > prevBest){ money = payFor(res.total) - payFor(prevBest); xp = Math.round(res.total - prevBest*0.8); rec.bestScore = res.total; }
  if (!S.free) S.money += money;
  S.xp += xp; let ups = 0;
  while (S.xp >= levelXp(S.level)){ S.xp -= levelXp(S.level); S.level++; S.skillPts++; ups++; }
  S.judgedBest = Math.max(S.judgedBest||0, res.total);
  saveState();
  return { money, xp, ups };
}
