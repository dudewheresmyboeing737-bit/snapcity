
/* =========================================================
   Contact Sheet v14.2 — tram, settings copy, bars, glass,
   3D shop-window people, calmer traffic.
   ========================================================= */
(function(){
"use strict";
const CS142=window.CS142={rails:null,trolleys:[],shopPeople:[],drink:0,barBought:false,glassMeshes:[],lastShop:null,curbBuilt:false};

/* ----- requested defaults / migration ----- */
function migrate142(){
  if(!S||!S.custom||S.custom._v142Applied)return;
  S.custom.trafficDensity="normal";      // slightly calmer street
  S.custom.streetcars="2";              // trams should feel special
  S.custom._v142Applied=true;
  saveState();
}

/* ----- every settings row gets visible copy ----- */
const CS142_DESC={
"Active editor":"Changes which editor personality weighs composition, gesture, light and technical execution most heavily.",
"Birds":"Controls how much pigeon, gull and crow activity you see around the city.",
"Blowing litter":"Lets loose paper and light trash react to wind gusts.",
"Button size":"Changes the size of touch-screen action buttons without changing gameplay.",
"Joystick size":"Changes the touch movement joystick size. Small is the default.",
"Café coffee":"Allows the hidden $2 coffee purchase that briefly steadies your hands.",
"Camera finish":"Changes the cosmetic finish of the camera you see in your hands.",
"Camera kits":"Shows quick camera-and-lens presets built around different shooting styles.",
"Character variety":"Controls how aggressively faces, clothes, hair, accessories and silhouettes are remixed.",
"City ambience":"Sets the volume of traffic wash, distant voices and general street sound.",
"Clock":"Choose whether time continues to pass or the current light is held.",
"Clouds":"Adds occasional cloud banks that drift with the wind and change the feel of the sky.",
"Colour-vision filter":"Applies an accessibility preview for different forms of colour vision.",
"Crosswalk timing":"Changes how long traffic and pedestrian signals remain in each phase.",
"Editor detail":"Controls how specific and extensive the written photo critique becomes.",
"Editor overlays":"Shows optional composition and technical overlays while reviewing photographs.",
"Editor personality":"Lets different fictional editors respond to photographs from different priorities.",
"Editors pay":"Changes how much career money good photographs earn.",
"Essay enhancement":"Adds longer sequences, more themes and a gallery-wall view to photo essays.",
"Event notice":"Controls whether street events are announced by sound, a written clue, or both.",
"Event pace":"Changes how frequently unusual street situations develop nearby.",
"Event pins":"Controls how much help the minimap gives you locating active street events.",
"Events & sirens":"Changes the loudness of event-specific sound, sirens and commotion.",
"Exposure coach":"Optional exposure advice. Foolproof also keeps Program mode near a neutral exposure.",
"Heritage streetcars":"Sets how many vintage streetcars are operating. Two keeps them noticeable but uncommon.",
"Film advance":"Automatic advances after every frame; manual makes mechanical cameras require winding.",
"Film grain":"Changes the visible strength of the loaded film stock's grain rendering.",
"Film prices":"Adjusts the career-mode cost of buying and loading film.",
"Fog density":"Changes how heavily distance is obscured when fog is active.",
"Fog rolling in":"Turns bay fog on or off for the current weather state.",
"Halation & glow":"Controls the red/orange glow film can produce around strong highlights.",
"Handheld steadiness":"Changes baseline hand movement before shutter speed, lens length and skills are considered.",
"Invert look":"Reverses vertical mouse/touch look direction.",
"Judging":"Makes the editor more forgiving or more demanding when scoring photographs.",
"Jump":"Changes jump height for obstacles, cars and rooftop traversal.",
"Last-frames heartbeat":"Adds an audible warning when a roll is almost finished.",
"Layout":"Changes the on-screen touch-control arrangement.",
"Lens filter":"Mounts an optical filter that changes exposure and/or the rendered photograph.",
"Light leaks (toy cameras)":"Changes the frequency and strength of simulated toy-camera light leaks.",
"Look around with":"Chooses the alternate control method for looking around without the mouse.",
"Menu style":"Changes the Camera Bag's visual treatment.",
"Motion comfort":"Reduces or removes UI and camera transitions for motion-sensitive players.",
"Mouse sensitivity":"Changes how quickly the view turns with mouse movement.",
"Neighborhood identity":"Shows district character and the current rhythm of the neighborhood.",
"Neon signs":"Controls how many storefront signs glow, especially toward evening and night.",
"Panel side":"Moves the compact exposure panel to the left or right side of the screen.",
"Pedestrians":"Changes how crowded the sidewalks feel.",
"People in windows":"Adds occasional figures behind shop and upper-floor windows.",
"Perfect Program exposure":"Corrects the intentionally sky-weighted meter when using Program mode.",
"Photo preview":"Shows or hides the small frame preview immediately after taking a photograph.",
"Photographer":"Sets the photographer name printed on contact-sheet presentation elements.",
"Photorealism":"Enables the more expensive material, lighting and rendering enhancements.",
"Preview time":"Changes how long the last-frame corner preview remains visible.",
"Profile":"Applies a group of difficulty and assistance settings in one click.",
"Project title":"Names the current photo essay or sequence.",
"Push / pull":"Rates the next roll above or below box speed, affecting exposure and development character.",
"Quick adjustments":"Shows or hides fast camera-setting controls during play.",
"Quick dial":"Shows aperture, shutter, ASA, focus and EV controls along the bottom of the screen.",
"Rain":"Turns rainfall and wet-street effects on or off.",
"Reduced shake":"On removes ordinary simulated hand shake; situational effects can still disturb the camera.",
"Reflections":"Changes the quality and cost of wet-road, glass and vehicle reflections.",
"Render quality":"Balances sharpness, effects and GPU load.",
"Roof-to-roof parkour":"Allows jumping between reachable rooftops while exploring above street level.",
"Scene ecology":"Lets crowds and animals react to one another instead of behaving as isolated props.",
"Screen display":"Controls how much HUD information is visible while walking.",
"Side exposure panel":"Shows aperture, shutter, ISO and frame count beside the viewfinder.",
"Snow":"Turns snowfall on or off for an unusual winter-weather option.",
"Special traffic":"Allows unusual vehicles to appear among ordinary city traffic.",
"Speed of the day":"Changes how quickly the in-game clock advances from morning through night.",
"Strap":"Changes the visible camera-strap colour.",
"Street detail":"Controls the density of hydrants, bins, mailboxes, signs and other small street objects.",
"Streetcar bells":"Turns nearby cable-car/streetcar bell sounds on or off.",
"String lights":"Shows or hides decorative storefront string lights.",
"Swipe to look":"Changes how touch dragging controls the camera.",
"Text size":"Changes menu and interface text size.",
"Time scale":"Slows the whole simulation without changing the in-world clock setting; Normal is full speed.",
"Traffic":"Changes how many ordinary vehicles remain active around you.",
"Transit on the map":"Shows moving buses and streetcars on the minimap.",
"Vehicle variety":"Controls how many body styles, paints, trims and accessories traffic can recombine.",
"Vibration":"Enables or disables touch-device vibration feedback.",
"Viewfinder grid":"Changes composition guides inside the raised camera viewfinder.",
"Viewfinder preview":"Optical shows the live scene; film preview approximates the loaded stock before exposure.",
"Volume":"Sets the game's overall audio level.",
"Wait mode":"Allows planting your feet to reduce movement while waiting for a composition.",
"Walking camera motion":"Changes head-bob strength while moving through the city.",
"Walking field of view":"Changes peripheral field of view while the camera is lowered.",
"Walking pace":"Changes normal and running movement speed.",
"Weather changes":"Lets weather evolve automatically or remain under manual control.",
"Weather polish":"Enables glare, mist, puddle shimmer and other atmosphere details.",
"Wind":"Changes the city's base wind strength.",
"Wind drama":"Controls how strongly gusts affect litter, umbrellas, hats and visual atmosphere.",
"Window glass":"Changes storefront reflection strength. Clear is easiest for shooting through glass."
};
function fallbackDesc(name){
  const n=name.toLowerCase();
  if(n.includes("camera")||n.includes("viewfinder")||n.includes("lens"))return `Changes how ${name.toLowerCase()} behaves or appears while photographing.`;
  if(n.includes("event"))return `Adjusts how ${name.toLowerCase()} affects street events.`;
  if(n.includes("weather")||n.includes("fog")||n.includes("rain")||n.includes("snow")||n.includes("wind"))return `Adjusts the city's ${name.toLowerCase()} effect.`;
  if(n.includes("film"))return `Changes the film-related behaviour for ${name.toLowerCase()}.`;
  return `Adjusts ${name.toLowerCase()} for your preferred way of playing.`;
}
function applySettingDescriptions(){
  document.querySelectorAll("#menu .formrow").forEach(row=>{
    const lab=row.querySelector("label"); if(!lab)return;
    const name=lab.childNodes[0] ? String(lab.childNodes[0].textContent||lab.textContent).trim() : lab.textContent.trim();
    let spec=row.querySelector(":scope > .spec");
    if(!spec){spec=document.createElement("span");spec.className="spec cs142-desc";row.appendChild(spec);} else spec.classList.add("cs142-desc");
    if(!spec.textContent.trim())spec.textContent=CS142_DESC[name]||fallbackDesc(name);
    else if(!CS142_DESC[name]) CS142_DESC[name]=spec.textContent.trim();
    // Prefer our concise, permanent copy for settings rows.
    if(CS142_DESC[name]) spec.textContent=CS142_DESC[name];
  });
}
{const base=renderMenu;renderMenu=function(...a){const r=base(...a);applySettingDescriptions();return r;};}

/* ----- curb readability: already 16 cm high, add a strong visible lip; automatic step-up remains ----- */
function buildCurbAccents(){
  if(CS142.curbBuilt||!G.scene)return; CS142.curbBuilt=true;
  // Follow the terrain. The old version laid one straight 78 m bar per curb at the
  // lot-centre height, so on hills one end floated metres above the street.
  const mat=new THREE.MeshStandardMaterial({color:lin("#aaa69d"),roughness:.96,side:THREE.DoubleSide});
  const STEP=2, HW=.04, Y0=.065, Y1=.145;
  for(const l of (World.lots||[])){
    const x0=l.x0-SWK, x1=l.x1+SWK, z0=l.z0-SWK, z1=l.z1+SWK;
    const pos=[], nor=[];
    const quad=(a,b,c,d,n)=>{ for(const v of [a,b,c,a,c,d]){ pos.push(v[0],v[1],v[2]); nor.push(n[0],n[1],n[2]); } };
    for(const [ax,az,bx,bz] of [[x0,z0,x1,z0],[x1,z0,x1,z1],[x1,z1,x0,z1],[x0,z1,x0,z0]]){
      const L=Math.hypot(bx-ax,bz-az), n=Math.max(1,Math.ceil(L/STEP));
      const tx=(bx-ax)/L, tz=(bz-az)/L, ox=tz, oz=-tx; // outward side of the clockwise loop
      for(let k=0;k<n;k++){
        const pa=[ax+(bx-ax)*k/n, az+(bz-az)*k/n], pb=[ax+(bx-ax)*(k+1)/n, az+(bz-az)*(k+1)/n];
        const ha=H(pa[0],pa[1]), hb=H(pb[0],pb[1]);
        const P=(p,h,side,y)=>[p[0]+ox*HW*side, h+y, p[1]+oz*HW*side];
        quad(P(pa,ha,-1,Y1),P(pa,ha,1,Y1),P(pb,hb,1,Y1),P(pb,hb,-1,Y1),[0,1,0]);          // top
        quad(P(pa,ha,1,Y0),P(pb,hb,1,Y0),P(pb,hb,1,Y1),P(pa,ha,1,Y1),[ox,0,oz]);          // street face
        quad(P(pb,hb,-1,Y0),P(pa,ha,-1,Y0),P(pa,ha,-1,Y1),P(pb,hb,-1,Y1),[-ox,0,-oz]);    // sidewalk face
      }
    }
    const g=new THREE.BufferGeometry();
    g.setAttribute("position",new THREE.Float32BufferAttribute(pos,3));
    g.setAttribute("normal",new THREE.Float32BufferAttribute(nor,3));
    g.computeBoundingSphere();
    const m=new THREE.Mesh(g,mat); m.receiveShadow=true; m.matrixAutoUpdate=false; m.updateMatrix();
    G.scene.add(m);
  }
}

/* ----- heritage tram model ----- */
function trolleySignTexture(text){
  const c=document.createElement("canvas");c.width=1024;c.height=128;const x=c.getContext("2d");x.fillStyle="#241a12";x.fillRect(0,0,c.width,c.height);x.strokeStyle="#c39a47";x.lineWidth=8;x.strokeRect(7,7,c.width-14,c.height-14);x.fillStyle="#e6b956";x.font="bold 54px Georgia,serif";x.textAlign="center";x.textBaseline="middle";x.fillText(text,c.width/2,c.height/2+3);const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;return t;
}
function trolleyPassenger(seed){
  const r=mulberry(seed),g=new THREE.Group(), skin=lin(["#f1c7a5","#d9a078","#b87950","#875737","#5e3a25"][(r()*5)|0]), top=lin(["#202226","#3f5e7a","#7a2e36","#d7d0c4","#2f5a3a","#9b633d","#4e3f65"][(r()*7)|0]), pants=lin(["#202226","#39455d","#4a443d","#18191b"][(r()*4)|0]);
  const mm=(c,rough=.8)=>new THREE.MeshStandardMaterial({color:c,roughness:rough});
  const torso=new THREE.Mesh(new THREE.BoxGeometry(.34,.58,.22),mm(top));torso.position.y=.93;g.add(torso);
  for(const sx of [-1,1]){const leg=new THREE.Mesh(new THREE.BoxGeometry(.13,.62,.15),mm(pants));leg.position.set(sx*.09,.36,0);g.add(leg);const arm=new THREE.Mesh(new THREE.BoxGeometry(.11,.52,.12),mm(top));arm.position.set(sx*.23,.9,0);arm.rotation.z=sx*(.05+r()*.18);g.add(arm);}
  const head=new THREE.Mesh(new THREE.SphereGeometry(.15,10,8),mm(skin,.72));head.position.y=1.32;head.scale.set(.92+r()*.15,1, .9+r()*.12);g.add(head);
  const hair=new THREE.Mesh(new THREE.SphereGeometry(.155,10,6,0,Math.PI*2,0,Math.PI*.55),mm(lin(["#1b1511","#4a3020","#7b5738","#c5aa73","#777"][(r()*5)|0])));hair.position.y=1.39;g.add(hair);
  g.scale.setScalar(.9+r()*.12);return g;
}
function buildCableCarGroup(seed,route){
  const r=mulberry(seed),g=new THREE.Group(), green=new THREE.MeshStandardMaterial({color:lin("#164d35"),roughness:.48,metalness:.12}), red=new THREE.MeshStandardMaterial({color:lin("#a7472d"),roughness:.52}), cream=new THREE.MeshStandardMaterial({color:lin("#e7d7b7"),roughness:.52}), wood=new THREE.MeshStandardMaterial({color:lin("#7b4f2d"),roughness:.68}), brass=new THREE.MeshStandardMaterial({color:lin("#b98d3d"),roughness:.28,metalness:.72}), dark=new THREE.MeshStandardMaterial({color:lin("#171719"),roughness:.65});
  const add=(geo,mat,x,y,z,rx=0,ry=0,rz=0)=>{const m=new THREE.Mesh(geo,mat);m.position.set(x,y,z);m.rotation.set(rx,ry,rz);m.castShadow=true;m.receiveShadow=true;g.add(m);return m;};
  // underframe / lower body
  add(new THREE.BoxGeometry(2.35,.34,8.8),dark,0,.34,0);
  add(new THREE.BoxGeometry(2.28,.72,8.45),green,0,.78,0);
  for(const sx of [-1,1]) add(new THREE.BoxGeometry(.025,.38,8.0),red,sx*1.145,.82,0);
  // enclosed front cabin (one end), open grip section on the other
  add(new THREE.BoxGeometry(2.23,1.55,3.15),cream,0,1.62,-2.45);
  for(const sx of [-1,1]){ for(const z of [-3.45,-2.7,-1.95]){const win=new THREE.Mesh(new THREE.PlaneGeometry(.62,.82),new THREE.MeshStandardMaterial({color:0x71818b,transparent:true,opacity:.38,roughness:.08,metalness:.18,side:THREE.DoubleSide}));win.position.set(sx*1.125,1.78,z);win.rotation.y=sx>0?Math.PI/2:-Math.PI/2;g.add(win);} }
  // open section: timber floor, benches, posts and side steps
  add(new THREE.BoxGeometry(2.2,.12,4.75),wood,0,1.12,1.65);
  for(const sx of [-1,1]){add(new THREE.BoxGeometry(.32,.09,4.65),wood,sx*.82,1.54,1.55);add(new THREE.BoxGeometry(.18,.08,5.0),wood,sx*1.28,.55,1.55);}
  for(const z of [-.55,.25,1.05,1.85,2.65,3.35]) for(const sx of [-1,1]) add(new THREE.CylinderGeometry(.026,.026,1.75,8),brass,sx*1.07,2.02,z);
  // roof + route boards
  add(new THREE.BoxGeometry(2.72,.18,9.25),cream,0,2.94,0);
  add(new THREE.BoxGeometry(2.56,.09,8.9),dark,0,3.04,0);
  const tex=trolleySignTexture(route),sm=new THREE.MeshBasicMaterial({map:tex,side:THREE.DoubleSide});
  for(const sx of [-1,1]){const p=new THREE.Mesh(new THREE.PlaneGeometry(3.7,.48),sm);p.position.set(sx*1.39,2.78,-.1);p.rotation.y=sx>0?Math.PI/2:-Math.PI/2;g.add(p);}
  // wheels and cable-car details
  for(const z of [-2.75,2.55])for(const sx of [-1,1]){const w=new THREE.Mesh(new THREE.CylinderGeometry(.34,.34,.18,16).rotateZ(Math.PI/2),dark);w.position.set(sx*1.05,.37,z);g.add(w);}
  add(new THREE.BoxGeometry(.9,.05,.12),brass,0,2.36,-4.22);add(new THREE.BoxGeometry(.9,.05,.12),brass,0,2.36,4.22);
  const lamp=new THREE.Mesh(new THREE.SphereGeometry(.13,12,8),new THREE.MeshStandardMaterial({color:0xffdf93,emissive:0xffb03a,emissiveIntensity:1.8}));lamp.position.set(0,1.15,-4.28);g.add(lamp);
  // passengers in fixed slots; visibility changes at stops
  g.userData.riderSlots=[];
  const slots=[]; for(let i=0;i<8;i++)slots.push([i%2?-.72:.72,1.1,-.25+(i>>1)*.9, i%2?Math.PI/2:-Math.PI/2]);
  for(let i=0;i<8;i++)slots.push([i%2?-.96:.96,.58,.35+(i>>1)*.82, i%2?Math.PI/2:-Math.PI/2]);
  slots.forEach((q,i)=>{const p=trolleyPassenger(seed*100+i);p.position.set(q[0],q[1],q[2]);p.rotation.y=q[3];g.add(p);g.userData.riderSlots.push(p);});
  return g;
}
function setTrolleyRiders(c,count){if(!c||!c.g||!c.g.userData.riderSlots)return;c.riderCount=clamp(count|0,1,c.g.userData.riderSlots.length);c.g.userData.riderSlots.forEach((p,i)=>p.visible=i<c.riderCount);}
function remodelTrolleys(){
  if(!Life.cars||!G.scene)return; const tr=Life.cars.filter(c=>c.trolley);
  tr.forEach((c,i)=>{if(i>=2){c.off=true;c.g.visible=false;return;}const old=c.g,route=i%2?"CALIFORNIA & MARKET":"POWELL & HYDE STS";const g=buildCableCarGroup(1420+i,route);g.position.copy(old.position);g.rotation.copy(old.rotation);G.scene.remove(old);G.scene.add(g);c.g=g;c.off=false;c.vmax=5.4;c.speed=Math.max(c.speed||0,2.8);c._stopWas=0;setTrolleyRiders(c,5+((Math.random()*8)|0));CS142.trolleys.push(c);});
}
function buildRails(){
  if(CS142.rails||!CS142.trolleys.length)return;const g=new THREE.Group(),steel=new THREE.MeshStandardMaterial({color:lin("#777b7f"),roughness:.28,metalness:.9}),tie=new THREE.MeshStandardMaterial({color:lin("#4b382a"),roughness:.92});
  const zs=[...new Set(CS142.trolleys.map(c=>Number(c.z.toFixed(2))))];
  for(const z of zs)for(let x=-300;x<=300;x+=6){const y=H(x,z)+.035,pitch=-Math.atan2(H(x+3,z)-H(x-3,z),6);for(const dz of [-.72,.72]){const m=new THREE.Mesh(new THREE.BoxGeometry(6,.035,.055),steel);m.position.set(x,y,z+dz);m.rotation.z=pitch;g.add(m);}if(x%12===0){const t=new THREE.Mesh(new THREE.BoxGeometry(.14,.035,1.75),tie);t.position.set(x,y-.015,z);g.add(t);}}
  G.scene.add(g);CS142.rails=g;
}
function trolleyStopLife(){
  for(const c of CS142.trolleys){if(c.off)continue;const now=c.stopT>0;if(now&&!c._stopWas){const delta=((Math.random()*7)|0)-3;setTrolleyRiders(c,clamp((c.riderCount||6)+delta,2,14));if(Math.hypot(c.x-Player.x,c.z-Player.z)<28)toast(delta>0?`${delta} people climb aboard the streetcar.`:delta<0?`${Math.abs(delta)} riders step off at the stop.`:`The streetcar pauses; nobody gets on this time.`,1300);}c._stopWas=now?1:0;}
}

/* ----- occupied city bus must keep moving ----- */
function forceOccupiedBus(dt){
  if(!(GP.ride&&GP.ride.kind==="bus"))return;const b=GP.ride.v;if(!b||b.trolley)return;
  const dir=b.lane>0?1:-1;b.stopT=0;b.lastStop=Math.round(b.x/P)*P;b.vmax=Math.max(b.vmax||0,7.2);
  if((b.speed||0)<3.8){const boost=(3.8-(b.speed||0));b.speed=3.8;b.x+=dir*boost*dt;if(b.x>300)b.x=-300;if(b.x<-300)b.x=300;b.g.position.set(b.x,H(b.x,b.z)+.02,b.z);}
}

/* ----- $4 bar drink easter egg: deliberately bad for steady photography ----- */
function cs142Status(){let e=document.getElementById("cs142Status");if(!e){e=document.createElement("div");e.id="cs142Status";document.body.appendChild(e);}if(CS142.drink>0){e.textContent=`BAR DRINK · ${Math.ceil(CS142.drink)}s · shaky hands`;e.classList.add("on");}else e.classList.remove("on");}
{const baseEnter=enterShop,baseLeave=leaveZone,baseAction=enterAction;
 enterShop=function(sh){CS142.barBought=false;CS142.lastShop=sh;const r=baseEnter(sh);try{const th=SHOPS[sh.theme];if(th&&th.id==="bar")toast(`At ${th.names[0]}. Press Enter again to order a $4 drink — if you have the cash.`,2600);}catch(e){}return r;};
 leaveZone=function(){const r=baseLeave();CS142.barBought=false;CS142.lastShop=null;return r;};
 enterAction=function(){if(ZONE.mode==="shop"&&CS142.lastShop&&!CS142.barBought){const th=SHOPS[CS142.lastShop.theme];if(th&&th.id==="bar"){if(S.money<4){toast("The drink is $4. You don't have enough.",1700);CS142.barBought=true;return;}S.money-=4;CS142.drink=90;CS142.barBought=true;saveState();toast("$4 drink. For the next minute and a half your hands are noticeably less reliable.",2400);return;}}return baseAction();};
}
if(typeof effectiveShakeMult==="function"){const baseShake=effectiveShakeMult;effectiveShakeMult=function(){const b=baseShake();return CS142.drink>0?Math.max(2.8,b*3.2):b;};}
{const base=updatePlayer;updatePlayer=function(dt){base(dt);if(CS142.drink>0){const a=.012+.012*Math.min(1,CS142.drink/25),t=Game.t;G.cam.rotation.x+=Math.sin(t*2.13)*a;G.cam.rotation.y+=Math.sin(t*1.37+1.8)*a*.7;G.cam.rotation.z+=Math.sin(t*1.79+.3)*a*1.25;}};}

/* ----- clear shop glass from the inside, while keeping the exterior treatment outside ----- */
function findGlassMeshes(){CS142.glassMeshes=[];if(!G.scene||!World.mats||!World.mats.glass)return;G.scene.traverse(o=>{if(o.isMesh&&o.material===World.mats.glass)CS142.glassMeshes.push(o);});}
function setInsideGlass(hidden){if(!CS142.glassMeshes.length)findGlassMeshes();CS142.glassMeshes.forEach(m=>m.visible=!hidden);}
{const baseEnter=enterShop,baseLeave=leaveZone;enterShop=function(sh){const r=baseEnter(sh);setInsideGlass(true);return r;};leaveZone=function(){setInsideGlass(false);return baseLeave();};}

/* ----- real 3D figures at shop windows (replaces flat/cardboard impression) ----- */
function miniShopPerson(seed){
 const r=mulberry(seed),g=new THREE.Group(),skin=lin(["#f2ceb0","#dca77f","#c1845c","#9a6543","#71472e","#4d3020"][(r()*6)|0]),top=lin(["#25282d","#3f5e7a","#7b3432","#d9d2c4","#376149","#7a5f3d","#59486f","#c58b32"][(r()*8)|0]),bottom=lin(["#202226","#37435d","#51483e","#17181a"][(r()*4)|0]),hair=lin(["#1b1511","#3e2a1d","#6e4a2d","#b99966","#777"][(r()*5)|0]);
 const mk=(geo,c,rough=.78)=>new THREE.Mesh(geo,new THREE.MeshStandardMaterial({color:c,roughness:rough}));
 const torso=mk(new THREE.BoxGeometry(.38,.62,.23),top);torso.position.y=1.02;g.add(torso);
 for(const sx of [-1,1]){const leg=mk(new THREE.BoxGeometry(.14,.68,.16),bottom);leg.position.set(sx*.1,.36,0);g.add(leg);const arm=mk(new THREE.CylinderGeometry(.055,.065,.55,8),top);arm.position.set(sx*.24,.98,0);arm.rotation.z=sx*(.08+r()*.28);g.add(arm);}
 const head=mk(new THREE.SphereGeometry(.16,12,9),skin,.7);head.position.y=1.44;head.scale.set(.88+r()*.2,1,.9+r()*.15);g.add(head);
 const hs=(r()*5)|0;if(hs!==4){const hg=hs===0?new THREE.SphereGeometry(.17,12,7,0,Math.PI*2,0,Math.PI*.55):hs===1?new THREE.BoxGeometry(.28,.12,.26):hs===2?new THREE.SphereGeometry(.19,10,7):hs===3?new THREE.CylinderGeometry(.17,.17,.12,12):new THREE.SphereGeometry(.17,10,7);const h=mk(hg,hair);h.position.y=1.53;if(hs===1)h.position.z=-.02;g.add(h);}
 // nose / mouth give the face some readable volume
 const nose=mk(new THREE.ConeGeometry(.035,.09,7).rotateX(Math.PI/2),skin,.65);nose.position.set(0,1.44,.15);g.add(nose);const mouth=mk(new THREE.BoxGeometry(.07,.018,.012),lin(r()<.5?"#6e3430":"#3a2523"),.8);mouth.position.set(0,1.38,.158);g.add(mouth);
 return g;
}
function rebuildShopWindowPeople(){
 if(!World.shops||!G.scene)return;
 if(window.CS14&&CS14.windowPeople){for(const w of CS14.windowPeople)if(w.g)G.scene.remove(w.g);CS14.windowPeople.length=0;}
 for(const w of CS142.shopPeople)G.scene.remove(w.g);CS142.shopPeople=[];
 const r=mulberry(142142);let made=0;
 for(let i=0;i<World.shops.length&&made<22;i+=2){const sh=World.shops[i],count=r()<.35?2:1;for(let j=0;j<count&&made<22;j++){const g=miniShopPerson(142000+i*7+j),along=(j-(count-1)/2)*.9+(r()-.5)*Math.min(1.4,sh.w*.18),n=sh.n,t=[n[1],-n[0]];g.position.set(sh.x+t[0]*along+n[0]*.045,sh.gy+.02,sh.z+t[1]*along+n[1]*.045);g.rotation.y=sh.ry+(r()-.5)*.3;g.scale.setScalar(.9+r()*.12);G.scene.add(g);CS142.shopPeople.push({g,phase:r()*6});made++;}}
}

/* ----- update loop ----- */
{const base=gameplayUpdate;gameplayUpdate=function(dt){base(dt);if(CS142.drink>0)CS142.drink=Math.max(0,CS142.drink-dt);cs142Status();trolleyStopLife();forceOccupiedBus(dt);for(const p of CS142.shopPeople){p.g.rotation.z=Math.sin(Game.t*.45+p.phase)*.012;}};}

/* ----- boot polish ----- */
{const base=boot;boot=async function(){await base();migrate142();buildCurbAccents();try{remodelTrolleys();buildRails();rebuildShopWindowPeople();findGlassMeshes();}catch(e){console.warn("[v14.2] optional visual polish skipped",e);}applySettingDescriptions();saveState();};}
console.log("[Contact Sheet v14.2] tram / settings / interiors patch loaded.");
})();
