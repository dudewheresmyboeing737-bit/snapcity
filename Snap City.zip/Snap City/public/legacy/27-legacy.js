
/* =========================================================
   Photographer's Cut v14.3
   skyline landmarks, gear navbar, editor cleanup, better critiques,
   calmer awareness, bridge closer, clouds/shadows, transit fixes.
   ========================================================= */
(function(){
"use strict";
const CS143 = window.CS143 = { landmarkGroup:null, cloudGroup:null, shadowGroup:null, applied:false };

function hashStr(s){ s=String(s||""); let h=2166136261>>>0; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619); } return h>>>0; }
function choice(arr, h, off=0){ return arr[(Math.abs((h+off)|0)) % arr.length]; }
function clamp01(x){ return Math.max(0, Math.min(1, x)); }

/* ----- defaults / migration ----- */
function migrate143(){
  if(!window.S || !S.custom || S.custom._v143Applied) return;
  S.custom.tJoy = "small";
  S.custom.eventNotify = "clue";
  S.custom.flagsOn = "off";
  S.custom.trafficDensity = "normal";
  S.custom._v143Applied = true;
  try{ saveState(); }catch(e){}
}

/* ----- all settings get short visible descriptions, and flag settings disappear ----- */
const EXTRA_DESC = {
  "Cameras":"Browse and buy camera bodies only — from disposables to serious rangefinders and SLRs.",
  "Lenses":"Shows lenses that fit your current body, along with their character and approximate field of view.",
  "Flashes":"Choose between available light, built-in flash and dedicated flash units.",
  "Filters":"Optical filters change colour, reflections, exposure and sometimes the character of the image itself."
};
function applyMenuPolish(){
  const body = document.querySelector('#menubody'); if(!body) return;
  body.querySelectorAll('.formrow').forEach(row=>{
    const label = row.querySelector('label'); if(!label) return;
    const txt = (label.childNodes[0] && label.childNodes[0].textContent ? label.childNodes[0].textContent : label.textContent || '').trim();
    if(/flags/i.test(txt)){ row.remove(); return; }
    let spec = row.querySelector(':scope > .spec.cs143-desc') || row.querySelector(':scope > .spec');
    if(!spec){ spec = document.createElement('span'); spec.className = 'spec cs143-desc'; row.appendChild(spec); }
    spec.classList.add('cs143-desc');
    if(!spec.textContent.trim()) spec.textContent = EXTRA_DESC[txt] || `Adjusts ${txt.toLowerCase()} for the way you want to play.`;
  });
  body.querySelectorAll('[data-seg="flagsOn"], [data-flags], .flags-setting').forEach(el=>{
    const row = el.closest('.formrow') || el.closest('.item') || el; if(row) row.remove();
  });
}
if(typeof renderMenu === 'function'){
  const _renderMenu143 = renderMenu;
  renderMenu = function(){ const r = _renderMenu143.apply(this, arguments); try{ applyMenuPolish(); }catch(e){} return r; };
}

/* ----- Gear page becomes a nav-bar style subnavigation ----- */
function gearTabBtn(v, label){ return `<button class="${(window.UI&&UI.gearSubTab||'cameras')===v?'on':''}" data-geartab="${v}">${label}</button>`; }
function filterItem(k){
  const f=LENS_FILTERS[k], own=(S.owned.filters||[]).includes(k), eq=(S.filter===k);
  return `<div class="item ${eq?'equipped':''}"><div class="camhead"><span class="kind">Filter · ${f.stops} stop${f.stops===1?'':'s'}</span></div><h4>${f.n}</h4><div class="desc">${f.d}</div><div class="foot"><span class="price">${own?'Owned':'$'+f.p}</span>${eq?`<button class="btn small alt" data-filt="none">Remove</button>`:own?`<button class="btn small" data-filt="${k}">Screw on</button>`:`<button class="btn small" data-fbuy="${k}" ${(!S.free&&S.money<f.p)?'disabled':''}>Buy</button>`}</div></div>`;
}
if(typeof menuGear === 'function'){
  const baseMenuGear = menuGear;
  menuGear = function(){
    UI.gearSubTab = UI.gearSubTab || 'cameras';
    const b = curBody(), f = UI.camFilter || 'all', lf = UI.lensFilter || 'fits';
    let h = `<p class="note">${moneyStr()}. On your neck: <b>${b.n}</b>${curLens()? ' with the '+curLens().n : ''}, loaded with ${curFilm().n} (${curRoll().left} left).</p>`;
    h += `<div class="gearSubnav" style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0 14px">${gearTabBtn('cameras','Cameras')}${gearTabBtn('lenses','Lenses')}${gearTabBtn('flashes','Flashes')}${gearTabBtn('filters','Filters')}</div>`;
    if(UI.gearSubTab==='cameras'){
      const cats = ['all','owned'].concat(BODY_TYPES);
      h += `<div class="sectionhead">Cameras <span class="spec">Browse camera bodies only</span></div><div class="spec cs143-desc" style="display:block;margin:-4px 0 10px">Choose the body you want to carry. Lens-compatible cameras automatically work with the Lenses section below.</div>`;
      h += `<div class="seg" data-camfilter>${cats.map(c=>`<button data-v="${c}" aria-pressed="${f===c}">${c==='all'?'All':c==='owned'?'Owned':c}</button>`).join('')}</div><div class="grid" style="margin-top:12px">`;
      const ids = Object.keys(BODIES).filter(id => f==='all' || (f==='owned' ? S.owned.bodies.includes(id) : BODIES[id].t===f)).sort((a,c)=>(BODIES[a].p-BODIES[c].p));
      h += ids.map(camItem).join('') + `</div>`;
    } else if(UI.gearSubTab==='lenses'){
      h += `<div class="sectionhead">Lenses <span class="spec">Browse lenses only</span></div><div class="spec cs143-desc" style="display:block;margin:-4px 0 10px">Swap to a different perspective or look. Wide lenses pull you in; longer lenses compress and isolate.</div>`;
      if (b.L) h += `<p class="note">The ${b.n} has a built-in ${LENSES[b.L].n}. Showing lenses for other cameras.</p>`;
      h += `<div class="seg" data-lensfilter>${[['fits','Fits this camera'],['owned','Owned'],['all','All mounts']].concat(Object.keys(MOUNTS).map(m=>[m,MOUNTS[m]])).map(([v,l])=>`<button data-v="${v}" aria-pressed="${lf===v}">${l}</button>`).join('')}</div><div class="grid" style="margin-top:12px">`;
      const lids = Object.keys(LENSES).filter(id=>!LENSES[id].fixed).filter(id => lf==='all' || (lf==='fits' ? (b.L ? true : mountFits(b, LENSES[id])) : lf==='owned' ? S.owned.lenses.includes(id) : LENSES[id].m===lf)).sort((a,c)=>LENSES[a].f-LENSES[c].f);
      h += (lids.length ? lids.map(lensItem).join('') : `<p class="note">Nothing here yet.</p>`) + `</div>`;
    } else if(UI.gearSubTab==='flashes'){
      h += `<div class="sectionhead">Flashes</div><div class="spec cs143-desc" style="display:block;margin:-4px 0 10px">Available light is usually kinder, but flash can rescue a frame or flatten it — choose carefully.</div><div class="grid">`;
      for (const [id,g] of Object.entries(FLASHES)){ const owned=S.owned.flashes.includes(id), eq=S.flash===id;
        h += `<div class="item ${eq?'equipped':''}"><h4>${g.name}</h4><div class="spec">${g.gn?`Guide number ${g.gn}${g.soft?' · soft':''}`:b.fl?`Uses the ${b.n}'s built-in flash (GN ${b.fl})`:'Available light only'}</div>${g.desc?`<div class="desc">${g.desc}</div>`:''}<div class="foot"><span class="price">${owned?'Owned':'$'+g.price}</span>${gearBtn('flashes',id,g.price,owned,eq)}</div></div>`; }
      h += `</div><p class="note" style="margin-top:14px">F toggles the flash. Leaf shutters sync at any speed; focal-plane shutters only up to their sync speed.</p>`;
    } else {
      S.owned.filters = S.owned.filters || (S.free ? Object.keys(LENS_FILTERS) : []);
      h += `<div class="sectionhead">Filters</div><div class="spec cs143-desc" style="display:block;margin:-4px 0 10px">Filters change colour response, reflections and in some cases the whole mood of the frame. Metered cameras compensate automatically.</div><div class="grid">${Object.keys(LENS_FILTERS).filter(k=>k!=='none').map(filterItem).join('')}</div>`;
    }
    return h;
  };
  document.addEventListener('click', ev=>{
    const t = ev.target.closest && ev.target.closest('[data-geartab]'); if(!t) return;
    UI.gearSubTab = t.dataset.geartab; renderMenu(); ev.preventDefault();
  }, true);
}

/* ----- film looks removed from darkroom/editor ----- */
if(typeof buildEdSide==='function'){
  const _buildEdSide143 = buildEdSide;
  buildEdSide = function(){
    const r = _buildEdSide143.apply(this, arguments);
    const side = document.getElementById('edside');
    if(side){
      const groups = [...side.querySelectorAll('.edgroup')];
      const filmHead = groups.find(g => /film looks/i.test(g.textContent||''));
      if(filmHead){
        const next = filmHead.nextElementSibling;
        filmHead.remove();
        if(next && (next.classList.contains('presets') || next.classList.contains('note'))) next.remove();
      }
    }
    return r;
  };
}

/* ----- vignetting belongs mostly to cheap bodies / rough lenses ----- */
if(typeof curLens === 'function'){
  const _curLens143 = curLens;
  curLens = function(){
    const L = _curLens143.apply(this, arguments); if(!L) return L;
    const b = curBody && curBody();
    let vig = L.vig || 0;
    if(b){
      const cheap = (b.t==='Disposable' || b.t==='Toy' || b.p<=180);
      const mid = (b.p>180 && b.p<700);
      if(cheap) vig *= 1.0;
      else if(mid) vig *= 0.35;
      else vig *= 0.08;
      if(vig < 0.04) vig = 0;
    }
    return Object.assign({}, L, { vig });
  };
}

/* ----- more varied editorial voice ----- */
function varyCritique(rec, res){
  if(!res || !Array.isArray(res.critique) || !res.critique.length) return res;
  const h = hashStr((rec && (rec.id || JSON.stringify(rec.meta||{}))) + 'crit');
  const score = res.total || 50, c = res.cats || {}, meta = rec.meta || {};
  const subject = res.primary || ((meta.stats && meta.stats.people>1)?'the crowd':(meta.stats&&meta.stats.people===1)?'the person':'the scene');
  const quality = score>=88?'excellent':score>=72?'strong':score>=56?'promising':score>=40?'uneven':'thin';
  const sharp = (c.tech||50)>=78?'sharp':(c.tech||50)>=55?'usable':'soft';
  const light = (c.light||50)>=78?'beautifully lit':(c.light||50)>=55?'serviceable in the light':'hurt by the light';
  const comp = (c.comp||50)>=78?'well structured':(c.comp||50)>=55?'reasonably organized':'visually loose';
  const openersA = {
    excellent:['This is a frame with real authority.','A photograph like this earns its keep immediately.','This one has genuine staying power.','There is real conviction in this frame.','This lands with the confidence of a keeper.'],
    strong:['There is a lot to like here.','This is stronger than an average street frame.','The picture has real traction.','This frame is doing several things right at once.','It holds together well.'],
    promising:['There is a photograph here, even if it is not fully resolved.','This feels close to working.','The frame has potential, though it does not entirely cash it in.','You are circling something worthwhile here.','It is a near-miss with useful ingredients.'],
    uneven:['The idea is better than the execution here.','This one fights itself a little.','There are fragments of a good picture, but they are not fully aligned.','The frame feels caught between seeing and settling.','You found a possibility, not yet a finished picture.'],
    thin:['This is more record than revelation.','At the moment, the frame feels undercooked.','The photograph never quite arrives.','This reads more like a note than a finished frame.','There is not enough here yet to carry the picture.']
  };
  const openersB = [
    `The ${subject} gives the picture its center of gravity.`,
    `What matters most here is the way ${subject} anchors the frame.`,
    `Your treatment of ${subject} is what decides the photograph.`,
    `The frame lives or dies on what ${subject} is doing.`,
    `Everything turns on how ${subject} has been placed and timed.`
  ];
  const openersC = [
    `${comp.charAt(0).toUpperCase()+comp.slice(1)}, ${light}, and technically ${sharp}.`,
    `${light.charAt(0).toUpperCase()+light.slice(1)}; composition is ${comp}; definition is ${sharp}.`,
    `Structurally this is ${comp}, and the file feels ${sharp} with light that is ${light}.`,
    `The picture is ${comp}, ${sharp}, and ${light}.`,
    `Formally it is ${comp}; technically it is ${sharp}; tonally it is ${light}.`
  ];
  const intros = [];
  for(const a of openersA[quality]) for(const b of openersB) for(const c0 of openersC) intros.push(`${a} ${b} ${c0}`);
  const intro = intros[h % intros.length];
  res.critique[0] = intro;
  if(score>=80 && res.critique[1]) res.critique[1] = choice([
    `What elevates it is not just the subject, but the way timing, spacing and light cooperate.`,
    `It works because the formal pieces line up with the human moment instead of competing with it.`,
    `The picture feels intentional: the technical choices support the encounter rather than merely recording it.`,
    `There is enough order here to make the moment readable without sanding away its spontaneity.`
  ], h, 17);
  else if(score<50 && res.critique[1]) res.critique[1] = choice([
    `The next step is to simplify: get closer, wait longer, or change position so the frame commits to one clear idea.`,
    `A better result probably comes from moving your feet and being less polite with distance and timing.`,
    `Right now the ingredients are there, but they are not yet arranged in a way that lets the image speak cleanly.`,
    `You are seeing possibilities, but the frame needs a firmer decision about subject, distance or background.`
  ], h, 29);
  return res;
}
if(typeof judgePhoto==='function'){
  const _judge143 = judgePhoto;
  judgePhoto = function(){ const res = _judge143.apply(this, arguments); try{ varyCritique(arguments[0], res); }catch(e){} return res; };
}

/* ----- closer skyline landmarks and bridge ----- */
function makeMat(hex, rough=.78, metal=.05, em=0){ return new THREE.MeshStandardMaterial({color:lin(hex), roughness:rough, metalness:metal, emissive: em?lin(hex):0x000000, emissiveIntensity:em}); }
function addMesh(g, geo, mat, x,y,z, ry=0){ const m = new THREE.Mesh(geo, mat); m.position.set(x,y,z); m.rotation.y = ry; g.add(m); return m; }
function addSalesforce(g,x,z){ const glass=makeMat('#7e96a8', .24, .25), steel=makeMat('#d6dbe0', .18, .8); const tower = new THREE.Group(); tower.position.set(x,0,z);
  addMesh(tower, new THREE.CylinderGeometry(22,30,280,18).translate(0,140,0), glass,0,0,0);
  addMesh(tower, new THREE.CylinderGeometry(18,22,70,18).translate(0,35,0), steel,0,280,0);
  addMesh(tower, new THREE.CylinderGeometry(10,16,22,18).translate(0,11,0), steel,0,340,0);
  g.add(tower); return tower;
}
function addFerry(g,x,z){ const cream=makeMat('#e8dfcf',.7), roof=makeMat('#ba6b42',.65), clock=makeMat('#f7f3e8',.4); const q = new THREE.Group(); q.position.set(x,0,z);
  addMesh(q, new THREE.BoxGeometry(95,28,26).translate(0,14,0), cream,0,0,0);
  for(let i=-4;i<=4;i++) addMesh(q, new THREE.BoxGeometry(7,13,1.2), makeMat('#4e5961',.25,.2), i*10,15,13.7);
  addMesh(q, new THREE.BoxGeometry(16,74,16).translate(0,37,0), cream,0,28,0);
  addMesh(q, new THREE.CylinderGeometry(6.5,8,10,4).translate(0,5,0), roof,0,103,0,Math.PI/4);
  addMesh(q, new THREE.CylinderGeometry(5.8,5.8,1,18), clock,0,83,8.3);
  g.add(q); return q;
}
function addPalace(g,x,z){ const stone=makeMat('#d8c9ae',.8), green=makeMat('#7e9f8c',.65); const p = new THREE.Group(); p.position.set(x,0,z);
  addMesh(p, new THREE.CylinderGeometry(18,18,6,22), green,0,0,0);
  addMesh(p, new THREE.SphereGeometry(18,20,12,0,Math.PI*2,0,Math.PI/2), stone,0,6,0);
  for(let i=-3;i<=3;i++) if(i!==0) addMesh(p, new THREE.CylinderGeometry(1.6,1.6,18,8), stone, i*8,9,18);
  g.add(p); return p;
}
function addPyramid(g,x,z){ const cream=makeMat('#ede8db',.7); addMesh(g, new THREE.ConeGeometry(18,265,4).rotateY(Math.PI/4).translate(0,132.5,0), cream, x,0,z); }
function addCoit(g,x,z){ const hill = new THREE.Mesh(new THREE.SphereGeometry(70,16,10,0,Math.PI*2,0,Math.PI/2), makeMat('#5d6f54',.95)); hill.scale.y=.45; hill.position.set(x,0,z); g.add(hill); addMesh(g, new THREE.CylinderGeometry(5.5,6,62,16).translate(0,31,0), makeMat('#ece5d8',.7), x,30,z); }
function addBridge(g,x,z){ const orange=makeMat('#bf482f',.5,.2); const bg=new THREE.Group(); bg.position.set(x,0,z); bg.rotation.y=-.13;
  for(const tx of [-250,250]){ for(const sx of [-9,9]) addMesh(bg,new THREE.BoxGeometry(5,140,5).translate(0,70,0),orange,tx,0,sx); for(const hy of [56,92,128]) addMesh(bg,new THREE.BoxGeometry(4,5,22),orange,tx,hy,0); }
  addMesh(bg,new THREE.BoxGeometry(1100,5,18),orange,0,42,0);
  const pts=[]; for(let k=0;k<=40;k++){ const xx=-550+k*1100/40; let y; if(Math.abs(xx)<=250){ const u=xx/250; y=44+96*u*u; } else { const u=(Math.abs(xx)-250)/300; y=128-86*u; } pts.push([xx,y]); }
  for(const sz of [-9,9]) for(let k=0;k<pts.length-1;k++){ const [x0,y0]=pts[k], [x1,y1]=pts[k+1]; const L=Math.hypot(x1-x0,y1-y0); const seg=new THREE.Mesh(new THREE.BoxGeometry(L,1.6,1.6),orange); seg.position.set((x0+x1)/2,(y0+y1)/2,sz); seg.rotation.z=Math.atan2(y1-y0,x1-x0); bg.add(seg); }
  g.add(bg); return bg;
}
function addCloudsAndShadows(){
  if(!window.G || !G.scene || CS143.cloudGroup) return;
  const cg = new THREE.Group(), sg = new THREE.Group();
  for(let i=0;i<5;i++){
    const c = new THREE.Group();
    const px = -220 + i*110 + (i%2)*40, pz = -120 + i*70;
    for(let j=0;j<5;j++) addMesh(c, new THREE.SphereGeometry(16+((i+j)%3)*6, 12, 8), new THREE.MeshBasicMaterial({color:0xffffff, transparent:true, opacity:.16}), (j-2)*16, 0, ((j%2)-.5)*10);
    c.position.set(px, 150 + i*8, pz); cg.add(c);
    const shadow = new THREE.Mesh(new THREE.CircleGeometry(55, 22), new THREE.MeshBasicMaterial({color:0x000000, transparent:true, opacity:.11, depthWrite:false}));
    shadow.rotation.x = -Math.PI/2; shadow.position.set(px, H(px,pz)+.08, pz); shadow.scale.set(1.6, .9, 1.2); sg.add(shadow); c.userData.shadow = shadow; c.userData.seed = i*2.1;
  }
  G.scene.add(cg); G.scene.add(sg); CS143.cloudGroup = cg; CS143.shadowGroup = sg;
}
function addLandmarks(){
  // Snap City: the old real-world landmark stand-ins were removed (the city is fictional now);
  // fictional landmarks are built by 44-snap-city-life.js outside the bigger street grid.
  if(!window.G || !G.scene || CS143.landmarkGroup) return;
  CS143.landmarkGroup = new THREE.Group(); G.scene.add(CS143.landmarkGroup);
}
function updateAtmosphere(dt){
  if(CS143.cloudGroup){
    const wind = (window.WIND ? Math.hypot(WIND.x||0, WIND.z||0) : 0.8) * 3.5;
    CS143.cloudGroup.children.forEach((c,idx)=>{ c.position.x += dt*(0.45 + wind*0.12 + idx*0.02); if(c.position.x>420) c.position.x=-420; const s=c.userData.shadow; if(s){ s.position.x=c.position.x; s.position.z=c.position.z; s.material.opacity = 0.07 + 0.05*Math.sin(Game.t*.13 + idx); }});
  }
}

/* ----- clear shop glass harder from inside ----- */
function setInsideGlassStrong(hidden){
  if(!window.World || !World.mats || !World.mats.glass) return;
  const m = World.mats.glass;
  if(hidden){ m.opacity = 0.06; m.roughness = 0.02; m.envMapIntensity = 0.02; }
  else { m.opacity = 0.22; m.roughness = 0.08; m.envMapIntensity = ({ clear:0.25, balanced:0.45, reflective:0.8 })[S.custom.windowGlass] || 0.45; }
  m.needsUpdate = true;
}
if(typeof enterShop==='function' && typeof leaveZone==='function'){
  const _enter143 = enterShop, _leave143 = leaveZone;
  enterShop = function(){ const r=_enter143.apply(this, arguments); try{ setInsideGlassStrong(true); }catch(e){} return r; };
  leaveZone = function(){ try{ setInsideGlassStrong(false); }catch(e){} return _leave143.apply(this, arguments); };
}

/* ----- buses and trolleys keep moving when ridden ----- */
function transitKeepMoving(dt){
  if(!(window.GP && GP.ride && GP.ride.v)) return;
  const v = GP.ride.v;
  v.stopT = Math.min(v.stopT||0, 0.15);
  v.vmax = Math.max(v.vmax||0, v.trolley?5.4:7.4);
  if((v.speed||0) < (v.trolley?2.4:3.9)) v.speed = v.trolley?2.4:3.9;
  if(v.lastStop!=null){ if(v.trolley) v.lastStop = -9999; else v.lastStop = Math.round(v.x/P)*P; }
}

/* ----- local shade / sun-block hints from tall buildings ----- */
function landmarkShadeFactor(){
  if(!window.Player) return 0;
  const zones = [ [175,355,85], [245,410,65], [150,455,55], [310,-210,45] ];
  let best = 0;
  for(const [x,z,r] of zones){ const d = Math.hypot(Player.x-x, Player.z-z); best = Math.max(best, 1 - Math.min(1,d/r)); }
  return best;
}
if(typeof sceneEV==='function'){
  const _sceneEV143 = sceneEV;
  sceneEV = function(){ let ev = _sceneEV143.apply(this, arguments); const sh = landmarkShadeFactor(); if(sh>0.01) ev -= 0.75*sh; return ev; };
}

/* ----- boot / runtime hooks ----- */
if(typeof gameplayUpdate==='function'){
  const _gameplay143 = gameplayUpdate;
  gameplayUpdate = function(dt){ const r = _gameplay143.apply(this, arguments); try{ transitKeepMoving(dt); updateAtmosphere(dt); }catch(e){} return r; };
}

function afterBoot143(){
  if(CS143.applied || !window.Game || !window.G || !G.scene) return;
  CS143.applied = true;
  try{ addLandmarks(); addCloudsAndShadows(); }catch(e){ console.warn('[v14.3] landmark/cloud patch skipped', e); }
  try{ applyMenuPolish(); }catch(e){}
  try{ if(window.S && S.custom) S.custom.flagsOn='off'; }catch(e){}
  console.log('[Contact Sheet v14.3] landmarks / gear nav / critiques patch active.');
}

function tickReady(){
  try{ migrate143(); if(window.Game && (Game.started || window.G && G.scene)) afterBoot143(); if(window.UI && UI.menuTab) applyMenuPolish(); }catch(e){}
}
setInterval(tickReady, 600);
setTimeout(tickReady, 30);
})();
