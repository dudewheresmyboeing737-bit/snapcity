/* boot() is now called by src/main.ts after ALL legacy scripts have loaded,
   so every patch (including 37-40) is in place before the game starts. */
