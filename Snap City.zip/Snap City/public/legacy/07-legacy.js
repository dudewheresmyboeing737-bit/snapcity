
/* =========================================================
   Life: pedestrians, dogs, pigeons, traffic, tram
   ========================================================= */
const TOPS = ["#2d3a4a","#4a4a48","#7d6b55","#1f1f22","#a39f96","#5b6e5a","#8a3b32","#d9d3c4","#3f5e7a","#6e5a7e","#b8ab94","#34404a"];
const VIVID = ["#d23c2e","#e8b82e","#2f7fc1","#e36f2d","#3aa06b","#c8367a"];
const PANTS = ["#26282c","#3c4a66","#5c5448","#1d2d44","#8c8578","#2a2a2a","#50443a"];
const SKIN = ["#f1c7a5","#e0ac84","#c68b62","#a8704a","#7d4f33","#5a3a26"];
const HAIR = ["#1c1612","#3b2a1d","#6b4a2e","#a67c52","#d8c08a","#8a8a8a","#b4442c"];
const DOGC = ["#c9a878","#2b2622","#f0ece4","#8a5a36","#6d6d6d"];
const Life = { people:[], dogs:[], birds:[], flocks:[], cars:[], cable:null, t:0, inst:{} };

function geomFromBuf(key){
  const b = BUFS[key]; const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(b.p,3)); g.setAttribute("normal", new THREE.Float32BufferAttribute(b.n,3));
  g.setAttribute("color", new THREE.Float32BufferAttribute(b.c,3)); g.computeBoundingSphere(); delete BUFS[key]; return g;
}
function rectPos(a, s){
  const L = 8*a; s = ((s%L)+L)%L;
  if (s<2*a) return [-a+s, -a, 1,0]; s-=2*a;
  if (s<2*a) return [a, -a+s, 0,1]; s-=2*a;
  if (s<2*a) return [a-s, a, -1,0]; s-=2*a;
  return [-a, a-s, 0,-1];
}
function angLerp(a,b,t){ let d = ((b-a+Math.PI)%(2*Math.PI)+2*Math.PI)%(2*Math.PI)-Math.PI; return a + d*t; }

function glowTex(){ const c = document.createElement("canvas"); c.width = 64; c.height = 128; const x = c.getContext("2d"); for (const sx of [18, 46]){ const g = x.createRadialGradient(sx, 118, 2, sx, 70, 60); g.addColorStop(0, "rgba(255,255,255,.9)"); g.addColorStop(1, "rgba(255,255,255,0)"); x.fillStyle = g; x.fillRect(0,0,64,128); } return new THREE.CanvasTexture(c); }
function buildLife(scene){
  const rnd = mulberry(99);
  const R = (a,b)=>a+rnd()*(b-a), RP = arr=>arr[(rnd()*arr.length)|0];
  // ----- people -----
  for (let i=-NB;i<=NB;i++) for (let j=-NB;j<=NB;j++){
    const zone = zoneOf(i,j), n = Math.max(Math.abs(i),Math.abs(j))===3?3:zone==="vic"?5:6;
    for (let k=0;k<n;k++){
      const dir = rnd()<0.5?1:-1, a = HALF + (dir>0? 1.9 : 2.9);
      const vivid = rnd()<0.17;
      const p = {
        type:"person", id:Life.people.length, cx:i*P, cz:j*P, a, dir, s:rnd()*8*a, speed:R(1.0,1.55), base:0, phase:rnd()*6,
        scale:R(0.9,1.07), top: vivid? RP(VIVID) : RP(TOPS), pants:RP(PANTS), skin:RP(SKIN), hair:RP(HAIR), vivid,
        hat: rnd()<0.2 ? RP(["#26231f","#c0362c","#e8a33d","#3f5e7a","#d9d3c4"]) : null, bag: rnd()<0.35, umbrellaColor: RP(["#c0362c","#1e3a5f","#26231f","#e8b82e","#2f7fc1","#d23c2e"]),
        umbrellaChance: rnd(), pause:0, act:"walk", aware:0, awareFlag:false, complained:0, heading:0, headYaw:0, headPitch:0, x:0,y:0,z:0, vx:0, vz:0, stationary:false, dog:null
      };
      Life.people.push(p);
    }
  }
  // dog walkers
  const walkers = Life.people.filter((p,idx)=>idx%5===2);
  for (const w of walkers){ w.speed = 1.1; const d = { type:"dog", owner:w, color: RP(DOGC), size:R(0.75,1.2), phase:0, x:0,y:0,z:0, heading:0 }; w.dog = d; Life.dogs.push(d); }
  // busker + audience at Fillmore block (0,0), north sidewalk
  const bx = -8, bz = -HALF-2.2;
  const busker = { type:"person", id:Life.people.length, performer:true, stationary:true, x:bx, z:bz, heading:Math.PI, scale:1.0, top:"#8a3b32", pants:"#26282c", skin:"#c68b62", hair:"#1c1612", hat:"#26231f", bag:false, vivid:true, act:"play", phase:0, speed:0, aware:0, headYaw:0, headPitch:0, complained:0, umbrellaChance:1 };
  Life.people.push(busker); Life.busker = busker;
  for (let k=0;k<4;k++){
    const ang = -1.0 + k*0.66, r = 2.6 + (k%2)*0.5;
    const wx = bx + Math.sin(ang)*r, wz = bz - Math.cos(ang)*r*0.55;
    Life.people.push({ type:"person", id:Life.people.length, watcher:true, stationary:true, x:wx, z:clamp(wz, -HALF-3.6, -HALF-0.8), heading:0, scale:R(0.9,1.05), top: rnd()<0.3?RP(VIVID):RP(TOPS), pants:RP(PANTS), skin:RP(SKIN), hair:RP(HAIR), hat:null, bag:rnd()<0.4, vivid:false, act:"watch", phase:rnd()*6, speed:0, aware:0, headYaw:0, headPitch:0, complained:0, umbrellaChance:1 });
  }
  for (const p of Life.people) if (p.watcher) p.heading = Math.atan2(bx-p.x, bz-p.z);
  // a living statue in Hayes Valley
  const statue = { type:"person", id:Life.people.length, performer:true, stationary:true, x:24, z:P-HALF-2.3, heading:Math.PI, scale:1, top:"#b9bcc0", pants:"#b9bcc0", skin:"#b9bcc0", hair:"#b9bcc0", hat:null, bag:false, vivid:false, act:"statue", phase:0, speed:0, aware:0, headYaw:0, headPitch:0, complained:0, umbrellaChance:1 };
  Life.people.push(statue);
  // life on the sidewalks: conversations, smokers by the door, people on benches
  const stay = (x, z, heading, anim, extra={}) => { const q = { type:"person", id:Life.people.length, stationary:true, x, z, heading, scale:1, top:"#555", pants:"#333", skin:"#c68b62", hair:"#222", hat:null, bag:false, vivid:false, act:"idle", phase:rnd()*6, speed:0, aware:0, headYaw:0, headPitch:0, complained:0, umbrellaChance:rnd(), pose:anim }; Object.assign(q, extra); Life.people.push(q); return q; };
  for (let i=-NB;i<=NB;i++) for (let j=-NB;j<=NB;j++){
    const cx = i*P, cz = j*P;
    for (let g=0; g<(rnd()<0.5?2:1); g++){
      const side = RP([[0,-1],[0,1],[-1,0],[1,0]]), along = R(-HALF+6, HALF-6), off = HALF + R(1.6,2.8);
      const gx = cx + (side[0] ? side[0]*off : along), gz = cz + (side[1] ? side[1]*off : along);
      const n = rnd()<0.6 ? 2 : 3;
      for (let k=0;k<n;k++){ const a = k/n*Math.PI*2 + R(-0.3,0.3), rr = R(0.45,0.65); const x = gx + Math.sin(a)*rr, z = gz + Math.cos(a)*rr; stay(x, z, Math.atan2(gx-x, gz-z), "talk", { smoke: rnd()<0.35 }); }
    }
    if (rnd()<0.8){ const side = RP([[0,-1],[0,1],[-1,0],[1,0]]), along = R(-HALF+4, HALF-4), off = HALF + 0.45;
      const x = cx + (side[0] ? side[0]*off : along), z = cz + (side[1] ? side[1]*off : along); stay(x, z, Math.atan2(side[0], side[1]), "lean", { smoke:true }); }
  }
  for (const b of (World.benches||[])){ if (rnd() < 0.55){ const n = rnd()<0.35 ? 2 : 1; for (let k=0;k<n;k++){ const lx = n===2 ? (k?0.45:-0.45) : R(-0.4,0.4); const rx = Math.cos(b.ry), rz = -Math.sin(b.ry); stay(b.x + rx*lx - Math.sin(b.ry)*0.08, b.z + rz*lx - Math.cos(b.ry)*0.08, b.ry, "sit", { smoke: rnd()<0.2, phoneSit: rnd()<0.4 }); } } }
  if (typeof spawnExtras === "function") spawnExtras(stay, rnd, R, RP);
  for (let k=0;k<28;k++) stay(0, -9999, 0, null, { pool:true, hidden:true });
  for (const role of ["fire","fire","fire","fire","police","police","police","police","robber","robber"]) stay(0, -9999, 0, null, { pool:true, hidden:true, role });
  const drnd = mulberry(4242);
  for (const p of Life.people){
    dressPerson(p, drnd);
    if (p.pool && !Life._sk){ Life._skN = (Life._skN||0) + 1; if (Life._skN <= 2){ p.look.acc.skate = "#26231f"; p.look.costume = null; } }
    if (p === busker){ Object.assign(p.look, { anim:"walk", acc:{}, top:"#8a3b32", hat:"fedora", hatColor:"#26231f", btype:"pants", bottom:"#26282c", sleeve:"long" }); p.top = "#8a3b32"; p.vivid = true; p.hat = "#26231f"; }
    if (p === statue){ const s_ = "#b9bcc0"; Object.assign(p.look, { statue:true, acc:{}, top:s_, bottom:s_, skin:s_, shoes:s_, hairColor:s_, hat:"tophat", hatColor:s_, btype:"coat", skirt:s_, skirtLen:0.28, sleeve:"long", glasses:false, beard:false, hair:"short", costume:null }); p.vivid = false; p.hat = s_; }
    if (p.stationary){ p.speed = 0; p.noPause = true; }
    if (p.pose){ p.look.anim = p.pose; if (p.pose==="sit" && p.look.btype==="tutu") p.look.btype = "pants"; if (p.phoneSit) p.act = "phone"; }
    if (p.smoke !== undefined) p.look.smoke = p.smoke && !p.look.costume;
    if (p.pool){ p.look.smoke = false; p.look.acc.sign = null; p.look.acc.cane = null; if (!p.look.costume) p.look.anim = "walk"; }
    if (p.role){ const L = p.look; Object.assign(L, { costume:null, anim:"walk", btype:"pants", sleeve:"long", glasses:false, acc:{}, mood:"neutral" }); L.b = Math.min(Math.max(L.b, 0.95), 1.25);
      if (p.role === "fire"){ Object.assign(L, { top:"#8a6a2a", bottom:"#8a6a2a", shoes:"#141414", hat:"hardhat", hatColor: RP(["#1a1a1a","#e8b82e","#c0362c"]), outfit:"worker" }); L.acc.scarf = "#e8e6a0"; }
      if (p.role === "police"){ Object.assign(L, { top:"#1d2a44", bottom:"#1d2a44", shoes:"#141414", hat:"cap", hatColor:"#1a2238", outfit:"business" }); }
      if (p.role === "homeless"){ Object.assign(L, { top: RP(["#4a4238","#3a3a36","#5c5448","#2d3a2e"]), bottom: RP(["#3a3a3a","#4a4238","#2a3a55"]), shoes:"#2a2420", hat: RP(["beanie","cap",null]), hatColor: RP(["#3a3f46","#7a2e36","#26231f"]), btype: "coat", skirt: RP(["#4a4238","#3a3a36"]), skirtLen:0.25, outfit:"coat", anim: p.pose || "sitground", beard: !L.fem && Math.random() < 0.7 }); L.acc.scarf = RP(["#7a2e36","#3f5e7a","#c9b28a"]); L.hairColor = RP(["#5a4a3a","#8f8f8f","#3b2a1d"]); }
      if (p.role === "robber"){ Object.assign(L, { top:"#1a1a1a", bottom:"#26282c", shoes:"#141414", hat:"beanie", hatColor:"#111", outfit:"casual" }); L.acc.tote = "#6b5a45"; L.glasses = true; }
      p.top = L.top; }
  }

  // ----- instanced meshes -----
  const N = Life.people.length, ND = Math.max(1, Life.dogs.length);
  const mat = new THREE.MeshStandardMaterial({ color:0xffffff, roughness:0.85 });
  const mk = (geom, count) => { const m = new THREE.InstancedMesh(geom, mat, count); m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); m.castShadow = true; m.receiveShadow = true; m.frustumCulled = false; scene.add(m); return m; };
  const I = Life.inst;
  buildPeopleMeshes(scene);
  buildDogMeshes(scene); Smoke.init(scene); Rain.init(scene); wetSurfaces();
  for (const k in I) if (I[k].instanceColor) I[k].instanceColor.needsUpdate = true;

  // ----- pigeons -----
  const flockSpots = [[-20,-HALF-2.5,0,0],[30,HALF+2.6,0,0],[-HALF-2.4,10,1,0],[HALF+2.5,-20,0,-1],[-12,HALF+2.4,0,1],[25,-HALF-2.5,-1,-1],[-30,-HALF-2.6,1,1],[10,HALF+2.5,-1,0],[HALF+2.4,15,0,1],[-25,-HALF-2.4,2,0],[15,HALF+2.5,0,-2],[-HALF-2.5,-18,-1,1],[5,-HALF-2.6,1,-1]];
  for (const [lx,lz,bi,bj] of flockSpots){
    const f = { cx:bi*P+lx, cz:bj*P+lz, state:"ground", t:0, birds:[] }; Life.flocks.push(f);
    const n = 6 + ((rnd()*5)|0);
    for (let k=0;k<n;k++){ const b = { flock:f, hx: f.cx + R(-1.8,1.8), hz: f.cz + R(-0.9,0.9), x:0,y:0,z:0, vx:0,vy:0,vz:0, heading:R(0,6.28), flap:rnd()*6, peck:rnd()*6, col: pick(["#8a8e95","#6f737a","#a7aab0","#5c5f66","#c9c9c6"]) }; b.x=b.hx; b.z=b.hz; b.y=groundY(b.x,b.z); f.birds.push(b); Life.birds.push(b); }
  }
  const NBd = Life.birds.length, bmat = new THREE.MeshStandardMaterial({ color:0xffffff, roughness:0.8 });
  const mkb = (geom,count)=>{ const m = new THREE.InstancedMesh(geom,bmat,count); m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); m.frustumCulled=false; m.castShadow=true; scene.add(m); return m; };
  I.bbody = mkb(new THREE.SphereGeometry(0.1,8,6).scale(0.85,0.8,1.5), NBd);
  I.bhead = mkb(new THREE.SphereGeometry(0.055,8,6), NBd);
  I.bwing = mkb(new THREE.BoxGeometry(0.26,0.012,0.13).translate(0.13,0,0), 2*NBd);
  Life.birds.forEach((b,i)=>{ const c = lin(b.col); I.bbody.setColorAt(i,c); I.bhead.setColorAt(i, lin("#4d5a58")); I.bwing.setColorAt(2*i, c.clone().multiplyScalar(0.85)); I.bwing.setColorAt(2*i+1, c.clone().multiplyScalar(0.85)); });
  for (const k of ["bbody","bhead","bwing"]) I[k].instanceColor.needsUpdate = true;

  // ----- moving cars -----
  const carMat = new THREE.MeshStandardMaterial({ vertexColors:true, roughness:0.35, metalness:0.35 });
  const lightMat = new THREE.MeshStandardMaterial({ color:lin("#fff4d8"), emissive:lin("#fff0cc"), emissiveIntensity:0 });
  const tailMat = new THREE.MeshStandardMaterial({ color:lin("#6a1414"), emissive:lin("#ff2a1a"), emissiveIntensity:0 });
  Life.carLightMats = [lightMat, tailMat];
  const streetsZ = []; for (let i=-NOUT;i<NOUT;i++) streetsZ.push((i+0.5)*P);
  let ci = 0;
  for (const z of streetsZ){
    for (const lane of [1,-1]){
      const count = (Math.abs(z)<200) ? 2 : 1;
      for (let k=0;k<count;k++){
        ci++; let this_x = R(-(NOUT+0.5)*P, (NOUT+0.5)*P); const c = lin(RP(CAR_COLORS)); const taxi = rnd()<0.18; const ctype = taxi ? "sedan" : pickCarType(rnd);
        const tm = tailMat.clone(); const g = buildCarGroup(ctype, taxi ? lin("#e8b82e") : (CAR_PALETTES[ctype] ? carPaint(ctype, rnd) : c), taxi ? { taxi } : carCharacter(ctype, rnd), [lightMat, tm]);
        const glow = new THREE.Mesh(Life.glowGeo || (Life.glowGeo = new THREE.PlaneGeometry(3.2, 9).rotateX(-Math.PI/2).translate(0, 0.06, 7)), Life.glowMat || (Life.glowMat = new THREE.MeshBasicMaterial({ map:glowTex(), color:0xfff0d0, transparent:true, opacity:0, depthWrite:false, blending:THREE.AdditiveBlending, fog:true }))); g.add(glow);
        scene.add(g);
        { let tries = 0; while (tries++ < 20 && Life.cars.some(o => o.lane === lane && Math.abs(o.z - (z + lane*1.3)) < 0.5 && Math.abs(o.x - this_x) < 10)) this_x = R(-(NOUT+0.5)*P, (NOUT+0.5)*P); }
        Life.cars.push({ type:"car", tailMat:tm, g, lane, z: z + lane*1.3, x: this_x, speed:0, vmax:R(7,10.5), taxi, color:c, heading: lane>0? Math.PI/2 : -Math.PI/2 });
      }
    }
  }
  // ----- city buses (you can ride these) -----
  for (const [zi, lane] of [[Math.floor(streetsZ.length/2), 1], [Math.max(0, Math.floor(streetsZ.length/2)-1), -1]]){
    const z = streetsZ[zi], tmB = tailMat.clone(), bg = buildCarGroup("bus", lin("#e4e0d4"), {}, [lightMat, tmB]);
    const stripe = new THREE.MeshStandardMaterial({ color:lin("#b3202a"), roughness:0.5 });
    for (const sx of [-1, 1]){ const m = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.28, 10.6), stripe); m.position.set(sx*1.285, 0.95, 0); bg.add(m); }
    const sign = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.26, 0.04), new THREE.MeshStandardMaterial({ color:lin("#222"), emissive:lin("#ffb13b"), emissiveIntensity:1.2 })); sign.position.set(0, 2.62, 5.56); bg.add(sign);
    scene.add(bg);
    Life.cars.push({ type:"car", bus:true, tailMat:tmB, g:bg, lane, z: z + lane*1.3, x: R(-200, 200), speed:0, vmax:7.2, taxi:false, color:lin("#e4e0d4"), heading: lane>0 ? Math.PI/2 : -Math.PI/2, stopT:0, lastStop:null });
  }
  // ----- cable car -----
  const key = "cablecar", red = lin("#8e1f24"), cream = lin("#eee3c6"), wood = lin("#6b4a2e"), dark = lin("#1f2226"), gold = lin("#c9a23a");
  const cp = (geom, lx,ly,lz, sx,sy,sz, cc) => pushGeom(key, geom, M(lx,ly,lz,0,sx,sy,sz), cc);
  cp(PRIM.box, 0,0.55,0, 2.5,0.22,8.4, dark);               // chassis
  cp(PRIM.box, 0,1.05,0, 2.45,0.8,5.0, red);                // lower body center
  cp(PRIM.box, 0,1.82,0, 2.46,0.75,5.0, dark);              // window band
  for (let k=-2;k<=2;k++) cp(PRIM.box, 1.23,1.82,k*1.2, 0.03,0.78,0.14, cream), cp(PRIM.box, -1.23,1.82,k*1.2, 0.03,0.78,0.14, cream);
  cp(PRIM.box, 0,2.3,0, 2.5,0.22,5.1, cream);
  for (const e of [-1,1]){ // open ends
    cp(PRIM.box, 0,0.95,e*3.35, 2.45,0.6,1.7, cream);
    for (const sx of [-1.15,1.15]) cp(PRIM.box, sx,1.85,e*3.35+e*0.7, 0.08,1.5,0.08, cream);
    cp(PRIM.box, 0,1.25,e*4.2, 2.3,0.5,0.06, red);
  }
  cp(PRIM.box, 0,2.62,0, 2.6,0.2,8.6, lin("#b5aa92"));      // roof
  cp(PRIM.box, 0,2.78,0, 1.2,0.14,7.6, lin("#8b8373"));
  cp(PRIM.box, 0,2.25,4.28, 1.6,0.3,0.05, lin("#1e3a5f"));   // route sign
  cp(PRIM.box, 0,2.25,-4.28, 1.6,0.3,0.05, lin("#1e3a5f"));
  for (const sx of [-1.4,1.4]) cp(PRIM.box, sx,0.75,0, 0.35,0.06,7.8, wood); // running boards
  cp(PRIM.box, 1.28,1.2,0, 0.02,0.1,4.8, gold); cp(PRIM.box, -1.28,1.2,0, 0.02,0.1,4.8, gold);
  // riders hanging on the side
  const riderC = ["#1f1f22","#3f5e7a","#d23c2e","#d9d3c4","#5b6e5a","#e8b82e"];
  for (let k=0;k<6;k++){ const sx = k<3? 1.55 : -1.55, z = -2 + (k%3)*1.6; const c = lin(riderC[k]); cp(PRIM.box, sx,1.5,z, 0.36,0.62,0.24, c); cp(PRIM.sph, sx,2.02,z, 0.22,0.24,0.22, lin(pick(SKIN))); cp(PRIM.box, sx,0.95,z, 0.3,0.5,0.2, lin(pick(PANTS))); }
  for (let k=0;k<5;k++) cp(PRIM.sph, (k%2?0.5:-0.5), 1.95, -1.8+k*0.9, 0.22,0.24,0.22, lin(pick(SKIN)));
  const cg = new THREE.Group(); const cm = new THREE.Mesh(geomFromBuf(key), new THREE.MeshStandardMaterial({ vertexColors:true, roughness:0.6 })); cm.castShadow = true; cg.add(cm);
  const clamp_ = new THREE.Mesh(new THREE.BoxGeometry(2.3,0.5,0.1), new THREE.MeshStandardMaterial({ color:lin("#fff6de"), emissive:lin("#ffe9b8"), emissiveIntensity:0 })); clamp_.position.set(0,2.4,4.32); cg.add(clamp_); Life.cableLight = clamp_.material;
  scene.add(cg);
  Life.cable = { type:"cable", g:cg, x:CABLE_X, z:180, dir:-1, speed:0, stopT:0, nextStop:null, bellT:0 };
}

/* ---------- update ---------- */
const _mA = new THREE.Matrix4(), _mB = new THREE.Matrix4(), _mC = new THREE.Matrix4(), _qA = new THREE.Quaternion(), _eA = new THREE.Euler(), _vA = new THREE.Vector3(), _vS = new THREE.Vector3(), _zeroS = new THREE.Vector3(0,0,0);
function partMat(base, lx,ly,lz, rx=0, ry=0, rz=0, s=1){ _eA.set(rx,ry,rz,"YXZ"); _qA.setFromEuler(_eA); _mB.compose(_vA.set(lx,ly,lz), _qA, _vS.set(s,s,s)); return _mC.multiplyMatrices(base, _mB); }
const HIDE = new THREE.Matrix4().makeScale(0,0,0);

function updateLife(dt, pl){
  Life.t += dt; Life.frame = (Life.frame||0) + 1;
  const I = Life.inst, T = World.timeDef || TIMES[2];
  const umbrellaWeather = S.rain ? 2 : (S.fog || T.id==="morning") ? 1 : 0;
  const notice = Math.max(1.8, 2.8 - 0.22*(sk("ghost") + sk("streetwise")));
  // people
  Life.people.forEach((p,i)=>{
    if (p.hidden) return;
    let moving = 0;
    if (!p.stationary){
      if (p.cross){ moving = crossUpdate(p, dt); } else {
      if (p.pause > 0){ p.pause -= dt; }
      else {
        p.s += p.dir*p.speed*dt; moving = 1;
        if (!p.noPause && Math.random() < dt*0.025){ p.pause = rand(2,6); p.act = Math.random()<0.5 ? "shop" : "phone"; }
        else p.act = "walk";
      }
      if (p.pause <= 0 && p.act!=="walk") p.act = "walk";
      const r = rectPos(p.a, p.s);
      p.x = p.cx + r[0]; p.z = p.cz + r[1];
      let target = Math.atan2(r[2]*p.dir, r[3]*p.dir);
      if (p.act==="shop"){ const onX = Math.abs(r[0]) >= p.a - 0.01; target = onX ? Math.atan2(-Math.sign(r[0]),0) : Math.atan2(0,-Math.sign(r[1])); }
      p.heading = angLerp(p.heading, target, Math.min(1, dt*6));
      maybeCross(p); }
    }
    p.y = groundY(p.x, p.z) + (p.evY||0);
    if (p.evMoving){ moving = 1; p.speed = p.evSpeed || 1.2; }
    // awareness of the photographer
    const dx = pl.pos.x - p.x, dz = pl.pos.z - p.z, dist = Math.hypot(dx,dz);
    let looking = false;
    if (pl.raised && dist < notice){
      const vx = p.x - pl.pos.x, vy = (p.y+1.5) - pl.pos.y, vz = p.z - pl.pos.z, vl = Math.hypot(vx,vy,vz);
      const dot = (vx*pl.fwd.x + vy*pl.fwd.y + vz*pl.fwd.z)/vl;
      if (dot > Math.cos(0.3)) looking = true;
    }
    if ((looking && dist < notice) || dist < 0.9) p.aware = Math.min(3, p.aware + dt*0.72*(notice/Math.max(dist,0.65))*(p.performer?0.12:1));
    else p.aware = Math.max(0, p.aware - dt*0.6);
    const aware = p.aware > 1;
    if (aware && !p.stationary && p.pause <= 0.5 && dist < 2.1 && Math.random() < dt*0.12){ p.pause = rand(0.35,0.7); p.act = "stare"; }
    if (aware && dist < 1.8 && pl.raised && p.complained <= 0 && !p.performer){ p.complained = 25; if (Math.random()<0.22){ const md = (p.look && p.look.mood) || "neutral"; const lines = { cheerful:["“Ha! Get my good side!”","“Hi! Is this for a project?”","“Say cheese!”"], poser:["“Wait, wait, let me pose.”","“You'll want to credit me for this one.”","“Make it black and white, it's more me.”"], grumpy:["“Put that thing away.”","“No. Absolutely not.”","“Do I look like a tourist attraction?”"], shy:["“Oh — please don't…”","“Um. Not me, okay?”"], curious:[`“Is that a ${curBody().n}? Does it still shoot?”`,"“Film? People still use film?”","“What are you taking pictures of?”"], anxious:["“Why are you photographing me?”","“Who are you with?”"], neutral:["“Hey — no photos, please.”","“Did you just take my picture?”","“Can I help you?”"] }[md] || ["“Can I help you?”"];
        toast(pick(lines)); if (md === "grumpy" || md === "anxious" || md === "neutral") Audio.hey(); } }
    p.complained -= dt;
    const yawTo = Math.atan2(dx, dz) - p.heading;
    const wantYaw = aware ? clamp(Math.atan2(Math.sin(yawTo), Math.cos(yawTo)), -1.3, 1.3) : (p.act==="shop"? 0 : Math.sin(Life.t*0.3 + i)*0.25);
    p.headYaw = lerp(p.headYaw, wantYaw, Math.min(1, dt*4));
    p.headPitch = lerp(p.headPitch, p.act==="phone" ? 0.55 : 0, Math.min(1, dt*4));
    p.moving = moving;
    const rate = moving ? (p.look && p.look.anim==='jog' ? p.speed*2.9 : p.speed*5.2/(p.look? p.look.h/1.75 : 1)) : 0;
    p.phase += rate*dt;
    const swing = moving ? Math.sin(p.phase)*0.5 : lerp(0, 0, 0);
    const umb = p.umbrellaChance < [0.03, 0.12, 0.62][umbrellaWeather];
    p.umbrella = umb && !p.stationary;
    posePerson(p, i, moving, dist, pl, aware, Life.t);
    p.stride = moving ? Math.abs(Math.sin(p.phase)) : 0;
    p.vx = moving ? Math.sin(p.heading)*p.speed : 0; p.vz = moving ? Math.cos(p.heading)*p.speed : 0;
  });
  updateDogs(dt, pl); Smoke.update(dt);
  // pigeons
  for (const f of Life.flocks){
    const dist = Math.hypot(pl.pos.x - f.cx, pl.pos.z - f.cz);
    if (f.state==="ground" && (dist < 1.8 || (dist < 3.6 && pl.speed > 3.2))){
      f.state = "fly"; f.t = 0; Audio.flutter();
      for (const b of f.birds){ const ang = Math.atan2(f.cz - pl.pos.z, f.cx - pl.pos.x) + rand(-0.9,0.9); const sp = rand(3.5,6); b.vx = Math.cos(ang)*sp; b.vz = Math.sin(ang)*sp; b.vy = rand(3,5.5); }
    }
    if (f.state==="fly"){ f.t += dt; if (f.t > rand(7,9)) f.state = "return"; }
    if (f.state==="return"){ let done = true; for (const b of f.birds){ if (Math.hypot(b.x-b.hx,b.z-b.hz) > 0.25 || b.y > groundY(b.hx,b.hz)+0.05) done = false; } if (done && dist > 5) { f.state = "ground"; } }
    f.flying = f.state !== "ground";
  }
  Life.birds.forEach((b,i)=>{
    const f = b.flock; let flap = 0, wingOpen = 0;
    if (f.state==="fly"){ b.vy -= 0.6*dt; b.x += b.vx*dt; b.y += b.vy*dt; b.z += b.vz*dt; b.heading = Math.atan2(b.vx, b.vz); b.flap += dt*22; flap = Math.sin(b.flap)*0.9; wingOpen = 1; }
    else if (f.state==="return"){ const tx=b.hx-b.x, tz=b.hz-b.z, ty=groundY(b.hx,b.hz)-b.y; const L = Math.hypot(tx,tz,ty); if (L > 0.05){ const sp = Math.min(5, L*1.5+0.3); b.x += tx/L*sp*dt; b.y += ty/L*sp*dt; b.z += tz/L*sp*dt; b.heading = Math.atan2(tx,tz); } b.flap += dt*14; flap = Math.sin(b.flap)*0.5; wingOpen = L>0.3?1:0; }
    else { b.y = groundY(b.x,b.z); b.peck += dt*(3+i%3); if (Math.random()<dt*0.3){ b.heading += rand(-1,1); } if (Math.random()<dt*0.4){ const nx = b.x + Math.sin(b.heading)*0.15, nz = b.z + Math.cos(b.heading)*0.15; if (Math.hypot(nx-b.hx,nz-b.hz) < 1.4){ b.x=nx; b.z=nz; } } }
    const pk = f.state==="ground" ? Math.max(0,Math.sin(b.peck))*0.5 : 0;
    _eA.set(0,b.heading,0,"YXZ"); _qA.setFromEuler(_eA); _mA.compose(_vA.set(b.x,b.y,b.z), _qA, _vS.set(1,1,1)); const base = _mA.clone();
    I.bbody.setMatrixAt(i, partMat(base, 0,0.12,0, f.state==="ground"?-0.25:0));
    I.bhead.setMatrixAt(i, partMat(base, 0,0.2-pk*0.12,0.14+pk*0.03));
    I.bwing.setMatrixAt(2*i, wingOpen ? partMat(base, 0.05,0.14,0, 0,0,flap) : partMat(base, 0.02,0.15,-0.02, 0, -1.4, 0, 0.8));
    I.bwing.setMatrixAt(2*i+1, wingOpen ? partMat(base, -0.05,0.14,0, 0,Math.PI,flap) : partMat(base, -0.02,0.15,-0.02, 0, Math.PI+1.4, 0, 0.8));
    b.flying = wingOpen && f.state==="fly";
  });
  for (const k in I) I[k].instanceMatrix.needsUpdate = true;
  flushPeople();

  // cable car
  const cc = Life.cable, streetsZ = []; for (let i=-NOUT;i<NOUT;i++) streetsZ.push((i+0.5)*P);
  if (cc.stopT > 0){ cc.stopT -= dt; cc.speed = 0; if (cc.stopT <= 0){ cc.lastStop = cc.nextStop; } }
  else {
    let target = 4.4;
    const ahead = streetsZ.filter(z => (z - cc.z)*cc.dir > 0.5 && Math.abs(z)<(NB+0.5)*P).sort((a,b)=>Math.abs(a-cc.z)-Math.abs(b-cc.z))[0];
    if (ahead !== undefined && Math.abs(ahead - cc.z) < 9 && ahead !== cc.lastStop){ target = Math.max(0.6, Math.abs(ahead - cc.z - cc.dir*5.8)*0.8); if (Math.abs(ahead - cc.dir*5.8 - cc.z) < 0.3){ cc.stopT = 5; cc.nextStop = ahead; Audio.bell(Math.max(0, 1 - Math.hypot(pl.pos.x-cc.x, pl.pos.z-cc.z)/80)); } }
    const pd = (pl.pos.z - cc.z)*cc.dir; if (Math.abs(pl.pos.x - cc.x) < 2.2 && pd > 0 && pd < 9) target = 0;
    cc.speed = lerp(cc.speed, target, Math.min(1, dt*1.2));
    cc.z += cc.dir*cc.speed*dt;
    { const TL = (NB+0.5)*P; if (cc.z < -TL){ cc.z = -TL; cc.dir = 1; cc.lastStop = null; } if (cc.z > TL){ cc.z = TL; cc.dir = -1; cc.lastStop = null; } }
  }
  const zf = cc.z + cc.dir*3, zb = cc.z - cc.dir*3; const pitch = -Math.atan2(H(cc.x,zf)-H(cc.x,zb), 6);
  cc.g.position.set(cc.x, H(cc.x,cc.z)+0.02, cc.z); cc.g.rotation.set(pitch, cc.dir>0?0:Math.PI, 0, "YXZ");
  cc.vz = cc.dir*cc.speed; cc.vx = 0;
  // cars
  for (const c of Life.cars){
    const dirx = c.lane > 0 ? 1 : -1; let target = c.vmax;
    const pAhead = (pl.pos.x - c.x)*dirx; if (pAhead > 0 && pAhead < 9 && Math.abs(pl.pos.z - c.z) < 1.8) target = 0;
    for (const o of Life.cars){ if (o===c || o.lane!==c.lane || Math.abs(o.z-c.z)>0.5) continue; const d = (o.x - c.x)*dirx, gap = (o.bus || c.bus) ? 8.8 : 5.5; if (d > 0 && d < gap + 4) target = Math.min(target, Math.max(0,(d-gap))*1.2); }
    target = Math.min(target, signalLimit(c, dirx));
    if (c.bus){ const ridingThis = !!(GP.ride && GP.ride.kind === "bus" && GP.ride.v === c); const sx = Math.round(c.x/P)*P; if (ridingThis){ c.stopT = 0; c.lastStop = sx; target = Math.max(target, Math.min(c.vmax||7, 4.8)); } else if (c.stopT > 0){ c.stopT -= dt; target = 0; } else if (Math.abs(c.x - sx) < 1.5 && c.lastStop !== sx){ c.lastStop = sx; c.stopT = 9; target = 0; } }
    if (Math.abs(cc.z - c.z) < 6.5){ const d = (cc.x - c.x)*dirx; if (d > 0 && d < 10) target = 0; }
    c.speed = lerp(c.speed, target, Math.min(1, dt*(target < c.speed ? 3 : 0.8)));
    c.x += dirx*c.speed*dt;
    { const E = (NOUT+0.5)*P + 10; // wrap at the edge of the (bigger) city, never on top of another car
      if (c.x > E || c.x < -E){ const nx = c.x > E ? -E : E; const busy = Life.cars.some(o => o !== c && o.lane === c.lane && Math.abs(o.z - c.z) < 0.5 && Math.abs(o.x - nx) < 9); if (!busy) c.x = nx; else { c.x = clamp(c.x, -E, E); c.speed = 0; } } }
    const xf = c.x + dirx*2, xb = c.x - dirx*2;
    c.g.position.set(c.x, H(c.x,c.z)+0.02, c.z); c.g.rotation.set(-Math.atan2(H(xf,c.z)-H(xb,c.z),4), c.heading, 0, "YXZ");
    c.vx = dirx*c.speed; c.vz = 0;
    const braking = target < c.speed - 0.2 || c.speed < 0.6; c.tailMat.emissiveIntensity = (0.5 + T.lamps*3 + (S.rain||S.fog ? 1.2 : 0)) * (braking ? 3.2 : 1);
    c.g.visible = Math.abs(c.x - pl.pos.x) + Math.abs(c.z - pl.pos.z) < 260;
  }
  const lampsOn = T.lamps, hl = Math.min(1, lampsOn + (S.rain ? 0.7 : 0) + (S.fog ? 0.5 : 0)); Life.carLightMats[0].emissiveIntensity = 0.3 + hl*7; if (Life.glowMat) Life.glowMat.opacity = hl*(S.rain ? 0.55 : 0.32); Life.cableLight.emissiveIntensity = lampsOn*5;
}

/* subjects for the judge: returns shape info for projection */
function lifeSubjects(){
  const out = [];
  for (const p of Life.people){
    if (p.hidden) continue;
    out.push({ kind: p.performer? "performer" : "person", eye:!!p.eyeC, gesture:p.gesture||null, gpeak:p.gPeak||0, ev:p.eventTag||null, ref:p, x:p.x, y:p.y, z:p.z, h:1.75*p.scale+(p.umbrella?0.6:0), r:0.32, vx:p.vx||0, vz:p.vz||0, heading:p.heading,
      stride:p.stride||0, aware:p.aware>1, umbrella:p.umbrella, vivid:p.vivid, hat:!!p.hat, dog:!!p.dog, phone:p.act==="phone", color:p.top, watcher:!!p.watcher });
  }
  for (const d of Life.dogs) out.push({ kind:"dog", ref:d, x:d.x,y:d.y,z:d.z, h:0.62*d.size*(d.leg||1), r:0.35*d.size*(d.len||1), vx:d.owner.vx||0, vz:d.owner.vz||0, heading:d.heading, color:d.color, ev: d.free ? "dogrun" : null });
  if (GP.truck && GP.truck.visible && GP.sirenEv){ const v = GP.sirenEv.v; out.push({ kind:"car", ref:GP.truck, x:v.x, y:H(v.x,v.z), z:v.z, h:2.2, r:1.4, len:6.5, vx:13*v.dir, vz:0, ev:"siren" }); }
  for (const f of Life.flocks){ if (!f.flying) continue; const fly = f.birds.filter(b=>b.flying); if (!fly.length) continue;
    let x=0,y=0,z=0; for (const b of fly){ x+=b.x; y+=b.y; z+=b.z; } x/=fly.length; y/=fly.length; z/=fly.length;
    let r = 0; for (const b of fly) r = Math.max(r, Math.hypot(b.x-x,b.y-y,b.z-z)); out.push({ kind:"birds", ref:f, x, y:y-r*0.5, z, h:r+0.4, r:r+0.2, vx:0, vz:0, count:fly.length, birds:fly }); }
  const cc = Life.cable; out.push({ kind:"cablecar", ref:cc, x:cc.x, y:H(cc.x,cc.z), z:cc.z, h:3.0, r:1.9, len:8.6, vx:0, vz:cc.vz });
  for (const c of Life.cars) out.push({ kind:"car", ref:c, x:c.x, y:H(c.x,c.z), z:c.z, h:c.bus?3.1:1.6, r:c.bus?1.6:1.3, len:c.bus?11:4.3, vx:c.vx, vz:0, taxi:c.taxi, bus:!!c.bus });
  return out;
}
// AF ray against moving things
function rayLife(o, d, maxD){
  let best = maxD, hit = null;
  const test = (cx, cy0, cy1, cz, r, obj) => {
    // vertical cylinder approx via closest approach in xz
    const ox = o.x - cx, oz = o.z - cz; const a = d.x*d.x + d.z*d.z; if (a < 1e-6) return;
    const b = 2*(ox*d.x + oz*d.z), c = ox*ox + oz*oz - r*r, disc = b*b - 4*a*c; if (disc < 0) return;
    const t = (-b - Math.sqrt(disc))/(2*a); if (t <= 0.1 || t >= best) return; const y = o.y + d.y*t; if (y < cy0 || y > cy1) return; best = t; hit = obj;
  };
  for (const p of Life.people) if (!p.hidden) test(p.x, p.y, p.y+1.8*p.scale, p.z, 0.3, p);
  for (const dg of Life.dogs) test(dg.x, dg.y, dg.y+0.7, dg.z, 0.35, dg);
  for (const c of Life.cars) test(c.x, H(c.x,c.z), H(c.x,c.z)+1.6, c.z, 1.4, c);
  const cc = Life.cable; test(cc.x, H(cc.x,cc.z), H(cc.x,cc.z)+2.9, cc.z, 2.2, cc);
  for (const b of Life.birds) if (b.flying) test(b.x, b.y-0.2, b.y+0.3, b.z, 0.25, b);
  return { dist:best, hit };
}
