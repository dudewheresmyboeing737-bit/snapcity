/* ============================================================
   Contact Sheet — Street Life & Architecture Pass
   Patch 39 — Ambient City Moments (performance rework)

   Short-lived, photographable street moments at real storefronts
   and open street areas, plus cheap facade/rooftop details.

   Rework notes
   - No runtime PointLights. Adding/removing a light changes the
     scene's light count, which forces three.js to rebuild every
     material's shader — a visible hitch. Window warmth is now an
     additive glow card on the shop glass.
   - Geometry and materials are cached and shared. Programs are
     pre-compiled once at init, so the first moment doesn't stall.
   - Everything sits on the real terrain (groundY), not at y = 0.
     The city is on hills; shopfronts sit around y ≈ 4, so the old
     moments spawned underground.
   - Moments spawn out of view (no pop-in) and linger until you
     look away (no pop-out), up to a grace limit.
   - Facade details face the street. Shops store n = (sin ry, cos ry),
     so local +Z is outward; stoops and bay windows used to point
     into the building.
   - Each facade/rooftop group is merged into one mesh per material
     and frozen (matrixAutoUpdate = false): ~2–3 draw calls per group
     instead of 6–9, and still frustum-culled individually.
   - Removed near-pedestrian props. The crowd is drawn with instanced
     meshes (Life.people entries have no .g group), so that code never
     ran. Props for the crowd belong inside posePerson().
   - Removed the boot() wrapper. Patch 36 calls boot() before this file
     loads, so wrapping it did nothing. Init happens on the first
     gameplay frame instead.
   - Uses G.cam (the game's camera). G.camera does not exist, so the
     old "in front of player" test always passed.
   - Reads S/G/World/Player/Game/Life via typeof. They are top-level
     let/const, so window.S etc. are undefined and the old patch
     never initialized at all.

   Requires: legacy game scripts (groundY, G, World, Game, Player, S).
   ============================================================ */
(function () {
  "use strict";

  // The game's core objects are top-level let/const in classic scripts, so
  // they are NOT properties of window (window.S is always undefined).
  // Read them through typeof instead.
  const env = {
    get S() { return typeof S !== "undefined" ? S : null; },
    get G() { return typeof G !== "undefined" ? G : null; },
    get World() { return typeof World !== "undefined" ? World : null; },
    get Player() { return typeof Player !== "undefined" ? Player : null; },
    get Game() { return typeof Game !== "undefined" ? Game : null; },
    get Life() { return typeof Life !== "undefined" ? Life : null; }
  };

  const CS39 = window.CS39 = window.CS39 || {};
  Object.assign(CS39, {
    initialized: false,
    architecture: [],
    activeMoments: [],
    nextMomentAt: 0,
    debug: { moments: 0, architecture: 0, lastMoment: "" }
  });

  const DEFAULTS = {
    streetMoments: "subtle",
    architectureDetail: "rich"
  };

  const MOMENT_RADIUS_MIN = 18;
  const MOMENT_RADIUS_MAX = 52;
  const MOMENT_AHEAD_DOT_MIN = -0.2;    // roughly ahead or to the side
  const MOMENT_LINGER_MAX_MS = 15000;   // extra time allowed while in view
  const MOMENT_DESPAWN_DIST = 110;      // end early if the player walks away
  const LOG_MOMENTS = false;

  const PERSON_PALETTES = [
    { coat: "#303f56", accent: "#d9a967", bag: "#8d5d44" },
    { coat: "#5b4658", accent: "#d7d1c3", bag: "#4a5364" },
    { coat: "#465c49", accent: "#c9955a", bag: "#705342" },
    { coat: "#6b3f3c", accent: "#d3c9b4", bag: "#4b4240" },
    { coat: "#39414b", accent: "#b8a17c", bag: "#745c41" },
    { coat: "#665f79", accent: "#ded6c5", bag: "#496475" }
  ];
  const SKIN_TONES = ["#c29172", "#8d5a3c", "#e0b394", "#6b4430", "#b07a57"];

  /* ----------------------------------------------------------
     Settings
     ---------------------------------------------------------- */

  function ensureSettings() {
    if (!env.S) return;
    S.custom = S.custom || {};
    Object.keys(DEFAULTS).forEach(function (key) {
      if (S.custom[key] === undefined) S.custom[key] = DEFAULTS[key];
    });
  }

  function option(name) {
    return env.S && S.custom ? S.custom[name] : undefined;
  }

  function architectureBudget() {
    const level = option("architectureDetail") || "rich";
    return {
      facades: level === "lean" ? 0 : level === "cinematic" ? 72 : 38,
      rooftops: level === "lean" ? 0 : level === "cinematic" ? 28 : 15
    };
  }

  /* ----------------------------------------------------------
     Shared resources
     ---------------------------------------------------------- */

  const MATS = new Map();
  const GEOS = new Map();

  function mat(hex, roughness, metalness) {
    const r = roughness === undefined ? 0.75 : roughness;
    const m = metalness === undefined ? 0 : metalness;
    const key = hex + "|" + r + "|" + m;
    let material = MATS.get(key);
    if (!material) {
      material = new THREE.MeshStandardMaterial({ color: hex, roughness: r, metalness: m });
      material.userData.cs39Shared = true;
      MATS.set(key, material);
    }
    return material;
  }

  function geo(key, factory) {
    let geometry = GEOS.get(key);
    if (!geometry) {
      geometry = factory();
      geometry.userData.cs39Shared = true;
      GEOS.set(key, geometry);
    }
    return geometry;
  }

  function box(w, h, d) {
    return geo("box|" + w + "|" + h + "|" + d, function () {
      return new THREE.BoxGeometry(w, h, d);
    });
  }

  function cyl(rt, rb, h, seg) {
    return geo("cyl|" + rt + "|" + rb + "|" + h + "|" + seg, function () {
      return new THREE.CylinderGeometry(rt, rb, h, seg);
    });
  }

  let glowBase = null;
  let glowGeometry = null;
  let birdMaterial = null;
  let birdGeometry = null;
  let umbrellaGeometry = null;
  let headGeometry = null;

  function sharedSpecials() {
    if (!glowBase) {
      glowBase = new THREE.MeshBasicMaterial({
        color: "#ffb86a",
        transparent: true,
        opacity: 0.0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        side: THREE.DoubleSide
      });
      glowGeometry = new THREE.PlaneGeometry(1, 1);
      birdMaterial = new THREE.MeshBasicMaterial({ color: "#20252b", side: THREE.DoubleSide });
      birdGeometry = new THREE.BufferGeometry();
      birdGeometry.setAttribute("position", new THREE.BufferAttribute(
        new Float32Array([-0.15, 0, 0, 0, 0.045, 0, 0.15, 0, 0]), 3
      ));
      umbrellaGeometry = new THREE.ConeGeometry(0.48, 0.18, 10, 1, true);
      headGeometry = new THREE.SphereGeometry(0.13, 8, 7);
    }
  }

  function addMesh(group, geometry, material, x, y, z, rx, ry, rz) {
    const mesh = new THREE.Mesh(geometry, material);
    mesh.position.set(x || 0, y || 0, z || 0);
    mesh.rotation.set(rx || 0, ry || 0, rz || 0);
    group.add(mesh);
    return mesh;
  }

  // Removes an object; disposes only resources this patch created per-instance.
  function removeObject(object) {
    if (!object) return;
    object.traverse(function (child) {
      if (!child.isMesh) return;
      if (child.geometry && !child.geometry.userData.cs39Shared &&
          child.geometry !== glowGeometry && child.geometry !== birdGeometry &&
          child.geometry !== umbrellaGeometry && child.geometry !== headGeometry) {
        child.geometry.dispose();
      }
      const material = child.material;
      if (material && material.userData && material.userData.cs39Own) material.dispose();
    });
    if (object.parent) object.parent.remove(object);
  }

  /* ----------------------------------------------------------
     World helpers
     ---------------------------------------------------------- */

  function ground(x, z) {
    try {
      if (typeof groundY === "function") return groundY(x, z);
      if (typeof H === "function") return H(x, z);
    } catch (e) {}
    return 0;
  }

  const _dir = new THREE.Vector3();
  const _frustum = new THREE.Frustum();
  const _projView = new THREE.Matrix4();
  const _sphere = new THREE.Sphere(new THREE.Vector3(), 1.4);
  let _frustumFrame = -1;

  function camera() {
    return env.G && G.cam ? G.cam : null;
  }

  function refreshFrustum() {
    const cam = camera();
    if (!cam) return false;
    const frame = env.Life && Life.frame !== undefined ? Life.frame : performance.now();
    if (frame !== _frustumFrame) {
      cam.updateMatrixWorld();
      _projView.multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse);
      _frustum.setFromProjectionMatrix(_projView);
      _frustumFrame = frame;
    }
    return true;
  }

  function inView(x, y, z, radius) {
    if (!refreshFrustum()) return false;
    _sphere.center.set(x, y, z);
    _sphere.radius = radius || 1.4;
    return _frustum.intersectsSphere(_sphere);
  }

  // Good spawn spot: within range, roughly ahead, but not currently on screen.
  function goodSpawnPoint(x, z) {
    if (!env.Player) return false;
    const dx = x - Player.x;
    const dz = z - Player.z;
    const distance = Math.hypot(dx, dz);
    if (distance < MOMENT_RADIUS_MIN || distance > MOMENT_RADIUS_MAX) return false;

    const cam = camera();
    if (!cam) return true;
    cam.getWorldDirection(_dir);
    const flat = Math.hypot(_dir.x, _dir.z) || 1;
    const dot = (dx / distance) * (_dir.x / flat) + (dz / distance) * (_dir.z / flat);
    if (dot < MOMENT_AHEAD_DOT_MIN) return false;

    return !inView(x, ground(x, z) + 1, z, 1.6);
  }

  function makeShopAnchor(shop, index) {
    if (!shop || !shop.n) return null;
    const nx = shop.n[0], nz = shop.n[1];
    const tx = nz, tz = -nx; // local +X for a group rotated by shop.ry
    const width = Math.max(0.8, Math.min(shop.w || 2, 5));
    const side = index % 2 ? 1 : -1;
    const outward = 0.9;
    const lateral = side * Math.min(width * 0.18, 0.48);

    const x = shop.x + nx * outward + tx * lateral;
    const z = shop.z + nz * outward + tz * lateral;
    if (!goodSpawnPoint(x, z)) return null;

    return {
      x: x, z: z, y: ground(x, z),
      normalX: nx, normalZ: nz, tangentX: tx, tangentZ: tz,
      angle: Math.atan2(nx, nz), // faces the street
      shop: shop, index: index
    };
  }

  function chooseShopAnchor() {
    if (!env.World || !Array.isArray(World.shops) || !World.shops.length) return null;
    const attempts = Math.min(40, World.shops.length * 2);
    for (let i = 0; i < attempts; i += 1) {
      const index = Math.floor(Math.random() * World.shops.length);
      const anchor = makeShopAnchor(World.shops[index], index);
      if (anchor) return anchor;
    }
    return null;
  }

  function chooseOpenAnchor() {
    if (!env.Player) return null;
    for (let i = 0; i < 24; i += 1) {
      const angle = Math.random() * Math.PI * 2;
      const distance = MOMENT_RADIUS_MIN + Math.random() * (MOMENT_RADIUS_MAX - MOMENT_RADIUS_MIN);
      const x = Player.x + Math.cos(angle) * distance;
      const z = Player.z + Math.sin(angle) * distance;
      if (!goodSpawnPoint(x, z)) continue;
      return {
        x: x, z: z, y: ground(x, z), angle: angle,
        normalX: Math.cos(angle), normalZ: Math.sin(angle),
        tangentX: -Math.sin(angle), tangentZ: Math.cos(angle)
      };
    }
    return null;
  }

  /* ----------------------------------------------------------
     Moment building blocks
     ---------------------------------------------------------- */

  function createMomentPerson(x, z, facing, paletteIndex) {
    sharedSpecials();
    const group = new THREE.Group();
    const palette = PERSON_PALETTES[Math.abs(paletteIndex) % PERSON_PALETTES.length];
    const legMat = mat("#27292c", 0.84, 0);
    const coatMat = mat(palette.coat, 0.8, 0);
    const skinMat = mat(SKIN_TONES[Math.abs(paletteIndex) % SKIN_TONES.length], 0.9, 0);
    const leg = cyl(0.08, 0.1, 0.72, 6);
    const arm = cyl(0.045, 0.05, 0.48, 6);

    addMesh(group, leg, legMat, -0.075, 0.38, 0);
    addMesh(group, leg, legMat, 0.075, 0.38, 0);
    addMesh(group, box(0.32, 0.56, 0.16), coatMat, 0, 1.02, 0);
    addMesh(group, headGeometry, skinMat, 0, 1.43, 0);
    const leftArm = addMesh(group, arm, coatMat, -0.23, 1.06, 0, 0, 0, 0.26);
    const rightArm = addMesh(group, arm, coatMat, 0.23, 1.06, 0, 0, 0, -0.26);

    const baseY = ground(x, z);
    group.position.set(x, baseY, z);
    group.rotation.y = facing;
    group.userData.baseY = baseY;
    group.userData.leftArm = leftArm;
    group.userData.rightArm = rightArm;
    group.userData.palette = palette;
    group.userData.kind = "moment-person";

    G.scene.add(group);
    return group;
  }

  function addMomentCoffeeCup(person, side) {
    const group = new THREE.Group();
    addMesh(group, cyl(0.035, 0.045, 0.14, 7), mat("#e4d7bd", 0.9, 0),
      side * 0.23, 1.18, 0.05, -0.15, 0, side * 0.12);
    addMesh(group, cyl(0.039, 0.039, 0.015, 7), mat(person.userData.palette.accent, 0.65, 0),
      side * 0.23, 1.255, 0.05, -0.15, 0, side * 0.12);
    person.add(group);
    return group;
  }

  function addMomentCamera(person, side) {
    const group = new THREE.Group();
    addMesh(group, box(0.14, 0.09, 0.06), mat("#1f252b", 0.35, 0.28),
      side * 0.22, 1.24, 0.1, -0.18, 0, side * 0.12);
    addMesh(group, cyl(0.028, 0.028, 0.04, 8), mat("#40474e", 0.28, 0.45),
      side * 0.22, 1.24, 0.145, Math.PI / 2, 0, 0);
    person.add(group);
    return group;
  }

  function createMomentUmbrella(x, z, facing, color) {
    sharedSpecials();
    const group = new THREE.Group();
    addMesh(group, umbrellaGeometry, mat(color, 0.76, 0), 0, 1.78, 0, Math.PI, 0, 0);
    addMesh(group, cyl(0.013, 0.013, 1.05, 5), mat("#302c2a", 0.42, 0.25), 0, 1.24, 0);
    group.position.set(x, ground(x, z), z);
    group.rotation.y = facing;
    G.scene.add(group);
    return group;
  }

  // Warm light spilling from the shop window, without a real light.
  function createWindowGlow(anchor) {
    sharedSpecials();
    const shop = anchor.shop;
    const material = glowBase.clone();
    material.userData.cs39Own = true;
    const glow = new THREE.Mesh(glowGeometry, material);
    const width = Math.min(Math.max((shop.w || 3) * 0.45, 1.2), 3.2);
    glow.scale.set(width, 2.2, 1);
    glow.position.set(
      shop.x + shop.n[0] * 0.09,
      (shop.gy !== undefined ? shop.gy : anchor.y) + 1.9,
      shop.z + shop.n[1] * 0.09
    );
    glow.rotation.y = shop.ry || anchor.angle;
    glow.renderOrder = 2;
    G.scene.add(glow);
    return glow;
  }

  function daylightFactor() {
    // Glow reads stronger at dusk/night; subtle during the day.
    const T = env.World && World.timeDef;
    if (T && typeof T.lamps === "number") return 0.35 + 0.65 * Math.min(1, T.lamps);
    return 0.5;
  }

  function makeMoment(kind, duration, focalPoint, subjects, updater) {
    const now = performance.now();
    return {
      kind: kind,
      startedAt: now,
      expiresAt: now + duration,
      hardLimit: now + duration + MOMENT_LINGER_MAX_MS,
      focalPoint: focalPoint,
      subjects: subjects,
      update: updater || function () {}
    };
  }

  /* ----------------------------------------------------------
     Moments
     ---------------------------------------------------------- */

  function createWindowGazeMoment() {
    const anchor = chooseShopAnchor();
    if (!anchor) return null;
    const facing = anchor.angle + Math.PI; // looking into the window
    const person = createMomentPerson(anchor.x, anchor.z, facing, anchor.index + 1);
    const glow = createWindowGlow(anchor);
    const k = daylightFactor();

    return makeMoment("window-gaze", 20000 + Math.random() * 7000,
      new THREE.Vector3(anchor.x, anchor.y + 1.2, anchor.z), [person, glow],
      function (now) {
        person.rotation.y = facing + Math.sin(now * 0.00045 + anchor.index) * 0.12;
        person.position.y = person.userData.baseY + Math.sin(now * 0.0012 + anchor.index) * 0.008;
        glow.material.opacity = k * (0.22 + Math.sin(now * 0.0017 + anchor.index) * 0.04);
      });
  }

  function createCoffeePauseMoment() {
    const anchor = chooseShopAnchor();
    if (!anchor) return null;
    const facing = anchor.angle + Math.PI * 0.12; // mostly facing the street
    const person = createMomentPerson(anchor.x, anchor.z, facing, anchor.index + 4);
    const cup = addMomentCoffeeCup(person, anchor.index % 2 ? 1 : -1);
    const glow = createWindowGlow(anchor);
    const k = daylightFactor();

    return makeMoment("coffee-pause", 16000 + Math.random() * 7000,
      new THREE.Vector3(anchor.x, anchor.y + 1.2, anchor.z), [person, glow],
      function (now) {
        const sway = Math.sin(now * 0.0014 + anchor.index);
        person.rotation.y = facing + sway * 0.13;
        cup.rotation.z = sway * 0.08;
        person.position.y = person.userData.baseY + sway * 0.007;
        glow.material.opacity = k * (0.18 + Math.sin(now * 0.0012 + anchor.index) * 0.03);
      });
  }

  function createDoorwayConversationMoment() {
    const anchor = chooseShopAnchor();
    if (!anchor) return null;
    const sep = 0.38;
    // Face each other across the tangent axis.
    const faceA = Math.atan2(-anchor.tangentX, -anchor.tangentZ);
    const faceB = Math.atan2(anchor.tangentX, anchor.tangentZ);
    const personA = createMomentPerson(anchor.x + anchor.tangentX * sep, anchor.z + anchor.tangentZ * sep, faceA, anchor.index + 2);
    const personB = createMomentPerson(anchor.x - anchor.tangentX * sep, anchor.z - anchor.tangentZ * sep, faceB, anchor.index + 5);
    const glow = createWindowGlow(anchor);
    const k = daylightFactor();

    return makeMoment("doorway-conversation", 18000 + Math.random() * 8000,
      new THREE.Vector3(anchor.x, anchor.y + 1.2, anchor.z), [personA, personB, glow],
      function (now) {
        const gesture = Math.sin(now * 0.0018 + anchor.index);
        personA.rotation.y = faceA + gesture * 0.08;
        personB.rotation.y = faceB - gesture * 0.08;
        personA.userData.rightArm.rotation.z = -0.26 + Math.max(0, gesture) * 0.3;
        personB.userData.leftArm.rotation.z = 0.26 - Math.max(0, -gesture) * 0.3;
        glow.material.opacity = k * (0.18 + Math.sin(now * 0.0013 + anchor.index) * 0.03);
      });
  }

  function createUmbrellaCrossingMoment() {
    if (!S.rain && !S.fog) return null;
    const anchor = chooseOpenAnchor();
    if (!anchor) return null;
    const facing = Math.atan2(anchor.normalX, anchor.normalZ);
    const startX = anchor.x - anchor.normalX * 3.2;
    const startZ = anchor.z - anchor.normalZ * 3.2;
    const person = createMomentPerson(startX, startZ, facing, Math.floor(Math.random() * PERSON_PALETTES.length));
    const umbrella = createMomentUmbrella(startX, startZ, facing, "#414b61");

    return makeMoment("umbrella-crossing", 13000,
      new THREE.Vector3(anchor.x, anchor.y + 1.2, anchor.z), [person, umbrella],
      function (now) {
        const elapsed = (now - this.startedAt) / 1000;
        const stride = Math.min(elapsed * 0.7, 6.8);
        const x = startX + anchor.normalX * stride;
        const z = startZ + anchor.normalZ * stride;
        const y = ground(x, z);
        const walking = stride < 6.8;
        person.position.set(x, y, z);
        umbrella.position.set(x, y, z);
        umbrella.rotation.z = Math.sin(now * 0.003 + anchor.angle) * 0.035;
        const swing = walking ? Math.sin(now * 0.009) * 0.12 : 0;
        person.userData.leftArm.rotation.z = 0.26 + swing;
        person.userData.rightArm.rotation.z = -0.26 - swing;
      });
  }

  function createBirdTakeoffMoment() {
    sharedSpecials();
    const anchor = chooseOpenAnchor();
    if (!anchor) return null;

    const subjects = [];
    const count = 6 + Math.floor(Math.random() * 4);
    for (let i = 0; i < count; i += 1) {
      const bird = new THREE.Group();
      const wings = new THREE.Mesh(birdGeometry, birdMaterial);
      bird.add(wings);
      const bx = anchor.x + (Math.random() - 0.5) * 2;
      const bz = anchor.z + (Math.random() - 0.5) * 1.5;
      const d = {
        x0: bx, z0: bz, y0: ground(bx, bz) + 0.05,
        phase: Math.random() * Math.PI * 2,
        speed: 1.2 + Math.random() * 1.7,
        delay: 0.35 + Math.random() * 0.8,
        dx: anchor.normalX * (0.7 + Math.random() * 0.75) + (Math.random() - 0.5) * 0.85,
        dz: anchor.normalZ * (0.7 + Math.random() * 0.75) + (Math.random() - 0.5) * 0.85,
        wings: wings
      };
      bird.userData = d;
      bird.position.set(bx, d.y0, bz);
      bird.rotation.y = Math.atan2(d.dx, d.dz);
      G.scene.add(bird);
      subjects.push(bird);
    }

    return makeMoment("bird-takeoff", 7500,
      new THREE.Vector3(anchor.x, anchor.y + 1.0, anchor.z), subjects,
      function (now) {
        const elapsed = (now - this.startedAt) / 1000;
        subjects.forEach(function (bird) {
          const d = bird.userData;
          const f = Math.max(0, elapsed - d.delay);
          if (f <= 0) {
            bird.position.y = d.y0 + Math.sin(now * 0.004 + d.phase) * 0.018;
            return;
          }
          // Time-based (was per-frame), so birds fly the same at any fps.
          const travel = 0.78 * d.speed * f;
          bird.position.set(d.x0 + d.dx * travel, d.y0 + 0.72 * f + 0.054 * f * f, d.z0 + d.dz * travel);
          d.wings.scale.y = 0.45 + Math.sin(now * 0.018 + d.phase) * 0.45;
        });
      });
  }

  function createStreetPhotographerMoment() {
    const anchor = chooseShopAnchor();
    if (!anchor) return null;
    const x = anchor.x + anchor.tangentX * 0.55;
    const z = anchor.z + anchor.tangentZ * 0.55;
    const facing = Math.atan2(-anchor.tangentX, -anchor.tangentZ) + 0.35; // shooting along the block
    const person = createMomentPerson(x, z, facing, anchor.index + 3);
    const cam = addMomentCamera(person, anchor.index % 2 ? 1 : -1);

    return makeMoment("street-photographer", 14000 + Math.random() * 6000,
      new THREE.Vector3(x, person.userData.baseY + 1.25, z), [person],
      function (now) {
        const phase = Math.sin(now * 0.0015 + anchor.index);
        const shoot = Math.max(0, Math.sin(now * 0.00085 + anchor.index));
        person.rotation.y = facing + phase * 0.16;
        cam.position.y = shoot > 0.72 ? 0.08 : 0;
        person.userData.leftArm.rotation.z = 0.26 - shoot * 0.42;
        person.userData.rightArm.rotation.z = -0.26 + shoot * 0.42;
      });
  }

  const MOMENT_FACTORIES = {
    "window-gaze": createWindowGazeMoment,
    "coffee-pause": createCoffeePauseMoment,
    "doorway-conversation": createDoorwayConversationMoment,
    "bird-takeoff": createBirdTakeoffMoment,
    "street-photographer": createStreetPhotographerMoment,
    "umbrella-crossing": createUmbrellaCrossingMoment
  };

  function canCreateMoment() {
    if (!env.Game || !Game.started) return false;
    if (!env.Player || !env.G || !G.scene) return false;
    if (option("streetMoments") === "off") return false;
    const limit = option("streetMoments") === "frequent" ? 2 : 1;
    return CS39.activeMoments.length < limit;
  }

  function chooseMoment() {
    const kinds = ["window-gaze", "coffee-pause", "doorway-conversation", "bird-takeoff", "street-photographer"];
    if (S.rain || S.fog) kinds.push("umbrella-crossing");
    // Shuffle so each kind gets a fair try.
    for (let i = kinds.length - 1; i > 0; i -= 1) {
      const j = Math.floor(Math.random() * (i + 1));
      const t = kinds[i]; kinds[i] = kinds[j]; kinds[j] = t;
    }
    for (let i = 0; i < kinds.length; i += 1) {
      const moment = MOMENT_FACTORIES[kinds[i]]();
      if (moment) return moment;
    }
    return null;
  }

  function endMoment(moment) {
    if (!moment || !moment.subjects) return;
    moment.subjects.forEach(removeObject);
    moment.subjects = [];
  }

  function momentVisible(moment) {
    const p = moment.focalPoint;
    return p ? inView(p.x, p.y, p.z, 2.5) : false;
  }

  function updateMoments(now) {
    if (canCreateMoment() && now >= CS39.nextMomentAt) {
      const moment = chooseMoment();
      if (moment) {
        CS39.activeMoments.push(moment);
        CS39.nextMomentAt = now + (option("streetMoments") === "frequent"
          ? 18000 + Math.random() * 12000
          : 34000 + Math.random() * 28000);
        CS39.debug.lastMoment = moment.kind;
        if (LOG_MOMENTS) console.info("[Contact Sheet] Street moment started:", moment.kind);
      } else {
        CS39.nextMomentAt = now + 4000; // no good spot yet; try again soon
      }
    }

    if (!CS39.activeMoments.length) {
      CS39.debug.moments = 0;
      return;
    }

    CS39.activeMoments = CS39.activeMoments.filter(function (moment) {
      const p = moment.focalPoint;
      const far = env.Player && p && Math.hypot(p.x - Player.x, p.z - Player.z) > MOMENT_DESPAWN_DIST;
      const expired = now >= moment.expiresAt;
      // Don't vanish in front of the player; wait until they look away.
      if (far || now >= moment.hardLimit || (expired && !momentVisible(moment))) {
        if (LOG_MOMENTS) console.info("[Contact Sheet] Street moment ended:", moment.kind);
        endMoment(moment);
        return false;
      }
      moment.update(now);
      return true;
    });

    CS39.debug.moments = CS39.activeMoments.length;
  }

  /* ----------------------------------------------------------
     Architecture
     Groups are built in local space (+Z = street side), then merged
     into one mesh per material and frozen.
     ---------------------------------------------------------- */

  function mergeGroupByMaterial(group) {
    const buckets = new Map();
    group.updateMatrixWorld(true);
    const inverse = new THREE.Matrix4().copy(group.matrixWorld).invert();
    const local = new THREE.Matrix4();

    group.traverse(function (child) {
      if (!child.isMesh) return;
      local.multiplyMatrices(inverse, child.matrixWorld);
      const g = child.geometry.clone();
      g.applyMatrix4(local);
      if (!buckets.has(child.material)) buckets.set(child.material, []);
      buckets.get(child.material).push(g);
    });

    const merged = new THREE.Group();
    buckets.forEach(function (geometries, material) {
      let vertexCount = 0, indexCount = 0;
      geometries.forEach(function (g) {
        vertexCount += g.attributes.position.count;
        indexCount += g.index ? g.index.count : g.attributes.position.count;
      });
      const pos = new Float32Array(vertexCount * 3);
      const nor = new Float32Array(vertexCount * 3);
      const IndexArray = vertexCount > 65535 ? Uint32Array : Uint16Array;
      const idx = new IndexArray(indexCount);
      let vOffset = 0, iOffset = 0;
      geometries.forEach(function (g) {
        pos.set(g.attributes.position.array, vOffset * 3);
        if (g.attributes.normal) nor.set(g.attributes.normal.array, vOffset * 3);
        if (g.index) {
          const src = g.index.array;
          for (let i = 0; i < src.length; i += 1) idx[iOffset + i] = src[i] + vOffset;
          iOffset += src.length;
        } else {
          for (let i = 0; i < g.attributes.position.count; i += 1) idx[iOffset + i] = vOffset + i;
          iOffset += g.attributes.position.count;
        }
        vOffset += g.attributes.position.count;
        g.dispose();
      });
      const out = new THREE.BufferGeometry();
      out.setAttribute("position", new THREE.BufferAttribute(pos, 3));
      out.setAttribute("normal", new THREE.BufferAttribute(nor, 3));
      out.setIndex(new THREE.BufferAttribute(idx, 1));
      out.computeBoundingSphere();
      const mesh = new THREE.Mesh(out, material);
      mesh.matrixAutoUpdate = false;
      if (material.transparent) mesh.renderOrder = 1;
      merged.add(mesh);
    });

    merged.position.copy(group.position);
    merged.rotation.copy(group.rotation);
    merged.matrixAutoUpdate = false;
    merged.updateMatrix();
    merged.updateMatrixWorld(true);
    return merged;
  }

  function placeOnShop(group, shop, lift) {
    group.position.set(shop.x, (shop.gy || 0) + (lift || 0), shop.z);
    group.rotation.y = shop.ry || 0;
  }

  function commitArchitecture(group) {
    const merged = mergeGroupByMaterial(group);
    G.scene.add(merged);
    CS39.architecture.push(merged);
  }

  function doorLateral(shop, doorWidth, index) {
    const half = Math.max(0, (shop.w || 2) / 2 - doorWidth / 2 - 0.15);
    return (index % 2 ? 1 : -1) * half;
  }

  function addDoor(group, shop, index, lift) {
    const doorWidth = Math.min(0.9, (shop.w || 2) * 0.18);
    const doorHeight = 2.05;
    const x = doorLateral(shop, doorWidth, index);
    const y = lift || 0;
    const frame = mat("#2d2925", 0.74, 0.05);
    const door = mat(index % 2 ? "#4d3a30" : "#353b40", 0.68, 0.08);
    // Glass front face is at local z ≈ +0.05; sit just proud of it.
    addMesh(group, box(doorWidth, doorHeight, 0.06), door, x, y + doorHeight / 2, 0.09);
    addMesh(group, box(0.08, doorHeight + 0.12, 0.09), frame, x - doorWidth / 2, y + doorHeight / 2, 0.1);
    addMesh(group, box(0.08, doorHeight + 0.12, 0.09), frame, x + doorWidth / 2, y + doorHeight / 2, 0.1);
    addMesh(group, box(doorWidth + 0.14, 0.08, 0.09), frame, x, y + doorHeight + 0.03, 0.1);
    return { x: x, width: doorWidth };
  }

  function addDoorFrame(shop, index) {
    const group = new THREE.Group();
    placeOnShop(group, shop);
    addDoor(group, shop, index, 0);
    commitArchitecture(group);
  }

  function addStoop(shop, index) {
    const group = new THREE.Group();
    placeOnShop(group, shop);
    const stepH = 0.12;
    const lift = stepH * 3;
    const door = addDoor(group, shop, index, lift);
    const width = Math.min(door.width + 0.5, 1.4);
    const stone = mat(index % 3 === 0 ? "#736f68" : "#5d5b58", 0.9, 0);
    // Stepped block: widest at street level, narrowing toward the door.
    for (let step = 0; step < 3; step += 1) {
      const depth = 0.18 * (3 - step);
      addMesh(group, box(width, stepH, depth), stone, door.x, stepH / 2 + step * stepH, 0.05 + depth / 2);
    }
    const rail = mat("#24272a", 0.5, 0.38);
    [-1, 1].forEach(function (side) {
      addMesh(group, cyl(0.018, 0.018, 0.62, 5), rail, door.x + side * (width / 2 - 0.05), lift + 0.31, 0.32);
    });
    commitArchitecture(group);
  }

  function addBayWindow(shop, index) {
    const group = new THREE.Group();
    // Above the storefront glass (which tops out near gy + 3.45).
    placeOnShop(group, shop, 3.95);
    const width = Math.min((shop.w || 2) * 0.38, 1.45);
    const trim = mat(index % 2 ? "#d0c7b5" : "#b8b0a2", 0.75, 0.05);
    let glass = MATS.get("cs39-bay-glass");
    if (!glass) {
      glass = new THREE.MeshStandardMaterial({
        color: "#4e7180", emissive: "#5a3e24", emissiveIntensity: 0.18,
        roughness: 0.28, metalness: 0.08, transparent: true, opacity: 0.82
      });
      glass.userData.cs39Shared = true;
      MATS.set("cs39-bay-glass", glass);
    }
    addMesh(group, box(width, 0.92, 0.28), trim, 0, 0.46, 0.14);
    addMesh(group, box(width * 0.82, 0.64, 0.02), glass, 0, 0.47, 0.29);
    [-width * 0.27, 0, width * 0.27].forEach(function (x) {
      addMesh(group, box(0.035, 0.72, 0.05), trim, x, 0.47, 0.305);
    });
    addMesh(group, box(width + 0.08, 0.06, 0.36), trim, 0, 0.95, 0.16);
    addMesh(group, box(width + 0.08, 0.06, 0.34), trim, 0, -0.03, 0.15);
    commitArchitecture(group);
  }

  function addRooftopProp(roof, index) {
    if (!roof) return;
    const group = new THREE.Group();
    const variant = index % 3;

    if (variant === 0) {
      addMesh(group, box(0.35, 1.05, 0.35), mat("#6b6258", 0.9, 0), 0, 0.53, 0);
      addMesh(group, box(0.48, 0.1, 0.48), mat("#413d39", 0.78, 0.04), 0, 1.08, 0);
    } else if (variant === 1) {
      const vent = mat("#899196", 0.42, 0.52);
      addMesh(group, cyl(0.24, 0.24, 0.45, 10), vent, 0, 0.24, 0);
      addMesh(group, cyl(0.31, 0.31, 0.07, 10), vent, 0, 0.49, 0);
    } else {
      addMesh(group, cyl(0.42, 0.42, 0.74, 10), mat("#3b4d5a", 0.52, 0.32), 0, 0.53, 0);
      [-0.23, 0.23].forEach(function (side) {
        addMesh(group, cyl(0.028, 0.028, 0.68, 5), mat("#2c2b29", 0.6, 0.3), side, 0.3, 0);
      });
    }

    // Offset in the roof's own axes so props stay on rotated roofs.
    const ry = roof.ry || 0;
    const ox = (seeded(index, 40) - 0.5) * (roof.w || 4) * 0.45;
    const oz = (seeded(index, 41) - 0.5) * (roof.d || 4) * 0.45;
    const c = Math.cos(ry), s = Math.sin(ry);
    group.position.set(roof.x + ox * c + oz * s, roof.top !== undefined ? roof.top : 12, roof.z - ox * s + oz * c);
    group.rotation.y = ry;
    commitArchitecture(group);
  }

  function seeded(index, salt) {
    const v = Math.sin(index * 127.1 + salt * 311.7) * 43758.5453123;
    return v - Math.floor(v);
  }

  function buildArchitecture() {
    if (!env.G || !G.scene || !env.World) return;
    if (CS39.architecture.length) return;
    const budget = architectureBudget();
    if (!budget.facades && !budget.rooftops) return;

    const shops = (World.shops || []).filter(function (s) { return s && s.n; });
    const facadeCount = Math.min(budget.facades, shops.length);
    const shopStep = facadeCount ? shops.length / facadeCount : 1;
    for (let i = 0; i < facadeCount; i += 1) {
      const shop = shops[Math.floor(i * shopStep)]; // spread across the city
      const selector = i % 4;
      if (selector === 0) addDoorFrame(shop, i);
      else if (selector === 1) addStoop(shop, i);
      else if (selector === 2) addBayWindow(shop, i);
      else { addDoorFrame(shop, i); addBayWindow(shop, i); }
    }

    const roofs = World.roofs || [];
    const roofCount = Math.min(budget.rooftops, roofs.length);
    const roofStep = roofCount ? roofs.length / roofCount : 1;
    for (let i = 0; i < roofCount; i += 1) {
      // +4 keeps clear of the every-9th roofs used by patch 23.
      addRooftopProp(roofs[(Math.floor(i * roofStep) + 4) % roofs.length], i);
    }

    CS39.debug.architecture = CS39.architecture.length;
  }

  function removeArchitecture() {
    CS39.architecture.forEach(function (object) {
      object.traverse(function (child) {
        if (child.isMesh && child.geometry) child.geometry.dispose(); // merged geometry is per-group
      });
      if (object.parent) object.parent.remove(object);
    });
    CS39.architecture = [];
    CS39.debug.architecture = 0;
  }

  /* ----------------------------------------------------------
     Shader pre-warm: compile every program this patch can use
     once, at init, so no moment triggers a compile mid-walk.
     ---------------------------------------------------------- */

  function prewarm() {
    if (!G.renderer || !G.renderer.compile || !G.cam) return;
    sharedSpecials();
    PERSON_PALETTES.forEach(function (p) { mat(p.coat, 0.8, 0); mat(p.accent, 0.65, 0); });
    SKIN_TONES.forEach(function (c) { mat(c, 0.9, 0); });
    ["#27292c|0.84|0", "#e4d7bd|0.9|0", "#1f252b|0.35|0.28", "#40474e|0.28|0.45",
     "#414b61|0.76|0", "#302c2a|0.42|0.25"].forEach(function (k) {
      const parts = k.split("|");
      mat(parts[0], +parts[1], +parts[2]);
    });

    const holder = new THREE.Group();
    const tiny = box(0.01, 0.01, 0.01);
    MATS.forEach(function (material) { holder.add(new THREE.Mesh(tiny, material)); });
    holder.add(new THREE.Mesh(glowGeometry, glowBase));
    holder.add(new THREE.Mesh(birdGeometry, birdMaterial));
    holder.position.copy(G.cam.position);
    G.scene.add(holder);
    try { G.renderer.compile(G.scene, G.cam); } catch (e) {}
    G.scene.remove(holder);
  }

  /* ----------------------------------------------------------
     Settings menu
     ---------------------------------------------------------- */

  function setupSettingsMenu() {
    if (typeof menuSettings !== "function") return;
    const previous = menuSettings;

    window.menuSettings = function () {
      ensureSettings();
      const c = S.custom;
      const segment = function (key, entries) {
        return `<div class="seg" data-seg="${key}">` +
          entries.map(function (e) {
            return `<button data-v="${e[0]}" aria-pressed="${c[key] === e[0]}">${e[1]}</button>`;
          }).join("") + `</div>`;
      };

      const section =
        `<div class="sectionhead">Street Life & Architecture</div>` +
        `<div class="formrow"><label>Street moments</label>` +
        segment("streetMoments", [["off", "Off"], ["subtle", "Subtle"], ["frequent", "Frequent"]]) +
        `<span class="spec">Short-lived scenes at real storefronts and open street areas: window gazes, coffee pauses, conversations, rain crossings, photographers, and bird takeoffs.</span></div>` +
        `<div class="formrow"><label>Architecture detail</label>` +
        segment("architectureDetail", [["lean", "Lean"], ["rich", "Rich"], ["cinematic", "Cinematic"]]) +
        `<span class="spec">Doors, stoops, bay windows, chimneys, vents, and rooftop tanks on selected buildings.</span></div>`;

      return section + previous.apply(this, arguments);
    };
  }

  function wireSettingsMenu() {
    if (typeof wireMenu !== "function") return;
    const previous = wireMenu;

    window.wireMenu = function () {
      const result = previous.apply(this, arguments);
      const menuBody = document.querySelector("#menubody");
      if (!menuBody) return result;

      menuBody.querySelectorAll('[data-seg="streetMoments"] button,[data-seg="architectureDetail"] button')
        .forEach(function (button) {
          button.onclick = function () {
            const group = button.closest("[data-seg]");
            if (!group) return;
            const key = group.dataset.seg;
            ensureSettings();
            S.custom[key] = button.dataset.v;

            if (key === "architectureDetail") {
              removeArchitecture();
              buildArchitecture();
            }
            if (key === "streetMoments" && S.custom[key] === "off") {
              CS39.activeMoments.forEach(endMoment);
              CS39.activeMoments = [];
              CS39.debug.moments = 0;
            }
            saveState();
            renderMenu();
          };
        });
      return result;
    };
  }

  /* ----------------------------------------------------------
     Lifecycle
     ---------------------------------------------------------- */

  function initialize() {
    if (CS39.initialized) return;
    if (!env.S || !env.G || !G.scene || !env.World || !World.shops) return;
    ensureSettings();
    buildArchitecture();
    prewarm();
    CS39.nextMomentAt = performance.now() + 12000;
    CS39.initialized = true;
    console.info("[Contact Sheet] Street Life & Architecture Pass initialized.");
  }

  function attachToGameLoop() {
    if (typeof gameplayUpdate !== "function") return;
    const previous = gameplayUpdate;

    window.gameplayUpdate = function () {
      const result = previous.apply(this, arguments);
      try {
        if (!CS39.initialized) initialize();
        else updateMoments(performance.now());
      } catch (error) {
        console.warn("[Contact Sheet Patch 39] Optional update skipped:", error);
      }
      return result;
    };
  }

  // Debug helper: CS39.spawn("window-gaze") forces a moment (ignores limits).
  CS39.spawn = function (kind) {
    const factory = MOMENT_FACTORIES[kind];
    if (!factory) return Object.keys(MOMENT_FACTORIES);
    const moment = factory();
    if (moment) CS39.activeMoments.push(moment);
    return moment ? moment.kind : null;
  };

  ensureSettings();
  setupSettingsMenu();
  wireSettingsMenu();
  attachToGameLoop();

  console.info("[Contact Sheet] Street Life & Architecture Pass loaded.");
})();
