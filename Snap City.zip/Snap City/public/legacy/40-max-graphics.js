/* =========================================================
   Patch 40 — Max graphics defaults
   Every graphics / world-detail setting at its highest value.

   - New games (career or free roam) start with these values.
   - Existing saves are upgraded once (flag: _maxGraphicsApplied).
     After that, anything you change in Settings sticks.
   To go back to lighter defaults, edit MAX_GRAPHICS below.
   ========================================================= */
(function(){
  "use strict";

  const MAX_GRAPHICS = {
    // Core renderer (15-legacy / 10-legacy)
    renderQuality: "ultra",          // supersampled view, 4096 shadows, 2x capture SS
    reflections: "high",
    graphicsEnhance: "on",           // SSAO + enhancement pass (20-legacy)
    weatherPolish: "on",
    // Stylized graphics overhaul (38)
    graphicsPreset: "ultra",
    atmosphereStrength: "cinematic",
    wetStreets: "on",
    livingSky: "on",
    facadeDetail: "obsessive",
    crowdPresentation: "rich",
    cinematicBloom: "on",
    stylizedPalette: "on",
    // Architecture (39)
    architectureDetail: "cinematic",
    // World detail and population
    streetDetail: "max",
    characterVariety: "max",
    vehicleVariety: "max",
    faceVariety: "max",
    specialVehicles: "on",
    peopleDensity: "full",
    trafficDensity: "full",
    streetcars: "8",
    birdLife: "normal",
    cloudLife: "some",
    windowLife: "on",
    neonAmount: "lots",
    stringLights: "on",
    litterOn: "on"
  };
  window.CS_MAX_GRAPHICS = MAX_GRAPHICS;

  function applyMax(s){
    if(!s) return s;
    s.custom = s.custom || {};
    Object.assign(s.custom, MAX_GRAPHICS);
    // Keep the old one-time "performance" migrations (29, 31) from ever firing.
    s.custom._v145Applied = true;
    s.custom._v147LeanApplied = true;
    s.custom._maxGraphicsApplied = true;
    return s;
  }

  // New games: defaultState() builds S.custom from scratch.
  if(typeof defaultState === "function"){
    const baseDefaultState = defaultState;
    window.defaultState = function(){
      return applyMax(baseDefaultState.apply(this, arguments));
    };
  }

  // Existing saves: upgrade once. Hooked as the outermost gameplayUpdate wrapper so
  // it runs before patch 38/39 initialise on the first frame (they read these
  // settings once, when they build clouds, birds, facade detail, etc.).
  function refresh(){
    try{ applyGraphicsQuality(); }catch(e){}
    try{ polishWorldMaterials(); }catch(e){}
    try{ applyInteriorSettings(); }catch(e){}
  }
  // Boot hook (outermost wrapper, since this file loads last): runs after every
  // other patch's boot migrations, and before patch 38 builds its layer.
  if(typeof boot === "function"){
    const baseBoot = boot;
    window.boot = async function(){
      // Decide from the raw save: boot merges defaultState().custom (which already
      // carries the flag) under the saved settings, so S.custom can't tell us.
      let needsUpgrade = true;
      try{ const raw = loadState(); needsUpgrade = !(raw && raw.custom && raw.custom._maxGraphicsApplied); }catch(e){}
      const result = await baseBoot.apply(this, arguments);
      try{
        if(needsUpgrade && typeof S !== "undefined" && S && S.custom){
          applyMax(S);   // brand-new player, or an older save being upgraded once
          refresh();
          saveState();
          console.info("[Contact Sheet] Graphics set to maximum.");
        }
      }catch(e){ console.warn("[Contact Sheet] Max graphics skipped:", e); }
      return result;
    };
  }

  // Fallback for anything that starts before boot finishes.
  if(typeof gameplayUpdate === "function"){
    const baseUpdate = gameplayUpdate;
    let checked = false;
    window.gameplayUpdate = function(){
      if(!checked && typeof S !== "undefined" && S && S.custom){
        checked = true;
        if(!S.custom._maxGraphicsApplied){
          applyMax(S);
          refresh();
          try{ saveState(); }catch(e){}
          console.info("[Contact Sheet] Graphics set to maximum.");
        }
      }
      return baseUpdate.apply(this, arguments);
    };
  }
})();
