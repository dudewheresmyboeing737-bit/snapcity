/* Snap City — equipment, persistent weather, input and the camera workbench.
   Loaded after the legacy systems. Public APIs also support repeatable smoke checks. */
(function(){
  'use strict';
  const SC=window.SnapCity={version:'1.0.0',capturePending:false,weatherTimer:210};
  const DEFAULTS={renderQuality:'balanced',graphicsPreset:'medium',graphicsEnhance:'off',
    atmosphereStrength:'subtle',cinematicBloom:'off',stylizedPalette:'off',
    livingSky:'on',cloudLife:'off',reflections:'balanced',facadeDetail:'rich',architectureDetail:'rich',
    streetDetail:'rich',faceVariety:'max',crowdPresentation:'rich',streetMoments:'frequent',
    psxStyle:'enhanced',captureQuality:'responsive',autoWeather:'off',fogAmount:'normal',
    eventPace:'normal',filmAdvance:'auto',shotPreview:'on',walkBob:'low',quickPickHud:'on'};
  const roles=['wide','normal','tele'];
  const names=['Wide','Normal','Tele'];
  const costs=[180,360];
  SC.cameraArt=id=>window.SNAP_CAMERA_ART?.[id]||`./cameras/${id}.svg`;
  function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function migrate(s){
    if(!s)return s;
    s.custom=s.custom||{};s.skills=s.skills||{};s.rolls=s.rolls||{};s.lensByBody=s.lensByBody||{};
    if(!s.custom._snapCity){Object.assign(s.custom,DEFAULTS);s.custom._snapCity=1;}
    for(const k in DEFAULTS) if(s.custom[k]===undefined)s.custom[k]=DEFAULTS[k];
    s.owned=s.owned||{bodies:['disp'],lenses:[],flashes:['none'],films:[]};
    s.owned.bodies=s.owned.bodies.filter(k=>BODIES[k]);
    s.owned.lenses=s.owned.lenses.filter(k=>LENSES[k]&&!LENSES[k].fixed);
    s.owned.films=(s.owned.films||[]).filter(k=>FILMS[k]);
    if(!s.owned.bodies.length)s.owned.bodies=['disp'];
    if(!BODIES[s.body])s.body=s.owned.bodies[0];
    for(const id of s.owned.bodies){
      const b=BODIES[id];
      if(!s.rolls[id]||!FILMS[s.rolls[id].stock])s.rolls[id]=defaultRoll(id);
      if(b.kit&&(!LENSES[s.lensByBody[id]]||!mountFits(b,LENSES[s.lensByBody[id]]))){
        s.lensByBody[id]=b.kit;if(!s.owned.lenses.includes(b.kit))s.owned.lenses.push(b.kit);
      }
    }
    for(const k in s.rolls)if(!BODIES[k])delete s.rolls[k];
    for(const k in s.lensByBody)if(!BODIES[k])delete s.lensByBody[k];
    s.skills.quickpick=s.skills.quickpick||0;
    s.quickKit=Array.isArray(s.quickKit)?s.quickKit:[null,null,null];
    s.quickSettings=s.quickSettings||{};s.weatherRevision=s.weatherRevision||0;
    if(s.free){
      for(const k in SKILLS)s.skills[k]=SKILLS[k].max;
      s.owned.bodies=Object.keys(BODIES);s.owned.lenses=Object.keys(LENSES).filter(k=>!LENSES[k].fixed);
      s.owned.filters=Object.keys(LENS_FILTERS).filter(k=>k!=='none');s.money=999999999;
      if(!s.quickKit.some(Boolean))s.quickKit=[{body:'gr1v',lens:'fx_gr1',focal:28},{body:'nikonf',lens:'f_50',focal:50},{body:'fm2',lens:'f_105',focal:105}];
      s.skillPts=0;
    }
    s.quickKit=s.quickKit.map((x,i)=>validKit(x,i,s)?x:null);
    return s;
  }
  SC.migrate=migrate;
  const baseDefault=defaultState;defaultState=function(free){return migrate(baseDefault(free));};
  const baseLoad=loadState;loadState=function(){return migrate(baseLoad());};
  const baseStart=startGame;startGame=function(mode){const r=baseStart(mode);migrate(S);SC.weatherTimer=210;updateKitHud();return r;};
  function focalRole(mm){return mm<40?0:mm<=70?1:2;}
  function validKit(slot,i,s=S){
    if(!slot||!BODIES[slot.body]||!s.owned.bodies.includes(slot.body))return false;
    const b=BODIES[slot.body],l=LENSES[slot.lens];
    if(!l||(b.L?b.L!==slot.lens:!s.owned.lenses.includes(slot.lens)||!mountFits(b,l)))return false;
    const mm=slot.focal||l.f;
    return mm>=l.f&&mm<=(l.f2||l.f)&&focalRole(mm)===i;
  }
  function kitOptions(i){
    const out=[];
    for(const id of S.owned.bodies){const b=BODIES[id];if(!b)continue;
      const lenses=b.L?[b.L]:S.owned.lenses.filter(k=>LENSES[k]&&mountFits(b,LENSES[k]));
      for(const lid of lenses){const l=LENSES[lid];const f=l.f2?clamp([28,50,105][i],l.f,l.f2):l.f;
        if(focalRole(f)!==i)continue;out.push({body:id,lens:lid,focal:f});}
    }return out;
  }
  function slotLabel(x){return x?`${BODIES[x.body].n} · ${x.focal}mm`:'Choose a camera';}
  function kitMenu(){
    const rank=sk('quickpick'),count=1+rank;
    return `<section class="sc-kit"><div class="sc-section-label">QUICK PICK <span>35mm / THREE PERSPECTIVES</span></div><p class="note">Keep a wide, normal and tele body loaded. Press <kbd>1</kbd> <kbd>2</kbd> <kbd>3</kbd> to switch. Each body keeps its own roll and exposure settings. Focus presets: <kbd>Alt</kbd> + number.</p><div class="sc-kit-slots">${roles.map((role,i)=>{
      const slot=S.quickKit[i],opts=kitOptions(i),locked=i>=count;
      return `<div class="sc-kit-slot ${locked?'locked':''}"><div class="sc-slot-heading"><b>${i+1}</b><span>${names[i]}<small>${['Under 40mm','40–70mm','Over 70mm'][i]}</small></span></div>${slot?`<img src="${SC.cameraArt(slot.body)}" alt="${esc(BODIES[slot.body].n)}">`:'<div class="sc-empty-camera">＋</div>'}<select aria-label="${names[i]} quick-pick camera" data-kit-slot="${i}" ${locked?'disabled':''}><option value="">${locked?'Learn Quick pick in Skills':'Choose a camera + lens'}</option>${opts.map(x=>`<option value="${x.body}|${x.lens}|${x.focal}" ${slot&&x.body===slot.body&&x.lens===slot.lens&&x.focal===slot.focal?'selected':''}>${esc(slotLabel(x))}</option>`).join('')}</select><small>${locked?`Quick pick rank ${i} required`:slot?'Loaded and ready':'Only owned, compatible gear appears'}</small></div>`;
    }).join('')}</div></section>`;
  }
  const baseGear=menuGear;menuGear=function(){return kitMenu()+baseGear();};
  const baseCamItem=camItem;camItem=function(id){let h=baseCamItem(id);return h.replace('<div class="camhead">',`<div class="sc-camera-plate"><span class="sc-plate-index">${String(Object.keys(BODIES).indexOf(id)+1).padStart(2,'0')} / 135</span><img src="${SC.cameraArt(id)}" alt="Low-poly illustration of ${esc(BODIES[id].n)}" loading="lazy" width="480" height="300"></div><div class="camhead">`);};
  const baseSkills=menuSkills;menuSkills=function(){
    const rank=sk('quickpick'),cost=costs[rank];
    let h=baseSkills();
    // Quick pick spends XP directly, while the other skills retain their level-point system.
    h=h.replace(/<div class="item[^>]*><h4>Quick pick<\/h4>[\s\S]*?<\/div><\/div>/,'');
    return `<section class="sc-skill"><div class="sc-dial">${rank}<small>QUICK PICK</small></div><div><div class="sc-section-label">QUICK PICK / ${rank===2?'MASTERED':`RANK ${rank} OF 2`}</div><h3>A camera for the moment.</h3><p>Rank 1 unlocks two ready bodies. Rank 2 unlocks wide, normal and tele together. Free Play begins at maximum rank.</p><div class="sc-skill-price">${rank<2?`<button class="btn" data-quick-learn ${!S.free&&S.xp<cost?'disabled':''}>Learn rank ${rank+1} · ${cost} XP</button><span>${S.xp} XP available</span>`:'<span class="sc-mastered">● All three cameras ready</span>'}</div></div></section>`+h;
  };
  SC.learnQuickPick=function(){const rank=sk('quickpick'),cost=costs[rank];if(rank>=2||(!S.free&&S.xp<cost))return false;if(!S.free)S.xp-=cost;S.skills.quickpick=rank+1;saveState();updateKitHud();return true;};
  function saveCurrentKitSettings(){S.quickSettings[S.body]={...S.set};}
  SC.assignKit=function(i,value){
    if(i>sk('quickpick')||i<0||i>2)return false;
    if(!value){S.quickKit[i]=null;saveState();updateKitHud();return true;}
    const [body,lens,focal]=value.split('|'),slot={body,lens,focal:+focal};
    if(!validKit(slot,i))return false;
    if(S.quickKit.some((x,j)=>j!==i&&x&&x.body===body)){toast('That body is already in another slot. Choose a different camera.');return false;}
    S.quickKit[i]=slot;saveState();updateKitHud();return true;
  };
  SC.selectKit=function(i){
    if(!S||i>sk('quickpick')){toast('Learn Quick pick in Skills to open this slot.');return false;}
    const slot=S.quickKit[i];if(!validKit(slot,i)){toast(`Choose your ${names[i].toLowerCase()} camera in the camera bag.`);return false;}
    if(SC.capturePending||CAP.busy||GP.loadT>0){toast('Finish this frame or film load first.',800);return false;}
    saveCurrentKitSettings();
    if(!BODIES[slot.body].L)S.lensByBody[slot.body]=slot.lens;
    equip('bodies',slot.body);
    if(S.quickSettings[slot.body])Object.assign(S.set,S.quickSettings[slot.body]);
    if(!modesFor(curBody()).includes(S.set.mode))S.set.mode=modesFor(curBody())[0];
    Player.zoomF=slot.focal;Player.lensSwap=0;Cam.afLock=false;Cam.focus=S.set.focus||4;
    SC.selectedSlot=i;computeExposure();UI.hudT=0;updateKitHud();saveState();
    toast(`${i+1} / ${names[i]} — ${slotLabel(slot)}`,1000);return true;
  };
  function updateKitHud(){
    if(!S)return;let el=document.querySelector('#quickPick');if(!el){el=document.createElement('div');el.id='quickPick';el.className='interactive';document.querySelector('#hud').append(el);}
    el.classList.toggle('hidden',S.custom.quickPickHud==='off');
    el.innerHTML=roles.map((_,i)=>{const x=S.quickKit[i],active=x&&S.body===x.body;return `<button data-quick-pick="${i}" aria-label="Quick pick ${names[i]}" aria-pressed="${!!active}" ${i>sk('quickpick')?'disabled':''}><kbd>${i+1}</kbd><span>${names[i]}<small>${x?x.focal+'mm':i>sk('quickpick')?'LOCKED':'EMPTY'}</small></span></button>`;}).join('');
  }
  const baseKey=onKey;onKey=function(e){
    if(Game.started&&!UI.open&&!/^(INPUT|SELECT|TEXTAREA)$/.test(e.target?.tagName||'')){
      if(/^Digit[123]$/.test(e.code)&&!e.altKey&&!e.ctrlKey&&!e.metaKey){e.preventDefault();if(!e.repeat)SC.selectKit(+e.code.slice(-1)-1);return;}
      if(e.altKey&&/^Digit[1-5]$/.test(e.code)){e.preventDefault();setZone(e.code);return;}
    }return baseKey(e);
  };
  const baseKeys=menuKeys;menuKeys=function(){return `<div class="sc-control-strip"><b>QUICK PICK</b> 1 Wide · 2 Normal · 3 Tele <span>Alt + 1–5: focus distances</span></div>`+baseKeys();};
  const baseEquip=equip;equip=function(kind,id){if(SC.capturePending||CAP.busy){toast('Saving the frame — try again in a moment.',800);return;}const r=baseEquip(kind,id);updateKitHud();return r;};
  const baseCapture=captureShot;
  captureShot=async function(){
    if(SC.capturePending||CAP.busy)return null;
    SC.capturePending=true;const began=performance.now();
    const rr=G.renderer,oldAuto=rr.autoClear,oldRain=Rain.len,heldVisible=heldCam&&heldCam.visible;
    try{return await baseCapture.apply(this,arguments);}
    catch(e){console.error('[Snap City] Capture failed',e);toast('Could not save that frame. The shutter is ready to try again.');return null;}
    finally{SC.capturePending=false;CAP.busy=false;SC.lastCaptureMs=performance.now()-began;rr.setRenderTarget(null);rr.autoClear=oldAuto;Rain.len=oldRain;G.quad.material=G.post;G.post.blending=THREE.NormalBlending;G.post.uniforms.accW.value=1;if(CAP.flash)CAP.flash.intensity=0;if(heldCam)heldCam.visible=heldVisible;document.querySelector('#shutterfx').style.opacity='0';}
  };
  function weatherSnapshot(){return {rain:!!S.rain,storm:!!S.storm,snow:!!S.snow,fog:!!S.fog};}
  SC.weather=function(mode,fog){
    if(!S)return;
    if(mode){S.storm=mode==='storm';S.rain=mode==='rain'||S.storm;S.snow=mode==='snow';}
    if(fog!==undefined)S.fog=!!fog;
    S.weatherRevision++;SC.weatherTimer=210+Math.random()*150;
    if(S.storm&&window.CS144Storm){CS144Storm.t=1.0;CS144Storm.activeWas=true;}
    Audio.init();applyTime();saveState();return weatherSnapshot();
  };
  SC.temporaryWeather=function(mode,fog,duration){
    if(S.custom.autoWeather!=='on')return null;
    const was=weatherSnapshot();SC.weather(mode,fog);const revision=S.weatherRevision;
    return {type:mode||'fog',t:0,ppl:[],done:false,x:Player.x,z:Player.z,step(){if(this.t>=duration){if(S.weatherRevision===revision){Object.assign(S,was);applyTime();}this.done=true;}}};
  };
  const baseEvent=startEvent;startEvent=function(type){if(type==='storm')return SC.temporaryWeather('storm',undefined,180);if(type==='fog')return SC.temporaryWeather(null,true,180);return baseEvent(type);};
  const baseTime=menuTime;menuTime=function(){return `<div class="sc-weather-display"><span>LIGHT / ATMOSPHERE</span><b>${S.storm?'THUNDERSTORM':S.snow?'SNOW':S.rain?'RAIN':'CLEAR'}${S.fog?' + FOG':''}</b><small>${S.custom.autoWeather==='on'?'Weather evolves slowly. Manual selections restart the weather timer.':'Manual weather stays set until you change it. Fog can coexist with rain or a storm.'}</small></div>`+baseTime();};
  const baseWire=wireMenu;wireMenu=function(){
    const r=baseWire();const b=document.querySelector('#menubody');
    b.querySelectorAll('[data-kit-slot]').forEach(el=>el.onchange=()=>{SC.assignKit(+el.dataset.kitSlot,el.value);renderMenu();});
    const learn=b.querySelector('[data-quick-learn]');if(learn)learn.onclick=()=>{if(SC.learnQuickPick()){toast(`Quick pick rank ${sk('quickpick')} learned.`);renderMenu();}};
    for(const type of ['rain','snow','storm','fog'])b.querySelectorAll(`[data-${type}] button`).forEach(el=>el.onclick=()=>{const on=el.dataset.v==='1';if(type==='fog')SC.weather(null,on);else SC.weather(on?type:'clear');renderMenu();});
    b.querySelectorAll('[data-seg="autoWeather"] button').forEach(el=>el.onclick=()=>{S.custom.autoWeather=el.dataset.v;S.weatherRevision++;SC.weatherTimer=240;saveState();renderMenu();});
    b.querySelectorAll('[data-seg="fogAmount"] button').forEach(el=>el.onclick=()=>{S.custom.fogAmount=el.dataset.v;applyTime();saveState();renderMenu();});
    b.querySelectorAll('[data-sc-setting]').forEach(el=>el.onclick=()=>{S.custom[el.dataset.scSetting]=el.dataset.value;saveState();applyGraphicsQuality();resize();updateKitHud();renderMenu();});
    return r;
  };
  const baseSettings=menuSettings;menuSettings=function(){
    const group=(id,label,opts)=>`<div class="sc-setting"><label>${label}</label><div class="sc-choice">${opts.map(([v,l])=>`<button data-sc-setting="${id}" data-value="${v}" aria-pressed="${S.custom[id]===v}">${l}</button>`).join('')}</div></div>`;
    const row=(id,label,opts,spec)=>`<div class="formrow" data-sc-row="${id}"><label>${label}</label><div class="seg">${opts.map(([v,l])=>`<button data-sc-setting="${id}" data-value="${v}" aria-pressed="${S.custom[id]===v}">${l}</button>`).join('')}</div>${spec?`<span class="spec">${spec}</span>`:''}</div>`;
    return row('psxStyle','Picture character',[['enhanced','Stylized'],['classic','Retro'],['clean','Clean']],'Stylized adds a faceted colour grade; Retro lowers resolution and colour depth for a vintage-console feel; Clean is untouched.')+row('captureQuality','Photo processing',[['responsive','Responsive'],['detail','Fine detail']],'Responsive saves 1080px photos with a shorter render; Fine detail saves 1500px.')+row('quickPickHud','Quick pick display',[['on','On'],['off','Off']],'The wide / normal / tele strip above the camera controls.')+baseSettings();
  };
  const baseRenderMenu=renderMenu;renderMenu=function(){
    const r=baseRenderMenu();const menu=document.querySelector('#menu');menu.dataset.scTab=UI.menuTab;
    const title=menu.querySelector('h2');title.innerHTML='<span class="sc-brand-mark">◉</span> SNAP CITY <small>CAMERA WORKBENCH</small>';
    document.querySelectorAll('#menu .tabs button').forEach((b,i)=>{b.dataset.number=String(i+1).padStart(2,'0');});
    if(UI.menuTab==='settings'||UI.menuTab==='custom'){
      const body=document.querySelector('#menubody');let block=null;
      [...body.children].forEach(el=>{if(el.classList.contains('sectionhead')){block=document.createElement('details');block.className='sc-settings-section';block.open=true;const sum=document.createElement('summary');sum.innerHTML=el.innerHTML;body.insertBefore(block,el);block.append(sum);el.remove();}else if(block)block.append(el);});
    }return r;
  };
  const baseGameUpdate=gameplayUpdate;gameplayUpdate=function(dt){
    const r=baseGameUpdate(dt);
    if(S&&S.custom.autoWeather==='on'){SC.weatherTimer-=dt;if(SC.weatherTimer<=0){const mode=pick(['clear','clear','rain','storm','clear']);SC.weather(mode,Math.random()<.28);toast(S.storm?'Thunder rolls over the rooftops.':S.rain?'Rain finds the pavement.':S.fog?'The city disappears into the fog.':'The light opens up.',2200);}}
    if(Rain.mesh&&S.storm){Rain.mesh.visible=true;Rain.mesh.material.uniforms.uA.value=.62;Rain.len=.64;}
    return r;
  };
  const baseHud=updateHUD;updateHUD=function(dt){const r=baseHud(dt);if(S.free){const money=document.querySelector('#stats .money');if(money)money.textContent='∞ FREE PLAY';}return r;};
  document.addEventListener('click',e=>{const el=e.target.closest?.('[data-quick-pick]');if(el){e.preventDefault();SC.selectKit(+el.dataset.quickPick);}});
  moneyStr=function(){return S.free?'Free Play · infinite money · every camera and skill':`$${S.money.toLocaleString()} in your pocket`;};
  const baseBoot=boot;boot=async function(){await baseBoot();migrate(S);updateKitHud();SC.ready=true;};
})();
