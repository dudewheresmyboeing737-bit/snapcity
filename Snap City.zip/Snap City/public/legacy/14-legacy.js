
/* =========================================================
   UI: panels, contact-sheet gallery, lightbox, menu, HUD
   ========================================================= */
const UI = { open:null, sort:"date", photos:[], lbIndex:-1, sample:null, sampleImages:false, downloads:null, urls:[], menuTab:"gear", hudT:0, mapT:0, locT:0 };

function showPanel(sel){
  for (const p of ["#menu","#gallery","#editor","#essayPanel"]) if (p !== sel) $(p).classList.add("hidden");
  $(sel).classList.remove("hidden"); UI.open = sel;
  if (document.pointerLockElement) document.exitPointerLock();
  Player.raised = false; Input.keys = {};
  $("#hud").classList.add("hidden"); $("#vf").classList.add("hidden"); $("#touch").classList.add("hidden");
}
function onPanelClosed(){
  UI.open = null; for (const p of ["#menu","#gallery","#editor","#essayPanel"]) $(p).classList.add("hidden"); $("#lightbox").classList.add("hidden");
  if (Game.started){ $("#hud").classList.remove("hidden"); if (Input.touch) $("#touch").classList.remove("hidden"); }
  applyHudPref();
}
function closeAll(){ if (!$("#lightbox").classList.contains("hidden")){ closeLightbox(); return; } if (UI.open === "#editor"){ $("#edCancel").click(); return; } onPanelClosed(); }

/* ---------------- gallery ---------------- */
function revokeUrls(){ for (const u of UI.urls) URL.revokeObjectURL(u); UI.urls = []; }
async function openGallery(){
  showPanel("#gallery");
  UI.photos = await DB.all();
  renderSheet();
}
function sortedPhotos(){
  const arr = UI.photos.slice();
  if (UI.sort === "score") arr.sort((a,b)=> (b.score??-1) - (a.score??-1) || b.ts - a.ts); else arr.sort((a,b)=>b.ts - a.ts);
  return arr;
}
function greaseSVG(kind){
  if (kind === "keep"){
    const w = 100, h = 70, pts = []; const j = () => rand(-2.2,2.2);
    for (let i=0;i<=26;i++){ const a = -0.5 + i/24*Math.PI*2.12; pts.push(`${(50 + Math.cos(a)*(46+j())).toFixed(1)},${(35 + Math.sin(a)*(31+j())).toFixed(1)}`); }
    return `<svg class="grease" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true"><polyline points="${pts.join(" ")}" fill="none" stroke="#c0362c" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke" style="stroke-width:3px"/></svg>`;
  }
  return `<svg class="grease" viewBox="0 0 100 70" preserveAspectRatio="none" aria-hidden="true"><path d="M22 14 L78 58 M79 12 L24 57" fill="none" stroke="#c0362c" stroke-width="3" stroke-linecap="round" vector-effect="non-scaling-stroke" opacity=".85"/></svg>`;
}
function renderSheet(){
  const sh = $("#sheet"); const arr = sortedPhotos();
  $$("#gsort button").forEach(b=>b.setAttribute("aria-pressed", b.dataset.sort===UI.sort));
  const un = UI.photos.filter(p=>!p.judged).length;
  $("#judgeAll").textContent = un ? `Judge ${un} unjudged` : "All frames judged"; $("#judgeAll").disabled = !un;
  if (!arr.length){ sh.innerHTML = `<p class="empty">No frames yet. Raise the camera with the right mouse button (or Z), frame something worth keeping, and click to take the picture. Your frames develop here as a contact sheet, and the editor will circle the keepers in grease pencil.</p>`; return; }
  const per = innerWidth < 700 ? 3 : 6;
  let html = "";
  const name = (S.name||"").trim() ? S.name.trim().toUpperCase().slice(0,18) : "";
  for (let i=0;i<arr.length;i+=per){
    html += `<div class="filmstrip" role="list" aria-label="Film strip">`;
    for (const p of arr.slice(i,i+per)){
      const sc = p.judged ? p.score : null, grease = sc!==null ? (sc >= 70 ? greaseSVG("keep") : sc < 35 ? greaseSVG("x") : "") : "";
      html += `<button class="frame${p.meta.instant?" instant":""}${p.meta.W && p.meta.W/p.meta.H > 2 ? " pano":""}" role="listitem" data-id="${p.id}" aria-label="Frame ${p.frameNo}${sc!==null?`, score ${sc}`:", not judged"}">
        <img src="${p.editedThumb || p.thumb}" alt="" loading="lazy">${grease}
        <span class="num">▸ ${p.frameNo}${p.edit?"A":""} &nbsp;${i===0 && p===arr[0] ? name : ""}</span><span class="sc">${sc!==null? sc : "—"}</span></button>`;
    }
    html += `</div>`;
  }
  sh.innerHTML = html;
  $$("#sheet .frame").forEach(f=>f.onclick = ()=>openLightbox(f.dataset.id));
}
async function judgeAllUnjudged(){
  const btn = $("#judgeAll"); btn.disabled = true;
  let n = 0, money = 0, ups = 0, best = 0;
  for (const p of UI.photos.filter(p=>!p.judged).sort((a,b)=>a.ts-b.ts)){
    const res = judgePhoto(p, p.editStats || p.meta.stats); const pay = applyJudgement(p, res); await DB.put(p);
    n++; money += pay.money; ups += pay.ups; best = Math.max(best, res.total);
  }
  renderSheet();
  toast(`${n} frame${n===1?"":"s"} judged. Best: ${best}.${!S.free && money? ` You earned $${money}.`:""}${ups? ` Level up! ${ups} new skill point${ups>1?"s":""}.`:""}`, 3600);
}

/* ---------------- lightbox ---------------- */
async function openLightbox(id, info){
  if (!UI.photos.length) UI.photos = await DB.all();
  const arr = sortedPhotos(); UI.lbIndex = arr.findIndex(p=>p.id===id); const p = arr[UI.lbIndex]; if (!p) return;
  revokeUrls(); const url = URL.createObjectURL(p.edited || p.orig); UI.urls.push(url);
  $("#lbimg").src = url; $("#lbimg").alt = `Frame ${p.frameNo}, ${p.meta.street}`;
  $("#lightbox").classList.remove("hidden");
  renderLbSide(p, info); addEssayButton(p);
}
function closeLightbox(){ $("#lightbox").classList.add("hidden"); revokeUrls(); if (UI.open === "#gallery") renderSheet(); }
function lbStep(d){ const arr = sortedPhotos(); if (!arr.length) return; const i = clamp(UI.lbIndex + d, 0, arr.length-1); if (i !== UI.lbIndex) openLightbox(arr[i].id); }
const CATL = { comp:"Composition", subj:"Subject and moment", light:"Light", sharp:"Sharpness", color:"Colour and tone" };
function exifLine(m){
  const fl = m.flash ? ` · ${m.flash}` : "";
  return `${m.bodyName} · ${m.lens}${m.feq? ` (${m.feq}mm equiv.)`:""}<br>${m.filmName? m.filmName + (m.push? ` pushed ${m.push>0?"+":""}${m.push}`:"") + (m.fmtName? ` · ${m.fmtName}`:"") + "<br>" : ""}${fmtShutter(m.t)} · ${fmtA(m.N)} · ASA ${m.iso}${fl}${m.hip?" · from the hip":""}<br>${m.street}, ${m.hood}<br>${m.timeName}${m.fog?", fog":""}`;
}
function renderLbSide(p, info){
  const side = $("#lbside"), m = p.meta;
  let top;
  if (p.judged){
    const delta = info && info.prev !== undefined && info.prev !== null && info.prev !== p.score ? `<span class="of">${p.score > info.prev ? "▲" : "▼"} from ${info.prev}</span>` : "";
    top = `<div class="score"><span class="big">${p.score}</span><span class="of">/ 100</span>${delta}</div><div class="verdict">${p.verdict||""}</div>
      ${Object.keys(CATL).map(k=>`<div class="cat"><span>${CATL[k]}</span><span class="bar"><b style="width:${p.cats[k]}%"></b></span><span>${p.cats[k]}</span></div>`).join("")}
      <div class="critique">${(p.critique||[]).map(t=>`<p>${t}</p>`).join("")}</div>`;
    if (info && info.pay && (info.pay.money || info.pay.ups)) top += `<p class="note">${!S.free && info.pay.money ? `Paid $${info.pay.money} by the photo desk. ` : ""}${info.pay.ups ? `Level up: you have ${S.skillPts} skill point${S.skillPts>1?"s":""} to spend.`:""}</p>`;
  } else top = `<div class="score"><span class="big">—</span><span class="of">not judged</span></div><p class="note">Judge it as shot, or develop it in the darkroom first. The photo desk pays for your best version.</p>`;
  const d = new Date(p.ts);
  side.innerHTML = `${top}
    <div class="exif">Frame ${p.frameNo}${p.edit?" (edited)":""} · ${d.toLocaleDateString()} ${d.toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"})}<br>${exifLine(m)}</div>
    <div class="actions">
      ${p.judged ? "" : `<button class="btn small" id="lbJudge">Judge it</button>`}
      <button class="btn small ${p.judged?"":"alt"}" id="lbEdit">Develop in darkroom</button>
      ${UI.sample && UI.sampleImages ? `<button class="btn small alt" id="lbAsk">Ask Claude for a critique</button>` : ""}
      ${UI.downloads ? `<button class="btn small alt" id="lbDown">Save to device</button>` : ""}
      <button class="btn small alt" id="lbDel">Delete</button>
      <button class="btn small alt" id="lbClose">Close</button>
    </div>
    <div class="note" style="margin-top:10px">← → to flip through frames · Esc to close</div>
    <div id="lbClaude"></div>`;
  const j = $("#lbJudge"); if (j) j.onclick = async ()=>{ const prev = p.score; const res = judgePhoto(p, p.editStats || m.stats); const pay = applyJudgement(p, res); await DB.put(p); renderLbSide(p, { prev, pay }); };
  $("#lbEdit").onclick = ()=>{ $("#lightbox").classList.add("hidden"); revokeUrls(); openEditor(p); };
  $("#lbClose").onclick = closeLightbox;
  $("#lbDel").onclick = async ()=>{ if (!confirm(`Delete frame ${p.frameNo}?`)) return; await DB.del(p.id); UI.photos = UI.photos.filter(x=>x.id!==p.id); closeLightbox(); };
  const dn = $("#lbDown"); if (dn) dn.onclick = async ()=>{ try { const nm = `contact-sheet-${String(p.frameNo).padStart(3,"0")}${p.edit?"-edit":""}.jpg`; const r = await UI.downloads.save({ filename:nm, data:p.edited || p.orig }); if (r && r.status === "saved") toast("Saved."); } catch(e){ if (e && e.code === "unavailable"){ UI.downloads = null; dn.remove(); } else if (!e || e.code !== "cancelled") toast("Couldn't save that file."); } };
  const ask = $("#lbAsk"); if (ask) ask.onclick = ()=>askClaude(p, ask);
}
async function askClaude(p, btn){
  const out = $("#lbClaude"); out.innerHTML = `<div class="claude-out">Thinking...</div>`; const box = out.firstChild; btn.disabled = true;
  const m = p.meta;
  const prompt = `You are a seasoned street photography editor. The attached image is a frame from a street photography game set in a stylised, procedurally generated fictional city called Snap City. Give a candid, specific critique in under 170 words: what works, what doesn't (composition, moment, light, timing), and one concrete thing to try next time on the street. Plain prose, no headings or lists, no score.
Shot details: ${m.bodyName}, ${m.lens}, ${m.filmName||"film"}, ${fmtShutter(m.t)} at ${fmtA(m.N)}, ASA ${m.iso}${m.flash?`, ${m.flash}`:""}; ${m.timeName}${m.fog?" in fog":""}; ${m.street}.${p.edit?" The photographer edited it in the darkroom.":""}${p.judged?` The in-game judge scored it ${p.score}/100.`:""}`;
  try {
    const { text } = await UI.sample(prompt, { images: p.edited || p.orig, onText: ({text}) => { box.textContent = text; } });
    box.textContent = text;
  } catch(e){
    box.textContent = e && e.text ? e.text : "";
    const msg = { not_granted:"Claude critiques were declined for this session.", images_unavailable:"This view can't send images to Claude.", rate_limited:"Too many requests right now. Try again in a minute.", cancelled:"" }[e && e.code];
    if (e && (e.code === "not_granted" || e.code === "images_unavailable")){ UI.sample = null; btn.remove(); }
    box.textContent = (box.textContent ? box.textContent + "\n\n" : "") + (msg ?? "Claude couldn't answer just now.");
  } finally { btn.disabled = false; }
}

/* ---------------- menu ---------------- */
function openMenu(tab){ if (tab) UI.menuTab = tab; showPanel("#menu"); renderMenu(); }
function renderMenu(){
  $$("#menu .tabs button").forEach(b=>b.setAttribute("aria-selected", b.dataset.tab===UI.menuTab));
  const body = $("#menubody");
  body.innerHTML = ({ gear:menuGear, film:menuFilm, skills:menuSkills, custom:menuCustom, time:menuTime, settings:menuSettings, keys:menuKeys })[UI.menuTab]();
  wireMenu();
}
function moneyStr(){ return S.free ? "Free roam: all gear unlocked" : `$${S.money.toLocaleString()} in your pocket`; }
function gearBtn(kind, id, price, owned, equipped, disabled){
  if (equipped) return `<span class="spec">Equipped</span>`;
  if (owned) return `<button class="btn small" data-equip="${kind}:${id}" ${disabled? "disabled":""}>Equip</button>`;
  const can = S.free || S.money >= price;
  return `<button class="btn small ${can?"":"alt"}" data-buy="${kind}:${id}" ${can?"":"disabled"}>Buy</button>`;
}
function camItem(id){
  const b = BODIES[id], owned = S.owned.bodies.includes(id), eq = S.body === id, fmt = FORMATS[b.fmt], fam = owned && S.fam && S.fam[id] ? ` · ${famLabel(id)} (${S.fam[id]} frames)` : "";
  const lens = b.L ? LENSES[b.L].n : `${MOUNTS[b.m]} mount${b.kit? ` · comes with ${LENSES[b.kit].n}`:""}`;
  const feats = [fmt.n, lens, b.fx ? "fixed exposure" : "modes " + b.md.split("").join(" "), b.mt ? "meter" : "no meter", b.af ? "autofocus" : b.ff ? "fixed focus" : b.zone ? "scale focus" : b.t==="Rangefinder"||b.t==="Panoramic" ? "rangefinder focus" : "manual focus", b.fl ? "built-in flash" : "", b.fx ? "" : `1/${b.ts}`].filter(Boolean).join(" · ");
  return `<div class="item ${eq?"equipped":""}"><div class="camhead"><span class="kind">${b.t}</span></div><h4>${b.n}</h4><div class="spec">${feats}${fam}</div><div class="desc">${b.d}</div>
    <div class="foot"><span class="price">${owned? "Owned" : "$"+b.p.toLocaleString()}</span>${gearBtn("bodies", id, b.p, owned, eq)}</div></div>`;
}
function lensItem(id){
  const L = LENSES[id], b = curBody(), owned = S.owned.lenses.includes(id), fits = mountFits(b, L), eq = !b.L && S.lensByBody[S.body] === id;
  const diag = Math.hypot(FORMATS[b.fmt].w, FORMATS[b.fmt].h);
  const eqv = fits ? ` · on this camera ≈ ${Math.round(L.f*43.27/diag)}${L.f2?"–"+Math.round(L.f2*43.27/diag):""}mm equiv.` : "";
  const ch = [L.glow>0.2?"glowing wide open":"", L.swirl?"swirly bokeh":"", L.vig>0.35?"heavy vignette":"", L.sh>0.94?"razor sharp":L.sh<0.82?"soft and dreamy":""].filter(Boolean).join(", ");
  return `<div class="item ${eq?"equipped":""}"><div class="camhead"><span class="kind">${MOUNTS[L.m]}${L.m==="M42"?" (fits Pentax K)":""}</span></div><h4>${L.n}</h4><div class="spec">${fmtA(L.a)}${eqv}${ch?` · ${ch}`:""}</div>${L.d?`<div class="desc">${L.d}</div>`:""}
    <div class="foot"><span class="price">${owned? "Owned" : "$"+L.p.toLocaleString()}</span>${gearBtn("lenses", id, L.p, owned, eq, !fits)}</div></div>`;
}
function menuGear(){
  const b = curBody(), f = UI.camFilter || "all";
  let h = `<p class="note">${moneyStr()}. On your neck: <b>${b.n}</b>${curLens()? " with the "+curLens().n : ""}, loaded with ${curFilm().n} (${curRoll().left} left).</p>`;
  const cats = ["all","owned"].concat(BODY_TYPES);
  h += `<div class="sectionhead">Cameras <span class="spec">${Object.keys(BODIES).length} film cameras</span></div><div class="seg" data-camfilter>${cats.map(c=>`<button data-v="${c}" aria-pressed="${f===c}">${c==="all"?"All":c==="owned"?"Owned":c}</button>`).join("")}</div><div class="grid" style="margin-top:12px">`;
  const ids = Object.keys(BODIES).filter(id => f==="all" || (f==="owned" ? S.owned.bodies.includes(id) : BODIES[id].t===f)).sort((a,c)=> (BODIES[a].p - BODIES[c].p));
  h += ids.map(camItem).join("") + `</div>`;
  const lf = UI.lensFilter || "fits";
  h += `<div class="sectionhead">Lenses <span class="spec">${Object.values(LENSES).filter(l=>!l.fixed).length} lenses</span></div>`;
  if (b.L) h += `<p class="note">The ${b.n} has a built-in ${LENSES[b.L].n}. Showing lenses for other cameras.</p>`;
  h += `<div class="seg" data-lensfilter>${[["fits","Fits this camera"],["owned","Owned"],["all","All mounts"]].concat(Object.keys(MOUNTS).map(m=>[m,MOUNTS[m]])).map(([v,l])=>`<button data-v="${v}" aria-pressed="${lf===v}">${l}</button>`).join("")}</div><div class="grid" style="margin-top:12px">`;
  const lids = Object.keys(LENSES).filter(id=>!LENSES[id].fixed).filter(id => lf==="all" || (lf==="fits" ? (b.L ? true : mountFits(b, LENSES[id])) : lf==="owned" ? S.owned.lenses.includes(id) : LENSES[id].m===lf)).sort((a,c)=>LENSES[a].f - LENSES[c].f);
  h += (lids.length ? lids.map(lensItem).join("") : `<p class="note">Nothing here yet.</p>`) + `</div>`;
  h += `<div class="sectionhead">Flashes</div><div class="grid">`;
  for (const [id,g] of Object.entries(FLASHES)){ const owned = S.owned.flashes.includes(id), eq = S.flash===id;
    h += `<div class="item ${eq?"equipped":""}"><h4>${g.name}</h4><div class="spec">${g.gn? `Guide number ${g.gn}${g.soft?" · soft":""}` : b.fl ? `Uses the ${b.n}'s built-in flash (GN ${b.fl})` : "Available light only"}</div>${g.desc?`<div class="desc">${g.desc}</div>`:""}<div class="foot"><span class="price">${owned?"Owned":"$"+g.price}</span>${gearBtn("flashes", id, g.price, owned, eq)}</div></div>`; }
  h += `</div><p class="note" style="margin-top:14px">F toggles the flash. Leaf shutters sync at any speed; focal-plane shutters only up to their sync speed.</p>`;
  return h;
}
function reloadCost(stockId){ const b = curBody(); if (S.free) return 0; if (b.film) return b.p; const f = FILMS[stockId || curRoll().stock]; return f.p + (FORMATS[b.fmt].film==="120" ? 3 : 0); }
function menuFilm(){
  const b = curBody(), fmt = FORMATS[b.fmt], r = curRoll();
  let h = `<p class="note">${b.n} takes ${fmt.film==="120" ? "120 roll film" : fmt.film==="instant" ? "instant packs" : "35mm film"}${fmt.film==="135" && b.fmt!=="135" ? ` (${fmt.n}: ${b.frames||fmt.frames} frames a roll)` : ` (${b.frames||fmt.frames} frames)`}. Loaded: <b>${curFilm().n}</b>, ${r.left} frames left. Loading a different film winds back and discards the rest of this roll.</p>`;
  if (b.film) return h + `<p class="note">It's a disposable: when it's done, press L to buy another ($${b.p}).</p>`;
  const push = S.set.push||0; const [pl, ph] = pushRange();
  h += `<div class="formrow"><label>Push / pull</label><div class="seg" data-push>${Array.from({length:ph-pl+1},(_,i)=>pl+i).map(v=>`<button data-v="${v}" aria-pressed="${push===v}">${v>0?"+":""}${v} stop${Math.abs(v)===1?"":"s"}</button>`).join("")}</div><span class="spec">Rates ${curFilm().n} at ASA ${Math.round(curFilm().iso*Math.pow(2,push))} and the lab develops the whole roll to match: pushing buys speed with grain and contrast, pulling gives softer tones and finer grain.${r.push !== undefined && r.push !== push ? ` The roll in the camera is rated ${r.push>0?"+":""}${r.push}.` : ""}</span></div>`;
  const kinds = { neg:"Colour negative", slide:"Colour slide", bw:"Black and white", instant:"Instant" };
  for (const k of ["neg","slide","bw","instant"]){
    const ids = Object.keys(FILMS).filter(id=>FILMS[id].k===k && FILMS[id].f.includes(fmt.film)); if (!ids.length) continue;
    h += `<div class="sectionhead">${kinds[k]}</div><div class="grid">`;
    for (const id of ids){ const f = FILMS[id], loaded = r.stock===id, cost = reloadCost(id);
      h += `<div class="item ${loaded?"equipped":""}"><div class="filmcan" style="--c:${filmColor(id)}"><span>${f.iso}</span></div><h4>${f.n}</h4><div class="spec">ASA ${f.iso} · latitude −${f.lat[0]} / +${f.lat[1]} stops${f.hal>0.4?" · halation":""}${f.ir?" · infrared":""}</div><div class="desc">${f.d}</div>
        <div class="foot"><span class="price">${cost? "$"+cost+" a roll" : "Free"}</span>${loaded ? `<button class="btn small alt" data-load="${id}" ${(!S.free && S.money<cost)?"disabled":""}>Fresh roll</button>` : `<button class="btn small" data-load="${id}" ${(!S.free && S.money<cost)?"disabled":""}>Load</button>`}</div></div>`; }
    h += `</div>`;
  }
  return h;
}
function filmColor(id){ return ({ gold200:"#f2b705", ultramax:"#e8a33d", colorplus:"#d9a441", portra160:"#e8d9b0", portra400:"#e6c98a", portra800:"#c8a060", ektar:"#e05a2a", superia:"#3aa06b", c200:"#5bb07a", lomo800:"#c8367a", cine800:"#c0362c", cine50:"#e8b82e", aero:"#8a1f3a", e100:"#2f7fc1", velvia:"#2e8b57", provia:"#3f6fa8", trix:"#e8b82e", hp5:"#f2f2ee", tmax100:"#b8b8b8", delta3200:"#26231f", fp4:"#6f8fae", panf:"#9aaec9", xp2:"#c9c9c6", foma:"#4a6fa5", sx70:"#f4f1e8", sx70bw:"#bdbdbd" })[id] || "#999"; }

function menuSkills(){
  const need = levelXp(S.level);
  let h = `<div class="sectionhead">Level ${S.level}</div><div class="xpbar"><b style="width:${Math.min(100, S.xp/need*100)}%"></b></div><p class="note">${S.xp} / ${need} XP to the next level. ${S.skillPts} skill point${S.skillPts===1?"":"s"} to spend. Judged frames earn XP; you get one point per level.</p><div class="grid" style="margin-top:14px">`;
  for (const [id,s] of Object.entries(SKILLS)){
    if(id === "quickpick") continue;
    const r = sk(id), pips = Array.from({length:s.max},(_,i)=>`<i class="${i<r?"on":""}"></i>`).join("");
    h += `<div class="item ${r?"equipped":""}"><h4>${s.name}</h4><div class="pips">${pips}</div><div class="desc">${s.desc}</div><div class="foot"><span class="spec">Rank ${r} of ${s.max}</span>${r<s.max? `<button class="btn small" data-skill="${id}" ${S.skillPts>0?"":"disabled"}>Learn</button>`:`<span class="spec">Mastered</span>`}</div></div>`;
  }
  return h + `</div>`;
}
function menuCustom(){
  const c = S.custom;
  const seg = (key, opts) => `<div class="seg" data-seg="${key}">${opts.map(([v,l])=>`<button data-v="${v}" aria-pressed="${c[key]===v}">${l}</button>`).join("")}</div>`;
  const straps = ["#c0362c","#26231f","#8a5a36","#3f5e7a","#556048","#e8a33d","#d9d3c4"];
  return `<div class="formrow"><label for="cName">Photographer</label><input type="text" id="cName" maxlength="24" placeholder="Your name for the edge print" value="${(S.name||"").replace(/"/g,"&quot;")}"></div>
    <div class="formrow"><label>Camera finish</label>${seg("finish", [["original","As made"],["black","Black"],["silver","Silver chrome"],["olive","Olive"],["cream","Cream and brown"]])}</div>
    <div class="formrow"><label>Strap</label><div class="swatches">${straps.map(s=>`<button data-strap="${s}" style="background:${s}" aria-label="Strap colour ${s}" aria-pressed="${c.strap===s}"></button>`).join("")}</div></div>
    <div class="formrow"><label>Viewfinder grid</label>${seg("grid", [["none","None"],["thirds","Thirds"],["golden","Golden ratio"],["diagonal","Diagonals"]])}</div>
    <div class="formrow"><label>Screen display</label>${seg("hud", [["on","Everything"],["min","Minimal"],["off","Clean"]])}</div>
    <p class="note">Your camera's shutter sound matters: loud focal-plane SLRs get noticed, leaf shutters and TLRs barely do.</p>
    <div class="sectionhead">Save</div><div class="formrow"><button class="btn small alt" data-reset>Start over</button><span class="spec">${DB.persistent()? "Photos are stored in this browser." : "This browser won't keep photos after you close the page."}</span></div>`;
}
function menuTime(){
  return `<p class="note">Light changes everything. Golden hour is warm and raking, blue hour glows, fog turns the hills into layers.</p>
    <div class="timecards" style="margin-top:12px">${TIMES.map(t=>`<button data-time="${t.id}" aria-pressed="${S.time===t.id}" style="background:linear-gradient(180deg,${t.top},${t.bot} 70%,${t.gnd})">${t.name}</button>`).join("")}</div>
    <div class="formrow" style="margin-top:18px"><label>Fog rolling in</label><div class="seg" data-fog><button data-v="0" aria-pressed="${!S.fog}">Clear</button><button data-v="1" aria-pressed="${S.fog}">Fog</button></div></div>
    <div class="formrow"><label>Clock</label><div class="seg" data-flow><button data-v="1" aria-pressed="${S.flow!==false}">Time flows</button><button data-v="0" aria-pressed="${S.flow===false}">Hold the light</button></div><span class="spec">It's ${fmtClock(S.clock)}. The sun crosses the city; a good corner may only have its light for a few minutes.</span></div>
    <div class="formrow"><label>Rain</label><div class="seg" data-rain><button data-v="0" aria-pressed="${!S.rain}">Dry</button><button data-v="1" aria-pressed="${!!S.rain}">Raining</button></div><span class="spec">Wet asphalt, puddles and umbrellas. Everything reflects.</span></div>`;
}
function fmtClock(h){ h = ((h||0)%24+24)%24; const hh = Math.floor(h), mm = Math.floor((h-hh)*60); return `${((hh+11)%12)+1}:${String(mm).padStart(2,"0")} ${hh<12?"am":"pm"}`; }
function menuSettings(){
  const c = S.custom, seg = (key, opts) => `<div class="seg" data-seg="${key}">${opts.map(([v,l])=>`<button data-v="${v}" aria-pressed="${c[key]===v}">${l}</button>`).join("")}</div>`;
  return `<div class="sectionhead">Camera HUD</div>
    <div class="formrow"><label>Side exposure panel</label>${seg("sideCamera",[["on","Show"],["off","Hide"]])}<span class="spec">Aperture, shutter, film speed, focus and frames beside the viewfinder.</span></div>
    <div class="formrow"><label>Quick adjustments</label>${seg("quickCamera",[["on","Buttons"],["off","Read-only"]])}<span class="spec">Click − / + beside aperture, shutter and push.</span></div>
    <div class="formrow"><label>Panel side</label>${seg("sidePosition",[["left","Left"],["right","Right"]])}</div>
    <div class="formrow"><label>Mouse sensitivity</label>${seg("mouseSensitivity",[["low","Low"],["normal","Normal"],["high","High"]])}</div>
    <div class="formrow"><label>Walking camera motion</label>${seg("walkBob",[["low","Subtle"],["normal","Natural"],["high","Pronounced"]])}</div>
    <div class="sectionhead">Street events</div>
    <div class="formrow"><label>Event pace</label>${seg("eventPace",[["calm","Calm"],["normal","Normal"],["busy","Busy city"]])}<span class="spec">How often something starts happening somewhere nearby.</span></div>
    <div class="formrow"><label>Event pins</label>${seg("eventPins",[["heard","Once you hear it"],["on","Always"],["off","Never"]])}<span class="spec">Mark live events on the minimap. By default a pin appears only after the sound reaches you.</span></div>
    <div class="formrow"><label>Event notice</label>${seg("eventNotify",[["sound","Sound only"],["clue","Sound and a written clue"]])}</div>
    <div class="sectionhead">Businesses</div>
    <div class="formrow"><label>Window glass</label>${seg("windowGlass",[["clear","Clear"],["balanced","Balanced"],["reflective","Reflective"]])}<span class="spec">Clear shows the people inside; reflective layers the street over them.</span></div>
    <div class="sectionhead">Graphics</div>
    <div class="formrow"><label>Render quality</label>${seg("renderQuality",[["performance","Performance"],["balanced","Balanced"],["cinematic","Cinematic"],["ultra","Ultra"]])}<span class="spec">Pixel density, shadow resolution and capture supersampling. Cinematic is for desktop GPUs. Ultra supersamples the whole view and maxes shadows — high-end GPUs only.</span></div>
    <div class="formrow"><label>Reflections</label>${seg("reflections",[["balanced","Balanced"],["high","High"]])}<span class="spec">Wet-street reflection resolution.</span></div>`;
}
function menuKeys(){
  const rows = [["W A S D","Walk"],["V","Switch between mouse look and arrow-key look"],["I K / U O","Aperture / shutter (always work; use these when arrows are looking)"],["Shift","Run (or hold your breath while the camera is raised)"],["C","Crouch"],["Mouse","Look (click the street to capture the mouse)"],["Right mouse or Z","Raise the camera to your eye"],["Left click or Space","Take the picture (unraised: shoot from the hip)"],["Scroll","Zoom (zoom lens) or turn the focus ring"],["Q / E","Tilt the camera"],["R","Exposure mode: P, A, S, M"],["↑ ↓","Aperture"],["← →","Shutter speed (exposure compensation in P and A)"],[", .","Push or pull the film"],["[ ]","Exposure compensation"],["T","Manual focus: turn the ring to whatever is in the centre. AF cameras: toggle autofocus"],["X","Snap to hyperfocal distance (Zone master)"],["F","Flash on or off"],["G","Cycle grid"],["N","Next lens that fits"],["L","Load a fresh roll of the same film"],["B","Develop the last frame"],["P","Contact sheet"],["Tab or M","Camera bag"],["H","Show or hide this help line"],["Esc","Release the mouse, close panels"]];
  return `<div class="formrow"><label>Look around with</label><div class="seg" data-arrowlook><button data-v="0" aria-pressed="${!S.custom.arrowLook}">Mouse</button><button data-v="1" aria-pressed="${!!S.custom.arrowLook}">Arrow keys</button></div><span class="spec">With arrow keys, ↑ ↓ ← → turn your head; aperture moves to I / K and shutter to U / O. Space shoots, Z raises the camera.</span></div>
  <table class="keys">${rows.map(([k,d])=>`<tr><td><span class="kbd">${k}</span></td><td>${d}</td></tr>`).join("")}</table>
  <p class="note" style="margin-top:14px">On a touch screen: drag the left pad to walk, drag anywhere else to look, tap Raise then the shutter button.</p>`;
}
function wireMenu(){
  const body = $("#menubody");
  $$("[data-buy]", body).forEach(b=>b.onclick=()=>{ const [k,id] = b.dataset.buy.split(":"); buy(k,id); renderMenu(); });
  const cf = $("[data-camfilter]", body); if (cf) $$("button", cf).forEach(b=>b.onclick=()=>{ UI.camFilter = b.dataset.v; renderMenu(); });
  const lf = $("[data-lensfilter]", body); if (lf) $$("button", lf).forEach(b=>b.onclick=()=>{ UI.lensFilter = b.dataset.v; renderMenu(); });
  $$("[data-load]", body).forEach(b=>b.onclick=()=>{ const r = curRoll(), full = curBody().frames || curFormat().frames; if (r.left > 0 && r.left < full && !confirm(`Wind back and lose the ${r.left} frames left on this roll?`)) return; loadFilm(b.dataset.load); renderMenu(); });
  const pu = $("[data-push]", body); if (pu) $$("button", pu).forEach(b=>b.onclick=()=>{ const r = curRoll(), full = curBody().frames || curFormat().frames; S.set.push = +b.dataset.v; if (r.left >= full) r.push = S.set.push; else toast("This roll keeps its rating; the new setting applies to the next roll you load.", 2600); saveState(); renderMenu(); });
  $$("[data-equip]", body).forEach(b=>b.onclick=()=>{ const [k,id] = b.dataset.equip.split(":"); equip(k,id); renderMenu(); });
  $$("[data-skill]", body).forEach(b=>b.onclick=()=>{ const id = b.dataset.skill; if (S.skillPts<=0 || sk(id)>=SKILLS[id].max) return; S.skills[id]++; S.skillPts--; saveState(); toast(`${SKILLS[id].name} rank ${S.skills[id]}.`); renderMenu(); });
  $$("[data-seg]", body).forEach(sg=>$$("button", sg).forEach(b=>b.onclick=()=>{ S.custom[sg.dataset.seg] = b.dataset.v; saveState(); if (sg.dataset.seg==="finish") buildHeldCam(); if (sg.dataset.seg==="grid") drawGrid(); if (["renderQuality","reflections"].includes(sg.dataset.seg)) applyGraphicsQuality(); if (sg.dataset.seg === "sideCamera") layoutVF(); if (["interiorActivity","windowGlass"].includes(sg.dataset.seg)) applyInteriorSettings(); UI.hudT = 0; renderMenu(); }));
  $$("[data-strap]", body).forEach(b=>b.onclick=()=>{ S.custom.strap = b.dataset.strap; saveState(); buildHeldCam(); renderMenu(); });
  const nm = $("#cName"); if (nm) nm.oninput = ()=>{ S.name = nm.value; saveState(); };
  $$("[data-time]", body).forEach(b=>b.onclick=()=>{ S.time = b.dataset.time; S.clock = clockOf(S.time); applyTime(); saveState(); renderMenu(); });
  const tf = $("[data-flow]", body); if (tf) $$("button", tf).forEach(b=>b.onclick=()=>{ S.flow = b.dataset.v==="1"; saveState(); renderMenu(); });
  const al = $("[data-arrowlook]", body); if (al) $$("button", al).forEach(b=>b.onclick=()=>{ S.custom.arrowLook = b.dataset.v==="1"; saveState(); renderMenu(); });
  const rn = $("[data-rain]", body); if (rn) $$("button", rn).forEach(b=>b.onclick=()=>{ S.rain = b.dataset.v==="1"; applyTime(); saveState(); renderMenu(); });
  const fg = $("[data-fog]", body); if (fg) $$("button", fg).forEach(b=>b.onclick=()=>{ S.fog = b.dataset.v==="1"; applyTime(); saveState(); renderMenu(); });
  const rs = $("[data-reset]", body); if (rs) rs.onclick = async ()=>{ if (!confirm("Start over? Your money, gear and skills reset. Photos stay on the contact sheet.")) return; localStorage.removeItem(SAVE_KEY); location.reload(); };
}
function equip(kind, id){
  if (kind==="bodies"){
    S.body = id; const b = BODIES[id];
    if (!b.L && !S.lensByBody[id]){ const own = S.owned.lenses.find(l=>mountFits(b, LENSES[l])); if (own) S.lensByBody[id] = own; }
    if (!S.rolls[id]) S.rolls[id] = defaultRoll(id);
    if (!modesFor(b).includes(S.set.mode)) S.set.mode = modesFor(b)[0];
    S.set.af = !!b.af; if (b.fl && S.flash==="none") S.set.flashOn = true;
    const L = curLens(); if (L && L.f2) Player.zoomF = L.f;
    layoutVF(); drawGrid();
  }
  else if (kind==="lenses"){ const b = curBody(); if (b.L || !mountFits(b, LENSES[id])) return; S.lensByBody[S.body] = id; Player.lensSwap = 0.9; if (LENSES[id].f2) Player.zoomF = LENSES[id].f; }
  else { S.flash = id; if (id!=="none") S.set.flashOn = true; }
  if (!curLens()) toast("This camera has no lens that fits. Find one under Lenses.");
  saveState(); buildHeldCam();
}
function buy(kind, id){
  const g = kind==="bodies" ? BODIES[id] : kind==="lenses" ? LENSES[id] : FLASHES[id], price = g.p ?? g.price;
  if (!S.free && S.money < price) return;
  if (!S.free) S.money -= price;
  S.owned[kind].push(id);
  if (kind==="bodies"){ const b = BODIES[id]; if (b.kit && !S.owned.lenses.includes(b.kit)){ S.owned.lenses.push(b.kit); } if (b.kit) S.lensByBody[id] = b.kit; S.rolls[id] = defaultRoll(id); }
  equip(kind, id); toast(`Bought the ${g.n || g.name}${kind==="bodies" && BODIES[id].kit ? " with its "+LENSES[BODIES[id].kit].n : ""}.`, 2400);
}
function loadFilm(stockId){
  const b = curBody(), cost = reloadCost(stockId);
  if (!S.free && S.money < cost){ toast("You can't afford that."); return false; }
  if (!S.free) S.money -= cost;
  S.rolls[S.body] = { stock: b.film || stockId, left: b.frames || curFormat().frames, push: b.film ? 0 : (S.set.push||0) }; GP.loadT = b.film ? 1.5 : curFormat().film === "135" ? 3.5 : 5.5;
  Audio.advance(); saveState(); toast(b.film ? `You tear open a new ${b.n}.` : `Loading ${FILMS[stockId].n}… ${S.rolls[S.body].left} frames.`, 2200); return true;
}
function reloadFilm(){ loadFilm(curRoll().stock); }

/* ---------------- HUD ---------------- */
function applyHudPref(){ const h = S ? S.custom.hud : "on"; $("#minimap").style.display = h==="off" ? "none" : ""; $("#gearline").style.display = h!=="on" ? "none" : ""; $("#loc").style.display = h==="off" ? "none" : ""; $("#stats").style.display = h==="off" ? "none" : ""; }
function meterHTML(diff){
  const d = clamp(Math.round(-diff*3)/3, -2, 2); let h = "";
  for (let i=-6;i<=6;i++){ const v = i/3; const on = (d<0 && v<0 && v>=d) || (d>0 && v>0 && v<=d); h += `<i class="${i===0?"c":""} ${on?"on":""}"></i>`; }
  return `<span class="meter" aria-label="Exposure meter">${h}</span>`;
}
const FK_LABEL = { af:"AF", rf:"Rangefinder", mf:"Manual focus", zone:"Scale focus", fixed:"Fixed focus" };
function updateHUD(dt){
  UI.hudT -= dt; if (UI.hudT > 0) return; UI.hudT = 0.08;
  const e = Cam.exp, b = curBody(), L = curLens(), st = S.set, film = curFilm(), roll = curRoll();
  if (!e) return;
  const tStr = `<span class="${e.warn?"warn":""}">${fmtShutter(e.t)}</span>`, aStr = fmtA(e.N);
  const iso = `ASA ${e.iso}${e.push? `<span class="dim"> ${e.push>0?"+":""}${e.push}</span>`:""}`;
  const evc = st.ev ? ` <span>${st.ev>0?"+":""}${st.ev.toFixed(1)}</span>` : "";
  const meter = e.meter ? meterHTML(e.meterDiff) : `<span class="dim">no meter</span>`;
  const mode = b.fx ? "Auto" : st.mode;
  $("#lcd").innerHTML = `<span class="mode">${mode}</span>${tStr}<span>${aStr}</span><span>${iso}</span>${meter}${evc}${e.flashOn?`<span style="color:var(--amber)">⚡${e.syncWarn?' <span class="warn">sync</span>':""}</span>`:""}`;
  const cs = $("#camSide"); if (cs){
    const show = S.custom.sideCamera !== "off" && S.custom.hud !== "off" && Player.raise > 0.3; cs.style.display = show ? "block" : "none"; $("#vfright").style.visibility = $("#vfleft").style.visibility = show && innerWidth > 900 ? "hidden" : "visible";
    const side = S.custom.sidePosition || "right"; cs.style.right = side === "right" ? "18px" : "auto"; cs.style.left = side === "left" ? "18px" : "auto";
    if (show){ const q = S.custom.quickCamera !== "off" && !b.fx, dis = q ? "" : " disabled", fk = focusKind(), fd = fk === "fixed" ? fmtDist(b.ff) : fmtDist(Cam.focus), fr = curRoll();
      cs.innerHTML = `<div class="csTitle">${b.n}</div><div class="csMode"><span>${mode}</span><span>${Math.round(lensFocal())}mm</span></div>
      <div class="csRow"><span>Aperture</span><button data-camadj="a-"${dis}>−</button><div class="csVal">${aStr}</div><button data-camadj="a+"${dis}>+</button></div>
      <div class="csRow"><span>Shutter</span><button data-camadj="t-"${dis}>−</button><div class="csVal">${fmtShutter(e.t)}</div><button data-camadj="t+"${dis}>+</button></div>
      <div class="csRow"><span>Push</span><button data-camadj="i-"${dis}>−</button><div class="csVal">${e.iso}${e.push ? ` <small>${e.push>0?"+":""}${e.push}</small>` : ""}</div><button data-camadj="i+"${dis}>+</button></div>
      <div class="csMeta">${FK_LABEL[fk]} · ${fd}${fk !== "af" ? `<br>${dofText(e)}` : ""}<br>${film.n}<br><span class="csFrames">${GP.loadT > 0 ? "loading film…" : `${fr.left} frame${fr.left===1?"":"s"} left`}</span>${st.ev?` · EV ${st.ev>0?"+":""}${st.ev.toFixed(1)}`:""}<br><span class="dim">${famLabel()}</span></div>`; }
  }
  const flen = L && L.f2 ? ` at ${Math.round(lensFocal())}mm` : "";
  $("#gearline").innerHTML = `<b>${b.n}</b>${L? L.n : "no lens"}${flen}<br>${film.n} · ${roll.left} left${curFlash().gn? " · "+curFlash().name + (st.flashOn?" on":" off") : ""}`;
  $("#stats .money").textContent = S.free ? "Free roam" : "$"+S.money.toLocaleString();
  $("#stats .sub").textContent = `Level ${S.level} · ${S.frameCount} frame${S.frameCount===1?"":"s"} shot${S.skillPts?` · ${S.skillPts} skill pt${S.skillPts>1?"s":""}`:""}`;
  UI.locT -= 0.08; if (UI.locT <= 0){ UI.locT = 0.5; const l = locationName(Player.x, Player.z); $("#loc .street").textContent = l.street; $("#loc .hood").textContent = l.hood; }
  if (Player.raise > 0.3){
    const fk = focusKind();
    $("#afbox").className = fk==="af" ? (Cam.afLock ? "lock" : "") : (fk==="rf" && Cam.afLock ? "lock mf" : "mf");
    let lq = "";
    if (sk("light") || sk("goldenhour")) lq = `<br><span id="lightq">EV ${Math.round(sceneEV()+Cam.skyFrac*1.3)} · ${World.timeDef.qname}${S.fog?", foggy":""}</span>`;
    else if (!e.meter && famOf() > 0.5) lq = `<br><span class="dim">Your eye says EV ${Math.round(sceneEV()+Cam.skyFrac*1.3)}</span>`;
    else if (!e.meter) lq = `<br><span class="dim">Sunny 16: f/16 at 1/ASA in sun</span>`;
    $("#vfinfo").innerHTML = `<span class="mode" style="font-weight:700">${mode}</span><span class="${e.warn?"warn":""}">${fmtShutter(e.t)}</span><span>${aStr}</span><span>ASA ${e.iso}</span>${meter}${e.flashOn?`<span class="flash">⚡</span>`:""}`;
    $("#vfleft").innerHTML = `${Math.round(lensFocal())}mm<br>${FK_LABEL[fk]}${fk==="fixed"?"":" "+fmtDist(Cam.focus)}${fk!=="af" ? `<br><span class="dim">${dofText(e)}</span>` : ""}${fk==="rf"||fk==="mf"?`<br><span class="dim">T to focus · 1–5 presets</span>`:fk==="zone"?`<br><span class="dim">1–5 zone presets</span>`:""}${Player.lensSwap>0?"<br>changing lens…":""}`;
    $("#vfright").innerHTML = `<div id="vfshots" class="${roll.left<=2?"crit":roll.left<=5?"low":""}">${GP.loadT>0 ? "…" : roll.left}</div>${GP.loadT>0 ? "loading film" : "left on roll"}<br>${film.n}${e.push ? ` @ ${e.iso}` : ""}${lq}`;
    const lv = $("#level"), rollDeg = Player.roll*180/Math.PI; lv.firstElementChild.style.transform = `translateX(${clamp(-rollDeg*4,-56,56)}px)`; lv.classList.toggle("ok", Math.abs(rollDeg) < 0.6);
    const br = $("#breath"); br.classList.toggle("hidden", !sk("breath")); if (sk("breath")) br.firstElementChild.style.width = (Player.breath*100)+"%";
    drawFocusScale(e);
  }
  UI.mapT -= 0.08; if (UI.mapT <= 0){ UI.mapT = 0.15; drawMinimap(); }
}
function drawFocusScale(e){
  const c = $("#focusscale"), x = c.getContext("2d"), W = c.width, Hh = c.height; x.clearRect(0,0,W,Hh);
  const pos = d => { const t = d === Infinity ? 1 : 1 - 1/Math.max(d, 0.4)*0.4; return 40 + (W-80)*clamp((t-0)/1, 0, 1); };
  x.fillStyle = "rgba(20,19,17,.55)"; x.fillRect(0, 10, W, Hh-20);
  if (focusKind()!=="af"){ const [n,f] = dofRange(Cam.focus, e.N); x.fillStyle = "rgba(232,163,61,.45)"; x.fillRect(pos(n), 14, pos(f)-pos(n), Hh-28); }
  x.strokeStyle = "#e4e3db"; x.fillStyle = "#e4e3db"; x.font = "600 22px Barlow Condensed, Arial Narrow, sans-serif"; x.textAlign = "center"; x.lineWidth = 2;
  for (const [d,l] of [[0.7,"0.7"],[1,"1"],[1.5,"1.5"],[2,"2"],[3,"3"],[5,"5"],[10,"10"],[Infinity,"∞"]]){ const px = pos(d); x.beginPath(); x.moveTo(px, 14); x.lineTo(px, 26); x.stroke(); x.fillText(l, px, 52); }
  x.fillText("m", W-18, 52);
  const fp = pos(Cam.focus); x.fillStyle = "#c0362c"; x.fillRect(fp-2, 10, 4, Hh-20);
}
function drawMinimap(){
  if (S.custom.hud === "off") return;
  const c = $("#minimap"), x = c.getContext("2d"), W = c.width, R = 120, s = (W/2)/R;
  x.clearRect(0,0,W,W); x.save(); x.beginPath(); x.arc(W/2,W/2,W/2,0,Math.PI*2); x.clip();
  x.translate(W/2, W/2);
  const fx = -Math.sin(Player.yaw), fz = -Math.cos(Player.yaw), rx = Math.cos(Player.yaw), rz = -Math.sin(Player.yaw);
  const tp = (wx, wz) => { const dx = wx-Player.x, dz = wz-Player.z; return [ (dx*rx + dz*rz)*s, -(dx*fx + dz*fz)*s ]; };
  x.fillStyle = "rgba(90,86,78,.75)"; x.fillRect(-W,-W,W*2,W*2); x.fillStyle = "rgba(214,216,210,.55)";
  for (const l of World.lots){ if (Math.abs(l.cx-Player.x) > R+60 || Math.abs(l.cz-Player.z) > R+60) continue; const p = [tp(l.x0,l.z0), tp(l.x1,l.z0), tp(l.x1,l.z1), tp(l.x0,l.z1)]; x.beginPath(); x.moveTo(...p[0]); for (const q of p.slice(1)) x.lineTo(...q); x.closePath(); x.fill(); }
  const dot = (wx,wz,col,r=4) => { const [a,b] = tp(wx,wz); x.fillStyle = col; x.beginPath(); x.arc(a,b,r,0,Math.PI*2); x.fill(); };
  if (sk("scout")){
    if (Life.busker) dot(Life.busker.x, Life.busker.z, "#e8a33d", 6);
    for (const f of Life.flocks) dot(f.cx, f.cz, "#9fd3ff", 4);
    for (const d of Life.dogs) dot(d.x, d.z, "#d9a441", 3.5);
    if (Life.cable) dot(Life.cable.x, Life.cable.z, "#c0362c", 6);
  }
  x.restore();
  x.fillStyle = "#eceeea"; x.beginPath(); x.moveTo(W/2, W/2-11); x.lineTo(W/2-7, W/2+8); x.lineTo(W/2+7, W/2+8); x.closePath(); x.fill();
  x.fillStyle = "#eceeea"; x.font = "600 24px Barlow Condensed, sans-serif"; x.textAlign = "center";
  const [nx, ny] = [ (0*rx + -1*rz), -(0*fx + -1*fz) ]; x.fillText("N", W/2 + nx*(W/2-18), W/2 + ny*(W/2-18) + 8);
}
