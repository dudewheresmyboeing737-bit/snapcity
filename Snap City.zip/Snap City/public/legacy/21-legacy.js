
/* =========================================================
   Contact Sheet v7 — play: jump onto anything, ride car roofs, climb to rooftops, step inside
   shops, quick-dial camera controls, more street plays that never repeat, lots of settings.
   ========================================================= */
const PLAYX = { vy:0, air:false, footY:null, surf:null, elev:0, snap:false };
const ZONE = { mode:null };
const V7_DEFAULTS = { quickDial:"on", invertY:"off", jumpHeight:"normal", peopleDensity:"full", trafficDensity:"full", birdLife:"normal", timeSpeed:"normal", autoWeather:"on", fogAmount:"normal",
  masterVol:"full", ambienceVol:"normal", eventVol:"normal", filmPrice:"normal", earnings:"normal", judging:"normal", heartbeat:"on", walkFov:"70", steadiness:"3", menuTheme:"leather" };
(function(){ const base = defaultState; defaultState = function(free){ const s = base(free); Object.assign(s.custom, V7_DEFAULTS, s.custom && s.custom.quickDial ? {} : {}); s.skills.steady = 3; return s; }; })();
function v7(){ S.custom = Object.assign({}, V7_DEFAULTS, S.custom); const st = +S.custom.steadiness; if (!isNaN(st)) S.skills.steady = Math.max(S.skills.steady||0, st === 3 ? 3 : st), S.skills.steady = st; }

/* ---------- standing on things: ground, benches, parked cars, moving cars, the bus ---------- */
function localXZ(o, x, z){ const dx = x - o.x, dz = z - o.z, c = Math.cos(o.ry || 0), s = Math.sin(o.ry || 0); return [dx*c - dz*s, dx*s + dz*c]; }
function surfaceAt(x, z, footY){
  let y = groundY(x, z), on = null; const reach = footY + 0.45;
  for (const b of (World.benches||[])){ if (Math.abs(b.x - x) > 1.5 || Math.abs(b.z - z) > 1.5) continue; const [lx, lz] = localXZ(b, x, z); const top = b.y + 0.49; if (Math.abs(lx) < 0.9 && Math.abs(lz) < 0.3 && top <= reach && top > y){ y = top; on = b; } }
  for (const c of (World.parkedCars||[])){ if (Math.abs(c.x - x) > 4 || Math.abs(c.z - z) > 4) continue; const [lx, lz] = localXZ(c, x, z); if (Math.abs(lx) < c.W/2 - 0.12 && Math.abs(lz) < c.L/2 - 0.35 && c.top <= reach && c.top > y){ y = c.top; on = c; } }
  for (const c of Life.cars){ if (!c.g.visible || Math.abs(c.x - x) > 7 || Math.abs(c.z - z) > 3) continue; const T = CAR_TYPES[c.bus ? "bus" : "sedan"], h = c.bus ? 3.05 : 1.5, L = c.bus ? 11 : 4.3;
    const top = H(c.x, c.z) + h; if (Math.abs(x - c.x) < L/2 - 0.3 && Math.abs(z - c.z) < 0.85 && top <= reach && top > y){ y = top; on = c; } }
  return { y, on };
}
function standY(dt){
  if (ZONE.mode) { PLAYX.elev = ZONE.mode === "roof" ? 10 : 0; const y = ZONE.y; if (PLAYX.air){ PLAYX.vy -= 13*dt; PLAYX.footY += PLAYX.vy*dt; if (PLAYX.footY <= y){ PLAYX.footY = y; PLAYX.air = false; } } else PLAYX.footY = y; return PLAYX.footY; }
  if (PLAYX.footY === null) PLAYX.footY = groundY(Player.x, Player.z);
  // ride along on whatever moving thing you stand on
  if (PLAYX.surf && PLAYX.surf.vx !== undefined && !PLAYX.air){ const c = PLAYX.surf; Player.x += (c.vx||0)*dt; Player.z += (c.vz||0)*dt; }
  const s = surfaceAt(Player.x, Player.z, PLAYX.footY);
  if (PLAYX.air){ PLAYX.vy -= 13*dt; PLAYX.footY += PLAYX.vy*dt; if (PLAYX.footY <= s.y && PLAYX.vy <= 0){ PLAYX.footY = s.y; PLAYX.air = false; PLAYX.surf = s.on; if (s.on) Audio.step && Audio.step(); } }
  else { if (s.y < PLAYX.footY - 0.35){ PLAYX.air = true; PLAYX.vy = 0; } else { PLAYX.footY = s.y; PLAYX.surf = s.on; } }
  PLAYX.elev = PLAYX.footY - groundY(Player.x, Player.z);
  return PLAYX.footY;
}
function jump(){ if (PLAYX.air) return; PLAYX.air = true; PLAYX.vy = ({ low:4.6, normal:5.8, high:7.2 })[S.custom.jumpHeight] || 5.8; PLAYX.surf = null; }

/* ---------- zones: rooftops and shop interiors ---------- */
function zoneClamp(x, z){ const o = ZONE.box; const [lx, lz] = localXZ(o, x, z), c = Math.cos(o.ry), s = Math.sin(o.ry);
  const m = ZONE.mode === "roof" ? 0.3 : 0.4, cx = clamp(lx, -o.w/2 + m, o.w/2 - m), cz = clamp(lz, -o.d/2 + m, o.d/2 - m); return [o.x + cx*c + cz*s, o.z - cx*s + cz*c]; }
function faceOut(n){ return Math.atan2(-n[0], -n[1]); }
function faceIn(n){ return Math.atan2(n[0], n[1]); }
function nearestShop(){ let best = null, bd = 1e9; for (const sh of (World.shops||[])){ const dx = Player.x - sh.x, dz = Player.z - sh.z, out = dx*sh.n[0] + dz*sh.n[1], al = Math.abs(dx*sh.n[1] - dz*sh.n[0]); if (out > -0.2 && out < 3.2 && al < sh.w/2 && out < bd){ bd = out; best = sh; } } return best; }
function nearestRoof(){ let best = null, bd = 1e9; for (const rf of (World.roofs||[])){ const dx = Player.x - rf.fx, dz = Player.z - rf.fz, out = dx*rf.n[0] + dz*rf.n[1], al = Math.abs(dx*rf.n[1] - dz*rf.n[0]); if (out > -0.2 && out < 3.5 && al < rf.w/2 && out < bd){ bd = out; best = rf; } } return best; }
function enterAction(){
  if (ZONE.mode) return leaveZone();
  for (const { v, kind } of rideTargets()){ if (Math.hypot(Player.x - v.x, Player.z - v.z) < (kind === "bus" ? 7 : 6) || GP.ride) return toggleRide(); }
  if (GP.ride) return toggleRide();
  const sh = nearestShop(); if (sh) return enterShop(sh);
  const rf = nearestRoof(); if (rf) return climbRoof(rf);
  toast("Nothing here. Enter works at a bus or tram, a shop window, or a building wall with a fire escape.", 2600);
}
function climbRoof(rf){
  const ry = rf.ry, inward = [-rf.n[0], -rf.n[1]];
  ZONE.mode = "roof"; ZONE.y = rf.top; ZONE.box = { x:rf.x, z:rf.z, ry, w:rf.w, d:rf.d }; ZONE.back = { x:Player.x, z:Player.z };
  Player.x = rf.fx + inward[0]*0.8; Player.z = rf.fz + inward[1]*0.8; Player.yaw = faceOut(rf.n); Player.pitch = -0.5; PLAYX.footY = rf.top; PLAYX.air = false; PLAYX.snap = true;
  if (!ZONE.parapet){ ZONE.parapet = new THREE.Mesh(new THREE.BoxGeometry(1,1,1), new THREE.MeshStandardMaterial({ color:lin("#6b6660"), roughness:0.9 })); World.scene.add(ZONE.parapet); }
  ZONE.parapet.visible = true; ZONE.parapet.scale.set(rf.w, 0.45, 0.22); ZONE.parapet.rotation.y = ry; ZONE.parapet.position.set(rf.fx - rf.n[0]*0.12, rf.top + 0.22, rf.fz - rf.n[1]*0.12);
  toast(`You climb the fire escape: ${Math.round(rf.top - groundY(rf.fx, rf.fz))} m up. The street is yours. Enter to climb down.`, 3200);
}
function enterShop(sh){
  const th = SHOPS[sh.theme], n = sh.n, inward = [-n[0], -n[1]], depth = 6.4, cx = sh.x + inward[0]*(depth/2 + 0.06), cz = sh.z + inward[1]*(depth/2 + 0.06);
  ZONE.mode = "shop"; ZONE.y = sh.gy; ZONE.box = { x:cx, z:cz, ry:sh.ry, w:sh.w, d:depth - 0.3 }; ZONE.back = { x:Player.x, z:Player.z };
  Player.x = sh.x + inward[0]*1.2; Player.z = sh.z + inward[1]*1.2; Player.yaw = faceIn(n); Player.pitch = 0; PLAYX.footY = sh.gy; PLAYX.snap = true;
  buildRoom(sh, cx, cz, depth);
  toast(`Inside ${th.names[0]}. Shoot the street through the glass; Enter to step back out.`, 3000);
}
function buildRoom(sh, cx, cz, depth){
  if (ZONE.room){ World.scene.remove(ZONE.room); }
  const g = new THREE.Group(), NT = SHOPS.length, t = sh.theme, H_ = 3.4, W = sh.w, L = SHOPS[t].light;
  const tile = (col) => { const u0 = col/4, u1 = (col+1)/4, v0 = 1 - (t+1)/NT, v1 = 1 - t/NT; return [u0, v0, u1, v1]; };
  const plane = (w, h, col, x, y, z, ry, opts={}) => { const geo = new THREE.PlaneGeometry(w, h); const uv = geo.attributes.uv, [u0, v0, u1, v1] = tile(col);
    for (let i=0;i<uv.count;i++){ uv.setXY(i, uv.getX(i) ? u1 : u0, uv.getY(i) ? v1 : v0); }
    const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ map:INT.tex, color:new THREE.Color(L[0]*0.85, L[1]*0.85, L[2]*0.85), side:THREE.DoubleSide, alphaTest: opts.alpha ? 0.5 : 0, transparent:false })); m.position.set(x, y, z); m.rotation.y = ry; g.add(m); return m; };
  const flat = (w, h, color, x, y, z, rx, ry) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color, side:THREE.DoubleSide })); m.position.set(x, y, z); m.rotation.set(rx, ry, 0); g.add(m); return m; };
  const n = sh.n, ry = Math.atan2(n[0], n[1]), gy = sh.gy;
  const at = (along, inn, y) => [sh.x + n[1]*along - n[0]*inn, gy + y, sh.z - n[0]*along - n[1]*inn];
  let p = at(0, depth, H_/2); plane(W, H_, 0, p[0], p[1], p[2], ry);                                     // back wall
  for (const sd of [-1, 1]){ p = at(sd*W/2, depth/2, H_/2); plane(depth, H_, 0, p[0], p[1], p[2], ry + Math.PI/2); }  // side walls
  p = at(0, depth/2, 0.01); flat(W, depth, new THREE.Color(L[0]*0.22, L[1]*0.18, L[2]*0.15), p[0], p[1], p[2], -Math.PI/2, ry);
  p = at(0, depth/2, H_); flat(W, depth, new THREE.Color(L[0]*0.5, L[1]*0.45, L[2]*0.4), p[0], p[1], p[2], Math.PI/2, ry);
  for (const [col, inn] of [[3, 3.1], [2, 1.9]]){ for (let k = -1; k <= 1; k++){ const a = k*5.5*0.5; if (Math.abs(a) > W/2) continue; p = at(a, inn, 2.95/2 - 0.35); const m = plane(Math.min(5.5, W), 2.95, col, p[0], p[1], p[2], ry, { alpha:true }); } }
  for (let k=0;k<3;k++){ p = at((k - 1)*W/3, depth/2, H_ - 0.02); const lamp = flat(1.2, 0.2, new THREE.Color(2, 1.8, 1.4), p[0], p[1], p[2], Math.PI/2, ry); }
  World.scene.add(g); ZONE.room = g;
}
function leaveZone(){
  const was = ZONE.mode; ZONE.mode = null; if (ZONE.room){ World.scene.remove(ZONE.room); ZONE.room = null; } if (ZONE.parapet) ZONE.parapet.visible = false;
  if (ZONE.back){ Player.x = ZONE.back.x; Player.z = ZONE.back.z; } PLAYX.footY = groundY(Player.x, Player.z); PLAYX.air = false; PLAYX.snap = true;
  toast(was === "roof" ? "Back down on the street." : "Back out on the sidewalk.", 1200);
}

/* ---------- quick dial: aperture, shutter, ASA, focus and exposure comp on screen ---------- */
function buildQuickDial(){
  if ($("#quickDial")) return;
  const d = document.createElement("div"); d.id = "quickDial"; d.className = "interactive";
  d.innerHTML = `<button data-q="mode" class="qd-mode"></button>
    <span class="qd"><button data-q="a-">◀</button><b data-v="a"></b><button data-q="a+">▶</button><small>aperture</small></span>
    <span class="qd"><button data-q="t-">◀</button><b data-v="t"></b><button data-q="t+">▶</button><small>shutter</small></span>
    <span class="qd"><button data-q="i-">◀</button><b data-v="i"></b><button data-q="i+">▶</button><small>ASA</small></span>
    <span class="qd"><button data-q="f-">◀</button><b data-v="f"></b><button data-q="f+">▶</button><small>focus</small></span>
    <span class="qd"><button data-q="e-">◀</button><b data-v="e"></b><button data-q="e+">▶</button><small>EV</small></span>
    <button data-q="multi" class="qd-mode" title="Multiple exposure">2×</button><button data-q="jump" class="qd-mode" title="Jump">⤒</button>`;
  document.body.appendChild(d);
  d.addEventListener("pointerdown", ev => ev.stopPropagation(), true);
  d.addEventListener("click", ev => { const b = ev.target.closest("[data-q]"); if (!b) return; ev.preventDefault(); ev.stopPropagation(); Audio.init(); const q = b.dataset.q, st = S.set, bd = curBody();
    if (q === "mode"){ const ms = modesFor(bd); st.mode = ms[(ms.indexOf(st.mode) + 1) % ms.length]; }
    else if (q[0] === "a" || q[0] === "t" || q[0] === "i") adjustCameraSide(q);
    else if (q[0] === "f"){ const zs = [1, 1.5, 2, 3, 5, 8, 15, 120], cur = zs.reduce((a,v)=>Math.abs(Math.log(v/(st.focus||3))) < Math.abs(Math.log(a/(st.focus||3))) ? v : a, zs[0]); if (bd.af) st.af = false; st.focus = zs[clamp(zs.indexOf(cur) + (q === "f+" ? 1 : -1), 0, zs.length-1)]; Cam.mfTarget = null; }
    else if (q[0] === "e"){ if (bd.mt) st.ev = clamp(Math.round(((st.ev||0) + (q === "e+" ? 1/3 : -1/3))*3)/3, -3, 3); }
    else if (q === "multi"){ GP.multi = GP.multi ? 0 : 1; toast(GP.multi ? "Multiple exposure armed." : "Multiple exposure off.", 1400); }
    else if (q === "jump") jump();
    computeExposure(); saveState(); UI.hudT = 0; }, true);
}
function updateQuickDial(){
  const d = $("#quickDial"); if (!d) return; const show = Game.started && S.custom.quickDial !== "off" && S.custom.hud !== "off" && !UI.open; d.style.display = show ? "flex" : "none"; if (!show) return;
  const e = Cam.exp; if (!e) return; const st = S.set, fk = focusKind();
  d.querySelector(".qd-mode").textContent = curBody().fx ? "AUTO" : st.mode;
  d.querySelector('[data-v="a"]').textContent = fmtA(e.N); d.querySelector('[data-v="t"]').textContent = fmtShutter(e.t);
  d.querySelector('[data-v="i"]').textContent = e.iso + (e.push ? (e.push > 0 ? "↑" : "↓") : "");
  d.querySelector('[data-v="f"]').textContent = fk === "af" ? "AF" : fk === "fixed" ? "fix" : (Cam.focus > 60 ? "∞" : fmtDist(Cam.focus));
  d.querySelector('[data-v="e"]').textContent = (st.ev ? (st.ev > 0 ? "+" : "") + st.ev.toFixed(1) : "±0");
  d.querySelector('[data-q="multi"]').classList.toggle("on", !!GP.multi);
}

/* ---------- more street plays; never the same twice in a row ---------- */
const V7EVENTS = {
  filmshoot:{ w:1.0, play:true, name:"a film crew shooting a scene", bonus:14 }, marathon:{ w:0.8, play:true, name:"the race tearing through", bonus:12 },
  flashmob:{ w:0.8, play:true, name:"the flash mob", bonus:16 }, tourgroup:{ w:1.0, play:true, name:"the walking tour", bonus:8 },
  carchase:{ w:0.7, play:true, name:"the car chase", bonus:16 }, wedding:{ w:0.8, play:true, name:"a street wedding", bonus:14 }, painter:{ w:1.0, play:true, name:"the street painter at work", bonus:10 },
};
Object.assign(EVENTS, V7EVENTS);
const BASE_W = {}; for (const k in EVENTS) BASE_W[k] = EVENTS[k].w;
function recolor(p, top, bottom){ const i = Life.people.indexOf(p); p._col = p._col || {}; const set = (n, idx, hex) => { if (!PCOL[n] || !PCOL[n][idx]) return; if (!p._col[n+idx]) p._col[n+idx] = PCOL[n][idx].clone(); PCOL[n][idx].copy(lin(hex)); };
  for (const n of ["torso","belly"]) set(n, i, top); for (const k of [0,1]){ set("uarm", 2*i+k, top); set("farm", 2*i+k, top); set("thigh", 2*i+k, bottom); set("shin", 2*i+k, bottom); } set("pelvis", i, bottom); }
function uncolor(p){ if (!p._col) return; const i = Life.people.indexOf(p); for (const key in p._col){ const n = key.replace(/\d+$/, ""), idx = +key.slice(n.length); if (PCOL[n] && PCOL[n][idx]) PCOL[n][idx].copy(p._col[key]); } p._col = null; }
function makeEasel(x, y, z, h){ const g = new THREE.Group(), wood = new THREE.MeshStandardMaterial({ color:lin("#6b4a2e"), roughness:0.8 });
  for (const sx of [-0.3, 0.3]){ const l = new THREE.Mesh(new THREE.BoxGeometry(0.04, 1.6, 0.04), wood); l.position.set(sx, 0.8, 0); l.rotation.z = -sx*0.3; g.add(l); }
  const c = document.createElement("canvas"); c.width = 128; c.height = 96; const x_ = c.getContext("2d"); x_.fillStyle = "#f4f1e8"; x_.fillRect(0,0,128,96);
  for (let k=0;k<40;k++){ x_.strokeStyle = ["#c0362c","#2f7fc1","#e8b82e","#3aa06b","#26231f","#e36f2d"][k%6]; x_.lineWidth = 3 + Math.random()*6; x_.beginPath(); x_.moveTo(Math.random()*128, Math.random()*96); x_.quadraticCurveTo(Math.random()*128, Math.random()*96, Math.random()*128, Math.random()*96); x_.stroke(); }
  const canv = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.6, 0.03), new THREE.MeshStandardMaterial({ map:new THREE.CanvasTexture(c), roughness:0.8 })); canv.position.set(0, 1.35, 0.03); g.add(canv);
  g.position.set(x, y, z); g.rotation.y = h; World.scene.add(g); return g; }
function startV7(type){
  const near = evSpot(28, 85); if (!near) return null;
  const st = streetFor(near), ax = near.along, o = near.out, E = { type, t:0, ppl:[], done:false, info:EVENTS[type], x:near.x, z:near.z, play:true };
  const face = (p, x, z) => { p.heading = Math.atan2(x - p.x, z - p.z); };
  const dir = Math.random() < 0.5 ? 1 : -1;
  if (type === "filmshoot"){
    const cast = genActors(8); if (cast.length < 6) return null; const [dirc, clap, a1, a2, ...crowd] = cast; E.ppl = cast;
    const takes = 2 + (Math.random()*3|0), scene = Math.random() < 0.5 ? "hug" : "argue", mark = { x: near.x, z: near.z };
    evPlace(dirc, mark.x + o[0]*3.2 + ax[0]*2, mark.z + o[1]*3.2 + ax[1]*2, 0, type); evPlace(clap, mark.x + o[0]*1.6, mark.z + o[1]*1.6, 0, type);
    crowd.forEach((p, k) => evPlace(p, mark.x + o[0]*(4.5 + (k%2)) + ax[0]*(k*1.2 - 2), mark.z + o[1]*(4.5 + (k%2)) + ax[1]*(k*1.2 - 2), 0, type));
    const takeLen = rand(18, 26), dur = takes*takeLen + 25;
    E.step = (dt) => { const t = E.t, tk = Math.floor(t/takeLen), u = t - tk*takeLen; face(dirc, mark.x, mark.z); crowd.forEach(p => face(p, mark.x, mark.z));
      if (tk < takes){
        if (u < dt*1.5){ evPlace(a1, mark.x - ax[0]*4, mark.z - ax[1]*4, 0, type); evPlace(a2, mark.x + ax[0]*4, mark.z + ax[1]*4, 0, type); clap.evSign = true; face(clap, mark.x, mark.z); dirc.evPose = "point"; }
        if (u > 2 && u < 2.1) { SND.play("clap", mark.x, mark.z, 1); clap.evSign = false; dirc.evPose = null; }
        if (u > 2.5 && u < takeLen - 5){ evWalk(a1, mark.x - ax[0]*0.5, mark.z - ax[1]*0.5, 1.2, dt); evWalk(a2, mark.x + ax[0]*0.5, mark.z + ax[1]*0.5, 1.2, dt); if (!a1.evMoving){ face(a1, a2.x, a2.z); face(a2, a1.x, a1.z); a1.evPose = scene === "hug" ? "hug" : (Math.floor(u) % 2 ? "shout" : "point"); a2.evPose = scene === "hug" ? "hug" : "handsup"; } }
        if (u > takeLen - 5 && u < takeLen - 4.9){ SND.play("shout", dirc.x, dirc.z, 1); dirc.evPose = "handsup"; a1.evPose = a2.evPose = null; if (tk === takes - 1) crowd.forEach(p => p.evPose = "clap"); }
      } else if (t > dur){ E.done = true; } };
  }
  else if (type === "marathon"){
    const runners = genActors(10 + (Math.random()*5|0)), fans = []; if (runners.length < 8) return null; E.ppl = runners;
    const lane = { x: st.x, z: st.z }, len = 170, bib = ["#e8b82e","#c0362c","#2f7fc1","#3aa06b","#f28cb1"];
    runners.forEach((p, k) => { evPlace(p, lane.x - ax[0]*dir*(90 + k*rand(2.5, 6)) + o[0]*rand(-1.5, 1.5), lane.z - ax[1]*dir*(90 + k*rand(2.5, 6)) + o[1]*rand(-1.5, 1.5), 0, type); p.look.anim = "jog"; recolor(p, bib[k % bib.length], "#26282c"); p.spd = rand(3.2, 4.6); });
    const sid = Life.people.filter(q => !q.pool && !q.hidden && Math.hypot(q.x - near.x, q.z - near.z) < 25).slice(0, 5);
    E.step = (dt) => { const t = E.t; runners.forEach(p => { evWalk(p, p.x + ax[0]*dir*40, p.z + ax[1]*dir*40, p.spd, dt); p.evPose = "run"; });
      sid.forEach(q => { q.pause = Math.max(q.pause||0, 1); q.evPose = t < 60 ? "clap" : null; }); if (Math.floor(t/5) !== Math.floor((t-dt)/5) && t < 60) SND.play("applause", near.x, near.z, 0.9);
      if (t > 75){ runners.forEach(p => { uncolor(p); p.look.anim = "walk"; }); sid.forEach(q => q.evPose = null); E.done = true; } };
  }
  else if (type === "flashmob"){
    const mob = Life.people.filter(q => !q.pool && !q.hidden && !q.stationary && !q.performer && Math.hypot(q.x - near.x, q.z - near.z) < 22).slice(0, 10); if (mob.length < 4) return null;
    const start = rand(3, 8), len = rand(25, 40);
    E.step = (dt) => { const t = E.t; mob.forEach((q, k) => { if (t > start + k*0.25 && t < start + len){ q.pause = 2; q.evPose = "dance"; q.heading = Math.atan2(near.x - q.x, near.z - q.z) + Math.sin(t*2 + k)*0.3; } else if (t >= start + len) q.evPose = null; });
      if (t > start && Math.floor(t/2) !== Math.floor((t-dt)/2) && t < start + len) SND.play("music", near.x, near.z, 1.2); if (t > start + len + 1 && t - dt <= start + len + 1) SND.play("applause", near.x, near.z, 1);
      if (t > start + len + 6){ mob.forEach(q => q.evPose = null); E.done = true; } };
  }
  else if (type === "tourgroup"){
    const grp = genActors(7 + (Math.random()*4|0)); if (grp.length < 6) return null; E.ppl = grp; const [guide, ...tour] = grp; const sp = rand(0.8, 1.0);
    evPlace(guide, near.x - ax[0]*dir*40, near.z - ax[1]*dir*40, 0, type); guide.evSign = true;
    tour.forEach((p, k) => evPlace(p, guide.x - ax[0]*dir*(1.5 + k*0.8) + o[0]*((k%2)*0.8 - 0.4), guide.z - ax[1]*dir*(1.5 + k*0.8) + o[1]*((k%2)*0.8 - 0.4), 0, type));
    const stops = [rand(25, 35), rand(70, 85)], stopLen = rand(14, 20), dur = 125;
    E.step = (dt) => { const t = E.t, stopped = stops.some(s => t > s && t < s + stopLen);
      if (!stopped){ evWalk(guide, guide.x + ax[0]*dir*5, guide.z + ax[1]*dir*5, sp, dt); guide.evPose = null; tour.forEach((p, k) => { evWalk(p, guide.x - ax[0]*dir*(1.5 + k*0.7) + o[0]*((k%2)*0.8 - 0.4), guide.z - ax[1]*dir*(1.5 + k*0.7) + o[1]*((k%2)*0.8 - 0.4), sp*1.15, dt); p.evPose = null; p.act = "idle"; }); }
      else { guide.evMoving = false; face(guide, guide.x - o[0]*5, guide.z - o[1]*5); guide.evPose = "point"; tour.forEach((p, k) => { p.evMoving = false; face(p, guide.x - o[0]*6, guide.z - o[1]*6); p.headPitch = -0.3; p.act = k % 3 === 0 ? "phone" : "idle"; p.evPose = k % 4 === 1 ? "point" : null; }); if (Math.floor(t/4) !== Math.floor((t-dt)/4)) SND.play("voices", guide.x, guide.z, 0.9); }
      if (t > dur){ guide.evSign = false; E.done = true; } };
  }
  else if (type === "carchase"){
    const runner = vehicle("getaway"), c1 = vehicle("police1"), c2 = vehicle("police2"), caught = Math.random() < 0.4, endX = st.x + st.ax*dir*60, endZ = st.z + st.az*dir*60;
    runner.x = st.x - st.ax*dir*160; runner.z = st.z - st.az*dir*160; c1.x = runner.x - st.ax*dir*25; c1.z = runner.z - st.az*dir*25; c2.x = c1.x - st.ax*dir*14; c2.z = c1.z - st.az*dir*14;
    E.step = (dt) => { const t = E.t;
      if (!caught || t < 12){ vehDrive(runner, runner.x + st.ax*dir*40, runner.z + st.az*dir*40, dt, 21); } else if (caught){ vehDrive(runner, endX, endZ, dt, 18); }
      vehDrive(c1, (caught && t > 12) ? endX - st.ax*dir*7 : runner.x - st.ax*dir*18, (caught && t > 12) ? endZ - st.az*dir*7 : runner.z - st.az*dir*18, dt, 21); vehDrive(c2, c1.x - st.ax*dir*12, c1.z - st.az*dir*12, dt, 21);
      vehLights(c1, true, t); vehLights(c2, true, t + 0.3);
      if (Math.floor(t/3.2) !== Math.floor((t-dt)/3.2)) SND.play("siren", c1.x, c1.z, 1.6); if (Math.floor(t/2.5) !== Math.floor((t-dt)/2.5) && t < 14) SND.play("horn", runner.x, runner.z, 1);
      if (t > (caught ? 55 : 24)){ for (const v of [runner, c1, c2]) v.g.visible = false; E.done = true; } };
  }
  else if (type === "wedding"){
    const cast = genActors(8); if (cast.length < 6) return null; E.ppl = cast; const [bride, groom, photog, ...guests] = cast;
    recolor(bride, "#f6f3ec", "#f6f3ec"); recolor(groom, "#1d1d20", "#1d1d20"); const spot = { x: near.x, z: near.z };
    evPlace(bride, spot.x - ax[0]*0.4, spot.z - ax[1]*0.4, 0, type); evPlace(groom, spot.x + ax[0]*0.4, spot.z + ax[1]*0.4, 0, type); evPlace(photog, spot.x + o[0]*4, spot.z + o[1]*4, 0, type);
    guests.forEach((p, k) => evPlace(p, spot.x + o[0]*(1.6 + (k%2)*0.8) + ax[0]*(k*1.1 - 2.5), spot.z + o[1]*(1.6 + (k%2)*0.8) + ax[1]*(k*1.1 - 2.5), 0, type));
    const cols = [new THREE.Color(1,0.6,0.7), new THREE.Color(1,1,1), new THREE.Color(1,0.85,0.3), new THREE.Color(0.6,0.8,1)], dur = rand(100, 140);
    E.step = (dt) => { const t = E.t, phase = Math.floor(t/12) % 4;
      face(photog, spot.x, spot.z); photog.evPose = "radio"; bride.heading = groom.heading = Math.atan2(o[0], o[1]);
      bride.evPose = groom.evPose = phase === 1 ? "hug" : phase === 2 ? "cheer" : null; if (phase === 1){ face(bride, groom.x, groom.z); face(groom, bride.x, bride.z); }
      guests.forEach((p, k) => { face(p, spot.x, spot.z); p.evPose = phase === 2 ? "cheer" : (phase === 3 ? "clap" : null); });
      if (phase === 2 && Math.random() < 0.7) for (let k=0;k<4;k++) Smoke.emit(spot.x + rand(-1.5,1.5), groundY(spot.x, spot.z) + 2.4 + rand(0,0.8), spot.z + rand(-1.5,1.5), rand(-0.5,0.5), rand(0.2,0.8), rand(-0.5,0.5), 0.05, rand(3,5), 0.95, cols[(Math.random()*4)|0], -1.2, 0);
      if (phase === 2 && Math.floor(t/3) !== Math.floor((t-dt)/3)) SND.play("applause", spot.x, spot.z, 1.1);
      if (t > dur){ uncolor(bride); uncolor(groom); E.done = true; } };
  }
  else if (type === "painter"){
    const cast = genActors(4 + (Math.random()*3|0)); if (cast.length < 4) return null; E.ppl = cast; const [painter, ...watch] = cast;
    evPlace(painter, near.x, near.z, Math.atan2(-o[0], -o[1]), type); const easel = makeEasel(near.x - o[0]*0.9, groundY(near.x, near.z), near.z - o[1]*0.9, Math.atan2(o[0], o[1])); face(painter, easel.position.x, easel.position.z);
    watch.forEach((p, k) => evPlace(p, near.x + o[0]*(1.5 + k*0.3) + ax[0]*(k*1.2 - 1.8), near.z + o[1]*(1.5 + k*0.3) + ax[1]*(k*1.2 - 1.8), 0, type));
    const dur = rand(120, 170);
    E.step = (dt) => { const t = E.t; painter.evPose = (Math.floor(t*0.7) % 3) ? "hose" : "radio"; face(painter, easel.position.x, easel.position.z);
      watch.forEach((p, k) => { face(p, easel.position.x, easel.position.z); p.act = k === 0 ? "phone" : "idle"; p.evPose = (t > dur - 12) ? "clap" : null; });
      if (t > dur){ World.scene.remove(easel); E.done = true; } };
  }
  return E;
}
(function(){ const base = startEvent; startEvent = function(type){ const E = V7EVENTS[type] ? startV7(type) : base(type); if (E){ S.evHist = (S.evHist || []).concat(type).slice(-8); } return E; }; })();
(function(){ const base = evSpot; evSpot = function(minD, maxD){ S.evSpots = S.evSpots || []; for (let k=0;k<6;k++){ const sp = base(minD, maxD); if (!sp) return sp; if (!S.evSpots.some(q => Math.hypot(q[0] - sp.x, q[1] - sp.z) < 35)){ S.evSpots = S.evSpots.concat([[sp.x, sp.z]]).slice(-6); return sp; } } return base(minD, maxD); }; })();
function reweightEvents(){ const hist = S.evHist || [], last = hist[hist.length - 1];
  for (const k in EVENTS){ const bw = BASE_W[k] ?? EVENTS[k].w; const recent = hist.slice(-4).includes(k); EVENTS[k].w = k === last ? 0 : bw * (recent ? 0.1 : 1) * (!hist.includes(k) ? 1.6 : 1); } }

/* ---------- settings that do things ---------- */
function applyV7Settings(){
  if (!S) return; v7();
  const vol = ({ off:0, half:0.5, full:1 })[S.custom.masterVol] ?? 1, ev = ({ low:0.5, normal:1, high:1.5 })[S.custom.eventVol] ?? 1;
  if (SND.out) SND.out.gain.value = 0.9*vol*ev; const m = Audio.master && Audio.master(); if (m) m.gain.value = 0.8*vol; Audio.ambK = ({ off:0, low:0.4, normal:1 })[S.custom.ambienceVol] ?? 1;
  document.body.dataset.menuTheme = S.custom.menuTheme || "leather";
}
function densityHide(p, i){ const k = ({ sparse:0.35, normal:0.7, full:1 })[S.custom.peopleDensity] ?? 1; return k < 1 && !p.pool && !p.stationary && ((i*7919) % 100)/100 > k; }
(function(){ const base = posePerson; posePerson = function(p, i, ...rest){ if (densityHide(p, i)) return; return base(p, i, ...rest); }; })();
(function(){ const base = ambience; ambience = function(dt){ const k = ({ off:0, low:0.4, normal:1 })[S.custom.ambienceVol] ?? 1; if (k === 0) return; if (k < 1 && Math.random() > k){ AMB.t = rand(2.5, 6.5); return; } base(dt); }; })();
(function(){ const base = rollTension; rollTension = function(dt){ if (S.custom.heartbeat === "off"){ const r = curRoll(); if (Player.raise > 0.6 && r && r.left > 0 && r.left <= 3 && GP.lastWarn !== r.left){ GP.lastWarn = r.left; toast(r.left === 1 ? "Last frame on the roll." : `${r.left} frames left.`, 1300); } return; } base(dt); }; })();
(function(){ const base = reloadCost; reloadCost = function(id){ return Math.round(base(id) * (({ cheap:0.5, normal:1, dear:2 })[S.custom.filmPrice] ?? 1)); }; })();
(function(){ const base = judgePhoto; judgePhoto = function(rec){ const res = base(rec); const d = ({ lenient:8, normal:0, harsh:-8 })[S.custom.judging] ?? 0; if (d && res && res.total !== undefined) res.total = clamp(res.total + d, 1, 100); return res; }; })();
(function(){ if (typeof payFor !== "function") return; const base = payFor; payFor = function(sc){ return Math.round(base(sc) * (({ half:0.5, normal:1, double:2 })[S.custom.earnings] ?? 1)); }; })();
(function(){ const base = look; look = function(dx, dy){ base(dx, S.custom.invertY === "on" ? -dy : dy); }; })();
/* Stable per-car 0..1 key for density culling: derived once from identity, never from the
   moving position, so a car never flickers in and out as it drives down the block. */
function carCullKey(c){
  if (c._cullK === undefined){
    const i = Life.cars ? Life.cars.indexOf(c) : 0;
    c._cullK = ((((Math.round(c.z*13) + i*37 + Math.round((c.vmax||0)*11))|0) % 100) + 100) % 100 / 100;
  }
  return c._cullK;
}
let WEATHER_T = 180;
(function(){ const base = gameplayUpdate; gameplayUpdate = function(dt){
  reweightEvents();
  const ts = ({ frozen:0, slow:0.4, normal:1, fast:4, hyper:12 })[S.custom.timeSpeed] ?? 1; const flow = S.flow; if (ts === 0) S.flow = false;
  const c0 = S.clock; base(dt); if (ts !== 1 && ts !== 0 && S.flow !== false && c0 !== undefined) S.clock = ((c0 + (S.clock - c0)*ts) % 24 + 24) % 24; if (ts === 0) S.flow = flow;
  if (Game.started){
    updateQuickDial();
    for (const c of Life.cars){ if (c.bus) continue; const k = ({ light:0.35, normal:0.7, full:1 })[S.custom.trafficDensity] ?? 1; if (k < 1 && carCullKey(c) > k) c.g.visible = false; }
    if (Birds.list){ const k = ({ few:0.3, normal:1 })[S.custom.birdLife] ?? 1; if (k < 1 && Birds.mb){ Birds.mb.count = Birds.mw.count = Birds.mh.count = Math.floor(Birds.list.length*k); } }
  } }; })();
(function(){ const base = menuSettings; menuSettings = function(){
  const c = S.custom, seg = (key, opts) => `<div class="seg" data-seg="${key}">${opts.map(([v,l])=>`<button data-v="${v}" aria-pressed="${c[key]===v}">${l}</button>`).join("")}</div>`;
  return base() + `
    <div class="sectionhead">Body & movement</div>
    <div class="formrow"><label>Jump</label>${seg("jumpHeight",[["low","Hop"],["normal","Jump"],["high","Leap"]])}<span class="spec">Space jumps while the camera is down. You can raise it mid-air and shoot.</span></div>
    <div class="formrow"><label>Invert look</label>${seg("invertY",[["off","Off"],["on","On"]])}</div>
    <div class="formrow"><label>Walking field of view</label>${seg("walkFov",[["60","60°"],["70","70°"],["80","80°"],["90","90°"]])}</div>
    <div class="formrow"><label>Handheld steadiness</label>${seg("steadiness",[["0","Shaky"],["1","Human"],["2","Steady"],["3","Rock steady"]])}<span class="spec">Starts at rock steady. Lower it for a rawer, riskier camera.</span></div>
    <div class="formrow"><label>Quick dial</label>${seg("quickDial",[["on","On screen"],["off","Hidden"]])}<span class="spec">Aperture, shutter, ASA, focus and EV buttons along the bottom of the screen.</span></div>
    <div class="sectionhead">The city</div>
    <div class="formrow"><label>Pedestrians</label>${seg("peopleDensity",[["sparse","Sparse"],["normal","Normal"],["full","Crowded"]])}</div>
    <div class="formrow"><label>Traffic</label>${seg("trafficDensity",[["light","Light"],["normal","Normal"],["full","Heavy"]])}</div>
    <div class="formrow"><label>Birds</label>${seg("birdLife",[["few","A few"],["normal","Plenty"]])}</div>
    <div class="formrow"><label>Speed of the day</label>${seg("timeSpeed",[["frozen","Frozen"],["slow","Slow"],["normal","Normal"],["fast","Fast"],["hyper","Time-lapse"]])}</div>
    <div class="formrow"><label>Weather changes</label>${seg("autoWeather",[["on","On its own"],["off","Only when I choose"]])}</div>
    <div class="formrow"><label>Fog density</label>${seg("fogAmount",[["clear","Thin"],["normal","Normal"],["heavy","Thick"]])}</div>
    <div class="sectionhead">Sound</div>
    <div class="formrow"><label>Volume</label>${seg("masterVol",[["off","Mute"],["half","Half"],["full","Full"]])}</div>
    <div class="formrow"><label>City ambience</label>${seg("ambienceVol",[["off","Off"],["low","Subtle"],["normal","Alive"]])}</div>
    <div class="formrow"><label>Events & sirens</label>${seg("eventVol",[["low","Low"],["normal","Normal"],["high","Loud"]])}</div>
    <div class="formrow"><label>Last-frames heartbeat</label>${seg("heartbeat",[["on","On"],["off","Off"]])}</div>
    <div class="sectionhead">Economy & judging</div>
    <div class="formrow"><label>Film prices</label>${seg("filmPrice",[["cheap","Half price"],["normal","Normal"],["dear","Double"]])}</div>
    <div class="formrow"><label>Editors pay</label>${seg("earnings",[["half","Stingy"],["normal","Normal"],["double","Generous"]])}</div>
    <div class="formrow"><label>Judging</label>${seg("judging",[["lenient","Lenient"],["normal","Fair"],["harsh","Brutal"]])}</div>
    <div class="sectionhead">Look of the bag</div>
    <div class="formrow"><label>Menu style</label>${seg("menuTheme",[["leather","Leatherette"],["chrome","Chrome & black"],["darkroom","Darkroom red"],["plain","Plain"]])}</div>`; }; })();
(function(){ const base = renderMenu; renderMenu = function(...a){ const r = base(...a); applyV7Settings(); return r; }; })();
(function(){ const base = onKey; onKey = function(ev){ if (ev.code === "Space" && Game.started && !UI.open && Player.raise < 0.5 && !ev.repeat){ ev.preventDefault(); jump(); return; } base(ev); }; })();
(function(){ const base = boot; boot = async function(){ await base(); v7(); buildQuickDial(); applyV7Settings(); }; })();
