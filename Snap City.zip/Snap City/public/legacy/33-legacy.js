
/* =========================================================
   Contact Sheet v14 — requested defaults + city/camera depth
   ========================================================= */
(function(){
"use strict";
const CS14 = window.CS14 = { version:14, glass:null, clouds:[], windowPeople:[], specials:[], rideStill:0, booted:false };
const V14_DEFAULTS = {
  tButtons:"normal", tJoy:"small", waitMode:"off", filmAdvance:"auto", vfPreview:"optical",
  neonAmount:"some", flagsOn:"off", eventNotify:"clue", exposureCoach:"tips", perfectProgram:"on", roofParkour:"on",
  cloudLife:"some", windowLife:"on", vehicleVariety:"max", faceVariety:"max"
};
function masterFree(s){
  if(!s || !s.free) return;
  s.skills=s.skills||{};
  for(const k in SKILLS) s.skills[k]=SKILLS[k].max;
  s.skillPts=0;
}
function applyRequestedDefaults(s, migrate){
  if(!s) return s; s.custom=s.custom||{}; s.custom.accessibility=s.custom.accessibility||{};
  if(migrate && !s.custom._v14DefaultsApplied){
    Object.assign(s.custom,V14_DEFAULTS);
    s.custom.strap="#26231f";
    s.custom.accessibility.reducedShake="true";
    s.custom.accessibility.timeScale=1.0;
    s.custom._v14DefaultsApplied=true;
  } else {
    for(const k in V14_DEFAULTS) if(s.custom[k]===undefined) s.custom[k]=V14_DEFAULTS[k];
    if(s.custom.strap===undefined) s.custom.strap="#26231f";
    if(s.custom.accessibility.reducedShake===undefined) s.custom.accessibility.reducedShake="true";
    if(s.custom.accessibility.timeScale===undefined) s.custom.accessibility.timeScale=1.0;
  }
  masterFree(s); return s;
}
{ const base=defaultState; defaultState=function(free){ return applyRequestedDefaults(base(free),true); }; }
{ const base=loadState; loadState=function(){ const s=base(); return s?applyRequestedDefaults(s,true):s; }; }

// "Reduced shake" now means exactly what the label says: no handheld shake.
if(typeof effectiveShakeMult==="function"){ const base=effectiveShakeMult; effectiveShakeMult=function(){ const a=S&&S.custom&&S.custom.accessibility||{}; if(a.reducedShake==="true") return 0; return base(); }; }

// Free roam is a sandbox: every skill is mastered immediately.
{ const base=startGame; startGame=function(mode){ const r=base(mode); if(S&&S.free){ masterFree(S); saveState(); } return r; }; }

// Remove flags completely; this title does not need political/national decoration.
function cs14HideFlags(){ try{ if(typeof FLAGS!=="undefined") FLAGS.forEach(f=>{ if(f&&f.g) f.g.visible=false; }); }catch(e){} }
window.cs14HideFlags = cs14HideFlags;

// Guaranteed clear shop glass while standing inside, restore normal glass outside.
{ const baseEnter=enterShop, baseLeave=leaveZone;
  enterShop=function(sh){ const r=baseEnter(sh); try{ if(World.mats&&World.mats.glass){ const m=World.mats.glass; CS14.glass={opacity:m.opacity,transparent:m.transparent,depthWrite:m.depthWrite,envMapIntensity:m.envMapIntensity}; m.transparent=true;m.opacity=.16;m.depthWrite=false;m.envMapIntensity=.08; } }catch(e){} return r; };
  leaveZone=function(){ const r=baseLeave(); try{ if(World.mats&&World.mats.glass&&CS14.glass){ Object.assign(World.mats.glass,CS14.glass); CS14.glass=null; applyInteriorSettings&&applyInteriorSettings(); } }catch(e){} return r; };
}

// Rooftop parkour: Space will leap to a nearby roof in the direction you're facing.
function cs14RoofTarget(){
  if(!ZONE || ZONE.mode!=="roof" || !World.roofs) return null;
  const fx=-Math.sin(Player.yaw), fz=-Math.cos(Player.yaw); let best=null,score=1e9;
  for(const r of World.roofs){
    if(Math.abs(r.x-ZONE.box.x)<.2 && Math.abs(r.z-ZONE.box.z)<.2) continue;
    const dx=r.x-Player.x,dz=r.z-Player.z,d=Math.hypot(dx,dz); if(d<2||d>15) continue;
    const facing=(dx*fx+dz*fz)/d; if(facing<.45) continue;
    const dh=Math.abs(r.top-ZONE.y); if(dh>2.8) continue;
    const s=d + dh*2 - facing*3; if(s<score){score=s;best=r;}
  } return best;
}
{ const base=jump; jump=function(){ if(S.custom.roofParkour!=="off" && ZONE.mode==="roof"){ const r=cs14RoofTarget(); if(r){ const old=ZONE.box; ZONE.y=r.top; ZONE.box={x:r.x,z:r.z,ry:r.ry,w:r.w,d:r.d}; const inward=[-r.n[0],-r.n[1]]; Player.x=r.fx+inward[0]*1.0;Player.z=r.fz+inward[1]*1.0;PLAYX.footY=r.top;PLAYX.air=false;PLAYX.snap=true; toast(`You clear the gap — ${Math.round(Math.hypot(r.x-old.x,r.z-old.z))} m to the next roof.`,1500); return; } } return base(); }; }

// Buses should actually continue after boarding instead of feeling parked forever.
{ const base=toggleRide; toggleRide=function(){ const before=GP.ride; const r=base(); if(!before&&GP.ride&&GP.ride.kind==="bus"){ const v=GP.ride.v; v.vmax=Math.max(v.vmax||0,6.8); v.stopT=Math.min(v.stopT||0,1.5); CS14.rideStill=0; } return r; }; }

// Coffee easter egg: $2, and everybody — including Free Roam — must actually have the cash.
{ const baseAction=enterAction, baseEnter=enterShop;
  enterShop=function(sh){ const r=baseEnter(sh); try{ const th=SHOPS[sh.theme]; if(th&&th.id==="cafe"&&S.custom.coffeeSystem!=="off") toast(`Coffee smells good. Press Enter again to buy one for $2 — only if you've got the cash.`,2600); }catch(e){} return r; };
  enterAction=function(){
    if(ZONE.mode==="shop"&&window.CS131&&CS131.currentShop&&!CS131.boughtHere){ const th=SHOPS[CS131.currentShop.theme]; if(th&&th.id==="cafe"&&S.custom.coffeeSystem!=="off"){
      if((S.money||0)<2){ toast("Coffee is $2. You actually need two dollars in your wallet.",1800); return; }
      S.money-=2; CS131.coffee=120; CS131.boughtHere=true; saveState(); toast("$2 coffee. Warm hands, steadier camera for two minutes.",2300); return;
    }} return baseAction();
  };
}

// Foolproof Program mode: cancel the sky-meter bias so P lands near the actual scene EV.
{ const base=computeExposure; computeExposure=function(){
    if(S&&S.custom&&S.custom.perfectProgram==="on"&&S.set.mode==="P"){
      const old=S.set.ev, bias=(Cam.skyFrac||0)*1.3; S.set.ev=old+bias; const e=base(); S.set.ev=old;
      if(e){ e.offset=clamp(e.offset,-.18,.18); e.mult=Math.pow(2,e.offset); const fl=curFlash(); e.flashRange=e.flashOn&&fl.gn?fl.gn*Math.sqrt(e.iso/100)/e.N:0; }
      return e;
    }
    const e=base(); if(e){const fl=curFlash();e.flashRange=e.flashOn&&fl.gn?fl.gn*Math.sqrt(e.iso/100)/e.N:0;} return e;
  }; }
function cs14Sunny16(){
  const film=curFilm(),iso=Math.round(film.iso*Math.pow(2,S.set.push||0)), ev=sceneEV(), sunny=Math.abs(ev-15)<2;
  const baseN=sunny?16:ev>=13?11:ev>=10?8:ev>=7?5.6:2.8;
  const N=snapA(clamp(baseN,apertures()[0],apertures()[apertures().length-1]));
  const t=snapT(clamp(N*N/Math.pow(2,ev+Math.log2(iso/100)),1/curBody().ts,1));
  return {N,t,iso,ev};
}
function cs14ApplyExposure(){ const q=cs14Sunny16(); S.set.mode="M";S.set.A=q.N;S.set.T=q.t;UI.hudT=0;saveState();toast(`Set ${fmtA(q.N)} · ${fmtShutter(q.t)} · ISO ${q.iso}. Metered from EV ${q.ev.toFixed(1)}.`,2200); }
function cs14ExposureTip(){
  if(!S||S.custom.exposureCoach==="off") return ""; const e=Cam.exp||computeExposure(),q=cs14Sunny16(),feq=Math.round(feqReal());
  const hand=1/Math.max(30,feq*1.6),flash=e.flashOn?` Flash range ≈ ${fmtDist(e.flashRange||0)}.`:"";
  return `<b>${S.custom.exposureCoach==="foolproof"?"Foolproof Auto":"Exposure Coach"}</b> · EV ${q.ev.toFixed(1)} · ${fmtA(e.N)} at ${fmtShutter(e.t)} · ISO ${e.iso}.${e.t>hand?" Watch camera shake at this shutter speed.":" Handheld speed is safe."}${flash}`;
}

// Expand the existing vehicle grammar. Geometry + paint + trim + accessories recombine.
if(typeof CAR_TYPES!=="undefined"){
  const defs={
    oldford:{L:5.05,W:1.88,clr:.25,belt:.92,nose:.8,tail:.9,wf:1.62,wr:-1.55,R:.37,cabin:[[-1.2,0],[-.72,1],[.4,1],[1.1,0]],ch:.5,chromeBumpers:true},
    fastback:{L:4.7,W:1.9,clr:.17,belt:.78,nose:.72,tail:.75,wf:1.47,wr:-1.42,R:.36,cabin:[[-.9,0],[-.42,1],[.45,.95],[1.05,0]],ch:.4},
    tuner:{L:4.45,W:1.82,clr:.14,belt:.75,nose:.7,tail:.72,wf:1.4,wr:-1.35,R:.34,cabin:[[-.85,0],[-.42,1],[.42,1],[.94,0]],ch:.38},
    supercar:{L:4.55,W:2.0,clr:.10,belt:.62,nose:.65,tail:.68,wf:1.42,wr:-1.38,R:.36,cabin:[[-.65,0],[-.2,.75],[.42,.72],[.85,0]],ch:.28,bev:.08},
    offroad:{L:4.75,W:1.96,clr:.3,belt:1.05,nose:.9,tail:.95,wf:1.45,wr:-1.42,R:.43,cabin:[[-1.2,0],[-.9,1],[.55,1],[.9,0]],ch:.62},
    limo:{L:7.0,W:1.92,clr:.21,belt:.9,nose:.8,tail:.9,wf:2.25,wr:-2.25,R:.36,cabin:[[-2.4,0],[-2.0,1],[1.45,1],[2.0,0]],ch:.48},
    delivery:{L:5.8,W:2.05,clr:.3,belt:1.25,nose:1.0,tail:1.1,wf:1.9,wr:-1.8,R:.4,cabin:[[-2.6,0],[-2.5,1],[.45,1],[.9,0]],ch:1.0},
    bigrig:{L:10.5,W:2.45,clr:.38,belt:1.6,nose:1.3,tail:1.4,wf:3.1,wr:-3.0,R:.55,cabin:[[-4.8,0],[-4.6,1],[ -2.2,1],[-1.7,0]],ch:1.45},
    lowrider:{L:5.2,W:1.9,clr:.12,belt:.68,nose:.82,tail:.92,wf:1.65,wr:-1.62,R:.32,cabin:[[-1.2,0],[-.65,1],[.45,1],[1.1,0]],ch:.42,chromeBumpers:true},
    hatch:{L:4.05,W:1.76,clr:.2,belt:.86,nose:.72,tail:.78,wf:1.25,wr:-1.22,R:.32,cabin:[[-1.7,0],[-1.55,1],[.42,1],[.88,0]],ch:.52}
  };
  Object.assign(CAR_TYPES,defs);
  for(const k of Object.keys(defs)) CAR_TYPE_WEIGHTS.push([k,k==="bigrig"?.18:k==="limo"?.22:.7]);
  const cols=["#15171a","#ece9df","#b7bcc1","#8a2d27","#1f4d75","#34553b","#d6a221","#7c5738","#6e477b","#9b9c97"];
  for(const k of Object.keys(defs)) if(!CAR_PALETTES[k]) CAR_PALETTES[k]=cols.slice();
}
function cs14VehicleTrim(){
  if(!Life.cars||S.custom.vehicleVariety==="low") return; const rng=mulberry(140014);
  Life.cars.forEach((c,i)=>{ if(!c.g||c.bus)return; const type=i%7;
    if(type===1||type===4){const sp=new THREE.Mesh(new THREE.BoxGeometry(.12,.1,1.3),new THREE.MeshStandardMaterial({color:0x171717,roughness:.4,metalness:.3}));sp.position.set(-1.75,.92,0);c.g.add(sp);}
    if(type===2){const rack=new THREE.Mesh(new THREE.BoxGeometry(1.4,.05,1.25),new THREE.MeshStandardMaterial({color:0x242424,metalness:.65,roughness:.35}));rack.position.set(-.2,1.35,0);c.g.add(rack);}
    if(type===3){const stripe=new THREE.Mesh(new THREE.BoxGeometry(3.2,.015,.13),new THREE.MeshBasicMaterial({color:0xf1efe8}));stripe.position.set(0,.52,.96);c.g.add(stripe);}
  });
}

// More face/color variety on the existing articulated people renderer.
function cs14Faces(){
  if(!Life.people||typeof PCOL==="undefined") return; const eyes=["#2d1d13","#4f341f","#6a5636","#3d5961","#486b4a","#7c8b84"]; const r=mulberry(141414);
  Life.people.forEach((p,i)=>{ if(!p.look)return; p.look.eyeSpacing=.24+r()*.15;p.look.mouthStyle=(r()*5)|0;p.look.faceWidth=.9+r()*.22;
    const ec=new THREE.Color(eyes[(r()*eyes.length)|0]); if(PCOL.eye){PCOL.eye[2*i]=ec;PCOL.eye[2*i+1]=ec.clone();}
    if(r()<.18&&!p.look.hat){p.look.hat=["beanie","cap","beret","fedora","sunhat","headscarf"][(r()*6)|0];p.look.hatColor=NEUTRAL.concat(BRIGHT)[(r()*(NEUTRAL.length+BRIGHT.length))|0];}
  });
}

// Clouds and occasional life in upper-floor windows.
function cs14Clouds(){
  if(S.custom.cloudLife==="off"||CS14.clouds.length||!G.scene)return; const r=mulberry(1407),mat=new THREE.MeshLambertMaterial({color:0xffffff,transparent:true,opacity:.38,depthWrite:false});
  for(let i=0;i<9;i++){const g=new THREE.Group();const n=4+((r()*5)|0);for(let j=0;j<n;j++){const m=new THREE.Mesh(new THREE.SphereGeometry(1,10,7),mat.clone());m.scale.set(8+r()*15,2.5+r()*5,5+r()*10);m.position.set((j-n/2)*8+r()*4,r()*2,r()*5);g.add(m);}g.position.set(rand(-240,240),75+rand(20,65),rand(-240,240));G.scene.add(g);CS14.clouds.push({g,v:.7+rand(0,1.4)});}
}
function cs14WindowLife(){
  if(S.custom.windowLife==="off"||CS14.windowPeople.length||!World.shops)return; const matBody=new THREE.MeshBasicMaterial({color:0x2c2723}),matHead=new THREE.MeshBasicMaterial({color:0xb77b5d});
  for(let i=0;i<Math.min(18,World.shops.length);i+=2){const sh=World.shops[i],g=new THREE.Group(),body=new THREE.Mesh(new THREE.BoxGeometry(.34,.65,.18),matBody),head=new THREE.Mesh(new THREE.SphereGeometry(.15,8,6),matHead);head.position.y=.47;g.add(body,head);const n=sh.n;g.position.set(sh.x-n[0]*.18,sh.gy+2.15,sh.z-n[1]*.18);g.rotation.y=sh.ry;G.scene.add(g);CS14.windowPeople.push({g,phase:i*.8});}
}
function cs14Ambient(dt){
  if(CS14.clouds.length){const wx=(typeof WIND!=="undefined"?WIND.x:1);for(const c of CS14.clouds){c.g.position.x+=wx*c.v*dt*.3;if(c.g.position.x>Player.x+330)c.g.position.x=Player.x-330;if(c.g.position.x<Player.x-330)c.g.position.x=Player.x+330;}}
  for(const w of CS14.windowPeople){w.g.rotation.z=Math.sin(Game.t*.35+w.phase)*.025;}
  if(GP.ride&&GP.ride.kind==="bus"){const v=GP.ride.v;if((v.speed||0)<.15){CS14.rideStill+=dt;if(CS14.rideStill>3){v.stopT=0;v.lastStop=Math.round(v.x/P)*P;v.vmax=Math.max(v.vmax||0,7);v.speed=Math.max(v.speed||0,1.2);CS14.rideStill=0;}}else CS14.rideStill=0;}
  cs14HideFlags();
}

// Capture more provenance and show it in the contact-sheet lightbox.
{ const base=captureShot; captureShot=async function(...a){ const rec=await base(...a); if(rec&&rec.meta){ const f=curFilm();rec.meta.filterName=(S.filter&&LENS_FILTERS[S.filter])?LENS_FILTERS[S.filter].n:"No filter";rec.meta.development={push:rec.meta.push||0,film:f.n,grain:f.grain,latitude:f.lat,shotPreview:S.custom.shotPreview||"on"};rec.meta.cameraSettings={mode:S.set.mode,ev:S.set.ev,focus:Cam.focus,af:S.set.af,flash:S.set.flashOn};rec.meta.weather={fog:!!S.fog,rain:!!S.rain,snow:!!S.snow,wind:typeof WIND!=="undefined"?Math.hypot(WIND.x||0,WIND.z||0):0};try{await DB.put(rec);}catch(e){} } return rec; }; }
{ const base=openLightbox; openLightbox=async function(id,info){ await base(id,info); try{const rec=await DB.get(id);if(!rec)return;const a=$("#lightbox aside");if(!a)return;let old=a.querySelector(".cs14-meta");if(old)old.remove();const m=rec.meta||{},ed=rec.edit||{};const div=document.createElement("div");div.className="cs14-meta";div.innerHTML=`<b>Frame record</b><br>${m.filmName||"—"} · ${m.bodyName||"—"} · ${m.lens||"—"}<br>${m.N?fmtA(m.N):"—"} · ${m.t?fmtShutter(m.t):"—"} · ISO ${m.iso||"—"} · ${m.filterName||"No filter"}<br>${m.timeName||""}${m.rain?" · rain":""}${m.fog?" · fog":""}${m.weather&&m.weather.snow?" · snow":""}<br><b>Development</b> · push ${m.push>0?"+":""}${m.push||0} · edit exposure ${Number(ed.ex||0).toFixed(1)} · contrast ${Number(ed.con||0).toFixed(1)} · grain ${Number(ed.grain||0).toFixed(1)} · preset ${ed.preset||"none"}`;a.appendChild(div);}catch(e){} }; }

// Settings UI: camera treatment, requested options, descriptions on hover, exposure coach.
const SETTING_TIPS={
 "Reduced shake":"On means zero simulated hand shake. Turn it Off if you want handheld movement to matter.",
 "Time scale":"Normal is real simulation speed. Slower values give you extra time to read street moments.",
 "Film advance":"Automatic is beginner-friendly. Manual mode makes mechanical cameras require winding between frames.",
 "Viewfinder preview":"Optical keeps the finder in colour like a real optical finder; Film look previews the loaded stock.",
 "Neon signs":"Controls how many storefront signs glow after dark.",
 "Window glass":"Clear is best for shooting from inside shops; reflective is harder but can create layered photographs.",
 "Wait mode":"Plant-feet mechanic. Off by default so movement stays immediate.",
 "Exposure coach":"Tips explains the current exposure. Foolproof also removes the sky-meter bias in Program mode.",
 "Perfect Program exposure":"Keeps P mode close to neutral exposure across bodies, lenses and filters.",
 "Roof-to-roof parkour":"Space on a rooftop leaps to a nearby roof in the direction you are facing.",
 "Clouds":"Occasional cloud banks drift with the wind.",
 "People in windows":"Adds occasional figures behind upper-floor glass.",
 "Vehicle variety":"Mixes body styles, paint, trim, spoilers, racks, trucks and unusual traffic.",
 "Character variety":"Controls how aggressively clothing/accessories are remixed across pedestrians."
};
{ const base=menuSettings; menuSettings=function(){ const c=S.custom,seg=(k,o)=>`<div class="seg" data-seg="${k}">${o.map(([v,l])=>`<button data-v="${v}" aria-pressed="${c[k]===v}">${l}</button>`).join("")}</div>`; return `<div class="sectionhead">Camera Assistance</div>
  <div class="formrow"><label>Exposure coach</label>${seg("exposureCoach",[["off","Off"],["tips","Tips"],["foolproof","Foolproof"]])}<span class="spec">Optional photographic guidance. Foolproof keeps Program mode neutral; Manual/A/S still behave like real camera modes.</span></div>
  <div class="formrow"><label>Perfect Program exposure</label>${seg("perfectProgram",[["on","On"],["off","Off"]])}<span class="spec">Compensates the sky-weighted meter so P mode doesn't randomly feel a stop dark with certain compositions.</span></div>
  <div class="formrow"><button class="btn small" data-expfix>Set recommended exposure</button><span class="spec">Uses the current EV, ISO and lens range. Think of it as a clickable Sunny-16/meter lesson.</span></div>
  <div class="sectionhead">Traversal & City Life</div>
  <div class="formrow"><label>Roof-to-roof parkour</label>${seg("roofParkour",[["on","On"],["off","Off"]])}</div>
  <div class="formrow"><label>Clouds</label>${seg("cloudLife",[["off","Off"],["some","Some"]])}</div>
  <div class="formrow"><label>People in windows</label>${seg("windowLife",[["on","On"],["off","Off"]])}</div>
  <div class="formrow"><label>Vehicle variety</label>${seg("vehicleVariety",[["normal","Normal"],["max","Maximum"]])}</div>`+base(); }; }
{ const base=wireMenu; wireMenu=function(){ base(); const b=document.querySelector("[data-expfix]");if(b)b.onclick=cs14ApplyExposure; const ts=document.querySelector('[data-aseg="timeScale"]');if(ts)ts.querySelectorAll("button").forEach(x=>x.onclick=()=>{S.custom.accessibility.timeScale=parseFloat(x.dataset.v)||1;saveState();applyAccessibility();renderMenu();}); }; }
{ const base=renderMenu; renderMenu=function(...a){ const r=base(...a); const joy=document.querySelector('[data-seg="tJoy"] [data-v="medium"]');if(joy)joy.textContent="Normal"; document.querySelectorAll("#menu .formrow").forEach(row=>{const lab=row.querySelector("label");if(!lab)return;const name=lab.textContent.trim(), spec=row.querySelector(".spec");const tip=SETTING_TIPS[name]||(spec&&spec.textContent.trim())||(`Adjust ${name.toLowerCase()} for how you want the camera or city to behave.`);row.dataset.tip=tip;row.title=tip;if(!lab.querySelector(".setting-help")){const h=document.createElement("span");h.className="setting-help";h.textContent="?";h.title=tip;lab.appendChild(h);}});return r; }; }

function cs14CoachHUD(){ let d=document.getElementById("cs14ExposureCoach");if(!d){d=document.createElement("div");d.id="cs14ExposureCoach";document.body.appendChild(d);}const on=Game.started&&Player.raise>.55&&S.custom.exposureCoach!=="off"&&!UI.open;d.classList.toggle("on",on);if(on)d.innerHTML=cs14ExposureTip(); }
{ const base=gameplayUpdate; gameplayUpdate=function(dt){ base(dt); cs14Ambient(dt); cs14CoachHUD(); }; }

// Boot-time polish after the proven original city/life creation is finished.
{ const base=boot; boot=async function(){ await base(); applyRequestedDefaults(S,true); cs14HideFlags(); if(S.free)masterFree(S); try{cs14VehicleTrim();cs14Faces();cs14Clouds();cs14WindowLife();}catch(e){console.warn("[v14] optional polish skipped",e);} CS14.booted=true; saveState(); }; }
console.log("[Contact Sheet v14] requested defaults/city/camera patch loaded.");
})();
