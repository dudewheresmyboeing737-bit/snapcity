
/* =========================================================
   World: Snap City — a fictional procedural city
   ========================================================= */
const P = 88, LOT = 70, HALF = 35, SWK = 4, ROADW = 10, RH = ROADW/2;
// City size (Settings > Picture & graphics > City size; read before the world is built).
const CITY_SIZE = (()=>{ try{ return localStorage.getItem("snapcity.citySize") || "standard"; }catch(e){ return "standard"; } })();
const NB = CITY_SIZE==="compact" ? 2 : CITY_SIZE==="large" ? 4 : 3, NOUT = NB + 1;
const NS_STREETS = {};   // x = (i+0.5)*P — filled with fictional names by nameCity()
const EW_STREETS = {};
const HOODS = {};
// Snap City is fictional and re-drawn every session: names are dealt from these pools.
const STREET_POOL = ["Dock","Mariner","Mercury","Willow","Silver","Lantern","Foundry","Horizon","Pier","North Light","Juniper","Beacon","Meridian","Amber","Union","Railway",
  "Copper","Tanner","Orchard","Signal","Ferrier","Kestrel","Harbor","Canal","Ember","Linden","Quarry","Weaver","Cobalt","Magnolia","Sparrow","Bellwether","Gaslight","Anchor",
  "Thistle","Prospect","Ironwood","Wren","Garnet","Coldwater","Hollis","Marlow","Saltbox","Vesper","Arcade","Fulton","Draper","Calder","Birch","Lamplighter"];
const HOOD_POOL = ["Mariner Heights","Juniper Hill","Old Quarter","Lantern Market","Mercury Square","Foundry District","South Yard","Copperline","Tanner's Row","Signal Hill",
  "The Narrows","Harbor Flats","Weaver's End","Gaslight Quarter","Orchard Park","Kestrel Point","Ironworks","Canal Street","Bellwether","Vesper Gardens"];
function nameCity(rnd){
  const deal = (pool) => { const a = pool.slice(); for (let k=a.length-1;k>0;k--){ const r=(rnd()*(k+1))|0; [a[k],a[r]]=[a[r],a[k]]; } return a; };
  const st = deal(STREET_POOL), hd = deal(HOOD_POOL); let n = 0;
  for (let i=-NOUT-1;i<=NOUT;i++){ NS_STREETS[i] = st[n++ % st.length]; EW_STREETS[i] = st[n++ % st.length]; }
  for (let j=-NOUT;j<=NOUT;j++) HOODS[j] = hd[(j+NOUT) % hd.length];
}
const CABLE_X = 0.5*P;
function H(x,z){ const up = smooth(50,-200,z) * (1 - smooth(-430,-580,z)); return 17*up + 1.4*Math.sin(x*0.012+1.0)*up; }
function zoneOf(i,j){ if (Math.abs(i)>NB || Math.abs(j)>NB) return "filler"; if (j<=-1) return "vic"; if (j===0) return "mixed"; return "down"; }

const World = {
  scene:null, sun:null, hemi:null, mats:{}, lots:[], lampPools:null, landmarkMats:[], skyMat:null, sunMesh:null,
  colliders:[], lamps:[], // {x0,x1,z0,z1}
  furniture:[], // for AF raycast: simple boxes of big props, unused mostly
};

/* ---------- buffers ---------- */
class GBuf { constructor(){ this.p=[]; this.n=[]; this.u=[]; this.c=[]; } }
const BUFS = {};
const GB = k => BUFS[k] || (BUFS[k] = new GBuf());
// Snap City: split the big merged batches into 330 m chunks so the renderer can skip what's
// off-screen (the city is 2.5x bigger; one city-wide mesh per material can't be culled).
const CHUNK = 330, CHUNKED = new Set(["plain","metal","foliage","glass","signs","civic","lamp","car_paint","car_glass","car_trim","car_chrome","car_head","car_tail","f_vic","f_office","f_brick","f_concrete","f_deco","f_edwardian","f_stucco","f_glass","f_castiron","f_derelict"]);
const GK = (key, x, z) => CHUNKED.has(key) ? key + "@" + Math.floor(x/CHUNK) + "," + Math.floor(z/CHUNK) : key;
const _m4 = new THREE.Matrix4(), _q = new THREE.Quaternion(), _v = new THREE.Vector3(), _v2 = new THREE.Vector3(), _s = new THREE.Vector3(), _e = new THREE.Euler(), _n3 = new THREE.Matrix3();
const PRIM = {};
function prims(){
  PRIM.box = new THREE.BoxGeometry(1,1,1).toNonIndexed();
  PRIM.boxB = new THREE.BoxGeometry(1,1,1).translate(0,0.5,0).toNonIndexed(); // base at y=0
  PRIM.cyl = new THREE.CylinderGeometry(0.5,0.5,1,10).translate(0,0.5,0).toNonIndexed();
  PRIM.cyl6 = new THREE.CylinderGeometry(0.5,0.5,1,6).translate(0,0.5,0).toNonIndexed();
  PRIM.cone = new THREE.ConeGeometry(0.5,1,8).translate(0,0.5,0).toNonIndexed();
  PRIM.sph = new THREE.IcosahedronGeometry(0.5,1).toNonIndexed();
  PRIM.frus = new THREE.CylinderGeometry(0.35,0.5,1,4,1).rotateY(Math.PI/4).translate(0,0.5,0).toNonIndexed(); // mansard
  PRIM.tri = new THREE.CylinderGeometry(0.5,0.5,1,3,1).rotateZ(Math.PI/2).rotateY(Math.PI/2).scale(1,1,1).translate(0,0.25,0).toNonIndexed(); // gable prism
  PRIM.sph0 = new THREE.IcosahedronGeometry(0.5,0).toNonIndexed();
  { const g = new THREE.IcosahedronGeometry(0.5,2).toNonIndexed(), P = g.attributes.position, v = new THREE.Vector3();
    const Nn = g.attributes.normal; for (let i=0;i<P.count;i++){ v.fromBufferAttribute(P,i); Nn.setXYZ(i, ...v.clone().normalize().toArray()); const h = Math.sin(v.x*37.1+v.y*11.7)*Math.cos(v.z*23.3-v.y*7.9)*0.5 + Math.sin(v.x*91.3+v.z*57.1)*0.25; v.multiplyScalar(1 + h*0.28); P.setXYZ(i, v.x, v.y, v.z); }
    PRIM.leaf = g; }
  PRIM.wheel = new THREE.CylinderGeometry(0.33,0.33,0.24,12).rotateZ(Math.PI/2).toNonIndexed();
}
function pushGeom(key, geom, m, color){
  const b = GB(GK(key, m.elements[12], m.elements[14])), pos = geom.attributes.position, nor = geom.attributes.normal, uv = geom.attributes.uv;
  _n3.getNormalMatrix(m);
  for (let i=0;i<pos.count;i++){
    _v.fromBufferAttribute(pos,i).applyMatrix4(m); b.p.push(_v.x,_v.y,_v.z);
    _v.fromBufferAttribute(nor,i).applyMatrix3(_n3).normalize(); b.n.push(_v.x,_v.y,_v.z);
    if (uv) b.u.push(uv.getX(i), uv.getY(i)); else b.u.push(0,0);
    b.c.push(color.r,color.g,color.b);
  }
}
function M(x,y,z, ry=0, sx=1,sy=1,sz=1, rx=0, rz=0){ _e.set(rx,ry,rz,"YXZ"); _q.setFromEuler(_e); return _m4.compose(_v2.set(x,y,z), _q, _s.set(sx,sy,sz)); }
function box(key, x,y,z, sx,sy,sz, color, ry=0, rx=0, rz=0){ pushGeom(key, PRIM.box, M(x,y,z,ry,sx,sy,sz,rx,rz), color); }

// facade box with world-scaled UVs. local: x∈[-w/2,w/2], y∈[0,h], z∈[-d/2,d/2]
function facadeBox(key, cx,yb,cz, w,h,d, ry, color, tw, th, vOff, uOff=0){
  const b = GB(GK(key, cx, cz)), cs = Math.cos(ry), sn = Math.sin(ry);
  const hw=w/2, hd=d/2;
  const faces = [
    { n:[0,0,1],  c:[[-hw,0,hd],[hw,0,hd],[hw,h,hd],[-hw,h,hd]], u:p=>(p[0]+hw)/tw },
    { n:[0,0,-1], c:[[hw,0,-hd],[-hw,0,-hd],[-hw,h,-hd],[hw,h,-hd]], u:p=>(hw-p[0])/tw },
    { n:[1,0,0],  c:[[hw,0,hd],[hw,0,-hd],[hw,h,-hd],[hw,h,hd]], u:p=>(hd-p[2])/tw },
    { n:[-1,0,0], c:[[-hw,0,-hd],[-hw,0,hd],[-hw,h,hd],[-hw,h,-hd]], u:p=>(p[2]+hd)/tw },
    { n:[0,1,0],  c:[[-hw,h,hd],[hw,h,hd],[hw,h,-hd],[-hw,h,-hd]], u:p=>0.02, top:true },
  ];
  for (const f of faces){
    const idx = [0,1,2,0,2,3];
    for (const k of idx){
      const p = f.c[k];
      const wx = cx + p[0]*cs + p[2]*sn, wz = cz - p[0]*sn + p[2]*cs;
      b.p.push(wx, yb+p[1], wz);
      b.n.push(f.n[0]*cs + f.n[2]*sn, f.n[1], -f.n[0]*sn + f.n[2]*cs);
      if (f.top) b.u.push(0.02, 0.97); else b.u.push(f.u(p)+uOff, (p[1]-vOff)/th);
      b.c.push(color.r,color.g,color.b);
    }
  }
}
// quad facing +z locally, with explicit uv rect
function quad(key, cx,cy,cz, w,h, ry, color, u0,v0,u1,v1, rx=0){
  const b = GB(GK(key, cx, cz)); const m = M(cx,cy,cz,ry,1,1,1,rx); _n3.getNormalMatrix(m);
  const cs = [[-w/2,-h/2,u0,v0],[w/2,-h/2,u1,v0],[w/2,h/2,u1,v1],[-w/2,-h/2,u0,v0],[w/2,h/2,u1,v1],[-w/2,h/2,u0,v1]];
  const nn = new THREE.Vector3(0,0,1).applyMatrix3(_n3).normalize();
  for (const c of cs){ _v.set(c[0],c[1],0).applyMatrix4(m); b.p.push(_v.x,_v.y,_v.z); b.n.push(nn.x,nn.y,nn.z); b.u.push(c[2],c[3]); b.c.push(color.r,color.g,color.b); }
}
// terrain-following grid
function grid(key, x0,z0,x1,z1, nx,nz, yOff, color, tile){
  const b = GB(key);
  const pt = (i,j) => { const x = lerp(x0,x1,i/nx), z = lerp(z0,z1,j/nz); return [x, H(x,z)+yOff, z]; };
  const nrm = (x,z) => { const e=0.5; const nx_ = H(x-e,z)-H(x+e,z), nz_ = H(x,z-e)-H(x,z+e); const l = Math.hypot(nx_,2*e,nz_); return [nx_/l, 2*e/l, nz_/l]; };
  for (let i=0;i<nx;i++) for (let j=0;j<nz;j++){
    const a = pt(i,j), bb = pt(i+1,j), c = pt(i+1,j+1), d = pt(i,j+1);
    for (const p of [a,d,c,a,c,bb]){ b.p.push(p[0],p[1],p[2]); const n = nrm(p[0],p[2]); b.n.push(n[0],n[1],n[2]); b.u.push(p[0]/tile, p[2]/tile); b.c.push(color.r,color.g,color.b); }
  }
}
// strip along a line following terrain (for paint/rails)
function strip(key, x0,z0,x1,z1, width, yOff, color, seg=4, height=0){
  const b = GB(key); const L = Math.hypot(x1-x0,z1-z0); const n = Math.max(1, Math.ceil(L/seg));
  const dx=(x1-x0)/L, dz=(z1-z0)/L, px=-dz*width/2, pz=dx*width/2;
  for (let i=0;i<n;i++){
    const t0=i/n, t1=(i+1)/n;
    const ax=lerp(x0,x1,t0), az=lerp(z0,z1,t0), bx=lerp(x0,x1,t1), bz=lerp(z0,z1,t1);
    const ya=H(ax,az)+yOff+height, yb=H(bx,bz)+yOff+height;
    const v = [[ax+px,ya,az+pz],[ax-px,ya,az-pz],[bx-px,yb,bz-pz],[ax+px,ya,az+pz],[bx-px,yb,bz-pz],[bx+px,yb,bz+pz]];
    for (const p of v){ b.p.push(p[0],p[1],p[2]); b.n.push(0,1,0); b.u.push(0,0); b.c.push(color.r,color.g,color.b); }
  }
}
function buildMesh(key, mat, opts={}){
  if (CHUNKED.has(key)){ let first = null; for (const k of Object.keys(BUFS)) if (k === key || k.startsWith(key + "@")){ const m = buildMeshOne(k, mat, opts); if (m && !first) first = m; } return first; }
  return buildMeshOne(key, mat, opts);
}
function buildMeshOne(key, mat, opts={}){
  const b = BUFS[key]; if (!b || !b.p.length) return null;
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(b.p,3));
  g.setAttribute("normal", new THREE.Float32BufferAttribute(b.n,3));
  g.setAttribute("uv", new THREE.Float32BufferAttribute(b.u,2));
  g.setAttribute("color", new THREE.Float32BufferAttribute(b.c,3));
  g.computeBoundingSphere();
  const m = new THREE.Mesh(g, mat);
  m.castShadow = !!opts.cast; m.receiveShadow = opts.receive !== false;
  m.matrixAutoUpdate = false; m.updateMatrix();
  World.scene.add(m); delete BUFS[key];
  return m;
}

/* ---------- procedural textures ---------- */
function cnv(w,h){ const c = document.createElement("canvas"); c.width=w; c.height=h; return c; }
function noiseFill(ctx, w, h, base, amt, rnd){
  const img = ctx.getImageData(0,0,w,h), d = img.data;
  for (let i=0;i<d.length;i+=4){ const n = (rnd()-0.5)*amt; d[i]=clamp(d[i]+n,0,255); d[i+1]=clamp(d[i+1]+n,0,255); d[i+2]=clamp(d[i+2]+n,0,255); }
  ctx.putImageData(img,0,0);
}
function shopInterior(){
  const c = document.createElement("canvas"); c.width = 512; c.height = 256; const x = c.getContext("2d"), r = mulberry(77);
  const g = x.createLinearGradient(0,0,0,256); g.addColorStop(0,"#3a2a1c"); g.addColorStop(0.5,"#2a1f16"); g.addColorStop(1,"#15100c"); x.fillStyle = g; x.fillRect(0,0,512,256);
  for (let i=0;i<6;i++){ const lx = 20 + i*85 + r()*20; const lg = x.createRadialGradient(lx,10,2,lx,10,70); lg.addColorStop(0,"rgba(255,226,170,.95)"); lg.addColorStop(1,"rgba(255,226,170,0)"); x.fillStyle = lg; x.fillRect(lx-70,0,140,90); x.fillStyle = "#fff3d6"; x.fillRect(lx-18,4,36,5); }
  for (let i=0;i<9;i++){ const sx = r()*480, sw = 30 + r()*70, sy = 90 + r()*60; x.fillStyle = `rgba(${25+r()*35|0},${20+r()*25|0},${15+r()*20|0},.95)`; x.fillRect(sx, sy, sw, 256-sy); for (let k=0;k<4;k++){ x.fillStyle = ["#a33a2c","#e8b82e","#2f7fc1","#e9e6de","#3aa06b"][(r()*5)|0]; x.globalAlpha = .22; x.fillRect(sx+3, sy+6+k*22, sw-6, 5); x.globalAlpha = 1; } }
  for (let i=0;i<3;i++){ const px = 60 + r()*400; x.fillStyle = "rgba(12,9,7,.85)"; x.beginPath(); x.arc(px, 120, 11, 0, 7); x.fill(); x.fillRect(px-14, 132, 28, 124); }
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
function glassGrad(ctx, x,y,w,h, cool){
  const g = ctx.createLinearGradient(x,y,x+w*0.6,y+h);
  if (cool){ g.addColorStop(0,"#6b8196"); g.addColorStop(0.45,"#2d3a47"); g.addColorStop(1,"#1a222b"); }
  else { g.addColorStop(0,"#4a5561"); g.addColorStop(0.5,"#232a31"); g.addColorStop(1,"#161b20"); }
  ctx.fillStyle = g; ctx.fillRect(x,y,w,h);
  ctx.fillStyle = "rgba(255,255,255,0.08)"; ctx.beginPath(); ctx.moveTo(x,y+h*0.25); ctx.lineTo(x+w*0.55,y); ctx.lineTo(x+w,y); ctx.lineTo(x,y+h*0.6); ctx.fill();
}
function makeFacade(style, seed){
  const rnd = mulberry(seed); const S_ = 512; const c = cnv(S_,S_), x = c.getContext("2d");
  const e = cnv(S_,S_), ex = e.getContext("2d"); ex.fillStyle="#000"; ex.fillRect(0,0,S_,S_);
  const cols=4, rows=3, cw=S_/cols, rh=S_/rows;
  const lit = (wx,wy,ww,wh) => { if (rnd()<0.42){ const warm = rnd()<0.8; const g = ex.createLinearGradient(0,wy,0,wy+wh); g.addColorStop(0, warm?"#ffd9a0":"#d6e4ff"); g.addColorStop(1, warm?"#ffb766":"#9fb8e8"); ex.fillStyle=g; ex.globalAlpha = 0.55+rnd()*0.45; ex.fillRect(wx,wy,ww,wh); ex.globalAlpha=1; } };
  if (style==="vic"){
    x.fillStyle="#cfcfcf"; x.fillRect(0,0,S_,S_);
    x.fillStyle="rgba(0,0,0,0.10)"; for (let yy=0; yy<S_; yy+=9) x.fillRect(0,yy,S_,1.5);
    noiseFill(x,S_,S_,0,10,rnd);
    for (let r=0;r<rows;r++) for (let k=0;k<cols;k++){
      const ww=54, wh=100, wx=k*cw+(cw-ww)/2, wy=(rows-1-r)*rh + 34;
      x.fillStyle="#fbfbfb"; x.fillRect(wx-9, wy-26, ww+18, wh+36);           // trim surround
      x.fillStyle="#e2e2e2"; x.beginPath(); x.moveTo(wx-12,wy-24); x.lineTo(wx+ww/2,wy-44); x.lineTo(wx+ww+12,wy-24); x.fill(); // pediment
      x.fillStyle="#fbfbfb"; x.fillRect(wx-14, wy-28, ww+28, 7);
      glassGrad(x, wx, wy, ww, wh, false);
      x.fillStyle="#f2f2f2"; x.fillRect(wx+ww/2-2, wy, 4, wh); x.fillRect(wx, wy+wh/2-2, ww, 4);
      x.fillStyle="#fbfbfb"; x.fillRect(wx-12, wy+wh, ww+24, 8); // sill
      x.fillStyle="rgba(0,0,0,0.25)"; x.fillRect(wx-12, wy+wh+8, ww+24, 3);
      lit(wx,wy,ww,wh);
    }
    // corner boards
    x.fillStyle="#f6f6f6"; x.fillRect(0,0,6,S_); x.fillRect(S_-6,0,6,S_);
  } else if (style==="office"){
    x.fillStyle="#d9d9d6"; x.fillRect(0,0,S_,S_);
    for (let r=0;r<rows;r++) for (let k=0;k<cols;k++){
      const wx=k*cw+10, wy=(rows-1-r)*rh+8, ww=cw-20, wh=rh-46;
      glassGrad(x, wx, wy, ww, wh, true);
      x.fillStyle="#b8bcc0"; x.fillRect(wx+ww/2-1.5, wy, 3, wh);
      x.fillStyle="#9ea3a8"; x.fillRect(wx, wy+wh, ww, 30);
      lit(wx,wy,ww,wh);
    }
    noiseFill(x,S_,S_,0,6,rnd);
  } else if (style==="brick"){
    x.fillStyle="#8e4535"; x.fillRect(0,0,S_,S_);
    for (let yy=0, row=0; yy<S_; yy+=8, row++){ for (let xx=(row%2)*10; xx<S_; xx+=20){ const v = rnd()*30-15; x.fillStyle=`rgb(${148+v},${70+v*0.6},${52+v*0.5})`; x.fillRect(xx+1,yy+1,18,6); } }
    for (let r=0;r<rows;r++) for (let k=0;k<cols;k++){
      const ww=60, wh=104, wx=k*cw+(cw-ww)/2, wy=(rows-1-r)*rh+30;
      x.fillStyle="#d9cfbd"; x.fillRect(wx-8, wy-16, ww+16, 14); x.fillRect(wx-6, wy+wh, ww+12, 8);
      x.fillStyle="#efefea"; x.fillRect(wx-3,wy-3,ww+6,wh+6);
      glassGrad(x, wx, wy, ww, wh, false);
      x.fillStyle="#efefea"; x.fillRect(wx, wy+wh*0.45, ww, 4);
      lit(wx,wy,ww,wh);
    }
    // fire escape on one column
    x.strokeStyle="#1d1d1d"; x.lineWidth=3;
    for (let r=0;r<rows;r++){ const yy=(rows-1-r)*rh+140; x.strokeRect(cw*1+8, yy, cw*2-16, 14); x.beginPath(); for (let t=0;t<cw*2-16;t+=8){ x.moveTo(cw+8+t,yy); x.lineTo(cw+8+t,yy+14); } x.stroke(); x.beginPath(); x.moveTo(cw+20, yy+14); x.lineTo(cw*2+30, yy+14+rh-14); x.stroke(); }
    noiseFill(x,S_,S_,0,12,rnd);
} else if (style==="deco"){
    x.fillStyle="#d8ccb4"; x.fillRect(0,0,S_,S_); noiseFill(x,S_,S_,0,8,rnd);
    const bays=4, bw=S_/bays;
    for (let r=0;r<rows;r++) for (let k=0;k<bays;k++){
      const wx=k*bw+22, wy=(rows-1-r)*rh+18, ww=bw-44, wh=rh-60;
      glassGrad(x, wx, wy, ww, wh, false); x.fillStyle="#cfc3aa"; x.fillRect(wx+ww/2-2, wy, 4, wh);
      x.fillStyle="#9c8f78"; x.fillRect(wx, wy+wh, ww, 42);
      x.fillStyle="#b9ab90"; for (let z=0;z<3;z++) x.fillRect(wx+8+z*(ww-16)/3, wy+wh+10, (ww-16)/3-6, 22);
      lit(wx,wy,ww,wh);
    }
    x.fillStyle="#efe6d2"; for (let k=0;k<=bays;k++){ x.fillRect(k*bw-9,0,18,S_); }
    x.fillStyle="rgba(0,0,0,0.12)"; for (let k=0;k<=bays;k++) x.fillRect(k*bw+9,0,3,S_);
  } else if (style==="edwardian"){
    x.fillStyle="#e4ddcf"; x.fillRect(0,0,S_,S_); noiseFill(x,S_,S_,0,8,rnd);
    for (let r=0;r<rows;r++){
      const wy=(rows-1-r)*rh+28, wh=108;
      for (const [gx,gw] of [[30,200],[282,200]]){
        x.fillStyle="#f8f5ee"; x.fillRect(gx-10, wy-14, gw+20, wh+26);
        for (let k=0;k<3;k++){ const wx=gx+k*(gw/3)+6, ww=gw/3-12; glassGrad(x, wx, wy, ww, wh, false); x.fillStyle="#f8f5ee"; x.fillRect(wx, wy+wh*0.38, ww, 4); lit(wx,wy,ww,wh); }
      }
      x.fillStyle="#f8f5ee"; x.fillRect(0, wy-30, S_, 8);
      x.fillStyle="rgba(0,0,0,0.18)"; for (let d=0; d<S_; d+=12) x.fillRect(d, wy-22, 6, 5);
    }
    x.fillStyle="#f3efe6"; x.fillRect(248,0,16,S_);
  } else if (style==="stucco"){
    x.fillStyle="#e9e2d4"; x.fillRect(0,0,S_,S_); noiseFill(x,S_,S_,0,16,rnd);
    for (let r=0;r<rows;r++) for (let k=0;k<3;k++){
      const ww=92, wh=96, wx=k*(S_/3)+(S_/3-ww)/2, wy=(rows-1-r)*rh+44;
      x.fillStyle="#d7cdb9"; x.beginPath(); x.moveTo(wx-8,wy+wh+6); x.lineTo(wx-8,wy+20); x.arc(wx+ww/2, wy+20, ww/2+8, Math.PI, 0); x.lineTo(wx+ww+8,wy+wh+6); x.fill();
      x.save(); x.beginPath(); x.moveTo(wx,wy+wh); x.lineTo(wx,wy+20); x.arc(wx+ww/2, wy+20, ww/2, Math.PI, 0); x.lineTo(wx+ww,wy+wh); x.closePath(); x.clip(); glassGrad(x, wx, wy-30, ww, wh+30, false); x.restore();
      x.fillStyle="#efe9dd"; x.fillRect(wx+ww/2-2, wy+10, 4, wh-10);
      x.fillStyle="#a2553a"; x.fillRect(wx-10, wy+wh+6, ww+20, 7);
      if (rnd()<0.4){ x.fillStyle="#3d3a35"; for (let b=0;b<7;b++) x.fillRect(wx-4+b*(ww+8)/6, wy+wh+14, 3, 22); x.fillRect(wx-6, wy+wh+14, ww+12, 3); }
      lit(wx,wy+20,ww,wh-20);
    }
  } else if (style==="glass"){
    const g0 = x.createLinearGradient(0,0,S_,S_); g0.addColorStop(0,"#5d7890"); g0.addColorStop(0.5,"#8fb0c8"); g0.addColorStop(1,"#4b6377");
    x.fillStyle=g0; x.fillRect(0,0,S_,S_);
    x.fillStyle="rgba(255,255,255,0.10)"; x.beginPath(); x.moveTo(0,S_*0.2); x.lineTo(S_*0.55,0); x.lineTo(S_*0.75,0); x.lineTo(0,S_*0.45); x.fill();
    x.fillStyle="#2a3440"; for (let k=0;k<=8;k++) x.fillRect(k*64-2,0,4,S_); for (let r=0;r<=3;r++) x.fillRect(0, r*rh-5, S_, 10);
    for (let r=0;r<rows;r++) for (let k=0;k<8;k++) lit(k*64+4, (rows-1-r)*rh+8, 56, rh-18);
  } else if (style==="castiron"){
    x.fillStyle="#9aa39c"; x.fillRect(0,0,S_,S_); noiseFill(x,S_,S_,0,8,rnd);
    for (let r=0;r<rows;r++) for (let k=0;k<4;k++){
      const ww=86, wh=118, wx=k*cw+(cw-ww)/2, wy=(rows-1-r)*rh+30;
      x.save(); x.beginPath(); x.moveTo(wx,wy+wh); x.lineTo(wx,wy+ww/2); x.arc(wx+ww/2, wy+ww/2, ww/2, Math.PI, 0); x.lineTo(wx+ww,wy+wh); x.closePath(); x.clip(); glassGrad(x, wx, wy, ww, wh, false); x.restore();
      x.strokeStyle="#6c756f"; x.lineWidth=5; x.beginPath(); x.arc(wx+ww/2, wy+ww/2, ww/2+3, Math.PI, 0); x.stroke();
      x.fillStyle="#7d877f"; x.fillRect(wx+ww/2-2, wy+ww/2, 4, wh-ww/2);
      lit(wx,wy+10,ww,wh-10);
    }
    x.fillStyle="#b7bfb8"; for (let k=0;k<=4;k++) x.fillRect(k*cw-5,0,10,S_); for (let r=0;r<3;r++) x.fillRect(0,(rows-1-r)*rh+10,S_,8);
  } else if (style==="derelict"){ // boarded-up: plywood over some windows, stains, graffiti tags
    x.fillStyle="#7d7466"; x.fillRect(0,0,S_,S_); noiseFill(x,S_,S_,0,26,rnd);
    for (let r=0;r<rows;r++) for (let k=0;k<cols;k++){
      const ww=62, wh=100, wx=k*cw+(cw-ww)/2, wy=(rows-1-r)*rh+30;
      if (rnd()<0.55){ x.fillStyle=`rgb(${150+rnd()*30|0},${118+rnd()*20|0},${80+rnd()*20|0})`; x.fillRect(wx-4,wy-4,ww+8,wh+8); x.strokeStyle="rgba(0,0,0,.25)"; x.lineWidth=2; for (let b=1;b<4;b++){ x.beginPath(); x.moveTo(wx-4,wy-4+b*(wh+8)/4); x.lineTo(wx+ww+4,wy-4+b*(wh+8)/4); x.stroke(); } }
      else { x.fillStyle="#141414"; x.fillRect(wx,wy,ww,wh); x.strokeStyle="#5a5a5a"; x.lineWidth=2; x.beginPath(); x.moveTo(wx+rnd()*ww,wy); x.lineTo(wx+ww*0.5,wy+wh*0.5); x.lineTo(wx+rnd()*ww,wy+wh); x.stroke(); }
    }
    for (let k=0;k<5;k++){ x.fillStyle="rgba(40,30,20,.25)"; x.fillRect(rnd()*S_, 0, 8+rnd()*14, S_); }
    for (let k=0;k<3;k++){ x.save(); x.translate(40+rnd()*400, 380+rnd()*110); x.rotate((rnd()-.5)*.3); x.font="bold 44px sans-serif"; x.fillStyle=["#e6406b","#35c1e0","#f2d24a","#8ee05a"][k%4]; x.fillText(["SNAP","ZEKE","NO.9","WILD","ARLO","KAZ"][(rnd()*6)|0],0,0); x.restore(); }
  } else { // concrete
    x.fillStyle="#cdc5b6"; x.fillRect(0,0,S_,S_);
    for (let r=0;r<rows;r++){
      const wy=(rows-1-r)*rh+40, wh=86;
      glassGrad(x, 0, wy, S_, wh, false);
      for (let k=0;k<8;k++){ x.fillStyle="#bdb5a6"; x.fillRect(k*64-3, wy, 6, wh); lit(k*64+3, wy, 58, wh); }
      x.fillStyle="rgba(0,0,0,0.12)"; x.fillRect(0, wy+wh, S_, 4);
    }
    x.fillStyle="rgba(0,0,0,0.08)"; for (let k=0;k<4;k++) x.fillRect(k*128,0,2,S_);
    noiseFill(x,S_,S_,0,14,rnd);
  }
  return { map:c, emis:e };
}
function makeGroundTex(kind){
  const rnd = mulberry(kind==="asphalt"?7:9), S_=512, c = cnv(S_,S_), x = c.getContext("2d");
  if (kind==="asphalt"){
    x.fillStyle="#5a5a58"; x.fillRect(0,0,S_,S_); noiseFill(x,S_,S_,0,38,rnd);
    for (let i=0;i<260;i++){ x.fillStyle = rnd()<0.5? "rgba(20,20,20,0.35)":"rgba(200,200,195,0.18)"; x.fillRect(rnd()*S_, rnd()*S_, 2, 2); }
    x.strokeStyle="rgba(25,25,25,0.45)"; x.lineWidth=1.5; for (let i=0;i<5;i++){ x.beginPath(); let px=rnd()*S_, py=rnd()*S_; x.moveTo(px,py); for (let k=0;k<8;k++){ px+=rnd()*40-20; py+=rnd()*40-20; x.lineTo(px,py);} x.stroke(); }
    x.fillStyle="rgba(30,30,30,0.25)"; x.fillRect(rnd()*300, rnd()*300, 140, 90);
  } else {
    x.fillStyle="#a9a7a0"; x.fillRect(0,0,S_,S_); noiseFill(x,S_,S_,0,22,rnd);
    x.fillStyle="rgba(60,58,54,0.55)"; for (let k=0;k<=4;k++){ x.fillRect(k*128-1,0,2,S_); x.fillRect(0,k*128-1,S_,2); }
    for (let i=0;i<30;i++){ x.fillStyle="rgba(40,40,40,0.25)"; x.beginPath(); x.arc(rnd()*S_,rnd()*S_,rnd()*4+1,0,7); x.fill(); }
  }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.encoding = THREE.sRGBEncoding; return t;
}
const SIGN_NAMES = ["Fog City Coffee","Hyde St Books","Golden Noodle","Pacific Hardware","Taquería 24","Wash & Fold","Tartine Bakery","Amoeba-ish Records","Pho Saigon","Dim Sum","Cafe Trieste","Liquor & Deli"];
function makeSigns(){
  const c = cnv(1024,768), x = c.getContext("2d"), bgs = ["#1e3a5f","#7c2e36","#f2e6c9","#2f4b3a","#c0362c","#f4f1ea","#3a2a1c","#e8a33d","#11303a","#b1262b","#fff4d6","#224422"];
  for (let i=0;i<12;i++){
    const col=i%2, row=(i/2)|0, sx=col*512, sy=row*128;
    x.fillStyle = bgs[i]; x.fillRect(sx+4, sy+4, 504, 120);
    const light = ["#f2e6c9","#f4f1ea","#e8a33d","#fff4d6"].includes(bgs[i]);
    x.fillStyle = light? "#26231f" : "#f6efe0";
    x.font = `${i%3===0?"italic ":""}600 64px ${i%2? "Newsreader, Georgia, serif" : "Barlow Condensed, Arial Narrow, sans-serif"}`;
    x.textAlign="center"; x.textBaseline="middle"; x.fillText(SIGN_NAMES[i], sx+256, sy+68, 470);
    x.strokeStyle = light? "#26231f" : "#f6efe0"; x.lineWidth=3; x.strokeRect(sx+14, sy+14, 484, 100);
  }
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.anisotropy = 4; return t;
}
function radialTex(inner, outer){
  const c = cnv(128,128), x = c.getContext("2d"), g = x.createRadialGradient(64,64,0,64,64,64);
  g.addColorStop(0, inner); g.addColorStop(1, outer); x.fillStyle=g; x.fillRect(0,0,128,128);
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}

/* ---------- palettes ---------- */
const VIC_COLORS = ["#e9c9c2","#b7d3cf","#f1e2b3","#cbd6e9","#e8b69f","#abc6a3","#f3efe4","#dac3de","#caa98a","#9fb8cb","#e6d08e","#86a1ae","#d98f7e","#6f8f7c"];
const TRIM_COLORS = ["#f5f2ea","#ffffff","#2f4b5a","#7a2e36","#ece2c6","#3b3f45"];
const DOWN_TINTS = ["#ffffff","#f2eee6","#e6ebef","#f7efe1","#dfe3e3"];
const FACADE_STYLES = ["vic","office","brick","concrete","deco","edwardian","stucco","glass","castiron","derelict"];
const PASTEL_TINTS = ["#f4e3c9","#e7d3e4","#d3e4e0","#f1d9c7","#e0e6c9","#f6efd8","#d8dfee","#f0d0cf"];
const AWN = ["#7a2e36","#1e3a5f","#2f5a3a","#c0362c","#26231f","#b88a2e","#e2d6c0","#304f6e"];
const CAR_COLORS = ["#1e4f8a","#b8322a","#2f5d3f","#c9a227","#6b2a3a","#4a6a7a","#8a9a6a","#d8c9a3","#c9ccce","#1f2226","#f3f3f1","#6b1f22","#27384d","#8e9396","#3c4a3a","#b8a27a","#d8c9a3","#20424f","#a33a2c","#e4e0d6"];

function buildWorld(scene, progress){
  World.scene = scene; prims(); initCarMats();
  const tex = {};
  FACADE_STYLES.forEach((s,i)=>{ const f = makeFacade(s, 101+i*13); tex[s] = { map:new THREE.CanvasTexture(f.map), emis:new THREE.CanvasTexture(f.emis) }; for (const k of ["map","emis"]){ const t = tex[s][k]; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.encoding = THREE.sRGBEncoding; t.anisotropy = 4; } });
  const TILE = { vic:[8.8,10.2], office:[12,10.8], brick:[12,10.5], concrete:[12,10.5], deco:[12,10.5], edwardian:[10,10.2], stucco:[11,10.2], glass:[12,10.8], castiron:[12,12.6], derelict:[12,10.5] };
  const mats = World.mats;
  for (const s in tex){ mats["f_"+s] = new THREE.MeshStandardMaterial({ map:tex[s].map, emissiveMap:tex[s].emis, emissive:new THREE.Color(1,1,1), emissiveIntensity:0, vertexColors:true, roughness: s==="glass"?0.18 : s==="office"?0.55 : s==="castiron"?0.6 : 0.9, metalness: s==="glass"?0.35 : s==="office"?0.15 : s==="castiron"?0.2 : 0 }); }
  mats.plain = new THREE.MeshStandardMaterial({ vertexColors:true, roughness:0.82 });
  mats.metal = new THREE.MeshStandardMaterial({ vertexColors:true, roughness:0.35, metalness:0.35 });
  mats.foliage = new THREE.MeshStandardMaterial({ vertexColors:true, roughness:0.95 });
  mats.glass = new THREE.MeshStandardMaterial({ color:lin("#1a2025"), emissive:lin("#ffffff"), emissiveMap:shopInterior(), emissiveIntensity:0.3, roughness:0.06, metalness:0.5, vertexColors:true });
  setupInteriorGlass(mats.glass);
  mats.lamp = new THREE.MeshStandardMaterial({ color:lin("#d8d2c0"), emissive:lin("#ffc27a"), emissiveIntensity:0, roughness:0.4 });
  mats.signal = new THREE.MeshBasicMaterial({ vertexColors:true });
  mats.signs = new THREE.MeshStandardMaterial({ map:makeShopSigns(), emissive:new THREE.Color(1,1,1), emissiveIntensity:0.05, roughness:0.6, vertexColors:true });
  mats.signs.emissiveMap = mats.signs.map;
  mats.civic = new THREE.MeshStandardMaterial({ map:makeCivicSigns(), emissive:new THREE.Color(1,1,1), emissiveIntensity:0.05, roughness:0.6, vertexColors:true }); mats.civic.emissiveMap = mats.civic.map;
  const asphalt = makeGroundTex("asphalt"), sidewalk = makeGroundTex("sidewalk");
  asphalt.anisotropy = sidewalk.anisotropy = 8;
  mats.road = new THREE.MeshStandardMaterial({ map:asphalt, vertexColors:true, roughness:0.95 });
  mats.walk = new THREE.MeshStandardMaterial({ map:sidewalk, vertexColors:true, roughness:0.92 });
  mats.paint = new THREE.MeshStandardMaterial({ vertexColors:true, roughness:0.8, polygonOffset:true, polygonOffsetFactor:-2, polygonOffsetUnits:-2 });
  mats.pool = new THREE.MeshBasicMaterial({ map:radialTex("rgba(255,196,120,0.55)","rgba(255,196,120,0)"), transparent:true, depthWrite:false, blending:THREE.AdditiveBlending, opacity:0, polygonOffset:true, polygonOffsetFactor:-4, polygonOffsetUnits:-4 });

  // A new city every session.
  World.seed = (Math.random()*2147483647)|0;
  const rnd = mulberry(World.seed);
  nameCity(rnd);
  const R = (a,b)=>a+rnd()*(b-a), RP = arr=>arr[(rnd()*arr.length)|0];
  const white = lin("#ffffff");

  // ---------- ground ----------
  { const E = (NOUT+0.5)*P + 20; grid("road", -E,-E,E,E, 2*Math.ceil(E/5),2*Math.ceil(E/5), 0, lin("#ffffff"), 5); }
  grid("roadOuter", -1100,-1100,1100,1100, 55,55, -0.35, lin("#e6e6e6"), 5);
  // water (the harbour, far north)
  const water = new THREE.Mesh(new THREE.PlaneGeometry(4000,1800).rotateX(-Math.PI/2), new THREE.MeshStandardMaterial({ color:lin("#4c6572"), roughness:0.25, metalness:0.3 }));
  water.position.set(0,0.4,-1500); scene.add(water); World.water = water;

  // ---------- blocks ----------
  const sgnOf = (i)=> i<0?-1:1;
  for (let i=-NOUT;i<=NOUT;i++) for (let j=-NOUT;j<=NOUT;j++){
    const cx=i*P, cz=j*P, zone = zoneOf(i,j);
    World.lots.push({ i,j,cx,cz,zone, x0:cx-HALF, x1:cx+HALF, z0:cz-HALF, z1:cz+HALF, hMax:0 });
    // sidewalk slab + curbs
    const s0x=cx-HALF-SWK, s1x=cx+HALF+SWK, s0z=cz-HALF-SWK, s1z=cz+HALF+SWK;
    grid("walk", s0x,s0z,s1x,s1z, 16,16, 0.16, lin("#ffffff"), 2);
    for (const [ax,az,bx,bz] of [[s0x,s0z,s1x,s0z],[s1x,s0z,s1x,s1z],[s1x,s1z,s0x,s1z],[s0x,s1z,s0x,s0z]]){
      const L = Math.hypot(bx-ax,bz-az), n = Math.ceil(L/4), b = GB("walk"), c = lin("#bdbab2");
      const nx=(bz-az)/L, nz=-(bx-ax)/L; // outward normal (clockwise path)
      for (let k=0;k<n;k++){
        const x0=lerp(ax,bx,k/n), z0=lerp(az,bz,k/n), x1=lerp(ax,bx,(k+1)/n), z1=lerp(az,bz,(k+1)/n);
        const y0=H(x0,z0), y1=H(x1,z1);
        for (const p of [[x0,y0-0.05,z0],[x1,y1-0.05,z1],[x1,y1+0.16,z1],[x0,y0-0.05,z0],[x1,y1+0.16,z1],[x0,y0+0.16,z0]]){ b.p.push(...p); b.n.push(nx,0,nz); b.u.push(0,0.5); b.c.push(c.r,c.g,c.b); }
      }
    }
    const alley = Math.abs(i)<=NB && Math.abs(j)<=NB && zone!=="down" && rnd() < 0.42;   // a lane cutting east-west through the block
    const AW = 2.6; // half-width of the lane
    World.lots[World.lots.length-1].alley = alley;
    if (alley){
      World.colliders.push({ x0:cx-HALF-0.4, x1:cx+HALF+0.4, z0:cz-HALF-0.4, z1:cz-AW });
      World.colliders.push({ x0:cx-HALF-0.4, x1:cx+HALF+0.4, z0:cz+AW, z1:cz+HALF+0.4 });
      (World.alleys = World.alleys || []).push({ cx, cz, x0:cx-HALF, x1:cx+HALF, w:AW*2 });
      dressAlley(cx, cz, AW, rnd, R, RP);
    } else World.colliders.push({ x0:cx-HALF-0.4, x1:cx+HALF+0.4, z0:cz-HALF-0.4, z1:cz+HALF+0.4 });

    // ---------- buildings along 4 edges ----------
    const D = 14;
    const edges = [
      { o:[cx-HALF, cz-HALF], t:[1,0],  n:[0,-1], L:LOT, m0:0, m1:0 },
      { o:[cx+HALF, cz+HALF], t:[-1,0], n:[0,1],  L:LOT, m0:0, m1:0 },
      { o:[cx+HALF, cz-HALF], t:[0,1],  n:[1,0],  L:LOT, m0:D, m1:D },
      { o:[cx-HALF, cz+HALF], t:[0,-1], n:[-1,0], L:LOT, m0:D, m1:D },
    ];
    let lotMax = 0;
    for (const ed of edges){
      let a = ed.m0;
      while (a < ed.L - ed.m1 - 2){
        let w = zone==="vic" ? R(6.8,9.2) : zone==="filler" ? R(14,26) : (rnd()<0.15 ? R(5,7) : rnd()<0.15 ? R(20,28) : R(8,18));
        if (a + w > ed.L - ed.m1 - 4) w = ed.L - ed.m1 - a;
        if (alley && ed.n[0] !== 0){ // leave the lane open where it meets the street
          const g0 = ed.L/2 - AW, g1 = ed.L/2 + AW;
          if (a + w > g0 && a < g1){ if (g0 - a >= 4){ w = g0 - a; } else { a = g1; continue; } }
        }
        const mid = a + w/2;
        const fx = ed.o[0] + ed.t[0]*mid, fz = ed.o[1] + ed.t[1]*mid;
        const ry = Math.atan2(ed.n[0], ed.n[1]);
        const bxC = fx - ed.n[0]*D/2, bzC = fz - ed.n[1]*D/2;
        // terrain under footprint
        let yMin = 1e9, yMax = -1e9;
        for (const u of [-w/2,w/2]) for (const v of [0,-D]){ const px = fx + ed.t[0]*u + ed.n[0]*v, pz = fz + ed.t[1]*u + ed.n[1]*v; const hh = H(px,pz); yMin = Math.min(yMin,hh); yMax = Math.max(yMax,hh); }
        const g = H(fx,fz) + 0.16; // street-level floor at facade
        const base = yMin - 0.6;
        const place = (lx, ly, lz) => [fx + ed.t[0]*lx + ed.n[0]*lz, ly, fz + ed.t[1]*lx + ed.n[1]*lz]; // lx along edge, lz outward from facade
        // Snap City: now and then leave a gap — pocket park, car park, empty lot or building site.
        if (zone!=="vic" && zone!=="filler" && Math.abs(i)<=NB && Math.abs(j)<=NB && w >= 7 && a > ed.m0 && rnd() < 0.1){
          let kind = RP(["park","parking","vacant","parking","park","vacant"]);
          if ((World.construction||[]).length < 4 && rnd() < 0.4) kind = "construction";
          buildGapFeature(kind, { place, g, w, D, ry, rnd, R, RP, ed });
          a += w; continue;
        }
        let top;
        if (zone === "vic"){
          const floors = rnd()<0.75 ? 3 : 2, garage = rnd()<0.6, rb = garage ? 2.6 : 1.1;
          const col = lin(RP(VIC_COLORS)), trim = lin(RP(TRIM_COLORS)), trimW = lin(rnd()<0.6?"#f5f2ea":RP(TRIM_COLORS));
          top = g + rb + floors*3.4;
          facadeBox("f_vic", bxC, base, bzC, w, top-base, D, ry, col, 8.8, 10.2, (g+rb)-base, rnd()); (World.roofs = World.roofs || []).push({ x:bxC, z:bzC, ry, w, d:D, top, fx, fz, n:ed.n });
          // base band
          const bb = place(0,0,0.06); facadeBox("plain", bb[0]-ed.n[0]*D/2, base, bb[2]-ed.n[1]*D/2, w+0.02, (g+rb)-base, D, ry, trim.clone().multiplyScalar(0.85), 1,1,0);
          if (garage){ const gp = place(-w*0.22, 0, 0.1); box("plain", gp[0], g+1.1, gp[2], 2.5, 2.2, 0.1, lin(rnd()<0.5?"#efeae0":"#8a7c68"), ry); }
          // stoop
          const nSteps = Math.round(rb/0.2), sx = w*0.28;
          for (let k=0;k<nSteps;k++){ const out = (nSteps-k)*0.12; const sp = place(sx, 0, out/2); const hh = g + rb*(k+1)/nSteps; box("plain", sp[0], (g-0.2+hh)/2, sp[2], 1.5, hh-(g-0.2), out, lin("#c9c4b8"), ry); }
          { const mid = place(sx, 0, nSteps*0.12*0.5 + 0.25); (World.stoops = World.stoops || []).push({ x:mid[0], z:mid[2], y: g + rb*0.45, ry, n:ed.n }); }
          const dp = place(sx, 0, 0.06); box("plain", dp[0], g+rb+1.15, dp[2], 1.1, 2.3, 0.12, lin(RP(["#3a2418","#26231f","#7a2e36","#1e3a5f"])), ry);
          box("plain", dp[0], g+rb+2.45, dp[2]+0, 1.5, 0.3, 0.3, trimW, ry);
          // bay window
          const bw = w*0.42, bayP = place(-w*0.18, 0, 0.5);
          facadeBox("f_vic", bayP[0], g+rb+0.15, bayP[2], bw, floors*3.4-0.35, 1.0, ry, col, 8.8, 10.2, -0.15, 0.37);
          const capP = place(-w*0.18,0,0.55); box("plain", capP[0], g+rb+floors*3.4-0.1, capP[2], bw+0.3, 0.3, 1.2, trimW, ry);
          box("plain", capP[0], g+rb+0.08, capP[2], bw+0.2, 0.2, 1.15, trimW, ry);
          // cornice + gable
          const cp = place(0,0,0.35); box("plain", cp[0], top+0.25, cp[2], w+0.5, 0.5, 0.9, trimW, ry);
          box("plain", cp[0], top-0.15, cp[2], w+0.2, 0.3, 0.6, trim, ry);
          if (rnd()<0.55){ // triangular gable facade
            const gp = place(0,0,-0.2); const gh = R(1.6,2.6);
            const m = M(gp[0], top+0.5, gp[2], ry); const tri = new THREE.BufferGeometry();
            const hw = w/2+0.1;
            tri.setAttribute("position", new THREE.Float32BufferAttribute([-hw,0,0, hw,0,0, 0,gh,0,  hw,0,-3, -hw,0,-3, 0,gh,-3,  -hw,0,0, 0,gh,0, 0,gh,-3, -hw,0,0, 0,gh,-3, -hw,0,-3,  hw,0,0, hw,0,-3, 0,gh,-3, hw,0,0, 0,gh,-3, 0,gh,0],3));
            tri.computeVertexNormals(); pushGeom("plain", tri, m, col.clone().lerp(trimW,0.25));
            top += gh;
          }
        } else if (zone === "filler"){
          const style = rnd()<0.18 ? "derelict" : RP(["office","concrete","brick","vic","edwardian","stucco","deco","glass","castiron"]);
          const hh = style==="vic" ? R(9,13) : R(12,42);
          top = g + hh;
          (World.roofs = World.roofs || []).push({ x:bxC, z:bzC, ry, w, d:D, top, fx, fz, n:ed.n });
          facadeBox("f_"+style, bxC, base, bzC, w, top-base, D, ry, lin(style==="vic"?RP(VIC_COLORS):(style==="stucco"||style==="edwardian")?RP(PASTEL_TINTS):RP(DOWN_TINTS)), TILE[style][0], TILE[style][1], g-base+1, rnd());
          box("plain", bxC, top+0.15, bzC, w+0.2, 0.3, D+0.2, lin("#5d5a55"), ry);
        } else {
          const derelict = rnd() < (zone==="mixed" ? 0.07 : 0.035);
          const style = derelict ? "derelict" : zone==="mixed" ? RP(["brick","edwardian","edwardian","stucco","vic","castiron","brick","concrete"]) : RP(["office","glass","deco","deco","concrete","brick","castiron","glass"]);
          const tw = TILE[style];
          const floors = derelict ? ((R(1,4))|0) : zone==="mixed" ? ((R(1,6))|0) : (rnd()<0.28 ? ((R(12,28))|0) : ((R(2,11))|0));
          const sfH = 4.5; top = g + sfH + floors*tw[1]/3;
          const tint = style==="vic" ? lin(RP(VIC_COLORS)) : (style==="stucco"||style==="edwardian") ? lin(RP(PASTEL_TINTS)) : lin(RP(DOWN_TINTS));
          (World.roofs = World.roofs || []).push({ x:bxC, z:bzC, ry, w, d:D, top, fx, fz, n:ed.n });
          facadeBox("f_"+style, bxC, base, bzC, w, top-base, D, ry, tint, tw[0], tw[1], (g+sfH)-base, rnd());
          // storefront
          const frame = lin(RP(["#2b2926","#3a2a1c","#1e3a5f","#e9e4d8","#6b6258","#7a2e36"]));
          const sp = place(0,0,0.05); facadeBox("plain", sp[0]-ed.n[0]*D/2, base, sp[2]-ed.n[1]*D/2, w+0.02, (g+sfH)-base, D, ry, frame, 1,1,0);
          const civic = !derelict && rnd() < 0.2 ? pickCivic(rnd) : null;
          if (civic || derelict){ buildCivicFront(civic, derelict, { place, g, w, ry, frame, rnd, R, RP, ed, D, top }); }
          else {
          const theme = pickTheme(rnd, fx, fz), gp = place(0,0,0.12); box("glass", gp[0], g+2.0, gp[2], w-0.8, 3.4, 0.1, new THREE.Color((theme+0.5)/16, 1, 1), ry); (World.shops = World.shops || []).push({ x:gp[0], z:gp[2], ry, w:w-0.8, gy:g, theme, n:ed.n }); { const sp_ = place(0,0,1.9), gy = groundY(sp_[0], sp_[2]) + 0.012; pushGeom("spill", PRIM.box, M(sp_[0], gy, sp_[2], ry, w-0.6, 0.004, 3.6), lin("#ffffff")); }
          box("plain", gp[0], g+3.55, gp[2]+0, w-0.8, 0.22, 0.16, frame.clone().multiplyScalar(0.7), ry);
          if (rnd()<0.62){ // awning
            const aw = Math.min(w-0.8, R(4,8)); const ap = place(R(-1,1), 0, 0.75);
            box("plain", ap[0], g+3.85, ap[2], aw, 0.08, 1.6, lin(RP(AWN)), ry, -0.38);
            box("plain", place(0,0,1.5)[0]+(ap[0]-place(0,0,0)[0]), g+3.45, place(0,0,1.5)[2]+(ap[2]-place(0,0,0)[2]), aw, 0.35, 0.04, lin(RP(AWN)), ry);
          }
          { const uv = signUV(theme, (rnd()*2)|0), sgp = place(R(-w*0.2,w*0.2),0,0.2); quad("signs", sgp[0], g+4.25, sgp[2], 3.6, 0.9, ry, white, uv[0], uv[1], uv[2], uv[3]);
            if (rnd() < 0.6){ const bp = place(w/2 - 0.7, 0, 0.75), iu = iconUV(theme); quad("signs", bp[0], g+4.6, bp[2], 0.8, 0.8, ry + Math.PI/2, white, iu[0], iu[1], iu[2], iu[3]); quad("signs", bp[0], g+4.6, bp[2], 0.8, 0.8, ry - Math.PI/2, white, iu[0], iu[1], iu[2], iu[3]); const bk = place(w/2 - 0.7, 0, 0.35); box("metal", bk[0], g+5.05, bk[2], 0.05, 0.05, 0.9, lin("#26231f"), ry); } }
          } // end shop
          // cornice
          const cp = place(0,0,0.25); box("plain", cp[0], top+0.2, cp[2], w+0.3, 0.4, 0.7, lin(style==="brick"?"#d9cfbd":"#9a968e"), ry);
          box("plain", bxC, top+0.1, bzC, w, 0.2, D, lin("#5d5a55"), ry);
          if (!derelict && floors < 10 && rnd() < 0.55) buildRoofVariant({ place, top, w, D, ry, rnd, R, RP });
          if (!derelict && zone!=="mixed" && floors>=10 && rnd()<0.75){ // towers step back as they rise
            let sw = w*R(0.6,0.8), sd = D*R(0.6,0.8), st = top; const tiers = rnd()<0.5 ? 2 : 1, cp_ = place(0,0,-D/2);
            for (let k=0;k<tiers;k++){ const th = R(5,13); facadeBox("f_"+style, cp_[0], st, cp_[2], sw, th, sd, ry, tint, tw[0], tw[1], 0, rnd()); box("plain", cp_[0], st+th+0.12, cp_[2], sw+0.3, 0.25, sd+0.3, lin("#9a968e"), ry); st += th; sw *= R(0.55,0.75); sd *= R(0.55,0.75); }
            if (style==="deco" && rnd()<0.6) pushGeom("plain", PRIM.cone, M(cp_[0], st+0.2, cp_[2], ry, sw*0.6, R(4,9), sd*0.6), lin("#cfc3aa"));
            if (style==="glass" && rnd()<0.5) pushGeom("metal", PRIM.cyl, M(cp_[0], st, cp_[2], 0, 0.3, R(6,14), 0.3), lin("#c9ccd0"));
            top = st;
          }
          if (!derelict && (style==="edwardian" || (style==="stucco" && rnd()<0.5))){ // bay-window columns
            const nb = w > 11 ? 2 : 1;
            for (let k=0;k<nb;k++){ const bx_ = nb===1 ? 0 : (k===0 ? -w*0.25 : w*0.25), bw_ = Math.min(3.4, w*0.34), bp_ = place(bx_,0,0.3);
              facadeBox("f_"+style, bp_[0], g+sfH+0.3, bp_[2], bw_, top-(g+sfH)-0.6, 0.6, ry, tint, tw[0], tw[1], -0.3, 0.1); box("plain", bp_[0], top-0.2, bp_[2], bw_+0.3, 0.3, 1.2, lin("#efe9dd"), ry); }
          }
          if (!derelict && zone==="mixed" && a===ed.m0 && rnd()<0.55){ // corner turret
            const tp_ = place(-w/2+1.3,0,-0.75), tr_ = 1.5;
            pushGeom("plain", PRIM.cyl, M(tp_[0], g+sfH, tp_[2], 0, tr_*2, top-(g+sfH)+0.4, tr_*2), tint);
            pushGeom("plain", PRIM.cone, M(tp_[0], top+0.4, tp_[2], 0, tr_*2.3, R(2.5,4), tr_*2.3), lin(RP(["#4a3a2c","#3b4a52","#6b3a32"])));
          }
          if (derelict){ const cp2 = place(R(-w/3,w/3),0,-D*0.3); box("plain", cp2[0], top+0.2, cp2[2], R(2,4), 0.5, R(2,4), lin("#4a4038"), ry, R(-.3,.3)); } // collapsed roof debris
          if (floors>6 && rnd()<0.5){ const tp = place(R(-w/4,w/4),0,-D*0.6); box("plain", tp[0], top+1.3, tp[2], 3, 2.4, 3, lin("#8a8680"), ry); }
          if (rnd()<0.3 && zone!=="down"){ const tp = place(R(-w/4,w/4),0,-D*0.5); pushGeom("plain", PRIM.cyl, M(tp[0], top+0.2, tp[2], 0, 2.2, 2.4, 2.2), lin("#6d5a48")); pushGeom("plain", PRIM.cone, M(tp[0], top+2.6, tp[2], 0, 2.4, 0.8, 2.4), lin("#4a3a2c")); }
        }
        lotMax = Math.max(lotMax, top - H(cx,cz));
        a += w;
      }
    }
    World.lots[World.lots.length-1].hMax = lotMax + 2;
    progress && progress(0.1 + 0.5*((i+NOUT)*(2*NOUT+1)+(j+NOUT))/((2*NOUT+1)**2));
  }

  // ---------- streets: paint, crosswalks, rails, furniture ----------
  const yellow = lin("#e2b43b"), whitePaint = lin("#e9e8e2");
  const streetsX = [], streetsZ = [];
  for (let i=-NOUT;i<NOUT;i++){ streetsX.push((i+0.5)*P); streetsZ.push((i+0.5)*P); }
  const nearIntersection = (a, list) => list.some(s => Math.abs(a - s) < RH + SWK + 1.5);
  // center lines along E-W streets (z const)
  for (const z of streetsZ){
    for (let i=-NOUT;i<=NOUT;i++){ const x0=i*P-HALF-SWK, x1=i*P+HALF+SWK; strip("paint", x0,z-0.16,x1,z-0.16,0.12,0.02,yellow); strip("paint", x0,z+0.16,x1,z+0.16,0.12,0.02,yellow); }
  }
  for (const x of streetsX){
    for (let j=-NOUT;j<=NOUT;j++){
      const z0=j*P-HALF-SWK, z1=j*P+HALF+SWK;
      if (Math.abs(x-CABLE_X)<1){ // cable car tracks
        for (const off of [-1.3,-0.2,0.2,1.3]) strip("metal", x+off,z0,x+off,z1,0.09,0.03,lin("#8d8f91"),4);
        strip("paint", x,z0,x,z1,0.05,0.025,lin("#1a1a1a"),4);
      } else { strip("paint", x-0.16,z0,x-0.16,z1,0.12,0.02,yellow); strip("paint", x+0.16,z0,x+0.16,z1,0.12,0.02,yellow); }
    }
  }
  // crosswalks
  for (const x of streetsX) for (const z of streetsZ){
    if (Math.abs(x) > 240 || Math.abs(z) > 240) continue;
    for (const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1]]){
      const cxw = x + dx*(RH+SWK+1.6), czw = z + dz*(RH+SWK+1.6);
      for (let k=-4;k<=4;k++){
        if (dx!==0){ const zz = z + k*1.1; strip("paint", cxw-1.5,zz,cxw+1.5,zz,0.55,0.02,whitePaint,3); }
        else { const xx = x + k*1.1; strip("paint", xx,czw-1.5,xx,czw+1.5,0.55,0.02,whitePaint,3); }
      }
    }
  }
  progress && progress(0.65);

  // furniture per playable block
  const poolB = GB("pool");
  const lampAt = (x,z,ry) => {
    const y = H(x,z)+0.16; const c = lin("#3d4540");
    pushGeom("metal", PRIM.cyl6, M(x,y,z,0,0.16,6.4,0.16), c);
    const ax = x + Math.sin(ry)*0.9, az = z + Math.cos(ry)*0.9;
    box("metal", (x+ax)/2, y+6.35, (z+az)/2, 0.08, 0.08, 1.8, c, ry);
    box("lamp", ax, y+6.2, az, 0.35, 0.18, 0.7, white, ry); World.lamps.push({ x:ax, y:y+6.0, z:az });
    // light pool on ground (quad following height roughly)
    const px = x + Math.sin(ry)*1.6, pz = z + Math.cos(ry)*1.6, r = 6;
    const pts = [[-r,-r,0,0],[r,-r,1,0],[r,r,1,1],[-r,-r,0,0],[r,r,1,1],[-r,r,0,1]];
    for (const p of pts){ const X=px+p[0], Z=pz+p[1]; poolB.p.push(X, H(X,Z)+0.2, Z); poolB.n.push(0,1,0); poolB.u.push(p[2],p[3]); poolB.c.push(1,1,1); }
  };
  const tree = (x,z) => { const y=H(x,z)+0.16, s=R(0.8,1.25), sp = RP(["plane","plane","plane","blossom","fruit","fruit","palm","cypress","eucalyptus","jacaranda","plane"]);
    const bark = lin(sp==="eucalyptus" ? "#cfc6b4" : sp==="palm" ? "#7a6a52" : RP(["#4a3a2e","#5a4636","#3f332a"]));
    const blob = (bx, by, bz, sz, col, sy=0.88) => pushGeom("foliage", PRIM.leaf, M(bx, by, bz, R(0,6), sz, sz*sy, sz), col);
    if (sp === "palm"){ const h = R(7, 11)*s; for (let k=0;k<6;k++) pushGeom("plain", PRIM.cyl, M(x + k*0.02, y + k*h/6, z, 0, 0.26 - k*0.015, h/6 + 0.05, 0.26 - k*0.015), bark);
      for (let k=0;k<12;k++){ const a = k/12*6.283 + R(-0.2,0.2), m = new THREE.Matrix4().compose(new THREE.Vector3(x + Math.sin(a)*1.3, y + h - 0.2, z + Math.cos(a)*1.3), new THREE.Quaternion().setFromEuler(new THREE.Euler(0.6 + R(0,0.4), a, 0, "YXZ")), new THREE.Vector3(0.35, 0.05, 2.8)); pushGeom("foliage", PRIM.box, m, lin(RP(["#4f6a2e","#5a7a34","#3f5a28"]))); }
      blob(x, y + h + 0.1, z, 0.9, lin("#6b5a2e")); }
    else if (sp === "cypress"){ pushGeom("plain", PRIM.cyl, M(x,y,z,0,0.18,1.2,0.18), bark); for (let k=0;k<5;k++) blob(x + R(-0.15,0.15), y + 1.4 + k*1.2*s, z + R(-0.15,0.15), (1.5 - k*0.22)*s, lin(RP(["#2c4a2c","#304f2e","#27432a"])), 1.25); }
    else {
      const th = sp === "eucalyptus" ? R(4.5, 6)*s : 3.0*s; pushGeom("plain", PRIM.cyl, M(x,y,z,0,0.24*s,th,0.24*s), bark);
      for (let b=0;b<3;b++){ const a = R(0,6.28); const m = new THREE.Matrix4().compose(new THREE.Vector3(x+Math.sin(a)*0.35*s, y+th*0.87, z+Math.cos(a)*0.35*s), new THREE.Quaternion().setFromEuler(new THREE.Euler(Math.cos(a)*0.6, 0, -Math.sin(a)*0.6)), new THREE.Vector3(0.1*s, 1.4*s, 0.1*s)); pushGeom("plain", PRIM.cyl, m, bark); }
      const pal = { plane:["#3f5a32","#4a6436","#36502e","#55693c","#425c34"], blossom:[RP(["#f2c4d4","#f7d8e2","#f4f1ea"]), "#e8b0c4", "#f6e0e8"], fruit:["#3f6a2e","#4a7a32","#355f2a"], eucalyptus:["#8a9a82","#7c8e78","#95a38c"], jacaranda:["#8a6fc4","#9a7ed0","#7a62b0"] }[sp];
      const base = lin(RP(pal)), nb = 6 + ((rnd()*4)|0);
      for (let b=0;b<nb;b++){ const a = R(0,6.28), rr = R(0.3,1.5)*s, hh = th + R(0.3, 2.2)*s, sz = R(1.4,2.3)*s*(sp==="eucalyptus"?0.8:1); const c = base.clone().multiplyScalar(R(0.8,1.15)); blob(x+Math.sin(a)*rr, y+hh, z+Math.cos(a)*rr, sz, c); }
      if (sp === "fruit"){ const fc = lin(RP(["#f29a1c","#f2d02b","#c0362c","#e36f2d"])); for (let k=0;k<22;k++){ const a = R(0,6.28), rr = R(0.6,2.2)*s; pushGeom("plain", PRIM.sph0, M(x+Math.sin(a)*rr, y+th+R(0.2,2.6)*s, z+Math.cos(a)*rr, 0, 0.14, 0.14, 0.14), fc); }
        for (let k=0;k<4;k++) pushGeom("plain", PRIM.sph0, M(x+R(-1,1), y+0.05, z+R(-1,1), 0, 0.13, 0.1, 0.13), fc); }
      if (sp === "blossom" || sp === "jacaranda") for (let k=0;k<14;k++) box("plain", x+R(-1.8,1.8), y+0.02, z+R(-1.8,1.8), 0.08, 0.01, 0.06, base.clone().multiplyScalar(R(0.9,1.1)), R(0,3));
    }
    box("plain", x, y+0.02, z, 1.2,0.05,1.2, lin("#4b3b2e")); };
  const car = (key, x,z,ry,col) => {
    const y = H(x,z)+0.02; const fx=x+Math.sin(ry)*2, fz=z+Math.cos(ry)*2, bx_=x-Math.sin(ry)*2, bz_=z-Math.cos(ry)*2; const pitch = -Math.atan2(H(fx,fz)-H(bx_,bz_),4);
    const tp = pickCarType(rnd), T = CAR_TYPES[tp]; pushCar(x, y, z, ry, pitch, tp, col);
    (World.parkedCars = World.parkedCars || []).push({ x, z, ry, L:T.L, W:T.W, top: y + (T.box ? T.clr + 2.75 : T.open ? T.belt + 0.05 : T.belt - 0.01 + T.ch + 0.04), type:tp });
  };
  World.parked = []; World.benches = [];
  for (let i=-NB-1;i<=NB+1;i++) for (let j=-NB-1;j<=NB+1;j++){
    const cx=i*P, cz=j*P, zone=zoneOf(i,j), inner = Math.abs(i)<=NB && Math.abs(j)<=NB;
    const curb = HALF+SWK-0.45;
    const sides = [ {ax:cx-HALF, az:cz-curb, dx:1, dz:0, ry:Math.PI}, {ax:cx-HALF, az:cz+curb, dx:1,dz:0, ry:0}, {ax:cx-curb, az:cz-HALF, dx:0,dz:1, ry:-Math.PI/2}, {ax:cx+curb, az:cz-HALF, dx:0,dz:1, ry:Math.PI/2} ];
    if (inner) for (const sd of sides){
      for (let t=6; t<LOT; t+=24){ lampAt(sd.ax+sd.dx*t, sd.az+sd.dz*t, sd.ry); }
      if (zone!=="down") for (let t=12; t<LOT-4; t+=R(9,16)){ if (rnd()<0.55) tree(sd.ax+sd.dx*t - Math.sin(sd.ry)*0.3, sd.az+sd.dz*t - Math.cos(sd.ry)*0.3); }
      if (rnd()<0.5){ const t=R(10,60); const x=sd.ax+sd.dx*t, z=sd.az+sd.dz*t, y=H(x,z)+0.16; pushGeom("plain", PRIM.cyl, M(x,y,z,0,0.3,0.7,0.3), lin(rnd()<0.5?"#b8322a":"#e0c23a")); pushGeom("plain", PRIM.sph, M(x,y+0.72,z,0,0.3,0.25,0.3), lin("#b8322a")); }
      if (rnd()<0.6){ const t=R(10,60); const x=sd.ax+sd.dx*t - Math.sin(sd.ry)*0.1, z=sd.az+sd.dz*t- Math.cos(sd.ry)*0.1, y=H(x,z)+0.16; pushGeom("plain", PRIM.cyl, M(x,y,z,0,0.6,1.0,0.6), lin("#2f4a3a")); }
      if (zone!=="vic" && rnd()<0.5){ const t=R(10,60); for (let k=0;k<3;k++){ const x=sd.ax+sd.dx*(t+k*0.6) - Math.sin(sd.ry)*0.2, z=sd.az+sd.dz*(t+k*0.6)- Math.cos(sd.ry)*0.2, y=H(x,z)+0.16; box("plain", x, y+0.55, z, 0.5, 1.1, 0.45, lin(RP(["#1e3a5f","#c0362c","#e8a33d","#2f5a3a","#e9e4d8"])), sd.ry); } }
      if (rnd()<0.35){ const t=R(14,56); const x=sd.ax+sd.dx*t + Math.sin(sd.ry)*-1.6, z=sd.az+sd.dz*t + Math.cos(sd.ry)*-1.6, y=H(x,z)+0.16; (World.benches = World.benches||[]).push({ x, z, ry:sd.ry, y }); box("plain", x, y+0.45, z, 1.8, 0.08, 0.5, lin("#5b4636"), sd.ry); box("plain", x, y+0.2, z, 1.6, 0.4, 0.06, lin("#2b2b2b"), sd.ry); box("plain", x - Math.sin(sd.ry)*0.23, y+0.78, z - Math.cos(sd.ry)*0.23, 1.8, 0.45, 0.06, lin("#5b4636"), sd.ry); }
      // parked cars in parking lane (road side of curb)
      for (let t=4; t<LOT-3; t+=7.4){
        if (rnd()<0.5) continue;
        if (World.lots[World.lots.length-1] && sd.dz!==0 && alleyAt(cx, cz) && Math.abs(t - LOT/2) < 6) continue; // keep alley mouths clear
        const off = 2.2; const x = sd.ax+sd.dx*t + Math.sin(sd.ry)*off, z = sd.az+sd.dz*t + Math.cos(sd.ry)*off;
        if (Math.abs(x-CABLE_X)<3 ) continue;
        const heading = (sd.dx!==0 ? (sd.ry===0? Math.PI/2 : -Math.PI/2) : (sd.ry>0 ? Math.PI : 0));
        car("metal", x, z, heading, lin(RP(CAR_COLORS))); World.parked.push({x,z,ry:heading}); { const ex = Math.abs(Math.sin(heading))*2.2 + Math.abs(Math.cos(heading))*0.95, ez = Math.abs(Math.cos(heading))*2.2 + Math.abs(Math.sin(heading))*0.95; World.colliders.push({ x0:x-ex, x1:x+ex, z0:z-ez, z1:z+ez, car:true }); }
      }
    }
    // traffic signal at one corner per intersection
    if (inner && zone!=="vic"){
      const x = cx+HALF+SWK-0.6, z = cz+HALF+SWK-0.6, y=H(x,z)+0.16;
      pushGeom("metal", PRIM.cyl6, M(x,y,z,0,0.14,4.2,0.14), lin("#3a3f3a"));
      box("metal", x, y+3.6, z, 0.4,1.1,0.35, lin("#222"), 0);
      box("signal", x, y+3.95, z+0.19, 0.18,0.18,0.02, lin("#ff3b30"));
      box("signal", x, y+3.3, z+0.19, 0.18,0.18,0.02, lin("#1f3a24"));
    }
  }
  progress && progress(0.78);

  // ---------- landmarks & skyline (distant, unfogged, hazed manually) ----------
  const lmMat = (hex) => { const m = new THREE.MeshBasicMaterial({ color:lin(hex), fog:false }); m.userData.base = lin(hex); World.landmarkMats.push(m); return m; };
  const lm = new THREE.Group(); scene.add(lm);
  // the Lantern Spire, south-east: a stepped tower with a glowing crown (Snap City's skyline mark)
  const pyr = new THREE.Group(); pyr.position.set(420, 0, 760); lm.add(pyr); pyr.userData.landmark = "the Lantern Spire";
  [[26,120],[20,70],[14,50],[8,40]].reduce((y,[r,h])=>{ const m = new THREE.Mesh(new THREE.CylinderGeometry(r*0.85, r, h, 8).translate(0,h/2,0), lmMat("#e8e5dc")); m.position.y = y; pyr.add(m); return y + h; }, 0);
  { const crown = new THREE.Mesh(new THREE.OctahedronGeometry(9).translate(0,289,0), lmMat("#f2d59a")); pyr.add(crown); const tip = new THREE.Mesh(new THREE.CylinderGeometry(0.6,1.4,40,6).translate(0,318,0), lmMat("#cfd2d4")); pyr.add(tip); }
  // skyline boxes
  const sr = mulberry(77);
  for (let k=0;k<46;k++){
    const ang = -0.4 + sr()*1.6, dist = 760 + sr()*420;
    const x = Math.sin(ang)*dist + 120, z = Math.cos(ang)*dist + 180;
    const h = 60 + sr()*sr()*190, w = 20 + sr()*30;
    const b = new THREE.Mesh(new THREE.BoxGeometry(w,h,w*(0.7+sr()*0.6)).translate(0,h/2,0), lmMat(["#b9bcbd","#9fa5a8","#cfccc4","#8c9296"][k%4]));
    b.position.set(x,0,z); b.rotation.y = sr()*0.5; lm.add(b);
  }
  // suspension bridge far north-west
  const orange = lmMat("#6f7f86"); // steel-grey harbour bridge
  const bridge = new THREE.Group(); bridge.position.set(-420, 0, -1250); bridge.rotation.y = -0.18; lm.add(bridge);
  for (const tx of [-640, 640]){
    for (const sx of [-14, 14]) { const leg = new THREE.Mesh(new THREE.BoxGeometry(8, 227, 8).translate(0,113,0), orange); leg.position.set(tx, 0, sx); bridge.add(leg); }
    for (const hy of [80, 140, 190, 222]){ const beam = new THREE.Mesh(new THREE.BoxGeometry(6, 8, 36), orange); beam.position.set(tx, hy, 0); bridge.add(beam); }
  }
  const deck = new THREE.Mesh(new THREE.BoxGeometry(2600, 7, 30), orange); deck.position.y = 67; bridge.add(deck);
  const cablePts = []; for (let k=0;k<=60;k++){ const x = -1300 + k*2600/60; let y; if (Math.abs(x)<=640){ const u = x/640; y = 72 + 150*u*u; } else { const u = (Math.abs(x)-640)/660; y = 222 - 150*u; } cablePts.push([x,y]); }
  for (const sz of [-14,14]) for (let k=0;k<60;k++){ const [x0,y0] = cablePts[k], [x1,y1] = cablePts[k+1]; const L = Math.hypot(x1-x0,y1-y0); const seg = new THREE.Mesh(new THREE.BoxGeometry(L, 2.2, 2.2), orange); seg.position.set((x0+x1)/2,(y0+y1)/2,sz); seg.rotation.z = Math.atan2(y1-y0,x1-x0); bridge.add(seg); }
  bridge.userData.landmark = "the bridge";
  // hilltop tower on a hill east
  const hill = new THREE.Mesh(new THREE.SphereGeometry(160, 20, 12, 0, Math.PI*2, 0, Math.PI/2), lmMat("#5f6f52")); hill.scale.y = 0.45; hill.position.set(720, 0, -520); lm.add(hill);
  { const mast = new THREE.Group(); mast.position.set(720, 68, -520); lm.add(mast); // radio mast on the hill
    for (const [lx,lz] of [[-5,-5],[5,-5],[5,5],[-5,5]]){ const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.7,1.2,110,5).translate(0,55,0), lmMat("#c23a2e")); leg.position.set(lx*(1),0,lz); leg.rotation.set(lz*0.03,0,-lx*0.03); mast.add(leg); }
    for (let k=0;k<5;k++){ const band = new THREE.Mesh(new THREE.BoxGeometry(10-k*1.4,1.2,10-k*1.4).translate(0,15+k*20,0), lmMat(k%2?"#c23a2e":"#ebe6da")); mast.add(band); }
    const spike = new THREE.Mesh(new THREE.CylinderGeometry(0.3,0.6,40,5).translate(0,128,0), lmMat("#ebe6da")); mast.add(spike); }
  World.landmarks = [ {name:"the Lantern Spire", pos:new THREE.Vector3(420,220,760)}, {name:"the harbour bridge", pos:new THREE.Vector3(-420,200,-1250)}, {name:"the radio mast on the hill", pos:new THREE.Vector3(720,140,-520)} ];

  // ---------- sky ----------
  const skyGeo = new THREE.SphereGeometry(1800, 32, 16);
  World.skyMat = new THREE.ShaderMaterial({ side:THREE.BackSide, depthWrite:false, fog:false, uniforms:{ top:{value:new THREE.Color()}, bot:{value:new THREE.Color()}, sunDir:{value:new THREE.Vector3()}, sunCol:{value:new THREE.Color()}, sunAmt:{value:1} },
    vertexShader:`varying vec3 vW; void main(){ vW = normalize(position); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
    fragmentShader:`uniform vec3 top; uniform vec3 bot; uniform vec3 sunDir; uniform vec3 sunCol; uniform float sunAmt; varying vec3 vW;
      void main(){ float h = clamp(vW.y*1.6+0.08,0.0,1.0); vec3 c = mix(bot, top, pow(h,0.7)); float s = max(dot(normalize(vW), sunDir),0.0);
      c += sunCol*(pow(s,900.0)*14.0 + pow(s,12.0)*0.35)*sunAmt; gl_FragColor = vec4(c,1.0); }` });
  const sky = new THREE.Mesh(skyGeo, World.skyMat); sky.frustumCulled = false; scene.add(sky); World.sky = sky;

  // ---------- lights ----------
  World.hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 1); scene.add(World.hemi);
  const sun = new THREE.DirectionalLight(0xffffff, 2);
  sun.castShadow = true; sun.shadow.mapSize.set(2048,2048);
  const sc = sun.shadow.camera; sc.left=-95; sc.right=95; sc.top=95; sc.bottom=-95; sc.near=10; sc.far=600;
  sun.shadow.bias = -0.00025; sun.shadow.normalBias = 0.045;
  scene.add(sun); scene.add(sun.target); World.sun = sun;
  scene.fog = new THREE.FogExp2(0xffffff, 0.003);

  // ---------- build meshes ----------
  buildMesh("road", mats.road, {receive:true});
  buildMesh("roadOuter", mats.road, {receive:true});
  buildMesh("walk", mats.walk, {receive:true});
  for (const s of FACADE_STYLES) buildMesh("f_"+s, mats["f_"+s], {cast:true});
  buildMesh("civic", mats.civic);
  buildMesh("plain", mats.plain, {cast:true});
  buildMesh("metal", mats.metal, {cast:true});
  buildMesh("foliage", mats.foliage, {cast:true});
  buildMesh("glass", mats.glass);
  { const c = document.createElement("canvas"); c.width = 64; c.height = 64; const x = c.getContext("2d"); const g = x.createLinearGradient(0,0,0,64); g.addColorStop(0,"rgba(255,214,160,0)"); g.addColorStop(0.3,"rgba(255,214,160,.9)"); g.addColorStop(0.55,"rgba(255,214,160,.6)"); g.addColorStop(1,"rgba(255,214,160,0)"); x.fillStyle = g; x.fillRect(0,0,64,64); const gx = x.createLinearGradient(0,0,64,0); gx.addColorStop(0,"rgba(0,0,0,1)"); gx.addColorStop(0.15,"rgba(0,0,0,0)"); gx.addColorStop(0.85,"rgba(0,0,0,0)"); gx.addColorStop(1,"rgba(0,0,0,1)"); x.globalCompositeOperation = "destination-out"; x.fillStyle = gx; x.fillRect(0,0,64,64);
    mats.spill = new THREE.MeshBasicMaterial({ map:new THREE.CanvasTexture(c), transparent:true, opacity:0, depthWrite:false, blending:THREE.AdditiveBlending, polygonOffset:true, polygonOffsetFactor:-2 });
    const sm = buildMesh("spill", mats.spill, {receive:false}); if (sm) sm.renderOrder = 2; }
  buildMesh("lamp", mats.lamp);
  buildMesh("signal", mats.signal);
  buildMesh("signs", mats.signs);
  if (typeof scatterCity === "function") scatterCity({ box, quad, rnd, R, RP });
  buildMesh("paint", mats.paint);
  buildParkedCarMeshes();
  World.lampPools = buildMesh("pool", mats.pool, {receive:false});
  progress && progress(0.9);
}

/* ---------- time of day ---------- */
/* ---------- moving light: a continuous clock blended between the five lighting presets ---------- */
const TIME_ANCHORS = [7.5, 12.5, 18.6, 19.6, 21.8];
function clockOf(id){ return TIME_ANCHORS[Math.max(0, TIMES.findIndex(t=>t.id===id))]; }
function blendTime(h){
  h = ((h % 24) + 24) % 24;
  let a, b, f;
  if (h >= 21.8 || h < 5.8){ a = 4; b = 4; f = 0; }
  else if (h < 7.5){ a = 4; b = 0; f = (h - 5.8)/1.7; }
  else { a = 0; while (a < 4 && h >= TIME_ANCHORS[a+1]) a++; b = Math.min(4, a+1); f = b === a ? 0 : (h - TIME_ANCHORS[a])/(TIME_ANCHORS[b] - TIME_ANCHORS[a]); }
  const A = TIMES[a], B = TIMES[b], out = {};
  for (const k in A){ const va = A[k], vb = B[k];
    if (typeof va === "number") out[k] = va + (vb - va)*f;
    else if (typeof va === "string" && va[0] === "#") out[k] = mixHex(va, vb, f);
    else out[k] = f < 0.5 ? va : vb; }
  if (a === 4 && b === 0){ out.elev = -8 + 18*f; out.azim = 80 + 15*f; }
  out.norm = (TIME_NORM[A.id]||1) + ((TIME_NORM[B.id]||1) - (TIME_NORM[A.id]||1))*f;
  return out;
}
function applyTime(light){
  if (S.clock === undefined) S.clock = clockOf(S.time);
  const T = blendTime(S.clock); S.time = T.id; World.timeNorm = T.norm;
  if (World.blackout){ T.lamps *= 0.03; T.win *= 0.03; }
  const el = T.elev*Math.PI/180, az = T.azim*Math.PI/180;
  const dir = new THREE.Vector3(Math.sin(az)*Math.cos(el), Math.sin(el), -Math.cos(az)*Math.cos(el)).normalize(); World.sunDir = dir.clone();
  World.sunDir = dir;
  World.sun.color.copy(lin(T.sun)); World.sun.intensity = T.sunI * (S.fog? 0.45 : 1);
  World.sun.castShadow = T.shadow > 0;
  World.hemi.color.copy(lin(T.sky)); World.hemi.groundColor.copy(lin(T.gnd)); World.hemi.intensity = T.hemiI * (S.fog? 1.15 : 1);
  const fogCol = lin(S.fog && T.id!=="morning" ? mixHex(T.fog, "#c3c8cb", T.id==="night"?0.25:0.6) : T.fog);
  World.scene.fog.color.copy(fogCol); World.scene.fog.density = S.fog ? Math.max(T.fogD*3.2, 0.012) : T.fogD;
  World.skyMat.uniforms.top.value.copy(lin(T.top)).lerp(fogCol, S.fog?0.6:0);
  World.skyMat.uniforms.bot.value.copy(lin(T.bot)).lerp(fogCol, S.fog?0.8:0);
  World.skyMat.uniforms.sunDir.value.copy(dir); World.skyMat.uniforms.sunCol.value.copy(lin(T.sun)); World.skyMat.uniforms.sunAmt.value = T.elev>-3 ? (S.fog?0.25:1) : 0;
  const m = World.mats;
  for (const s of FACADE_STYLES) if (m["f_"+s]) m["f_"+s].emissiveIntensity = (s==="derelict"?0.3:1)*T.win*1.6;
  m.glass.emissiveIntensity = 0.09 + T.win*0.62;
  if (m.spill) m.spill.opacity = Math.max(0, T.win - 0.3)*0.42*(S.rain ? 1.4 : 1);
  m.lamp.emissiveIntensity = T.lamps*9;
  m.signs.emissiveIntensity = 0.03 + T.lamps*0.55;
  // landmark haze
  const haze = S.fog ? 0.85 : ({morning:0.6, noon:0.28, golden:0.35, blue:0.45, night:0.55})[T.id];
  const dark = ({morning:0.9, noon:1, golden:0.95, blue:0.45, night:0.18})[T.id];
  const hz = lin(T.bot);
  for (const mm of World.landmarkMats){ mm.color.copy(mm.userData.base).multiplyScalar(dark).lerp(hz, haze); if (T.id==="golden") mm.color.lerp(lin("#ffcf9a"), 0.12); }
  World.water.material.color.copy(lin("#4c6572")).multiplyScalar(dark);
  World.timeDef = T;
  applyWeather(T);
  if (!light || !Env.rt) updateEnv();
  wetSurfaces();
}
function mixHex(a,b,t){ const ca = new THREE.Color(a), cb = new THREE.Color(b); return "#"+ca.lerp(cb,t).getHexString(); }

/* ---------- queries ---------- */
function collidePoint(x,z,r=0.35){
  const elev = (typeof PLAYX !== "undefined" && PLAYX.footY !== null) ? PLAYX.footY - groundY(x, z) : 0;
  for (const c of World.colliders){ if (c.car && elev > 1.1) continue; if (x > c.x0-r && x < c.x1+r && z > c.z0-r && z < c.z1+r){
      const dl = x-(c.x0-r), dr = (c.x1+r)-x, dt = z-(c.z0-r), db = (c.z1+r)-z; const mn = Math.min(dl,dr,dt,db);
      if (mn===dl) x = c.x0-r; else if (mn===dr) x = c.x1+r; else if (mn===dt) z = c.z0-r; else z = c.z1+r; } }
  const lim = (NB+0.5)*P + 20; x = clamp(x,-lim,lim); z = clamp(z,-lim,lim);
  return [x,z];
}
function groundY(x,z){ // sidewalk raised
  for (const l of World.lots){ if (x > l.x0-SWK && x < l.x1+SWK && z > l.z0-SWK && z < l.z1+SWK) return H(x,z)+0.16; }
  return H(x,z);
}
function locationName(x,z){
  const ni = Math.round(x/P - 0.5), nj = Math.round(z/P - 0.5);
  const sx = (ni+0.5)*P, sz = (nj+0.5)*P, dx = Math.abs(x-sx), dz = Math.abs(z-sz);
  const ns = NS_STREETS[ni] || "Divisadero", ew = EW_STREETS[nj] || "Pacific";
  const bi = Math.round(x/P), bj = clamp(Math.round(z/P),-2,2);
  let street;
  if (dx < 14 && dz < 14) street = `${ns} St & ${ew} St`;
  else if (dz < dx) { const a = NS_STREETS[Math.floor(x/P-0.5)] , b = NS_STREETS[Math.floor(x/P-0.5)+1]; street = `${ew} St${a&&b? `, between ${a} and ${b}`:""}`; }
  else { const a = EW_STREETS[Math.floor(z/P-0.5)], b = EW_STREETS[Math.floor(z/P-0.5)+1]; street = `${ns} St${a&&b? `, between ${a} and ${b}`:""}`; }
  return { street, hood: HOODS[bj] || "Snap City" };
}
// ray vs world (analytic): returns distance to first hit among lots (as boxes), ground
function rayWorld(o, d, maxD=400){
  let best = maxD;
  for (const l of World.lots){
    const top = H(l.cx,l.cz) + l.hMax;
    const t = rayAABB(o,d, l.x0, -50, l.z0, l.x1, top, l.z1);
    if (t !== null && t < best) best = t;
  }
  // ground march
  if (d.y < 0){ let prev = 0; for (let t=0.5; t<best; t*= 1.12){ const y = o.y + d.y*t, gy = groundY(o.x+d.x*t, o.z+d.z*t); if (y <= gy){ let a=prev, b=t; for (let k=0;k<10;k++){ const mdd=(a+b)/2; const yy=o.y+d.y*mdd; if (yy<=groundY(o.x+d.x*mdd,o.z+d.z*mdd)) b=mdd; else a=mdd; } best = Math.min(best,b); break; } prev = t; } }
  return best;
}
function rayAABB(o,d, x0,y0,z0,x1,y1,z1){
  let tmin = -Infinity, tmax = Infinity;
  for (const [oo,dd,a,b] of [[o.x,d.x,x0,x1],[o.y,d.y,y0,y1],[o.z,d.z,z0,z1]]){
    if (Math.abs(dd) < 1e-9){ if (oo < a || oo > b) return null; }
    else { let t1=(a-oo)/dd, t2=(b-oo)/dd; if (t1>t2) [t1,t2]=[t2,t1]; tmin=Math.max(tmin,t1); tmax=Math.min(tmax,t2); if (tmin>tmax) return null; }
  }
  if (tmax < 0) return null; return tmin > 0 ? tmin : null;
}

/* =========================================================
   Snap City: civic buildings, derelict fronts, alleys and shop variety
   ========================================================= */
const CIVIC = [
  { id:"library",  sign:0,  w:1 }, { id:"fire",     sign:1,  w:1 }, { id:"police",   sign:2,  w:0.7 },
  { id:"post",     sign:3,  w:0.7 }, { id:"church",  sign:4,  w:0.8 }, { id:"school",   sign:5,  w:0.7 },
  { id:"clinic",   sign:6,  w:0.7 }, { id:"community", sign:7, w:0.8 }, { id:"theatre", sign:8,  w:0.9 },
  { id:"gym",      sign:9,  w:0.6 }, { id:"gallery",  sign:10, w:0.8 }, { id:"museum",  sign:11, w:0.5 }
];
const CIVIC_TEXT = ["PUBLIC LIBRARY","FIRE STATION 9","POLICE","POST OFFICE","ST. BRIGID'S","HOLLIS SCHOOL","CITY CLINIC","COMMUNITY HALL","THE ODEON","IRON GYM","GALLERY 41","CITY MUSEUM","FOR LEASE","CLOSED","",""];
function makeCivicSigns(){
  const c = document.createElement("canvas"); c.width = 1024; c.height = 1024; const x = c.getContext("2d");
  const bgs = ["#2d3b2f","#8e1f1a","#1b2f5c","#1d3f73","#f1ece0","#3a2a5a","#f4f4f0","#5a3a1c","#141414","#1a1a1a","#f7f7f4","#e8e1d0","#f2c230","#6b1d1d","#222","#222"];
  const fgs = ["#f0e2b6","#fff4e0","#f5f5f5","#ffffff","#3a2a1c","#f2d27a","#c0362c","#f5e6c8","#ffcf5a","#e8e8e8","#111111","#3a2a1c","#111111","#f5f5f5","#fff","#fff"];
  for (let k=0;k<16;k++){
    const col = k%2, row = (k/2)|0, X = col*512, Y = row*128;
    x.fillStyle = bgs[k]; x.fillRect(X+4, Y+4, 504, 120);
    x.strokeStyle = fgs[k]; x.globalAlpha = .6; x.lineWidth = 4; x.strokeRect(X+12, Y+12, 488, 104); x.globalAlpha = 1;
    x.fillStyle = fgs[k]; x.textAlign = "center"; x.textBaseline = "middle";
    const t = CIVIC_TEXT[k]; let fs = 64; x.font = `bold ${fs}px Georgia, serif`; while (x.measureText(t).width > 460 && fs > 20){ fs -= 2; x.font = `bold ${fs}px Georgia, serif`; }
    x.fillText(t, X+256, Y+66);
    if (k===6){ x.fillStyle="#c0362c"; x.fillRect(X+30,Y+52,40,12); x.fillRect(X+44,Y+38,12,40); }
  }
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.anisotropy = 4; return t;
}
function civicUV(k){ const col = k%2, row = (k/2)|0; return [col*0.5 + 0.002, 1 - (row+1)/8 + 0.003, (col+1)*0.5 - 0.002, 1 - row/8 - 0.003]; }
function pickCivic(rnd){
  World.civicCount = World.civicCount || {};
  const pool = CIVIC.filter(c => (World.civicCount[c.id]||0) < (c.id==="library"||c.id==="fire"||c.id==="police"||c.id==="school"||c.id==="post" ? 6 : 9));
  if (!pool.length) return null;
  let tot = 0; for (const c of pool) tot += c.w; let r = rnd()*tot;
  for (const c of pool){ r -= c.w; if (r <= 0){ World.civicCount[c.id] = (World.civicCount[c.id]||0) + 1; return c; } }
  return pool[0];
}
// Choose a shop theme that isn't already on this stretch of street, favouring the least-used ones.
function pickTheme(rnd, x, z){
  World._themeLog = World._themeLog || []; World._themeUse = World._themeUse || new Array(SHOPS.length).fill(0);
  const near = new Set(World._themeLog.filter(t => Math.hypot(t.x-x, t.z-z) < 110).map(t => t.theme));
  let best = -1, bestScore = 1e9;
  for (let k=0;k<SHOPS.length;k++){
    if (near.has(k)) continue;
    const score = World._themeUse[k] + rnd()*1.5;
    if (score < bestScore){ bestScore = score; best = k; }
  }
  if (best < 0) best = (rnd()*SHOPS.length)|0;
  World._themeUse[best]++; World._themeLog.push({ x, z, theme:best });
  return best;
}
function buildCivicFront(civic, derelict, o){
  const { place, g, w, ry, rnd, R } = o, white = lin("#ffffff");
  const door = (lx, dw, dh, col) => { const p_ = place(lx,0,0.1); box("plain", p_[0], g+dh/2, p_[2], dw, dh, 0.12, lin(col), ry); };
  const win = (lx, ww, wh, y) => { const p_ = place(lx,0,0.1); box("plain", p_[0], g+y, p_[2], ww, wh, 0.08, lin("#1c262e"), ry); };
  const sign = (k, y, sw) => { const uv = civicUV(k), sp = place(0,0,0.2); quad("civic", sp[0], g+y, sp[2], sw||Math.min(w-1, 4.6), (sw||Math.min(w-1,4.6))/4, ry, white, uv[0], uv[1], uv[2], uv[3]); };
  if (derelict){
    for (let k=-1;k<=1;k++){ const p_ = place(k*w*0.3,0,0.12); box("plain", p_[0], g+1.6, p_[2], w*0.26, 2.8, 0.06, lin(RP_(rnd,["#b89868","#a88a5c","#c2a577"])), ry, 0, R(-0.04,0.04)); }
    door(0, 1.1, 2.2, "#3a2e26"); if (rnd()<0.7) sign(rnd()<0.5?12:13, 3.9, 3.2);
    return;
  }
  (World.civic = World.civic || []).push({ id:civic.id, x:place(0,0,0)[0], z:place(0,0,0)[2], ry, gy:g });
  switch (civic.id){
    case "library": case "museum": {
      for (let k=0;k<2;k++){ const p_ = place(0,0,0.25+k*0.3); box("plain", p_[0], g-0.1+(1-k)*0.12, p_[2], Math.min(w-1,8)-k*0.4, 0.2, 0.3, lin("#d9d2c2"), ry); }
      for (let k=-2;k<=2;k++){ const p_ = place(k*Math.min(w-2,7)/4,0,0.35); pushGeom("plain", PRIM.cyl, M(p_[0], g, p_[2], 0, 0.55, 4.2, 0.55), lin("#efe9dc")); }
      const p_ = place(0,0,0.35); box("plain", p_[0], g+4.35, p_[2], Math.min(w-1,8.4), 0.35, 0.8, lin("#e6dfcf"), ry);
      door(0, 1.8, 2.8, "#4a3424"); win(-2.4, 1.2, 2.2, 1.6); win(2.4, 1.2, 2.2, 1.6); sign(civic.sign, 3.9); break; }
    case "fire": {
      for (const lx of [-w*0.22, w*0.22]){ const p_ = place(lx,0,0.1); box("plain", p_[0], g+1.9, p_[2], Math.min(3.6,w*0.38), 3.8, 0.14, lin("#9b1c17"), ry); for (let r=0;r<3;r++){ const q = place(lx,0,0.18); box("plain", q[0], g+2.9-r*0.01, q[2], Math.min(3.2,w*0.34), 0.4, 0.04, lin("#27333b"), ry); } }
      const lp = place(0,0,0.4); box("plain", lp[0], g+4.1, lp[2], 0.3, 0.3, 0.3, lin("#ff3b2f"), ry); sign(civic.sign, 4.4); break; }
    case "police": door(0, 1.6, 2.4, "#1b2f5c"); win(-2.2, 1.6, 1.6, 1.8); win(2.2, 1.6, 1.6, 1.8); for (const lx of [-1.2, 1.2]){ const p_ = place(lx,0,0.35); box("plain", p_[0], g+2.8, p_[2], 0.28, 0.4, 0.28, lin("#4a78ff"), ry); } sign(civic.sign, 3.9); break;
    case "post": door(0, 1.8, 2.5, "#2a3c5e"); win(-2.4, 1.8, 2, 1.7); win(2.4, 1.8, 2, 1.7); { const mb = place(w*0.35,0,0.5); box("plain", mb[0], g+0.6, mb[2], 0.6, 1.1, 0.5, lin("#1d3f73"), ry); } sign(civic.sign, 3.9); break;
    case "church": {
      door(0, 2, 3.4, "#4a2c1c"); const rw = place(0,0,0.14); pushGeom("plain", PRIM.cyl, M(rw[0], g+5.4, rw[2], ry, 2.2, 0.1, 2.2, Math.PI/2), lin("#6a4a8a"));
      const sp_ = place(w*0.3,0,-2); pushGeom("plain", PRIM.cyl, M(sp_[0], g, sp_[2], 0, 3, (o.top||g+12) - g + 6, 3), lin("#e2dccf")); pushGeom("plain", PRIM.cone, M(sp_[0], (o.top||g+12)+6, sp_[2], 0, 3.4, 7, 3.4), lin("#4f5a60"));
      sign(civic.sign, 4.2, 3.4); break; }
    case "school": door(0, 2, 2.6, "#7a2e36"); win(-3, 2, 1.8, 1.8); win(3, 2, 1.8, 1.8); { const fp = place(w*0.4,0,0.45); pushGeom("metal", PRIM.cyl, M(fp[0], g, fp[2], 0, 0.1, 7, 0.1), lin("#c9ccd0")); box("plain", fp[0]+0.6, g+6.3, fp[2], 1.2, 0.7, 0.04, lin("#2f6b4a"), ry); } sign(civic.sign, 3.9); break;
    case "theatre": { const mq = place(0,0,1.2); box("plain", mq[0], g+3.9, mq[2], Math.min(w-1,7), 1.1, 2.2, lin("#1a1a1a"), ry); box("lamp", mq[0], g+3.3, mq[2], Math.min(w-1,7)-0.2, 0.08, 2.0, lin("#ffffff"), ry); door(-1, 1.4, 2.4, "#6b1d1d"); door(1, 1.4, 2.4, "#6b1d1d"); sign(civic.sign, 5.0); break; }
    default: door(0, 1.6, 2.4, "#2b2926"); win(-2.3, 2.2, 2, 1.7); win(2.3, 2.2, 2, 1.7); sign(civic.sign, 3.9);
  }
}
function RP_(rnd, arr){ return arr[(rnd()*arr.length)|0]; }
// A service lane through the block: fences, dumpsters, pipes, crates and a string of bulbs.
function dressAlley(cx, cz, AW, rnd, R, RP){
  const inner0 = cx - HALF + 14.2, inner1 = cx + HALF - 14.2, mid = (inner0+inner1)/2, len = inner1 - inner0;
  const wall = RP(["#6b5446","#7a6a5a","#5d5a55","#8b5a4a"]);
  for (const sd of [-1,1]){ const z = cz + sd*(AW+0.12); pushGeom("plain", PRIM.box, M(mid, H(mid,z)+0.16+1.3, z, 0, len, 2.6, 0.22), lin(wall)); }
  for (let k=0;k<3+((rnd()*3)|0);k++){
    const x = R(cx-HALF+2, cx+HALF-2), z = cz + (rnd()<0.5?-1:1)*(AW-0.7), y = H(x,z)+0.16;
    const kind = rnd();
    if (kind < 0.35){ box("metal", x, y+0.65, z, 1.8, 1.3, 1.0, lin(RP(["#2f5a3a","#3b4a6b","#5a3a2f"]))); box("plain", x, y+1.33, z, 1.9, 0.08, 1.05, lin("#1a1a1a"), 0, 0, 0.12); }
    else if (kind < 0.6){ for (let c=0;c<2+((rnd()*3)|0);c++) box("plain", x+R(-0.4,0.4), y+0.25+c*0.5, z+R(-0.2,0.2), 0.6, 0.48, 0.5, lin("#8a6a44"), R(0,1)); }
    else if (kind < 0.8){ pushGeom("metal", PRIM.cyl, M(x, y, z, 0, 0.6, 0.9, 0.6), lin("#4a4d52")); }
    else { box("plain", x, y+0.04, z, R(0.8,1.6), 0.02, R(0.5,0.9), lin("#101418")); } // puddle / stain
  }
  for (const sd of [-1,1]){ const z = cz + sd*(AW+0.02); pushGeom("metal", PRIM.cyl, M(R(inner0,inner1), H(cx,z)+0.16, z, 0, 0.12, R(3,7), 0.12), lin("#5a5d62")); }
  if (rnd()<0.6){ for (let k=0;k<12;k++){ const x = lerp(cx-HALF+1, cx+HALF-1, k/11), y = H(x,cz)+4.2 - Math.sin(k/11*Math.PI)*0.6; box("lamp", x, y, cz, 0.12, 0.12, 0.12, lin("#ffffff")); } }
  // back-of-house life: fire escapes, AC units, back doors with lamps, bins, bags, pallets, laundry
  for (const sd of [-1,1]){
    const zw = cz + sd*(AW+0.2);
    for (let k=0;k<2;k++){ const x = R(cx-HALF+2, cx+HALF-2), y = H(x,zw)+0.16; box("plain", x, y+1.1, zw - sd*0.05, 1.0, 2.2, 0.1, lin(RP(["#3a2e26","#5a3a2f","#2f3a42","#6b5446"]))); box("lamp", x+0.7, y+2.5, zw - sd*0.2, 0.2, 0.2, 0.2, lin("#ffffff")); }
    for (let k=0;k<3;k++){ const x = R(cx-HALF+1, cx+HALF-1), y = H(x,zw)+0.16+R(2.6,7); box("metal", x, y, zw - sd*0.35, 0.8, 0.55, 0.55, lin("#b8bcc0")); }
    if (rnd()<0.7){ const x = R(cx-HALF+4, cx+HALF-4), y = H(x,zw)+0.16; for (let f=1;f<=3;f++){ box("metal", x, y+f*3.1, zw - sd*0.6, 2.6, 0.08, 1.1, lin("#2b2f33")); box("metal", x, y+f*3.1+0.5, zw - sd*1.1, 2.6, 0.05, 0.05, lin("#2b2f33")); } box("metal", x+1.1, y+4.6, zw - sd*0.6, 0.08, 6.2, 0.5, lin("#2b2f33"), 0, 0.35); }
    for (let k=0;k<4;k++){ const x = R(cx-HALF+1, cx+HALF-1), y = H(x,cz)+0.16; pushGeom("plain", PRIM.sph, M(x, y+0.25, cz + sd*(AW-0.45), 0, 0.55, 0.5, 0.5), lin(RP(["#1a1a1a","#2b2b2b","#1d2d44"]))); }
  }
  if (rnd()<0.6){ const x = R(cx-HALF+3, cx+HALF-3), y = H(x,cz)+0.16; box("plain", x, y+0.08, cz - AW + 0.9, 1.2, 0.15, 1.0, lin("#8a6a44")); box("plain", x, y+0.23, cz - AW + 0.9, 1.2, 0.15, 1.0, lin("#8a6a44")); }
  if (rnd()<0.55){ const x0 = R(cx-HALF+3, cx), y = H(x0,cz)+6.2; box("metal", x0+4, y, cz, 8, 0.02, 0.02, lin("#dddddd")); for (let k=0;k<6;k++) box("plain", x0+0.8+k*1.3, y-0.45, cz, 0.6, 0.8, 0.03, lin(RP(["#f2efe6","#c0362c","#2f7fc1","#e8b82e","#3aa06b","#f28cb1"]))); }
  if (rnd()<0.5){ const x = R(cx-HALF+2, cx+HALF-2), y = H(x,cz)+0.16; for (let k=0;k<3;k++) pushGeom("metal", PRIM.cyl, M(x+k*0.5, y, cz+AW-0.35, 0, 0.05, 0.8, 0.05), lin("#6b6f73")); }
  (World.alleyWalls = World.alleyWalls || []).push({ cx, cz, AW, x0: cx-HALF+14.5, x1: cx+HALF-14.5 });
  // bollards at both mouths: people only
  for (const ex of [cx-HALF-0.2, cx+HALF+0.2]) for (const bz of [-1.2, 0, 1.2]) pushGeom("metal", PRIM.cyl, M(ex, H(ex,cz+bz)+0.16, cz+bz, 0, 0.18, 0.9, 0.18), lin("#e8b82e"));
}

/* ---------- Snap City: breathing room between buildings ---------- */
function alleyAt(cx, cz){ return (World.alleys||[]).some(a => a.cx === cx && a.cz === cz); }
// A slot on the street that isn't a building: pocket park, car park, vacant lot or construction site.
function buildGapFeature(kind, o){
  const { place, g, w, D, ry, rnd, R, RP } = o;
  const slab = (col, y) => { const c = place(0,0,-D/2); box("plain", c[0], g + (y||0.02), c[2], w - 0.2, 0.06, D - 0.2, lin(col), ry); };
  const along = (lx, lz, fn) => { const p_ = place(lx, 0, lz); fn(p_[0], p_[2]); };
  const treeAt = (x, z, s) => { const y = H(x,z) + 0.16; pushGeom("plain", PRIM.cyl, M(x, y, z, 0, 0.25*s, 2.2*s, 0.25*s), lin("#4a3a2c")); for (let k=0;k<3;k++) pushGeom("foliage", PRIM.sph, M(x + R(-0.6,0.6)*s, y + 2.6*s + R(0,0.8)*s, z + R(-0.6,0.6)*s, 0, 2.2*s, 1.8*s, 2.2*s), lin(RP(["#3f5a34","#4f6b3a","#5a7a44","#6b8a4a"]))); };
  (World.gaps = World.gaps || []).push({ kind, x: place(0,0,-D/2)[0], z: place(0,0,-D/2)[2], ry, w, d: D, gy: g, fx: place(0,0,0)[0], fz: place(0,0,0)[2], n: o.ed.n });
  if (kind === "park"){
    slab("#5f7a4a");
    for (let k=0;k<2+((rnd()*2)|0);k++) along(R(-w/2+1.5, w/2-1.5), -R(2.5, D-2), (x,z) => treeAt(x, z, R(0.8,1.2)));
    for (const lx of [-w*0.25, w*0.25]) along(lx, -1.4, (x,z) => { box("plain", x, g+0.45, z, 1.6, 0.08, 0.45, lin("#6b4a2e"), ry); box("plain", x, g+0.22, z, 1.5, 0.44, 0.08, lin("#2b2926"), ry); });
    along(0, -0.1, (x,z) => { for (let k=-4;k<=4;k++){ const q = place(k*w/9.5, 0, -0.1); box("metal", q[0], g+0.45, q[2], 0.05, 0.9, 0.05, lin("#2b2f33"), ry); } box("metal", x, g+0.85, z, w-0.6, 0.05, 0.05, lin("#2b2f33"), ry); });
  } else if (kind === "parking"){
    slab("#3a3b3e");
    for (let k=0;k<Math.floor(w/2.8);k++){ const q = place(-w/2 + 1.4 + k*2.8, 0, -D*0.55); box("paint", q[0], g+0.06, q[2], 0.1, 0.01, 4.8, lin("#e9e8e2"), ry); }
    const cars = Math.floor(w/2.8) - 1;
    for (let k=0;k<cars;k++){ if (rnd() < 0.45) continue; const q = place(-w/2 + 2.8 + k*2.8, 0, -D*0.55); try{ pushCar(q[0], H(q[0],q[2]) + 0.02, q[2], ry + (rnd()<0.5?0:Math.PI), 0, "sedan", lin(RP(CAR_COLORS))); }catch(e){} }
    along(0, -0.15, (x,z) => box("plain", x, g+0.35, z, w-0.4, 0.7, 0.3, lin("#8a8680"), ry));
    along(w/2 - 0.8, 0.1, (x,z) => { box("metal", x, g+1.4, z, 0.08, 2.8, 0.08, lin("#2b2f33"), ry); box("plain", x, g+2.9, z, 0.9, 0.9, 0.06, lin("#1d3f73"), ry); });
  } else if (kind === "vacant"){
    slab("#6b5a45");
    for (let k=0;k<10;k++){ const q = place(R(-w/2+1, w/2-1), 0, -R(1, D-1)); pushGeom("foliage", PRIM.sph, M(q[0], g+0.15, q[2], 0, R(0.4,1.2), R(0.3,0.7), R(0.4,1.2)), lin(RP(["#6b7a3a","#8a8a4a","#5a6a34"]))); }
    for (let k=0;k<3;k++){ const q = place(R(-w/2+1, w/2-1), 0, -R(2, D-2)); box("plain", q[0], g+0.25, q[2], R(0.6,1.6), 0.5, R(0.4,1), lin(RP(["#8a6a44","#5d5a55","#7a3a2a"])), R(0,3)); }
    for (let k=-5;k<=5;k++){ const q = place(k*w/11, 0, -0.1); box("metal", q[0], g+1.1, q[2], 0.05, 2.2, 0.05, lin("#7d8288"), ry); }
    along(0, -0.1, (x,z) => { box("metal", x, g+2.15, z, w-0.3, 0.04, 0.04, lin("#7d8288"), ry); box("metal", x, g+1.1, z, w-0.3, 2.1, 0.01, lin("#9aa0a6"), ry); });
  } else if (kind === "construction"){
    slab("#7a6a52");
    const hoard = RP(["#2f5d8a","#e9e6de","#2f6b4a"]);
    for (let k=-3;k<=3;k++){ const q = place(k*w/7, 0, -0.15); box("plain", q[0], g+1.2, q[2], w/7 - 0.08, 2.4, 0.08, lin(k%2 ? hoard : "#f2f0ea"), ry); }
    for (let k=0;k<4;k++){ const q = place(R(-w/2+2, w/2-2), 0, -R(3, D-3)); box("plain", q[0], g+0.35, q[2], R(1.5,3), 0.7, R(0.8,1.6), lin(RP(["#a8a29a","#b87a4a","#8a8680"])), R(0,3)); }
    // a concrete core and floor slabs going up, with scaffolding on the street face
    const lv = 2 + ((rnd()*4)|0), c = place(0,0,-D/2);
    for (let k=0;k<lv;k++) box("plain", c[0], g + 0.2 + k*3.2, c[2], w - 3, 0.3, D - 3, lin("#b9b4aa"), ry);
    for (let k=0;k<lv;k++) for (const lx of [-w/2+2, w/2-2]) for (const lz of [-2, -D+2]){ const q = place(lx, 0, lz); box("plain", q[0], g + 1.8 + k*3.2, q[2], 0.35, 3.2, 0.35, lin("#a8a39a"), ry); }
    for (let k=0;k<=lv;k++){ const q = place(0,0,-1.3); box("metal", q[0], g + k*3.2 + 0.1, q[2], w - 1.6, 0.06, 0.9, lin("#6b6f73"), ry); }
    for (let k=0;k<=Math.floor(w/2.2);k++){ const q = place(-w/2+0.8+k*2.2, 0, -0.9); box("metal", q[0], g + lv*1.6, q[2], 0.06, lv*3.2, 0.06, lin("#8a8e92"), ry); }
    (World.construction = World.construction || []).push({ x: c[0], z: c[2], ry, w, d: D, gy: g, top: g + lv*3.2, fx: place(0,0,0)[0], fz: place(0,0,0)[2], n: o.ed.n });
  }
}
// A roof that isn't flat: mansard, gable, garden or a little dome.
function buildRoofVariant(o){
  const { place, top, w, D, ry, rnd, R, RP } = o, c = place(0,0,-D/2), r = rnd();
  if (r < 0.28){ pushGeom("plain", PRIM.frus, M(c[0], top+0.3, c[2], ry, w*1.36, R(2.2,3.4), D*1.36), lin(RP(["#3b4046","#4a3a34","#2f3a42"]))); for (let k=0;k<Math.max(2,Math.floor(w/3));k++){ const q = place(-w/2 + 1.5 + k*3, 0, -0.8); box("plain", q[0], top+1.4, q[2], 1.1, 1.3, 1.0, lin("#e9e4d8"), ry); } }
  else if (r < 0.45){ pushGeom("plain", PRIM.tri, M(c[0], top+0.3, c[2], ry, w, R(2.5,4), D), lin(RP(["#6b3a32","#4a4038","#3b4a52"]))); }
  else if (r < 0.55){ box("plain", c[0], top+0.35, c[2], w*0.8, 0.3, D*0.7, lin("#5f7a4a"), ry); for (let k=0;k<3;k++){ const q = place(R(-w/3,w/3),0,-R(2,D-2)); pushGeom("foliage", PRIM.sph, M(q[0], top+0.9, q[2], 0, 1.2, 1.1, 1.2), lin("#4f6b3a")); } }
  else if (r < 0.6){ pushGeom("plain", PRIM.sph, M(c[0], top+0.3, c[2], 0, Math.min(w,D)*0.5, Math.min(w,D)*0.35, Math.min(w,D)*0.5), lin(RP(["#6f7a73","#b08a4a","#9aa39c"]))); }
}
