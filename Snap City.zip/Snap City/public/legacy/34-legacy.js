
/* =========================================================
   Contact Sheet v14.1 — usability + subtle NPCs + posters
   ========================================================= */
(function(){
"use strict";
const CS141=window.CS141={posters:[],applied:false};
function migrate141(){
  if(!S||!S.custom||S.custom._v141Applied)return;
  S.custom.tJoy="small";
  S.custom.eventNotify="clue"; // sound + written clue
  S.custom.flagsOn="off";
  S.custom.accessibility=S.custom.accessibility||{};
  if(!Number.isFinite(Number(S.custom.accessibility.timeScale))) S.custom.accessibility.timeScale=1;
  S.custom._v141Applied=true;
  saveState();
}
// Replace the Time Scale row with a number-safe renderer so selection always shows correctly.
{const base=menuSettings;menuSettings=function(){
  let h=base(); const a=(S.custom&&S.custom.accessibility)||{}, cur=Number(a.timeScale||1);
  const row=`<div class="formrow"><label>Time scale</label><div class="seg" data-aseg="timeScale">${[[1,"Normal"],[.75,"75%"],[.5,"50%"],[.35,"35%"]].map(([v,l])=>`<button data-v="${v}" aria-pressed="${Math.abs(cur-v)<.001}">${l}</button>`).join("")}</div><span class="spec">Normal runs the street in real time. Slower choices give you more time to read gestures and light.</span></div>`;
  h=h.replace(/<div class="formrow"><label>Time scale<\/label>[\s\S]*?<\/div><span class="spec">Slow the simulation for reading moments\.<\/span><\/div>/,row);
  h=h.replace(/<div class="formrow"><label>Flags<\/label>[\s\S]*?<\/div>\s*<\/div>/g,"");
  return h;
};}
// Robust delegated handler; works even when the menu re-renders itself.
document.addEventListener("click",e=>{
  const b=e.target.closest&&e.target.closest('[data-aseg="timeScale"] button'); if(!b)return;
  e.preventDefault(); e.stopPropagation();
  S.custom.accessibility=S.custom.accessibility||{}; S.custom.accessibility.timeScale=Number(b.dataset.v)||1;
  saveState(); applyAccessibility(); renderMenu();
},true);

// A handful of generated posters: photographic background material, not visual spam.
function posterTexture(seed,title,sub){
  const r=mulberry(seed),c=document.createElement("canvas");c.width=384;c.height=560;const x=c.getContext("2d");
  const bg=["#e9d7b7","#d9e2df","#e0b8ad","#171a21","#efcc54","#98a9c4"][(r()*6)|0];x.fillStyle=bg;x.fillRect(0,0,c.width,c.height);
  for(let i=0;i<10;i++){x.fillStyle=`hsla(${(r()*360)|0},${35+(r()*50)|0}%,${25+(r()*55)|0}%,.72)`;const w=40+r()*220,h=30+r()*180;x.save();x.translate(r()*384,r()*560);x.rotate((r()-.5)*1.4);x.fillRect(-w/2,-h/2,w,h);x.restore();}
  x.fillStyle=bg==="#171a21"?"#f3eadc":"#181716";x.font="bold 39px Arial Narrow,Arial";x.textAlign="center";x.fillText(title,192,70);x.font="bold 19px Arial";x.fillText(sub,192,505);x.font="14px Arial";x.fillText("TONIGHT · DOORS 8PM",192,535);
  const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=Math.min(8,G.renderer.capabilities.getMaxAnisotropy());return t;
}
function buildPosters(){
  if(CS141.posters.length||!World.shops||!G.scene)return;
  const names=[["BAND OF THE WEEK","THE STATIC HEARTS"],["MIDNIGHT MATINEE","A FILM BY E. ROJAS"],["LIVE AT THE HALL","THE WESTERN LINES"],["ONE NIGHT ONLY","JUNE MERCER"],["CITY AFTER DARK","NEW 35MM PRINT"],["FRIDAY SHOW","MOTEL RADIO"]];
  const picks=[]; for(let i=1;i<World.shops.length&&picks.length<6;i+=Math.max(3,Math.floor(World.shops.length/8)))picks.push(World.shops[i]);
  picks.forEach((sh,i)=>{const [title,sub]=names[i%names.length],tex=posterTexture(14100+i,title,sub),mat=new THREE.MeshBasicMaterial({map:tex,side:THREE.DoubleSide}),m=new THREE.Mesh(new THREE.PlaneGeometry(1.15,1.7),mat);
    const side=(i%2?1:-1)*Math.min(sh.w*.32,1.5),n=sh.n,a=[n[1],-n[0]];m.position.set(sh.x+a[0]*side+n[0]*.035,sh.gy+1.55,sh.z+a[1]*side+n[1]*.035);m.rotation.y=sh.ry;G.scene.add(m);CS141.posters.push(m);});
}
// Existing v14 bus recovery is supplemented every frame: an occupied bus never performs the long scheduled stop.
function keepOccupiedBusMoving(){if(!(GP.ride&&GP.ride.kind==="bus"))return;const b=GP.ride.v;if(!b)return;b.stopT=0;b.vmax=Math.max(b.vmax||0,7);if((b.speed||0)<2.2)b.speed=2.2;}
{const base=gameplayUpdate;gameplayUpdate=function(dt){base(dt);keepOccupiedBusMoving();};}
{const base=boot;boot=async function(){await base();migrate141();cs14HideFlags&&cs14HideFlags();buildPosters();};}
console.log("[Contact Sheet v14.1] subtle NPCs, posters, settings fixes loaded.");
})();
