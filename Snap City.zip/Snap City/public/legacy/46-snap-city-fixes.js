/* =========================================================
   Snap City — patch 46: lively events, stray animals, air traffic, markets
   ========================================================= */
(function(){
  "use strict";
  if (typeof window === "undefined") return;

  /* =========================================================
     1. FIX: Collapse all settings sections by default
     Remove extra settings items that were added by later patches
     ========================================================= */
  if (typeof renderMenu === "function") {
    const _baseRender = renderMenu;
    renderMenu = function() {
      const r = _baseRender.apply(this, arguments);
      try {
        const body = document.querySelector("#menubody");
        if (body) {
          // Collapse all settings sections
          body.querySelectorAll("details.sc-settings-section").forEach(d => { d.open = false; });
        }
      } catch(e) {}
      return r;
    };
  }

  // Also collapse in the 44-snap-city-life regroupSettings
  if (typeof window.SnapCity !== "undefined" && window.SnapCity.life) {
    // The regroupSettings in patch 44 sets det.open = idx < 2 (first 2 open)
    // We override after it runs to collapse all
    const _origRegroup = window.SnapCity.life.regroupSettings;
  }

  /* =========================================================
     2. RANDOMIZED EVENT NPC BEHAVIOR
     Firefighters actively fight fire, crowds react variedly
     ========================================================= */

  // Override startPlay to randomize fire event behaviors
  const _startPlayBase = startPlay;
  startPlay = function(type) {
    const E = _startPlayBase(type);
    if (!E) return E;

    if (type === "fire") {
      const crew = E.ppl ? E.ppl.filter(function(p) { return p.role === "fire"; }) : [];
      const crowd = E.ppl ? E.ppl.filter(function(p) { return p.role !== "fire"; }) : [];

      // Assign randomized behavior profiles
      crew.forEach(function(p, k) {
        p._fireRole = ["hose", "support", "coord", "rescue"][k % 4];
        p._patrolOffset = { ax: rand(-3, 3), oz: rand(-2, 2) };
        p._moveTimer = rand(3, 8);
        p._targetX = 0; p._targetZ = 0;
      });

      crowd.forEach(function(p, k) {
        var beh = ["film", "point", "backaway", "talk", "phone", "handsface", "watch"];
        p._crowdBeh = beh[(k + Math.floor(Math.random() * beh.length)) % beh.length];
        p._reactTimer = rand(2, 6);
      });

      // Wrap the step to add randomized behaviors on top of original
      var _origStep = E.step;
      E.step = function(dt) {
        // Call original step for fire FX, vehicle, smoke, etc.
        try { _origStep.call(E, dt); } catch(e) {}

        var t = E.t;
        var burn = t < 75 ? Math.min(1, t/15) : Math.max(0, 1 - (t - 75)/50);
        var win = { x: E.x, z: E.z, ox: 0, oz: 0 };
        // Try to get fire position from the event
        try {
          var near = evSpot(30, 85);
          if (near) { win.ox = near.out[0]; win.oz = near.out[1]; }
        } catch(e) {}

        // Crew: firefighters actively fight the fire
        if (t > 25 && t < 170) {
          crew.forEach(function(p, k) {
            if (p.hidden) return;
            p._moveTimer -= dt;

            if (p._moveTimer <= 0) {
              p._moveTimer = rand(4, 10);
              var angle = rand(0, Math.PI * 2);
              var dist = rand(3, 8);
              p._targetX = win.x + Math.cos(angle) * dist + p._patrolOffset.ax;
              p._targetZ = win.z + Math.sin(angle) * dist + p._patrolOffset.oz;
            }

            if (p._targetX !== 0 || p._targetZ !== 0) {
              var dx = p._targetX - p.x, dz = p._targetZ - p.z;
              var d = Math.hypot(dx, dz);
              if (d > 0.3) {
                p.heading = Math.atan2(dx, dz);
                var sp = 2.0 + rand(0, 1);
                p.x += dx/d * sp * dt;
                p.z += dz/d * sp * dt;
                try { p.y = groundY(p.x, p.z); } catch(e) {}
                p.evMoving = true;
                p.evSpeed = sp;
              } else {
                p.evMoving = false;
                try { p.heading = Math.atan2(win.x - p.x, win.z - p.z); } catch(e) {}
                p.headPitch = -0.3;

                // Role-specific actions
                if (p._fireRole === "hose" && burn > 0.1) {
                  p.evPose = "hose";
                  // Spray water
                  try {
                    var hx = p.x + Math.sin(p.heading) * 0.6;
                    var hz = p.z + Math.cos(p.heading) * 0.6;
                    var hy = p.y + 1.25;
                    for (var j = 0; j < 3; j++) {
                      var dx2 = win.x - hx, dz2 = win.z - hz, dh = Math.hypot(dx2, dz2);
                      if (dh > 0.1) Smoke.emit(hx, hy, hz, dx2/dh * 9 + rand(-0.4, 0.4), 5.2 + (win.y - hy) * 0.35 + rand(-0.3, 0.3), dz2/dh * 9 + rand(-0.4, 0.4), 0.12, 1.4, 0.55, WATER, -7, 0.5);
                    }
                  } catch(e) {}
                } else if (p._fireRole === "support") {
                  p.evPose = Math.random() < 0.5 ? "point" : null;
                  if (Math.random() < 0.3) p._moveTimer = 0;
                } else if (p._fireRole === "coord") {
                  p.evPose = Math.floor(t / 3) % 2 ? "radio" : "point";
                } else if (p._fireRole === "rescue") {
                  p.evPose = t < 100 ? "point" : "radio";
                  if (Math.random() < 0.2) p._moveTimer = 0;
                }
              }
            }
          });
        }

        // Crowd: varied reactions
        if (t > 12 && t < 170) {
          crowd.forEach(function(p, k) {
            if (p.hidden) return;
            p._reactTimer -= dt;

            if (p._reactTimer <= 0) {
              p._reactTimer = rand(3, 8);
              if (Math.random() < 0.4) {
                var beh = ["film", "point", "backaway", "talk", "phone", "handsface", "watch"];
                p._crowdBeh = beh[Math.floor(Math.random() * beh.length)];
              }
            }

            try {
              var dx2w = win.x - p.x, dz2w = win.z - p.z;
              var distToFire = Math.hypot(dx2w, dz2w);
              if (distToFire < 0.1) distToFire = 1;

              switch (p._crowdBeh) {
                case "film":
                  p.heading = Math.atan2(dx2w, dz2w);
                  p.headPitch = -0.2; p.evPose = null; p.act = "phone"; break;
                case "point":
                  p.heading = Math.atan2(dx2w, dz2w); p.headPitch = -0.35;
                  p.evPose = "point"; p.act = "idle"; break;
                case "backaway":
                  if (distToFire < 12) {
                    p.x -= dx2w/distToFire * 0.5 * dt;
                    p.z -= dz2w/distToFire * 0.5 * dt;
                    try { p.y = groundY(p.x, p.z); } catch(e) {}
                    p.heading = Math.atan2(dx2w, dz2w);
                    p.evMoving = true; p.evSpeed = 0.5;
                  } else { p.evMoving = false; p.evPose = "handsface"; }
                  break;
                case "talk":
                  var neighbor = crowd[(k + 1) % crowd.length];
                  if (neighbor && neighbor !== p) p.heading = Math.atan2(neighbor.x - p.x, neighbor.z - p.z);
                  p.evPose = Math.floor(t / 2) % 2 ? "point" : null; p.headPitch = 0; break;
                case "phone":
                  p.heading = Math.atan2(dx2w, dz2w); p.act = "phone"; p.evPose = null; break;
                case "handsface":
                  p.heading = Math.atan2(dx2w, dz2w); p.evPose = "handsface"; break;
                case "clap":
                  p.heading = Math.atan2(dx2w, dz2w);
                  p.evPose = burn < 0.3 ? "clap" : "handsface"; break;
                default:
                  p.evPose = null; p.act = "idle";
              }
            } catch(e) {}
          });
        }
      };
    }

    return E;
  };

  /* Also randomize the V8 rescue and heist crowd */
  if (typeof startV8 === "function") {
    const _startV8Base = startV8;
    startV8 = function(type) {
      var E;
      try { E = _startV8Base(type); } catch(e) { return null; }
      if (!E) return E;

      try {
        if (type === "rescue" || type === "heist") {
          var crowd = E.ppl ? E.ppl.filter(function(p) { return p.role !== "fire" && p.role !== "police" && p.role !== "robber"; }) : [];
          crowd.forEach(function(p, k) {
            var beh = type === "rescue" ? ["film", "point", "handsface", "watch", "clap"] : ["duck", "film", "point", "backaway", "handsup"];
            p._crowdBeh = beh[(k + Math.floor(Math.random() * beh.length)) % beh.length];
            p._reactTimer = rand(2, 6);
          });
          var _origStep = E.step;
          E.step = function(dt) {
            try { _origStep.call(E, dt); } catch(e) {}
            crowd.forEach(function(p, k) {
              if (p.hidden) return;
              p._reactTimer -= dt;
              if (p._reactTimer <= 0) {
                p._reactTimer = rand(3, 6);
                if (Math.random() < 0.3) {
                  var beh = type === "rescue" ? ["film", "point", "handsface", "watch", "clap"] : ["duck", "film", "point", "backaway", "handsup"];
                  p._crowdBeh = beh[Math.floor(Math.random() * beh.length)];
                }
              }
            });
          };
        }
      } catch(e) {}

      return E;
    };
  }

  /* =========================================================
     3. STRAY CATS — simple wandering animals
     Uses lightweight mesh, doesn't interfere with dog system
     ========================================================= */
  var StrayCats = {
    list: [], mesh: null, initialized: false, colorMeshes: [],

    init() {
      if (this.initialized) return;
      if (typeof World === "undefined" || !World.scene) return;
      if (typeof THREE === "undefined") return;
      this.initialized = true;

      var catColors = ["#3a2a1c", "#6b4a2e", "#8a6a48", "#c9a36a", "#26231f", "#e8e0d4", "#5a3a22"];
      var numCats = 4 + Math.floor(Math.random() * 4);

      for (var i = 0; i < numCats; i++) {
        var color = catColors[Math.floor(Math.random() * catColors.length)];
        var cx = rand(-100, 100), cz = rand(-100, 100);

        // Simple cat: body sphere + head sphere + tail
        var g = new THREE.Group();
        var mat = new THREE.MeshStandardMaterial({ color: lin ? lin(color) : new THREE.Color(color), roughness: 0.95 });

        var body = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 6), mat);
        body.scale.set(1, 0.7, 1.5);
        g.add(body);

        var head = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 6), mat);
        head.position.set(0, 0.05, 0.22);
        g.add(head);

        // Ears
        for (var s of [-1, 1]) {
          var ear = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.08, 4), mat);
          ear.position.set(s * 0.05, 0.14, 0.2);
          g.add(ear);
        }

        // Tail
        var tail = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.03, 0.25, 5), mat);
        tail.position.set(0, 0.05, -0.2);
        tail.rotation.x = 0.6;
        g.add(tail);

        // Legs
        for (var lx of [-0.1, 0.1]) for (var lz of [-0.1, 0.1]) {
          var leg = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.15, 4), mat);
          leg.position.set(lx, -0.12, lz);
          g.add(leg);
        }

        g.position.set(cx, groundY(cx, cz) + 0.1, cz);
        g.castShadow = true;
        World.scene.add(g);

        var cat = {
          g: g, x: cx, y: groundY(cx, cz), z: cz, heading: rand(0, 6.28),
          speed: 0, phase: 0, still: 0,
          homeX: cx, homeZ: cz,
          state: "wander", stateTimer: rand(2, 8),
          targetX: cx, targetZ: cz,
          color: color
        };
        this.list.push(cat);
      }
    },

    update(dt) {
      if (!this.initialized) { this.init(); return; }
      if (!this.list.length) return;

      for (var i = 0; i < this.list.length; i++) {
        var cat = this.list[i];
        cat.stateTimer -= dt;

        // Flee from nearby dogs or player
        var fleeing = false;
        try {
          if (typeof Life !== "undefined" && Life.dogs) {
            for (var j = 0; j < Life.dogs.length; j++) {
              var d = Life.dogs[j];
              if (Math.hypot(d.x - cat.x, d.z - cat.z) < 8) {
                cat.state = "flee"; cat.stateTimer = rand(3, 6); fleeing = true; break;
              }
            }
          }
        } catch(e) {}
        if (!fleeing) {
          var pd = Math.hypot(Player.x - cat.x, Player.z - cat.z);
          if (pd < 3) { cat.state = "flee"; cat.stateTimer = rand(2, 4); }
        }

        if (cat.stateTimer <= 0) {
          var r = Math.random();
          if (r < 0.3) { cat.state = "sit"; cat.stateTimer = rand(5, 15); }
          else if (r < 0.7) { cat.state = "wander"; cat.stateTimer = rand(4, 10); }
          else { cat.state = "stalk"; cat.stateTimer = rand(3, 8); }

          if (cat.state === "wander" || cat.state === "stalk") {
            var a = rand(0, 6.28), r2 = rand(5, 20);
            cat.targetX = cat.homeX + Math.cos(a) * r2;
            cat.targetZ = cat.homeZ + Math.sin(a) * r2;
          }
        }

        var wantSpeed = 0;
        if (cat.state === "flee") {
          var threat = { x: Player.x, z: Player.z };
          var dx = cat.x - threat.x, dz = cat.z - threat.z;
          var d = Math.hypot(dx, dz) || 1;
          cat.targetX = cat.x + dx/d * 15;
          cat.targetZ = cat.z + dz/d * 15;
          wantSpeed = 4.0;
        } else if (cat.state === "wander") wantSpeed = 1.2;
        else if (cat.state === "stalk") wantSpeed = 0.6;

        var dx = cat.targetX - cat.x, dz = cat.targetZ - cat.z;
        var dd = Math.hypot(dx, dz);
        if (dd > 0.2 && wantSpeed > 0) {
          cat.speed = lerp(cat.speed, wantSpeed, Math.min(1, dt * 4));
          cat.x += dx/dd * cat.speed * dt;
          cat.z += dz/dd * cat.speed * dt;
          try { cat.y = groundY(cat.x, cat.z); } catch(e) {}
          cat.heading = Math.atan2(dx, dz);
        } else {
          cat.speed = lerp(cat.speed, 0, Math.min(1, dt * 4));
          if (cat.state === "flee" && dd < 0.5) { cat.state = "wander"; cat.stateTimer = rand(3, 6); }
        }

        cat.still = cat.speed < 0.2 ? cat.still + dt : 0;
        cat.phase += cat.speed * dt * 9;

        // Update mesh
        cat.g.position.set(cat.x, cat.y + 0.1, cat.z);
        cat.g.rotation.y = cat.heading;
        // Tail swish
        if (cat.g.children[3]) cat.g.children[3].rotation.x = 0.6 + Math.sin(cat.phase) * 0.3;
        // Bob when walking
        var bob = cat.speed > 0.2 ? Math.abs(Math.sin(cat.phase)) * 0.02 : 0;
        cat.g.position.y = cat.y + 0.1 + bob;

        // Hide if far away
        var distToPlayer = Math.hypot(cat.x - Player.x, cat.z - Player.z);
        cat.g.visible = distToPlayer < 120;
      }
    }
  };

  // Hook stray cats into the game loop — wrapped in try-catch to never break the game
  if (typeof gameplayUpdate === "function") {
    var _gpCats = gameplayUpdate;
    gameplayUpdate = function(dt) {
      _gpCats(dt);
      try {
        if (typeof Game !== "undefined" && Game.started) StrayCats.update(dt);
      } catch(e) {}
    };
  }

  // Add cats to life subjects for photo scoring — wrapped in try-catch
  if (typeof lifeSubjects === "function") {
    var _lsCats = lifeSubjects;
    lifeSubjects = function() {
      var out = _lsCats();
      try {
        for (var i = 0; i < StrayCats.list.length; i++) {
          var cat = StrayCats.list[i];
          out.push({ kind: "dog", ref: { x: cat.x, y: cat.y, z: cat.z, heading: cat.heading, color: cat.color, free: null }, x: cat.x, y: cat.y, z: cat.z, h: 0.3, r: 0.2, vx: 0, vz: 0, heading: cat.heading, color: cat.color, ev: null });
        }
      } catch(e) {}
      return out;
    };
  }

  /* =========================================================
     4. HELICOPTERS — simple air traffic
     ========================================================= */
  var Helicopters = {
    mesh: null, active: false, t: 0, nextT: 60, rotorAngle: 0,

    init(scene) {
      if (!scene || this.mesh) return;
      var g = new THREE.Group();
      var dark = new THREE.MeshBasicMaterial({ color: 0x2a2a2e });

      var fus = new THREE.Mesh(new THREE.CapsuleGeometry(0.5, 1.5, 4, 8), dark);
      fus.rotation.z = Math.PI / 2; g.add(fus);

      var cockpit = new THREE.Mesh(new THREE.SphereGeometry(0.4, 8, 6), new THREE.MeshBasicMaterial({ color: 0x1a2a3a }));
      cockpit.position.set(1.2, 0.15, 0); g.add(cockpit);

      var tail = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.25, 2.5, 6), dark);
      tail.rotation.z = Math.PI / 2; tail.position.set(-1.8, 0.15, 0); g.add(tail);

      var fin = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.5, 0.3), dark);
      fin.position.set(-2.8, 0.4, 0); g.add(fin);

      // Main rotor
      var rotor = new THREE.Group();
      var blade = new THREE.Mesh(new THREE.BoxGeometry(5, 0.02, 0.15), new THREE.MeshBasicMaterial({ color: 0x1a1a1a }));
      var blade2 = blade.clone(); blade2.rotation.y = Math.PI / 2;
      rotor.add(blade, blade2); rotor.position.set(0, 0.55, 0);
      g.add(rotor); g.userData.rotor = rotor;

      // Tail rotor
      var tailRotor = new THREE.Group();
      var trBlade = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.02, 0.06), new THREE.MeshBasicMaterial({ color: 0x1a1a1a }));
      var trBlade2 = trBlade.clone(); trBlade2.rotation.z = Math.PI;
      tailRotor.add(trBlade, trBlade2); tailRotor.position.set(-2.8, 0.4, 0.15);
      tailRotor.rotation.x = Math.PI / 2; g.add(tailRotor); g.userData.tailRotor = tailRotor;

      // Skids
      for (var sx of [-0.4, 0.4]) {
        var skid = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 2.2, 6), new THREE.MeshBasicMaterial({ color: 0x1a1a1a }));
        skid.rotation.z = Math.PI / 2; skid.position.set(0, -0.55, sx); g.add(skid);
      }

      g.visible = false; g.scale.set(2.5, 2.5, 2.5);
      this.mesh = g; scene.add(g);
    },

    update(dt, camPos) {
      if (!this.mesh) {
        try { if (typeof G !== "undefined" && G.scene) this.init(G.scene); else return; } catch(e) { return; }
      }
      if (!this.mesh) return;

      this.rotorAngle += dt * 30;
      if (this.mesh.userData.rotor) this.mesh.userData.rotor.rotation.y = this.rotorAngle;
      if (this.mesh.userData.tailRotor) this.mesh.userData.tailRotor.rotation.z = this.rotorAngle * 1.5;

      if (!this.active) {
        this.nextT -= dt;
        if (this.nextT <= 0) {
          if (Math.random() < 0.4) {
            this.active = true; this.t = 0;
            this.startX = camPos.x + rand(-150, 150);
            this.startZ = camPos.z + rand(-150, 150);
            this.startY = 80 + rand(15, 40);
            this.dir = rand(0, Math.PI * 2);
            this.mesh.visible = true;
            var colors = [0x2a2a2e, 0x1a3a5a, 0x6b1f22, 0x2f5a3a, 0xe8e8e8];
            this.mesh.children[0].material.color.setHex(colors[Math.floor(Math.random() * colors.length)]);
          } else { this.nextT = rand(30, 80); }
        }
      } else {
        this.t += dt;
        var speed = 12;
        var dist = this.t * speed;
        var x = this.startX + Math.sin(this.dir) * dist;
        var z = this.startZ + Math.cos(this.dir) * dist;
        this.mesh.position.set(x, this.startY + Math.sin(this.t * 0.3) * 3, z);
        this.mesh.rotation.y = this.dir + Math.PI / 2;
        this.mesh.rotation.z = Math.sin(this.t * 0.1) * 0.03;
        var d = Math.hypot(x - camPos.x, z - camPos.z);
        this.mesh.visible = d < 350;
        if (d > 400 || this.t > 30) { this.active = false; this.mesh.visible = false; this.nextT = rand(50, 120); }
      }
    }
  };

  // Hook helicopters into the game loop — try-catch wrapped
  var _gpHeli = gameplayUpdate;
  gameplayUpdate = function(dt) {
    _gpHeli(dt);
    try {
      if (typeof Game !== "undefined" && Game.started) {
        Helicopters.update(dt, G.cam.position);
      }
    } catch(e) {}
  };

  /* =========================================================
     5. FARMERS MARKET — recurring street event
     ========================================================= */
  var FarmersMarket = {
    stalls: [], props: [], active: false,

    createStall(x, z, ry) {
      var g = new THREE.Group();
      var wood = new THREE.MeshStandardMaterial({ color: lin ? lin("#8a6a44") : new THREE.Color("#8a6a44"), roughness: 0.9 });
      var canvas = new THREE.MeshStandardMaterial({ color: lin ? lin("#e8dcc0") : new THREE.Color("#e8dcc0"), roughness: 0.8 });
      var produceColors = ["#c0362c", "#e8b82e", "#3aa06b", "#e36f2d", "#f2c230"];

      var table = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.08, 0.9), wood);
      table.position.y = 0.75; g.add(table);

      for (var sx of [-1, 1]) for (var sz of [-0.4, 0.4]) {
        var leg = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.75, 0.06), wood);
        leg.position.set(sx, 0.375, sz); g.add(leg);
      }

      var canopy = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.04, 1.2), canvas);
      canopy.position.y = 2.0; g.add(canopy);

      for (var px of [-1.1, 1.1]) for (var pz of [-0.5, 0.5]) {
        var pole = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 2.0, 6), wood);
        pole.position.set(px, 1.0, pz); g.add(pole);
      }

      // Produce crates
      for (var k = 0; k < 4; k++) {
        var cx = (k % 2) * 1.4 - 0.7, cz = (k < 2 ? -0.15 : 0.15);
        var crate = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.15, 0.4), new THREE.MeshStandardMaterial({ color: lin ? lin("#c9a26a") : new THREE.Color("#c9a26a"), roughness: 0.9 }));
        crate.position.set(cx, 0.87, cz); g.add(crate);
        var pc = produceColors[Math.floor(Math.random() * produceColors.length)];
        for (var j = 0; j < 6; j++) {
          var fruit = new THREE.Mesh(new THREE.SphereGeometry(0.07, 6, 5), new THREE.MeshStandardMaterial({ color: lin ? lin(pc) : new THREE.Color(pc), roughness: 0.6 }));
          fruit.position.set(cx + rand(-0.2, 0.2), 0.97, cz + rand(-0.1, 0.1)); g.add(fruit);
        }
      }

      g.position.set(x, groundY(x, z), z); g.rotation.y = ry;
      World.scene.add(g);
      return g;
    },

    start() {
      if (this.active) return null;
      var near;
      try { near = evSpot(25, 70); } catch(e) { return null; }
      if (!near) return null;

      this.active = true; this.stalls = []; this.props = [];
      var ax = near.along, o = near.out;
      var numStalls = 4 + Math.floor(Math.random() * 3);

      for (var k = 0; k < numStalls; k++) {
        var offset = (k - (numStalls - 1) / 2) * 4;
        var sx = near.x + ax[0] * offset + o[0] * 3;
        var sz = near.z + ax[1] * offset + o[1] * 3;
        var ry = Math.atan2(o[0], o[1]) + Math.PI;
        var stall = this.createStall(sx, sz, ry);
        this.stalls.push({ x: sx, z: sz, ry: ry, mesh: stall });
        this.props.push(stall);
      }

      var vendors, customers;
      try { vendors = genActors(numStalls); customers = genActors(4 + Math.floor(Math.random() * 4)); } catch(e) { return null; }
      if (!vendors || vendors.length < 2) {
        this.props.forEach(function(p) { try { World.scene.remove(p); } catch(e) {} });
        this.stalls = []; this.props = []; this.active = false;
        return null;
      }

      var E = { type: "market", t: 0, ppl: [], done: false, info: { name: "the farmers market", bonus: 14 }, x: near.x, z: near.z, play: false };
      E.ppl = vendors.concat(customers);

      vendors.forEach(function(p, k) {
        var stall = this.stalls[k % this.stalls.length];
        try { evPlace(p, stall.x - o[0] * 0.5, stall.z - o[1] * 0.5, Math.atan2(o[0], o[1]), "market"); } catch(e) {}
        p._stallIdx = k % this.stalls.length; p._vendor = true; p._vendorTimer = rand(2, 5);
      }.bind(this));

      customers.forEach(function(p, k) {
        var stall = this.stalls[k % this.stalls.length];
        try { evPlace(p, stall.x + o[0] * 1.5 + ax[0] * rand(-1, 1), stall.z + o[1] * 1.5 + ax[1] * rand(-1, 1), Math.atan2(-o[0], -o[1]), "market"); } catch(e) {}
        p._customer = true; p._browseTimer = rand(3, 8); p._browseIdx = k % this.stalls.length;
      }.bind(this));

      var self = this;
      var dur = rand(200, 320);

      E.step = function(dt) {
        var t = E.t;
        try {
          vendors.forEach(function(p, k) {
            if (p.hidden) return;
            var stall = self.stalls[p._stallIdx];
            if (!stall) return;
            p._vendorTimer -= dt;
            if (p._vendorTimer <= 0) {
              p._vendorTimer = rand(3, 7);
              if (Math.random() < 0.3) {
                try { evWalk(p, stall.x + o[0] * 1.2 + ax[0] * rand(-1, 1), stall.z + o[1] * 1.2 + ax[1] * rand(-1, 1), 1.0, dt); } catch(e) {}
              } else {
                try { evWalk(p, stall.x - o[0] * 0.5, stall.z - o[1] * 0.5, 1.0, dt); } catch(e) {}
              }
            }
            if (!p.evMoving) {
              p.heading = Math.atan2(o[0], o[1]);
              p.evPose = Math.floor(t / 2 + k) % 3 === 0 ? "point" : Math.floor(t / 2 + k) % 3 === 1 ? "handsup" : null;
              p.headPitch = 0;
            }
          });

          customers.forEach(function(p, k) {
            if (p.hidden) return;
            p._browseTimer -= dt;
            if (p._browseTimer <= 0) {
              p._browseTimer = rand(4, 10);
              p._browseIdx = (p._browseIdx + 1 + Math.floor(Math.random() * 2)) % self.stalls.length;
              var stall = self.stalls[p._browseIdx];
              if (stall) try { evWalk(p, stall.x + o[0] * 1.5 + ax[0] * rand(-1, 1), stall.z + o[1] * 1.5 + ax[1] * rand(-1, 1), 1.0 + rand(0, 0.5), dt); } catch(e) {}
            }
            if (!p.evMoving) {
              var stall = self.stalls[p._browseIdx];
              if (stall) { p.heading = Math.atan2(stall.x - p.x, stall.z - p.z); p.headPitch = -0.3; }
              p.evPose = Math.random() < 0.3 ? "point" : null;
              p.act = Math.random() < 0.2 ? "phone" : "idle";
            }
          });

          if (Math.floor(t / 5) !== Math.floor((t - dt) / 5) && t < dur - 10) {
            try {
              if (Math.random() < 0.4) SND.play("voices", near.x + rand(-5, 5), near.z + rand(-5, 5), 0.6);
              else if (Math.random() < 0.5) SND.play("bell", near.x + rand(-5, 5), near.z + rand(-5, 5), 0.4);
            } catch(e) {}
          }
        } catch(e) {}

        if (t > dur) {
          E.done = true;
          self.props.forEach(function(p) { try { World.scene.remove(p); } catch(e) {} });
          self.stalls = []; self.props = []; self.active = false;
        }
      };

      return E;
    }
  };

  // Register farmers market event
  if (typeof EVENTS !== "undefined") { EVENTS.market = { w: 1.2, name: "the farmers market", bonus: 14 }; }
  if (typeof BASE_W !== "undefined") { BASE_W.market = 1.2; }

  // Hook into startEvent for market type
  var _startEventMarket = startEvent;
  startEvent = function(type) {
    if (type === "market") {
      try {
        var E = FarmersMarket.start();
        if (E && typeof S !== "undefined") S.evHist = (S.evHist || []).concat(type).slice(-8);
        return E;
      } catch(e) { return null; }
    }
    return _startEventMarket(type);
  };

  /* =========================================================
     6. MORE BIRDS — extend existing Birds system
     ========================================================= */
  if (typeof Birds !== "undefined" && typeof Birds.init === "function") {
    var _birdsInit = Birds.init;
    Birds.init = function() {
      _birdsInit.call(this);
      try {
        var pigeonColors = ["#6b6b6e", "#5a5a5e", "#7a7a7e", "#4a4a4e"];
        var extra = 6;
        for (var k = 0; k < extra; k++) {
          var i = this.list.length;
          var benches = World.benches || [];
          var B = benches[Math.floor(Math.random() * Math.max(1, benches.length))] || { x: 0, z: 0 };
          var px = B.x + rand(-4, 4), pz = B.z + rand(-4, 4);
          this.list.push(Object.assign({
            kind: "pigeon", s: 0.12, x: px, y: 0, z: pz,
            h: rand(0, 6.28), t: Math.random() * 100, flap: 0,
            home: { x: px, z: pz }, state: "ground", wait: rand(0.5, 2), hop: 0
          }));
          try { this.list[i].y = groundY(px, pz); } catch(e) {}
          var col = new THREE.Color();
          var c = pigeonColors[k % pigeonColors.length];
          if (this.mb && this.mb.instanceColor) {
            this.mb.setColorAt(i, col.copy(lin(c)));
            this.mh.setColorAt(i, col.copy(lin(c)));
            this.mw.setColorAt(2*i, col.copy(lin(c)).multiplyScalar(0.9));
            this.mw.setColorAt(2*i+1, col.copy(lin(c)).multiplyScalar(0.9));
            this.mb.instanceColor.needsUpdate = true;
            this.mh.instanceColor.needsUpdate = true;
            this.mw.instanceColor.needsUpdate = true;
          }
        }
      } catch(e) {}
    };
  }

  console.info("[Snap City] Patch 46 loaded: randomized event NPCs, stray cats, helicopters, farmers market, more birds.");
})();
