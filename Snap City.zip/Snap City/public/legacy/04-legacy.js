
/* =========================================================
   Weather: rain (wet asphalt, puddles, falling streaks)
   ========================================================= */
function puddleTex(){
  const c = document.createElement("canvas"); c.width = c.height = 512; const x = c.getContext("2d"), r = mulberry(404);
  x.fillStyle = "rgb(95,95,95)"; x.fillRect(0,0,512,512);
  for (let i=0;i<2600;i++){ const v = 70 + r()*60 | 0; x.fillStyle = `rgba(${v},${v},${v},.35)`; x.fillRect(r()*512, r()*512, 2+r()*5, 2+r()*5); }
  for (let i=0;i<9;i++){ const px = r()*512, py = r()*512, rad = 25 + r()*70;
    for (let k=0;k<6;k++){ const g = x.createRadialGradient(px + (r()-0.5)*rad, py + (r()-0.5)*rad*0.6, 0, px, py, rad*(0.5+r()*0.6)); g.addColorStop(0, "rgba(14,14,14,1)"); g.addColorStop(0.7, "rgba(18,18,18,.9)"); g.addColorStop(1, "rgba(18,18,18,0)"); x.fillStyle = g; x.fillRect(px-rad*1.5, py-rad*1.5, rad*3, rad*3); } }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; return t;
}
// lighting and sky under rain; runs inside applyTime before the reflection map is rebuilt
function applyWeather(T){
  const m = World.mats;
  m.pool.opacity = T.lamps*0.85*(S.rain ? 1.5 : 1);
  if (!S.rain) return;
  World.sun.intensity *= 0.28; World.hemi.intensity *= 0.82;
  const rc = lin(mixHex(T.fog, T.id==="night" ? "#262a30" : "#858d93", T.id==="night" ? 0.6 : 0.75));
  World.scene.fog.color.copy(rc); World.scene.fog.density = Math.max(World.scene.fog.density, T.id==="night" ? 0.006 : 0.0085);
  World.skyMat.uniforms.top.value.lerp(rc, 0.85); World.skyMat.uniforms.bot.value.lerp(rc, 0.9); World.skyMat.uniforms.sunAmt.value *= 0.12;
}
// wet surfaces: dark, glossy asphalt with mirror puddles reflecting the sky and lights
function wetSurfaces(){
  const m = World.mats, wet = !!S.rain;
  if (!World.puddle) World.puddle = puddleTex();
  for (const [mat, dry, dark, envI] of [[m.road, 0.95, 0.5, 0.9], [m.walk, 0.92, 0.62, 0.22]]){
    const want = wet ? World.puddle : null, env = wet && Env.rt ? Env.rt.texture : null;
    if (mat.roughnessMap !== want || !!mat.envMap !== !!env) mat.needsUpdate = true;
    mat.roughnessMap = want; mat.envMap = env; mat.envMapIntensity = envI;
    mat.roughness = wet ? 1.0 : dry; mat.metalness = wet ? 0.15 : 0; mat.color.setScalar(wet ? dark : 1);
  }
  if (Rain.mesh) Rain.mesh.visible = wet;
  if (wet && !Refl.rt && G.renderer) Refl.setup();
}
const Rain = {
  mesh:null, len:0.45,
  init(scene){
    const n = 5000, pos = new Float32Array(n*6), end = new Float32Array(n*2), r = mulberry(8);
    for (let i=0;i<n;i++){ const x = r()*40, y = r()*24, z = r()*40; pos.set([x,y,z, x,y,z], i*6); end[i*2] = 0; end[i*2+1] = 1; }
    const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.BufferAttribute(pos,3)); g.setAttribute("aEnd", new THREE.BufferAttribute(end,1));
    const mat = new THREE.ShaderMaterial({ transparent:true, depthWrite:false, uniforms:{ uWind:{value:new THREE.Vector2(0.6,0)}, uTime:{value:0}, uCam:{value:new THREE.Vector3()}, uLen:{value:0.45}, uCol:{value:new THREE.Color(0.8,0.82,0.85)}, uA:{value:0.32} },
      vertexShader:`attribute float aEnd; uniform vec2 uWind; uniform float uTime; uniform vec3 uCam; uniform float uLen; varying float vA;
        void main(){ vec3 p = position; p.y = mod(p.y - uTime*9.0, 24.0) - 7.0 + uCam.y; p.x = mod(p.x - uCam.x - uTime*uWind.x, 40.0) - 20.0 + uCam.x; p.z = mod(p.z - uCam.z - uTime*uWind.y, 40.0) - 20.0 + uCam.z;
          p.y += aEnd*uLen; p.x += aEnd*uLen*0.066*uWind.x; p.z += aEnd*uLen*0.066*uWind.y; vec4 mv = modelViewMatrix*vec4(p,1.0); gl_Position = projectionMatrix*mv; vA = clamp(1.0 - (-mv.z)/22.0, 0.0, 1.0)*(0.4 + 0.6*aEnd); }`,
      fragmentShader:`uniform vec3 uCol; uniform float uA; varying float vA; void main(){ gl_FragColor = vec4(uCol, uA*vA); }` });
    this.mesh = new THREE.LineSegments(g, mat); this.mesh.frustumCulled = false; this.mesh.visible = false; this.mesh.renderOrder = 6; scene.add(this.mesh);
  },
  update(dt, camPos){
    if (!this.mesh || !this.mesh.visible) return; const u = this.mesh.material.uniforms;
    u.uTime.value += dt; u.uCam.value.copy(camPos); u.uLen.value = this.len;
    const T = World.timeDef || TIMES[2]; u.uCol.value.copy(lin(T.fog)).multiplyScalar(T.id==="night" ? 1.6 : 1.1); u.uA.value = T.id==="night" ? 0.5 : 0.35;
  }
};
