
/* =========================================================
   Street plays: a fire, a bank robbery, a protest. Each unfolds over minutes,
   with vehicles, crowds and sound, and plays out a little differently every time.
   ========================================================= */
const PLAY = { veh:{} };
function roleActors(role, n){ const f = Life.people.filter(p=>p.pool && p.role === role && !p.busy); return f.slice(0, n); }
function genActors(n){ return Life.people.filter(p=>p.pool && !p.role && !p.busy).slice(0, n); }
function mkVehicle(kind){
  let g;
  if (kind === "engine"){ g = buildCarGroup("boxtruck", lin("#b3171b"), { boxCol: lin("#b3171b") }, [Life.carLightMats[0], CarMats.tailOff]);
    const w = new THREE.MeshStandardMaterial({ color:lin("#f2efe6"), roughness:0.5 }), ch = new THREE.MeshStandardMaterial({ color:lin("#c9c9c4"), roughness:0.3, metalness:0.9 });
    for (const sx of [-1,1]){ const st = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.12, 6.0), w); st.position.set(sx*1.11, 1.2, -0.2); g.add(st); }
    const lad = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.12, 4.8), ch); lad.position.set(0, 3.2, -0.6); g.add(lad);
    for (let k=0;k<12;k++){ const rung = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.03, 0.04), ch); rung.position.set(0, 3.28, -2.8 + k*0.4); g.add(rung); }
  } else { g = buildCarGroup("sedan", lin("#f2f2ee"), { twoTone: lin("#15171a") }, [Life.carLightMats[0], CarMats.tailOff]);
    const band = new THREE.Mesh(new THREE.BoxGeometry(1.86, 0.34, 1.6), new THREE.MeshStandardMaterial({ color:lin("#15171a"), roughness:0.4 })); band.position.set(0, 0.62, 1.55); g.add(band); }
  const mk = c => new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.11, 0.22), new THREE.MeshStandardMaterial({ color:lin(c), emissive:lin(c), emissiveIntensity:0.3 }));
  const r = mk(kind === "engine" ? "#ff2020" : "#ff2020"), b = mk(kind === "engine" ? "#ff2020" : "#2050ff"); const top = kind === "engine" ? 3.0 : 1.55;
  r.position.set(-0.3, top, kind === "engine" ? 2.4 : -0.1); b.position.set(0.3, top, kind === "engine" ? 2.4 : -0.1); g.add(r, b); g.userData.bar = [r, b]; g.visible = false; World.scene.add(g);
  return { g, x:0, z:0, h:0, speed:0, kind };
}
function vehicle(key){ return PLAY.veh[key] || (PLAY.veh[key] = mkVehicle(key.startsWith("engine") ? "engine" : "police")); }
function vehDrive(v, tx, tz, dt, vmax){ const dx = tx - v.x, dz = tz - v.z, d = Math.hypot(dx, dz); if (d < 0.3){ v.speed = 0; return true; }
  v.speed = Math.min(vmax, Math.max(1.5, d*0.6)); const st = Math.min(d, v.speed*dt); v.x += dx/d*st; v.z += dz/d*st; v.h = Math.atan2(dx, dz); vehPlace(v); return false; }
function vehPlace(v){ v.g.position.set(v.x, H(v.x, v.z) + 0.02, v.z); v.g.rotation.y = v.h; v.g.visible = true; }
function vehLights(v, on, t){ const f = on ? Math.floor(t*6 + (v.kind === "engine" ? 1 : 0)) % 2 : -1; v.g.userData.bar[0].material.emissiveIntensity = f === 1 ? 9 : 0.3; v.g.userData.bar[1].material.emissiveIntensity = f === 0 ? 9 : 0.3; }
// the street next to a sidewalk spot: returns lane point and direction along it
function streetFor(near){ const o = near.out, a = near.along, off = P/2 - (HALF + 2.3); return { x: near.x + o[0]*(off - 2.2), z: near.z + o[1]*(off - 2.2), ax:a[0], az:a[1] }; }
const FIRE = { light:null, glow:null };
function fireFx(pos, amt, t){
  if (!FIRE.light){ FIRE.light = new THREE.PointLight(0xff7a2a, 0, 22, 2); World.scene.add(FIRE.light); FIRE.glow = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 1.3), new THREE.MeshBasicMaterial({ color:0xff8a3a, transparent:true, opacity:0, blending:THREE.AdditiveBlending, depthWrite:false })); World.scene.add(FIRE.glow); }
  if (!pos || amt <= 0){ FIRE.light.intensity = 0; FIRE.glow.material.opacity = 0; return; }
  const fl = 0.75 + 0.25*Math.sin(t*23) * Math.sin(t*7.3); FIRE.light.position.set(pos.x + pos.ox*1.2, pos.y, pos.z + pos.oz*1.2); FIRE.light.intensity = 60*amt*fl;
  FIRE.glow.position.set(pos.x + pos.ox*0.08, pos.y, pos.z + pos.oz*0.08); FIRE.glow.rotation.y = Math.atan2(pos.ox, pos.oz); FIRE.glow.material.opacity = 0.9*amt*fl;
}
const SMOKE_DARK = new THREE.Color(0.08, 0.075, 0.07), SMOKE_GREY = new THREE.Color(0.45, 0.45, 0.46), WATER = new THREE.Color(0.75, 0.82, 0.9), FLAME = new THREE.Color(1.6, 0.6, 0.15);
function startPlay(type){
  const near = evSpot(30, 85); if (!near) return null;
  const st = streetFor(near), E = { type, t:0, ppl:[], done:false, info:EVENTS[type], x:near.x, z:near.z, play:true };
  const faceTo = (p, x, z) => { p.heading = Math.atan2(x - p.x, z - p.z); };
  if (type === "fire"){
    const crew = roleActors("fire", 3 + (Math.random() < 0.5 ? 1 : 0)), crowd = genActors(3 + (Math.random()*3|0)); if (crew.length < 3 || crowd.length < 3) return null;
    const floor = 1 + (Math.random()*3|0), win = { x: near.x - near.out[0]*2.45 + near.along[0]*rand(-6,6), z: near.z - near.out[1]*2.45 + near.along[1]*rand(-6,6), ox: near.out[0], oz: near.out[1] };
    win.y = groundY(win.x, win.z) + 4.5 + floor*3.2 - 3; E.ppl = crew.concat(crowd); E.x = win.x; E.z = win.z;
    const eng = vehicle("engine"), arrive = rand(40, 60), dir = Math.random() < 0.5 ? 1 : -1, park = { x: st.x + st.ax*dir*4, z: st.z + st.az*dir*4 };
    eng.x = park.x - st.ax*dir*160; eng.z = park.z - st.az*dir*160; eng.h = Math.atan2(st.ax*dir, st.az*dir);
    const intensity = rand(0.7, 1.2), dur = rand(170, 230);
    crowd.forEach((p, k) => { evPlace(p, near.x + near.along[0]*rand(-14,14) + near.out[0]*rand(1,3), near.z + near.along[1]*rand(-14,14) + near.out[1]*rand(1,3), 0, "fire"); p.spot = { x: near.x + near.out[0]*(3 + k*0.3) + near.along[0]*(k*1.3 - 3), z: near.z + near.out[1]*(3 + k*0.3) + near.along[1]*(k*1.3 - 3) }; });
    E.step = (dt) => { const t = E.t;
      const burn = t < 75 ? Math.min(1, t/15)*intensity : Math.max(0, intensity*(1 - (t - 75)/50)), white = clamp((t - 80)/40, 0, 1);
      if (burn > 0.02 || white < 1){ const n = Math.random() < (0.6 + burn*0.8) ? 1 : 0; for (let k=0;k<n;k++) Smoke.emit(win.x + win.ox*0.3 + rand(-0.4,0.4), win.y + 0.5, win.z + win.oz*0.3 + rand(-0.4,0.4), win.ox*0.6 + rand(-0.2,0.2), 1.1 + burn, win.oz*0.6 + rand(-0.2,0.2), 0.9 + burn*0.7, rand(8, 12), 0.55*(burn + 0.35*(1-white)), white > 0.3 ? SMOKE_GREY : SMOKE_DARK, 0.25, 0.9); }
      if (burn > 0.2 && Math.random() < burn*0.7) Smoke.emit(win.x + win.ox*0.1 + rand(-0.5,0.5), win.y - 0.3, win.z + win.oz*0.1, rand(-0.1,0.1), 1.5, rand(-0.1,0.1), 0.35, 0.6, 0.8, FLAME, 1.5, 0.4);
      fireFx(win, burn, t);
      if (Math.floor(t/2.3) !== Math.floor((t-dt)/2.3) && burn > 0.3) SND.play("crackle", win.x, win.z, 0.5 + burn*0.5);
      crowd.forEach((p, k) => { if (t < 12) return; if (t < dur - 25){ if (!evWalk(p, p.spot.x, p.spot.z, 1.5, dt)){} else { faceTo(p, win.x, win.z); p.evPose = t < 60 ? (k % 3 === 0 ? "point" : k % 3 === 1 ? "handsface" : null) : t > 125 && t < 140 ? "clap" : null; p.act = (k === 2 && t < 90) ? "phone" : "idle"; p.headPitch = -0.35; } } else { p.evPose = null; p.headPitch = 0; evWalk(p, p.spot.x + near.along[0]*30, p.spot.z + near.along[1]*30, 1.3, dt); } });
      if (t > 20 && t - dt <= 20) SND.play("crowd", near.x, near.z, 1);
      if (t > arrive - 25 && t < arrive + 5 && Math.floor(t/3.2) !== Math.floor((t-dt)/3.2)) SND.play("siren", eng.x, eng.z, 1.6);
      if (t > arrive - 25 && t < dur - 20){ vehDrive(eng, park.x, park.z, dt, 13); vehLights(eng, true, t); }
      if (t > arrive + 3 && t < dur - 22){ crew.forEach((p, k) => { if (p.hidden) evPlace(p, eng.x + st.az*1.4*(k%2?1:-1), eng.z - st.ax*1.4*(k%2?1:-1), 0, "fire");
        const tx = near.x + near.out[0]*1.6 + near.along[0]*(k*1.6 - 2.4), tz = near.z + near.out[1]*1.6 + near.along[1]*(k*1.6 - 2.4);
        if (evWalk(p, tx, tz, 2.6, dt)){ faceTo(p, win.x, win.z); p.headPitch = -0.3; p.evPose = (k === 0 && t < 135) ? "hose" : (k === 1 && t < 125) ? "point" : t > 140 ? "radio" : null; }
        if (k === 0 && t < 135 && !p.evMoving){ const hx = p.x + Math.sin(p.heading)*0.6, hz = p.z + Math.cos(p.heading)*0.6, hy = p.y + 1.25; for (let j=0;j<3;j++){ const dx = win.x - hx, dz = win.z - hz, dh = Math.hypot(dx, dz); Smoke.emit(hx, hy, hz, dx/dh*9 + rand(-0.4,0.4), 5.2 + (win.y - hy)*0.35 + rand(-0.3,0.3), dz/dh*9 + rand(-0.4,0.4), 0.12, 1.4, 0.55, WATER, -7, 0.5); } } }); }
      if (t > dur - 22){ crew.forEach(p => { if (!p.hidden && evWalk(p, eng.x, eng.z, 2.4, dt)) { p.hidden = true; p.busy = true; } }); }
      if (t > dur - 12){ vehDrive(eng, park.x + st.ax*dir*200, park.z + st.az*dir*200, dt, 9); vehLights(eng, false, t); }
      if (t > dur){ eng.g.visible = false; fireFx(null, 0); E.done = true; } };
  }
  else if (type === "robbery"){
    const robbers = roleActors("robber", 2), cops = roleActors("police", 2 + (Math.random() < 0.6 ? 2 : 0)), crowd = genActors(3); if (robbers.length < 2 || cops.length < 2) return null;
    const dir = Math.random() < 0.5 ? 1 : -1, caught = Math.random() < 0.35, getaway = !caught && Math.random() < 0.5, door = { x: near.x - near.out[0]*1.9, z: near.z - near.out[1]*1.9 };
    E.ppl = robbers.concat(cops, crowd); E.x = door.x; E.z = door.z;
    const escape = { x: near.x + near.along[0]*dir*70, z: near.z + near.along[1]*dir*70 }, catchAt = { x: near.x + near.along[0]*dir*28 + near.out[0]*0.8, z: near.z + near.along[1]*dir*28 + near.out[1]*0.8 };
    const p1 = vehicle("police1"), p2 = vehicle("police2"), park1 = { x: st.x - st.ax*dir*3, z: st.z - st.az*dir*3 }, park2 = caught ? { x: st.x + st.ax*dir*27, z: st.z + st.az*dir*27 } : { x: st.x + st.ax*dir*9, z: st.z + st.az*dir*9 };
    for (const [v, pk, off] of [[p1, park1, 150], [p2, park2, -150]]){ v.x = pk.x - st.ax*dir*off; v.z = pk.z - st.az*dir*off; v.h = Math.atan2(st.ax*dir*Math.sign(off), st.az*dir*Math.sign(off)); }
    const getCar = getaway ? vehicle("getaway") : null;
    crowd.forEach((p, k) => { evPlace(p, near.x + near.along[0]*(k*2 - 2 - dir*6) + near.out[0]*0.8, near.z + near.along[1]*(k*2 - 2 - dir*6) + near.out[1]*0.8, Math.atan2(near.along[0]*dir, near.along[1]*dir), "robbery"); });
    const dur = rand(150, 200);
    E.step = (dt) => { const t = E.t;
      if (Math.floor(t/1.1) !== Math.floor((t-dt)/1.1) && t < 60) SND.play("bell", door.x, door.z, 0.8);
      if (t > 1 && t < 25){ robbers.forEach((p, k) => { if (p.hidden){ evPlace(p, door.x + near.along[0]*k*0.8, door.z + near.along[1]*k*0.8, 0, "robbery"); p.look.anim = "jog"; }
          const tgt = caught ? catchAt : escape; if (!(caught && t > 14)) evWalk(p, tgt.x + near.along[0]*k*0.9, tgt.z + near.along[1]*k*0.9, 4.6, dt); p.evPose = "run"; if (getaway && t > 14){ p.hidden = true; } }); }
      if (getaway){ if (t > 12 && t < 16){ getCar.x = escape.x - near.along[0]*dir*40 + near.out[0]*4.5; getCar.z = escape.z - near.along[1]*dir*40 + near.out[1]*4.5; getCar.h = Math.atan2(near.along[0]*dir, near.along[1]*dir); vehPlace(getCar); } if (t > 16 && t < 30){ vehDrive(getCar, getCar.x + near.along[0]*dir*300, getCar.z + near.along[1]*dir*300, dt, 16); if (t - dt <= 16) SND.play("horn", getCar.x, getCar.z, 1); } if (t > 30) getCar.g.visible = false; }
      if (!caught && !getaway && t > 25) robbers.forEach(p => { p.hidden = true; });
      crowd.forEach((p, k) => { if (t > 2 && t < 30){ faceTo(p, robbers[0].x, robbers[0].z); p.evPose = t < 8 && k === 0 ? "duck" : t < 12 ? "handsface" : k === 1 ? "point" : null; p.act = k === 2 ? "phone" : "idle"; } else if (t > dur - 25){ p.evPose = null; evWalk(p, p.x - near.along[0]*dir*40, p.z - near.along[1]*dir*40, 1.3, dt); } });
      if (t > 10 && t < 36 && Math.floor(t/3.2) !== Math.floor((t-dt)/3.2)) SND.play("siren", p1.x, p1.z, 1.4);
      if (t > 14 && t < dur - 18){ vehDrive(p1, park1.x, park1.z, dt, 15); vehDrive(p2, park2.x, park2.z, dt, 15); vehLights(p1, true, t); vehLights(p2, true, t + 0.3); }
      if (t > 34 && t < dur - 18){ cops.forEach((p, k) => { const v = k % 2 ? p2 : p1; if (p.hidden) evPlace(p, v.x + st.az*1.4, v.z - st.ax*1.4, 0, "robbery");
          if (caught && k % 2 === 1){ if (evWalk(p, catchAt.x - near.along[0]*dir*1.8, catchAt.z - near.along[1]*dir*1.8, 3, dt)){ faceTo(p, robbers[0].x, robbers[0].z); p.evPose = "point"; } }
          else { const wt = crowd[k % crowd.length]; if (evWalk(p, wt.x - near.along[0]*dir*1.1, wt.z - near.along[1]*dir*1.1, 2.2, dt)){ faceTo(p, wt.x, wt.z); p.evPose = k === 0 ? "radio" : null; faceTo(wt, p.x, p.z); wt.evPose = t % 12 < 4 ? "point" : null; } } });
        if (caught) robbers.forEach(p => { p.look.anim = "walk"; p.evPose = "handsup"; faceTo(p, cops[1] ? cops[1].x : cops[0].x, cops[1] ? cops[1].z : cops[0].z); }); }
      if (t > 40 && Math.floor(t/9) !== Math.floor((t-dt)/9) && t < dur - 20) SND.play("radio", p1.x, p1.z, 0.7);
      if (t > dur - 18){ cops.forEach((p, k) => { const v = k % 2 ? p2 : p1; if (!p.hidden && evWalk(p, v.x, v.z, 2.2, dt)) p.hidden = true; }); if (caught) robbers.forEach(p => { if (!p.hidden && evWalk(p, p2.x, p2.z, 1.6, dt)) p.hidden = true; }); }
      if (t > dur - 8){ vehDrive(p1, p1.x + st.ax*dir*200, p1.z + st.az*dir*200, dt, 10); vehDrive(p2, p2.x + st.ax*dir*200, p2.z + st.az*dir*200, dt, 10); vehLights(p1, false, t); vehLights(p2, false, t); }
      if (t > dur){ p1.g.visible = p2.g.visible = false; robbers.forEach(p => p.look.anim = "walk"); E.done = true; } };
  }
  else if (type === "protest"){
    const n = 7 + (Math.random()*6|0), marchers = genActors(n), cops = roleActors("police", 2); if (marchers.length < 6) return null;
    E.ppl = marchers.concat(cops); const dir = Math.random() < 0.5 ? 1 : -1, ax = [near.along[0]*dir, near.along[1]*dir], o = near.out;
    const start = { x: near.x - ax[0]*70, z: near.z - ax[1]*70 }, rally = { x: near.x + ax[0]*6, z: near.z + ax[1]*6 }, end = { x: near.x + ax[0]*110, z: near.z + ax[1]*110 };
    marchers.forEach((p, k) => { const row = k >> 1, side = (k & 1) ? 1 : -1; p.off = { a: -row*1.4, o: side*0.7 + o[0]*0 }; evPlace(p, start.x + ax[0]*p.off.a + o[0]*p.off.o, start.z + ax[1]*p.off.a + o[1]*p.off.o, Math.atan2(ax[0], ax[1]), "protest"); p.evSign = k > 0 && Math.random() < 0.75; });
    cops.forEach((p, k) => { evPlace(p, start.x + ax[0]*(k*-6) + o[0]*3.4, start.z + ax[1]*(k*-6) + o[1]*3.4, 0, "protest"); });
    const march = (to, sp, dt) => { let all = true; marchers.forEach(p => { if (!evWalk(p, to.x + ax[0]*p.off.a + o[0]*p.off.o, to.z + ax[1]*p.off.a + o[1]*p.off.o, sp, dt)) all = false; }); cops.forEach((p, k) => evWalk(p, to.x + ax[0]*(k*-6 - 1) + o[0]*3.4, to.z + ax[1]*(k*-6 - 1) + o[1]*3.4, sp, dt)); return all; };
    const rallyT = rand(30, 50), dur = rallyT + rand(110, 160);
    E.step = (dt) => { const t = E.t, leader = marchers[0];
      if (Math.floor(t/2.1) !== Math.floor((t-dt)/2.1)) SND.play("chant", leader.x, leader.z, 1.1);
      if (t < rallyT + 70){ const arrived = march(rally, 1.0, dt); leader.evPose = "fist"; if (arrived) marchers.slice(1).forEach(p => { faceTo(p, leader.x, leader.z); });
        if (t > rallyT + 20 && t < rallyT + 65){ faceTo(leader, near.x + o[0]*4, near.z + o[1]*4); leader.evPose = Math.floor(t/2) % 2 ? "shout" : "fist"; marchers.slice(1).forEach((p, k) => { if (!p.evSign) p.evPose = (Math.floor(t/2.5 + k) % 4 === 0) ? "cheer" : null; }); if (Math.floor(t/12) !== Math.floor((t-dt)/12)) SND.play("applause", leader.x, leader.z, 1.2); } }
      else { march(end, 1.05, dt); marchers.forEach(p => { if (!p.evSign) p.evPose = null; }); leader.evPose = "fist"; }
      if (t > dur){ marchers.forEach(p => { p.evSign = false; }); E.done = true; } };
  }
  return E;
}
EVENTS.fire = { w:0.8, play:true, name:"the fire and the crew who put it out", bonus:18 };
EVENTS.robbery = { w:0.7, play:true, name:"the robbery and the police response", bonus:18 };
EVENTS.protest = { w:0.9, play:true, name:"the protest march", bonus:14 };
const _startEventBase = startEvent;
startEvent = function(type){ return EVENTS[type] && EVENTS[type].play ? startPlay(type) : _startEventBase(type); };

/* ---------- extra sounds for the plays and the city ---------- */
const _sndPlayBase = SND.play.bind(SND);
SND.play = function(kind, x, z, vol=1){
  if (!this.init()) return; const c = this.ctx, t = c.currentTime;
  const out = () => this.node(x, z, vol), g = (o) => { const n = c.createGain(); n.connect(o); return n; };
  if (kind === "bell"){ const o = out(); for (let k=0;k<10;k++){ const e = g(o); this.env(e, t + k*0.1, 0.22, 0.09); this.osc(e, t + k*0.1, 0.09, "square", 1250); } return; }
  if (kind === "crackle"){ const o = out(); for (let k=0;k<25;k++){ const t0 = t + Math.random()*2.2, e = g(o); this.env(e, t0, 0.3*Math.random() + 0.05, 0.04); this.noise(e, t0, 0.05, "bandpass", 800 + Math.random()*2500, 1.5); } const r = g(o); r.gain.value = 0.12; this.noise(r, t, 2.3, "lowpass", 300, 0.7); return; }
  if (kind === "radio"){ const o = out(); const e = g(o); this.env(e, t, 0.2, 0.9); this.noise(e, t, 0.9, "bandpass", 1600, 3); const e2 = g(o); this.env(e2, t + 0.9, 0.2, 0.12); this.osc(e2, t + 0.9, 0.12, "sine", 1400); return; }
  if (kind === "chirp"){ const o = out(); for (let k=0;k<2 + (Math.random()*4|0);k++){ const t0 = t + k*(0.1 + Math.random()*0.1), e = g(o); this.env(e, t0, 0.12, 0.08); const os = this.osc(e, t0, 0.09, "sine", 3000 + Math.random()*1800); os.frequency.exponentialRampToValueAtTime(2200 + Math.random()*2500, t0 + 0.08); } return; }
  if (kind === "gull"){ const o = out(); for (let k=0;k<3;k++){ const t0 = t + k*0.35, e = g(o); this.env(e, t0, 0.14, 0.3); const os = this.osc(e, t0, 0.3, "sawtooth", 900); os.frequency.linearRampToValueAtTime(1500, t0 + 0.08); os.frequency.linearRampToValueAtTime(700, t0 + 0.3); } return; }
  if (kind === "caw"){ const o = out(); for (let k=0;k<2;k++){ const t0 = t + k*0.45, e = g(o); this.env(e, t0, 0.15, 0.25); this.noise(e, t0, 0.26, "bandpass", 900, 4); this.osc(e, t0, 0.25, "sawtooth", 420); } return; }
  if (kind === "voices"){ const o = out(); const e = g(o); e.gain.setValueAtTime(0.0001, t); e.gain.exponentialRampToValueAtTime(0.08, t + 0.5); e.gain.exponentialRampToValueAtTime(0.0001, t + 3); this.noise(e, t, 3.1, "bandpass", 700, 1.2); for (let k=0;k<3;k++){ const t0 = t + Math.random()*2.4, e2 = g(o); this.env(e2, t0, 0.06, 0.25); this.osc(e2, t0, 0.25, "sawtooth", 160 + Math.random()*120); } return; }
  return _sndPlayBase(kind, x, z, vol);
};
/* ambient city: subtle, positional, never constant */
const AMB = { t:3 };
function ambience(dt){
  AMB.t -= dt; if (AMB.t > 0) return; AMB.t = rand(2.5, 6.5);
  const T = World.timeDef || TIMES[2], night = T.id === "night", a = rand(0, 6.28), d = rand(18, 70), x = Player.x + Math.cos(a)*d, z = Player.z + Math.sin(a)*d, r = Math.random();
  if (!night && !S.rain && r < 0.42) SND.play("chirp", x, z, 0.35);
  else if (r < 0.5 && T.id !== "night") SND.play("gull", Player.x + Math.cos(a)*90, Player.z + Math.sin(a)*90, 0.4);
  else if (r < 0.58) SND.play("caw", x, z, 0.35);
  else if (r < 0.66) SND.play("siren", Player.x + Math.cos(a)*420, Player.z + Math.sin(a)*420, 0.25);
  else if (r < 0.74) SND.play("horn", x*1.4 - Player.x*0.4, z*1.4 - Player.z*0.4, 0.35);
  else if (r < 0.8) SND.play("bark", x, z, 0.3);
  else if (r < 0.9) SND.play("voices", x*0.6 + Player.x*0.4, z*0.6 + Player.z*0.4, 0.8);
}
const _gpUpdateBase = gameplayUpdate;
gameplayUpdate = function(dt){ _gpUpdateBase(dt); if (Game.started){ ambience(dt); Birds.update(dt); } };

/* ---------- more birds: gulls wheeling overhead, crows on the lamp posts, sparrows by the benches ---------- */
const Birds = {
  list:[], mesh:null,
  init(){
    const n = 9 + 8 + 18, mat = new THREE.MeshStandardMaterial({ color:0xffffff, roughness:0.85 });
    const body = new THREE.SphereGeometry(1, 10, 8).scale(0.45, 0.4, 1).toNonIndexed(), wing = new THREE.PlaneGeometry(1, 0.42).translate(0.5, 0, 0).rotateX(-Math.PI/2).toNonIndexed();
    const mk = (g_, c) => { const m = new THREE.InstancedMesh(g_, mat, c); m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); m.frustumCulled = false; m.castShadow = true; World.scene.add(m); return m; };
    mat.side = THREE.DoubleSide; this.mb = mk(body, n); this.mw = mk(wing, n*2); this.mh = mk(new THREE.SphereGeometry(0.42, 8, 6).toNonIndexed(), n);
    const col = new THREE.Color(), add = (kind, s, c, hc, extra) => { const i = this.list.length; this.list.push(Object.assign({ kind, s, x:Player.x, y:30, z:Player.z, h:0, t:Math.random()*100, flap:Math.random()*6 }, extra)); this.mb.setColorAt(i, col.copy(lin(c))); this.mh.setColorAt(i, col.copy(lin(hc))); this.mw.setColorAt(2*i, col.copy(lin(c)).multiplyScalar(0.9)); this.mw.setColorAt(2*i+1, col.copy(lin(c)).multiplyScalar(0.9)); };
    for (let k=0;k<9;k++) add("gull", 0.34, "#f2f2ee", "#f4f4f0", { r: rand(25, 70), alt: rand(22, 48), sp: rand(6, 9)*(Math.random()<0.5?1:-1), cx: rand(-150,150), cz: rand(-150,150) });
    const lamps = (World.lamps||[]).slice(); for (let k=0;k<8;k++){ const L = lamps[(Math.random()*lamps.length)|0] || { x:0, z:0 }; add("crow", 0.2, "#16161a", "#101014", { perch:{ x:L.x, z:L.z, y:(L.y ?? groundY(L.x, L.z) + 6) + 0.35 }, state:"perch", wait: rand(5, 30) }); }
    const benches = (World.benches||[]).slice(); for (let k=0;k<18;k++){ const B = benches[((k/3)|0) % Math.max(1, benches.length)] || { x:0, z:0 }; add("sparrow", 0.085, ["#7a5a3a","#8a6a48","#6b4a2e"][k%3], "#5a3a26", { home:{ x:B.x + rand(-2,2), z:B.z + rand(-2,2) }, state:"ground", wait:rand(0.5,2) }); }
    for (const m of [this.mb, this.mw, this.mh]) m.instanceColor.needsUpdate = true;
    this.list.forEach(b => { if (b.kind === "sparrow"){ b.x = b.home.x; b.z = b.home.z; b.y = groundY(b.x, b.z); } if (b.kind === "crow"){ b.x = b.perch.x; b.z = b.perch.z; b.y = b.perch.y; } });
  },
  update(dt){
    if (!this.mb){ if (World.lamps) this.init(); else return; }
    const m = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), v = new THREE.Vector3(), sc = new THREE.Vector3(), T = World.timeDef || TIMES[2];
    this.list.forEach((b, i) => {
      b.t += dt; let flap = 0, open = 1, bank = 0;
      if (b.kind === "gull"){ if (T.id === "night"){ b.y = -50; } else { const a = b.t*b.sp/b.r; b.x = b.cx + Math.cos(a)*b.r; b.z = b.cz + Math.sin(a)*b.r; b.y = b.alt + Math.sin(b.t*0.3)*3; b.h = a + (b.sp > 0 ? Math.PI : 0); bank = b.sp > 0 ? 0.35 : -0.35; flap = (Math.sin(b.t*0.4) > 0.7) ? Math.sin(b.t*9)*0.5 : 0.08; if (Math.hypot(b.cx - Player.x, b.cz - Player.z) > 220){ b.cx = Player.x + rand(-120,120); b.cz = Player.z + rand(-120,120); } } }
      else if (b.kind === "crow"){ if (b.state === "perch"){ open = 0; b.wait -= dt; b.h += Math.sin(b.t*0.7)*dt*0.5; if (b.wait < 0){ const lamps = World.lamps || []; const near = lamps.filter(L => Math.hypot(L.x - b.x, L.z - b.z) < 60); const L = near[(Math.random()*near.length)|0]; if (L){ b.from = { x:b.x, y:b.y, z:b.z }; b.perch = { x:L.x, z:L.z, y:(L.y ?? groundY(L.x, L.z) + 6) + 0.35 }; b.state = "fly"; b.ft = 0; b.fd = Math.max(1.5, Math.hypot(L.x - b.x, L.z - b.z)/7); if (Math.random() < 0.5) SND.play("caw", b.x, b.z, 0.4); } b.wait = rand(8, 40); } }
        else { b.ft += dt/b.fd; const u = Math.min(1, b.ft); b.x = lerp(b.from.x, b.perch.x, u); b.z = lerp(b.from.z, b.perch.z, u); b.y = lerp(b.from.y, b.perch.y, u) + Math.sin(u*Math.PI)*4; b.h = Math.atan2(b.perch.x - b.from.x, b.perch.z - b.from.z); flap = Math.sin(b.t*14)*0.8; if (u >= 1) b.state = "perch"; } }
      else { const d = Math.hypot(Player.x - b.x, Player.z - b.z); if (b.state === "ground"){ open = 0; b.y = groundY(b.x, b.z); b.wait -= dt; if (b.wait < 0){ b.wait = rand(0.3, 1.5); const a = rand(0, 6.28); const nx = b.x + Math.cos(a)*0.25, nz = b.z + Math.sin(a)*0.25; if (Math.hypot(nx - b.home.x, nz - b.home.z) < 2.5){ b.x = nx; b.z = nz; b.h = Math.atan2(Math.cos(a), Math.sin(a)); b.hop = 0.15; } } if (b.hop > 0){ b.hop -= dt; b.y += Math.sin(b.hop/0.15*Math.PI)*0.06; } if (d < 3.5 || (b.flee && b.flee > 0)){ b.state = "up"; b.ut = 0; } }
        else { b.ut += dt; flap = Math.sin(b.t*30)*0.9; if (b.ut < 2){ b.y += dt*2.5; b.x += Math.cos(b.h)*dt; } else if (b.ut > 6 && d > 5){ b.y = Math.max(groundY(b.x, b.z), b.y - dt*2); if (b.y <= groundY(b.x, b.z) + 0.01) b.state = "ground"; } } }
      e.set(0, b.h, bank, "YXZ"); q.setFromEuler(e); m.compose(v.set(b.x, b.y, b.z), q, sc.set(b.s, b.s, b.s)); this.mb.setMatrixAt(i, m);
      const hm = m.clone().multiply(new THREE.Matrix4().makeTranslation(0, 0.25, 0.85)); this.mh.setMatrixAt(i, hm);
      const span = b.kind === "gull" ? 2.8 : b.kind === "crow" ? 2.0 : 1.5;
      for (const s_ of [0,1]){ const w = m.clone().multiply(new THREE.Matrix4().makeRotationY(s_ ? Math.PI : 0)).multiply(new THREE.Matrix4().makeRotationZ(open ? flap + 0.05 : -1.3)).multiply(new THREE.Matrix4().makeScale(open ? span : 0.9, 1, 1)); this.mw.setMatrixAt(2*i + s_, w); }
    });
    this.mb.instanceMatrix.needsUpdate = this.mw.instanceMatrix.needsUpdate = this.mh.instanceMatrix.needsUpdate = true;
  }
};
