
// joint tables sampled from motion-captured walk and run cycles (three.js example Xbot, Mixamo animation data)
// columns: thigh0, thigh1, knee0, knee1, arm0, arm1, armZ0, armZ1, elbow0, elbow1, lean, hipYaw, torsoTwist, bob
const MOCAP = {"walk":[[0.073,-0.151,0.099,0.921,0.355,0.123,-0.119,0.083,-0.567,-0.619,-0.014,0.176,-0.193,0.018],[0.127,-0.227,0.093,0.816,0.254,0.183,-0.124,0.065,-0.578,-0.574,-0.009,0.151,-0.149,0.021],[0.176,-0.272,0.097,0.666,0.158,0.254,-0.128,0.052,-0.582,-0.567,-0.001,0.115,-0.092,0.019],[0.226,-0.297,0.102,0.486,0.069,0.328,-0.13,0.04,-0.578,-0.568,0.006,0.072,-0.03,0.015],[0.285,-0.314,0.093,0.306,-0.004,0.393,-0.132,0.03,-0.57,-0.548,0.012,0.028,0.031,0.009],[0.353,-0.334,0.067,0.168,-0.062,0.441,-0.133,0.024,-0.566,-0.496,0.015,-0.01,0.085,0.003],[0.422,-0.364,0.044,0.11,-0.105,0.484,-0.137,0.02,-0.58,-0.45,0.014,-0.042,0.126,-0.006],[0.481,-0.394,0.04,0.124,-0.137,0.537,-0.144,0.012,-0.611,-0.442,0.01,-0.066,0.154,-0.016],[0.521,-0.387,0.06,0.135,-0.172,0.583,-0.15,0.001,-0.63,-0.445,0.007,-0.079,0.164,-0.022],[0.535,-0.326,0.114,0.095,-0.221,0.59,-0.153,-0.008,-0.608,-0.419,0.0,-0.079,0.155,-0.021],[0.513,-0.282,0.228,0.109,-0.25,0.592,-0.155,-0.013,-0.606,-0.426,-0.011,-0.076,0.14,-0.018],[0.442,-0.24,0.427,0.13,-0.243,0.586,-0.155,-0.008,-0.642,-0.458,-0.017,-0.073,0.122,-0.014],[0.339,-0.195,0.62,0.161,-0.21,0.556,-0.151,0.007,-0.687,-0.481,-0.015,-0.061,0.096,-0.007],[0.219,-0.144,0.769,0.172,-0.157,0.504,-0.145,0.025,-0.732,-0.493,-0.009,-0.053,0.074,-0.001],[0.092,-0.082,0.867,0.157,-0.098,0.435,-0.135,0.045,-0.76,-0.49,-0.002,-0.053,0.056,0.006],[-0.024,-0.018,0.894,0.134,-0.042,0.354,-0.125,0.065,-0.763,-0.474,0.004,-0.057,0.034,0.013],[-0.122,0.042,0.852,0.119,0.012,0.274,-0.115,0.083,-0.753,-0.468,0.01,-0.053,-0.001,0.017],[-0.202,0.097,0.752,0.109,0.065,0.201,-0.105,0.102,-0.734,-0.476,0.014,-0.037,-0.051,0.02],[-0.271,0.152,0.607,0.102,0.119,0.132,-0.095,0.121,-0.702,-0.491,0.017,-0.01,-0.113,0.021],[-0.33,0.204,0.432,0.101,0.178,0.069,-0.087,0.141,-0.663,-0.516,0.019,0.021,-0.177,0.02],[-0.369,0.254,0.246,0.108,0.251,0.019,-0.079,0.163,-0.63,-0.555,0.021,0.05,-0.236,0.016],[-0.387,0.3,0.107,0.13,0.34,-0.017,-0.069,0.185,-0.615,-0.613,0.019,0.081,-0.295,0.007],[-0.427,0.328,0.135,0.189,0.448,-0.025,-0.057,0.212,-0.635,-0.718,0.018,0.113,-0.344,-0.008],[-0.437,0.358,0.201,0.233,0.532,-0.032,-0.042,0.23,-0.629,-0.807,0.013,0.137,-0.373,-0.018],[-0.403,0.391,0.226,0.257,0.585,-0.033,-0.027,0.238,-0.603,-0.879,0.004,0.147,-0.377,-0.021],[-0.359,0.41,0.236,0.297,0.61,-0.019,-0.017,0.235,-0.572,-0.944,-0.007,0.151,-0.367,-0.02],[-0.309,0.395,0.227,0.393,0.619,0.016,-0.014,0.226,-0.551,-1.011,-0.017,0.153,-0.351,-0.018],[-0.264,0.332,0.246,0.563,0.609,0.064,-0.019,0.211,-0.534,-1.063,-0.024,0.15,-0.327,-0.015],[-0.222,0.234,0.28,0.757,0.58,0.109,-0.033,0.193,-0.52,-1.077,-0.025,0.146,-0.299,-0.011],[-0.162,0.132,0.267,0.894,0.533,0.141,-0.053,0.169,-0.51,-1.038,-0.022,0.147,-0.272,-0.004],[-0.082,0.035,0.21,0.955,0.468,0.15,-0.075,0.142,-0.497,-0.935,-0.018,0.156,-0.247,0.005],[-0.002,-0.068,0.149,0.967,0.407,0.142,-0.098,0.112,-0.515,-0.792,-0.015,0.173,-0.224,0.013]],"run":[[0.111,-0.526,0.585,2.112,-0.102,0.918,-0.134,0.104,-1.019,-1.427,0.003,-0.048,-0.007,-0.033],[0.257,-0.616,0.468,2.007,-0.316,0.944,-0.085,0.105,-0.944,-1.42,0.002,-0.071,0.095,-0.021],[0.399,-0.674,0.342,1.862,-0.477,0.991,-0.038,0.108,-0.897,-1.443,0.001,-0.094,0.202,-0.009],[0.538,-0.696,0.207,1.674,-0.595,1.061,-0.0,0.111,-0.861,-1.499,-0.001,-0.118,0.315,0.004],[0.626,-0.678,0.151,1.452,-0.657,1.146,0.012,0.109,-0.886,-1.612,-0.001,-0.121,0.405,0.015],[0.674,-0.645,0.167,1.213,-0.706,1.214,0.021,0.104,-0.933,-1.722,-0.001,-0.112,0.471,0.025],[0.672,-0.596,0.276,0.956,-0.743,1.259,0.024,0.097,-1.001,-1.824,-0.001,-0.089,0.509,0.034],[0.645,-0.502,0.444,0.662,-0.748,1.241,0.021,0.089,-1.054,-1.863,-0.001,-0.055,0.507,0.039],[0.608,-0.389,0.634,0.367,-0.733,1.206,0.014,0.083,-1.085,-1.887,-0.001,-0.021,0.487,0.04],[0.559,-0.252,0.85,0.079,-0.688,1.155,0.003,0.079,-1.081,-1.897,-0.003,0.012,0.447,0.035],[0.505,-0.19,1.064,0.04,-0.63,1.078,-0.012,0.087,-0.979,-1.881,-0.007,0.043,0.392,0.021],[0.449,-0.18,1.265,0.139,-0.564,0.981,-0.031,0.097,-0.861,-1.839,-0.012,0.074,0.335,0.004],[0.387,-0.249,1.439,0.435,-0.481,0.85,-0.059,0.106,-0.734,-1.757,-0.016,0.109,0.276,-0.014],[0.302,-0.248,1.572,0.612,-0.37,0.692,-0.092,0.112,-0.679,-1.648,-0.019,0.139,0.216,-0.03],[0.2,-0.21,1.675,0.726,-0.247,0.523,-0.126,0.111,-0.669,-1.534,-0.021,0.162,0.157,-0.043],[0.075,-0.123,1.724,0.755,-0.115,0.346,-0.162,0.103,-0.719,-1.42,-0.024,0.169,0.102,-0.048],[-0.056,-0.002,1.705,0.711,0.022,0.197,-0.193,0.093,-0.806,-1.341,-0.024,0.159,0.05,-0.045],[-0.179,0.129,1.639,0.638,0.174,0.076,-0.217,0.079,-0.936,-1.284,-0.023,0.143,-0.001,-0.036],[-0.274,0.259,1.489,0.541,0.339,-0.002,-0.228,0.068,-1.137,-1.253,-0.019,0.122,-0.057,-0.016],[-0.319,0.339,1.283,0.486,0.498,-0.035,-0.227,0.069,-1.331,-1.263,-0.01,0.098,-0.117,0.005],[-0.335,0.387,1.049,0.473,0.649,-0.055,-0.217,0.077,-1.516,-1.291,-0.002,0.072,-0.176,0.026],[-0.315,0.392,0.8,0.574,0.795,-0.067,-0.203,0.094,-1.695,-1.348,0.008,0.041,-0.221,0.04],[-0.291,0.397,0.574,0.708,0.932,-0.095,-0.184,0.104,-1.859,-1.402,0.015,0.011,-0.245,0.045],[-0.265,0.399,0.37,0.862,1.05,-0.129,-0.158,0.109,-2.001,-1.455,0.02,-0.017,-0.255,0.043],[-0.244,0.391,0.224,1.046,1.096,-0.162,-0.119,0.109,-2.096,-1.493,0.022,-0.035,-0.239,0.033],[-0.234,0.363,0.175,1.247,1.089,-0.153,-0.085,0.11,-2.132,-1.539,0.022,-0.045,-0.212,0.021],[-0.233,0.321,0.198,1.458,1.049,-0.109,-0.06,0.111,-2.126,-1.592,0.02,-0.05,-0.177,0.007],[-0.256,0.261,0.357,1.649,0.957,0.035,-0.077,0.113,-2.028,-1.66,0.018,-0.053,-0.145,-0.008],[-0.255,0.171,0.505,1.821,0.81,0.219,-0.111,0.116,-1.865,-1.7,0.017,-0.058,-0.115,-0.022],[-0.231,0.055,0.639,1.975,0.606,0.434,-0.147,0.114,-1.634,-1.716,0.017,-0.065,-0.087,-0.035],[-0.145,-0.13,0.677,2.078,0.362,0.628,-0.165,0.114,-1.405,-1.604,0.014,-0.066,-0.057,-0.039],[-0.03,-0.325,0.657,2.122,0.12,0.788,-0.16,0.11,-1.222,-1.518,0.01,-0.06,-0.031,-0.038]]};
function mocapSample(tab, ph){ const F = tab.length, u = ((ph/(Math.PI*2)) % 1 + 1) % 1 * F, i0 = Math.floor(u) % F, i1 = (i0+1) % F, f = u - Math.floor(u), a = tab[i0], b = tab[i1]; return a.map((v,k)=> v + (b[k]-v)*f); }
/* =========================================================
   People: appearance generator, articulated instanced bodies, poses
   ========================================================= */
const SKINS = ["#f7dcc8","#f1c7a5","#e9b891","#dca47c","#c98e64","#b0764e","#946040","#7c4e32","#654028","#51331f","#3e2717"];
const HAIRC = ["#15110e","#2a1f17","#3b2a1d","#5a3d26","#7a5534","#a67c52","#caa46a","#e2cf9a","#8f8f8f","#cfcfcf","#efefef","#9b3b24","#c64d9b","#3f7fd0","#58b37a"];
const NEUTRAL = ["#26282c","#3a3f46","#4d5156","#6b6f73","#8e9396","#c9c9c4","#e9e6de","#f4f2ec","#1d2d44","#2f4b5a","#3f5e7a","#5b6e5a","#6f5a45","#8a7a62","#a39580","#7a2e36","#4a3040","#2d4a3c"];
const BRIGHT = ["#d23c2e","#e8b82e","#2f7fc1","#e36f2d","#3aa06b","#c8367a","#8a3fb5","#16a3a3","#f28cb1","#ffd24a","#ff6a3d","#5cc4ff"];
const JEANS = ["#2a3a55","#344a6c","#1f2a3d","#4d6282","#6c83a5","#23272e","#3a3a3a"];
const TROUSERS = ["#26282c","#3c3c3e","#5c5448","#8c8578","#2b3440","#4a4238","#bfb49e","#6b5a45"];
const SHOES = ["#141414","#2a2420","#5a3a26","#e9e6de","#8a8a8a","#b33a2c","#1e3a5f"];
const OUTFITS = [["casual",22],["business",10],["dress",7],["skirt",6],["coat",8],["puffer",5],["hoodie",7],["tourist",4],["jogger",5],["worker",3],["chef",1.5],["nurse",2],["goth",2],["punk",1.5],["hipster",4],["grandma",3],["elder",5],["skater",3],["costume",0.5],["sign",0.5],["modest",3]];
function wpick(list, r){ let t = 0; for (const [,w] of list) t += w; let x = r()*t; for (const [k,w] of list){ if ((x -= w) < 0) return k; } return list[0][0]; }

function dressPerson(p, r){
  const RP = a => a[(r()*a.length)|0], R = (a,b) => a + r()*(b-a);
  const fem = r() < 0.5;
  let age = r(); // 0 young .. 1 old
  const L = { fem, outfit: wpick(OUTFITS, r), hs:R(0.95,1.08), nose:R(0.8,1.5), skin:RP(SKINS), anim:"walk", acc:{} };
  if (L.outfit === "elder" || L.outfit === "grandma") age = R(0.8,1);
  L.age = age;
  L.h = (fem ? R(1.52,1.8) : R(1.62,1.98)) * (age > 0.85 ? 0.96 : 1);
  const br = r(); L.b = br < 0.33 ? R(0.8,0.98) : br < 0.72 ? R(0.98,1.14) : br < 0.92 ? R(1.18,1.4) : R(1.4,1.65);
  // hair
  const gray = age > 0.7 ? (r() < 0.75) : age > 0.5 && r() < 0.25;
  L.hairColor = gray ? RP(["#8f8f8f","#b5b5b5","#cfcfcf","#efefef"]) : RP(HAIRC.slice(0,8));
  if (!gray && r() < 0.06) L.hairColor = RP(HAIRC.slice(11));
  const hstyles = fem ? [["long",5],["bun",2],["pony",2],["short",2],["afro",1.2],["bald",0.1]] : [["short",7],["bald",age>0.6?1.5:0.25],["afro",1],["long",0.8],["pony",0.4],["mohawk",0.08]];
  L.hair = wpick(hstyles, r);
  L.beard = !fem && r() < 0.28; L.beardColor = L.hairColor;
  L.glasses = r() < (age > 0.5 ? 0.45 : 0.18);
  L.hat = null; L.hatColor = RP(NEUTRAL);
  L.top = RP(NEUTRAL); L.sleeve = "long"; L.bottom = RP(JEANS); L.btype = "pants"; L.shoes = RP(SHOES); L.skirt = null; L.skirtLen = 0.2;
  L.speed = R(1.05,1.5) * (age > 0.8 ? 0.6 : 1);
  const vivid = () => { L.top = RP(BRIGHT); L.vivid = true; };
  switch (L.outfit){
    case "casual": L.sleeve = r()<0.5?"short":"long"; if (r()<0.1) vivid(); L.bottom = r()<0.7 ? RP(JEANS) : RP(TROUSERS); if (r()<0.25) L.acc.tote = RP(["#3a2a1c","#26231f","#c9b28a","#7a2e36"]); if (r()<0.2) L.acc.cup = "#f4f2ec"; if (r()<0.15){ L.hat = "cap"; L.hatColor = RP(NEUTRAL.concat(BRIGHT)); } break;
    case "business": L.top = RP(["#26282c","#2b3440","#3a3f46","#4d5156","#1d2d44"]); L.bottom = L.top; L.shoes = RP(["#141414","#2a2420","#5a3a26"]); if (!fem || r()<0.4) L.acc.tie = RP(["#7a2e36","#1e3a5f","#26231f","#c0362c","#3f5e7a"]); if (r()<0.35) L.acc.tote = "#1d1b19"; if (r()<0.25) L.acc.cup = "#f4f2ec"; if (fem && r()<0.5){ L.btype = "skirt"; L.skirt = L.top; L.skirtLen = 0.2; } break;
    case "dress": L.btype = "dress"; L.skirt = r()<0.15 ? RP(BRIGHT) : RP(NEUTRAL); L.top = L.skirt; L.skirtLen = R(0.17,0.3); L.sleeve = r()<0.6?"short":"none"; if (L.skirt && BRIGHT.includes(L.skirt)) L.vivid = true; if (r()<0.4) L.acc.tote = RP(["#c9b28a","#26231f","#e9e6de"]); if (r()<0.15){ L.hat = "sunhat"; L.hatColor = RP(["#e8d9b0","#c9b28a","#f4f2ec"]); } break;
    case "skirt": L.btype = "skirt"; L.skirt = r()<0.2 ? RP(BRIGHT) : RP(NEUTRAL); L.skirtLen = R(0.13,0.24); L.sleeve = r()<0.5?"short":"long"; if (r()<0.08) vivid(); break;
    case "coat": L.btype = "coat"; L.top = RP(["#6b5a45","#26282c","#3a3f46","#8a7a62","#7a2e36","#2d4a3c","#c9b28a","#1d2d44"]); L.skirt = L.top; L.skirtLen = R(0.22,0.3); L.bottom = RP(TROUSERS); if (r()<0.4) L.acc.scarf = RP(BRIGHT.concat(NEUTRAL)); if (r()<0.25){ L.hat = r()<0.5?"fedora":"beanie"; } break;
    case "puffer": L.top = r()<0.2 ? RP(BRIGHT) : RP(NEUTRAL); L.b *= 1.08; if (BRIGHT.includes(L.top)) L.vivid = true; if (r()<0.4){ L.hat = "beanie"; L.hatColor = RP(NEUTRAL.concat(BRIGHT)); } break;
    case "hoodie": L.top = r()<0.2 ? RP(BRIGHT) : RP(NEUTRAL); L.acc.backpack = RP(NEUTRAL.concat(BRIGHT)); age = L.age = Math.min(age, 0.35); if (r()<0.3){ L.hat = "cap"; L.hatColor = RP(NEUTRAL); } break;
    case "tourist": vivid(); L.sleeve = "short"; L.btype = "shorts"; L.bottom = RP(["#bfb49e","#8c8578","#2a3a55","#e9e6de"]); L.acc.camera = "#1d1d1c"; if (r()<0.6){ L.hat = r()<0.5?"cap":"sunhat"; L.hatColor = RP(["#e9e6de","#e8b82e","#2f7fc1","#c9b28a"]); } if (r()<0.4) L.acc.backpack = RP(NEUTRAL); L.speed *= 0.8; break;
    case "jogger": L.top = RP(BRIGHT.concat(["#26282c","#e9e6de"])); L.sleeve = r()<0.5?"none":"short"; L.btype = "shorts"; L.bottom = RP(["#26282c","#1d2d44","#3a3f46"]); L.shoes = RP(["#e9e6de","#ff6a3d","#5cc4ff","#e8b82e"]); L.anim = "jog"; L.speed = R(2.6,3.4); L.acc.tote = null; L.glasses = false; age = L.age = Math.min(age, 0.55); if (BRIGHT.includes(L.top)) L.vivid = true; break;
    case "worker": L.top = RP(["#ffd24a","#ff6a3d"]); L.vivid = true; L.bottom = RP(JEANS); L.shoes = "#5a3a26"; L.hat = "hardhat"; L.hatColor = RP(["#f4f2ec","#ffd24a","#ff6a3d"]); L.b = Math.max(L.b, 1.05); break;
    case "chef": L.top = "#f4f2ec"; L.bottom = RP(["#26282c","#e9e6de"]); L.hat = "chef"; L.hatColor = "#fbfaf6"; L.acc.cup = null; break;
    case "nurse": L.top = RP(["#2e9c95","#3b6fb0","#6a4fa0"]); L.bottom = L.top; L.sleeve = "short"; L.shoes = "#e9e6de"; L.acc.cup = r()<0.5 ? "#f4f2ec" : null; break;
    case "goth": L.top = "#15151a"; L.bottom = "#15151a"; L.shoes = "#141414"; L.btype = r()<0.5 ? "coat" : "pants"; L.skirt = "#15151a"; L.skirtLen = 0.3; L.hairColor = RP(["#15110e","#c64d9b","#8a3fb5","#efefef"]); L.hair = fem ? "long" : "short"; L.skin = RP(SKINS.slice(0,3)); break;
    case "punk": L.top = "#1a1a1a"; L.bottom = RP(["#7a2e36","#26282c","#2a3a55"]); L.hair = "mohawk"; L.hairColor = RP(["#d23c2e","#58b37a","#3f7fd0","#e8b82e","#c64d9b"]); L.shoes = "#141414"; L.sleeve = "none"; break;
    case "hipster": L.top = RP(["#7a2e36","#2d4a3c","#6b5a45","#3f5e7a","#8a3b32"]); L.bottom = RP(JEANS); if (!fem) L.beard = true; L.glasses = r()<0.7; if (r()<0.6){ L.hat = "beanie"; L.hatColor = RP(["#c0362c","#e8a33d","#26231f","#3f5e7a"]); } L.acc.tote = r()<0.5 ? "#c9b28a" : null; L.acc.cup = r()<0.5 ? "#8a5a36" : null; break;
    case "grandma": L.fem = true; L.btype = "dress"; L.skirt = RP(["#6a4fa0","#3f5e7a","#7a2e36","#c9b28a","#8e5a8a"]); L.top = RP(["#e9e6de","#c9c9c4","#8e9396"]); L.skirtLen = 0.3; L.hair = RP(["short","bun"]); L.acc.shopBag = RP(["#e9e6de","#c0362c","#2f7fc1"]); L.speed = R(0.6,0.85); L.anim = "elder"; break;
    case "elder": L.btype = r()<0.4 ? "coat" : "pants"; L.top = RP(["#6b5a45","#8a7a62","#3a3f46","#2d4a3c","#7a2e36"]); L.skirt = L.top; L.skirtLen = 0.25; L.bottom = RP(TROUSERS); L.acc.cane = "#3a2a1c"; L.anim = "elder"; L.speed = R(0.55,0.8); if (!fem && r()<0.5){ L.hat = r()<0.5 ? "fedora" : "beret"; L.hatColor = RP(["#26282c","#6b5a45","#3a3f46"]); } break;
    case "skater": L.top = RP(NEUTRAL.concat(BRIGHT)); L.bottom = RP(JEANS.concat(["#8c8578"])); L.acc.skate = RP(["#c0362c","#26231f","#e8b82e","#3aa06b"]); L.anim = "skate"; L.speed = R(3.4,4.4); age = L.age = Math.min(age, 0.35); if (r()<0.5){ L.hat = r()<0.5?"beanie":"cap"; L.hatColor = RP(NEUTRAL.concat(BRIGHT)); } break;
    case "sign": L.acc.sign = RP(["#f4f2ec","#ffd24a","#f28cb1","#5cc4ff"]); L.speed *= 0.7; break;
    case "modest": L.btype = "dress"; L.skirt = RP(["#26282c","#1d2d44","#6b5a45","#2d4a3c","#7a2e36","#c9b28a"]); L.top = L.skirt; L.skirtLen = 0.36; L.hat = "headscarf"; L.hatColor = RP(["#26282c","#e9e6de","#c8367a","#2f7fc1","#6a4fa0","#c9b28a","#16a3a3"]); L.hair = "bald"; L.beard = false; L.fem = true; break;
    case "costume": {
      const c = RP(["banana","gorilla","hero","fairy","bunny","victorian","clown"]); L.costume = c; L.vivid = true;
      if (c === "banana"){ L.top = "#f2d02b"; L.bottom = "#f2d02b"; L.acc.banana = "#f2d02b"; L.hair = "bald"; L.hat = null; }
      if (c === "gorilla"){ const f = RP(["#221d1a","#2e2622","#3a302a"]); L.skin = "#2a2422"; L.top = f; L.bottom = f; L.shoes = f; L.hair = "afro"; L.hairColor = f; L.hs = 1.18; L.nose = 1.6; L.b = Math.max(1.2, L.b); L.glasses = false; }
      if (c === "hero"){ L.top = RP(["#2f7fc1","#d23c2e","#3aa06b","#8a3fb5"]); L.bottom = L.top; L.acc.cape = RP(["#d23c2e","#e8b82e","#26231f"]); L.shoes = RP(["#d23c2e","#e8b82e"]); }
      if (c === "fairy"){ L.top = RP(["#f28cb1","#b98ee8","#8fe0e0"]); L.btype = "tutu"; L.skirt = L.top; L.acc.wings = "#f4f2ec"; L.hairColor = RP(["#f28cb1","#b98ee8","#e2cf9a"]); }
      if (c === "bunny"){ L.hat = "bunny"; L.hatColor = RP(["#f4f2ec","#f28cb1"]); L.top = RP(["#f4f2ec","#f28cb1","#c9c9c4"]); }
      if (c === "victorian"){ L.hat = "tophat"; L.hatColor = "#15151a"; L.btype = "coat"; L.top = "#26231f"; L.skirt = "#26231f"; L.skirtLen = 0.3; L.bottom = "#3a3f46"; L.beard = !fem; L.acc.cane = "#1a1a1a"; }
      if (c === "clown"){ L.top = RP(BRIGHT); L.bottom = RP(BRIGHT); L.hair = "afro"; L.hairColor = RP(["#d23c2e","#3aa06b","#3f7fd0"]); L.nose = 2.2; L.noseColor = "#e0241b"; L.shoes = RP(["#d23c2e","#e8b82e"]); }
      break; }
  }
  if (L.hat === "headscarf") L.hair = "bald";
  L.mood = L.costume ? (r()<0.6 ? "poser" : "cheerful") : wpick([["cheerful",3],["neutral",4],["grumpy",L.age>0.7?3:1.5],["shy",2],["curious",2],["poser",1],["anxious",1]], r);
  L.smoke = L.age > 0.15 && !["jogger","skater","costume","chef","nurse","sign"].includes(L.outfit) && r() < 0.13;
  p.look = L; p.speed = L.speed; p.scale = L.h/1.75; p.top = L.top; p.vivid = !!L.vivid || BRIGHT.includes(L.top); p.hat = L.hat ? L.hatColor : null; p.bag = !!(L.acc.tote || L.acc.backpack);
  if (L.anim === "jog" || L.anim === "skate") p.noPause = true;
}

/* ---------------- geometry ---------------- */
function lathe(pts, seg=12){ return new THREE.LatheGeometry(pts.map(([x,y])=>new THREE.Vector2(x,y)), seg).toNonIndexed(); }
function peopleGeoms(){
  const G_ = {};
  G_.limb = lathe([[0,0.04],[0.7,0.02],[1,-0.06],[0.96,-0.4],[0.8,-0.9],[0.55,-1],[0,-1.02]], 10);
  G_.torso = lathe([[0,-0.02],[0.82,0],[0.86,0.18],[0.74,0.42],[0.86,0.72],[0.96,0.88],[0.62,1.0],[0,1.03]], 14);
  G_.sph = new THREE.SphereGeometry(1, 12, 9).toNonIndexed();
  G_.sphLo = new THREE.SphereGeometry(1, 8, 6).toNonIndexed();
  G_.nose = new THREE.ConeGeometry(0.2, 0.42, 6).rotateX(Math.PI/2).translate(0,0,0.14).toNonIndexed();
  G_.cyl = new THREE.CylinderGeometry(1,1,1,10).toNonIndexed();
  G_.box = new THREE.BoxGeometry(1,1,1).toNonIndexed();
  G_.boxDown = new THREE.BoxGeometry(1,1,1).translate(0,-0.5,0).toNonIndexed();
  G_.skirt = lathe([[0.98,0.02],[1.0,0],[1.12,-0.5],[1.32,-1],[0,-1.001]].slice(0,4), 14);
  G_.tutu = lathe([[0.9,0.1],[2.1,0],[2.0,-0.12],[0.9,-0.2]], 16);
  G_.torus = new THREE.TorusGeometry(1, 0.35, 6, 14).rotateX(Math.PI/2).toNonIndexed();
  G_.banana = lathe([[0,-0.02],[0.7,0.05],[0.95,0.3],[1,0.55],[0.9,0.8],[0.55,0.97],[0.15,1.06],[0.12,1.15],[0,1.16]], 14);
  const cap = (r, th=0.52) => new THREE.SphereGeometry(r, 16, 8, 0, Math.PI*2, 0, Math.PI*th).toNonIndexed();
  const H_ = {};
  H_.short = mergeParts([{ g:cap(1.08,0.5), m:TM(0,0.06,-0.1, -0.42) }]);
  H_.long = mergeParts([{ g:cap(1.09,0.54), m:TM(0,0.05,-0.08, -0.38) }, { g:new THREE.CylinderGeometry(0.98,1.02,1.35,12,1,false,Math.PI*0.6,Math.PI*0.8).toNonIndexed(), m:TM(0,-0.55,-0.12, 0,0,0, 1,1,0.8) }]);
  H_.bun = mergeParts([{ g:cap(1.08,0.52), m:TM(0,0.05,-0.08, -0.4) }, { g:new THREE.SphereGeometry(0.46,10,8).toNonIndexed(), m:TM(0,0.78,-0.72) }]);
  H_.pony = mergeParts([{ g:cap(1.08,0.52), m:TM(0,0.05,-0.08, -0.4) }, { g:new THREE.CylinderGeometry(0.24,0.1,1.3,8).toNonIndexed(), m:TM(0,-0.2,-1.08, 0.25) }]);
  H_.afro = mergeParts([{ g:new THREE.SphereGeometry(1.5,14,10).toNonIndexed(), m:TM(0,0.32,-0.18) }]);
  H_.mohawk = mergeParts([{ g:cap(1.03,0.4), m:TM(0,0.02,-0.02) }, { g:new THREE.BoxGeometry(0.22,0.7,1.7).toNonIndexed(), m:TM(0,1.02,-0.12) }]);
  H_.beard = new THREE.SphereGeometry(1.04, 14, 8, Math.PI/2-1.05, 2.1, Math.PI*0.64, Math.PI*0.3).toNonIndexed();
  const brim = (r, h=0.06) => new THREE.CylinderGeometry(r, r, h, 20).toNonIndexed();
  const HT = {};
  HT.beanie = mergeParts([{ g:cap(1.14,0.56), m:TM(0,0.08,0, 0,0,0, 1,1.15,1) }]);
  HT.cap = mergeParts([{ g:cap(1.1,0.46), m:TM(0,0.1,0) }, { g:new THREE.BoxGeometry(1.3,0.06,1.0).toNonIndexed(), m:TM(0,0.38,0.98, -0.12) }]);
  HT.fedora = mergeParts([{ g:new THREE.CylinderGeometry(0.82,0.98,0.85,16).toNonIndexed(), m:TM(0,0.95,0) }, { g:brim(1.75), m:TM(0,0.56,0) }]);
  HT.tophat = mergeParts([{ g:new THREE.CylinderGeometry(0.92,0.88,2.1,16).toNonIndexed(), m:TM(0,1.55,0) }, { g:brim(1.55), m:TM(0,0.55,0) }]);
  HT.sunhat = mergeParts([{ g:cap(1.12,0.5), m:TM(0,0.12,0) }, { g:brim(2.4,0.05), m:TM(0,0.42,0) }]);
  HT.beret = mergeParts([{ g:new THREE.SphereGeometry(1.18,16,8).toNonIndexed(), m:TM(0.1,0.78,0, 0,0,-0.25, 1,0.35,1) }]);
  HT.bunny = mergeParts([{ g:cap(1.06,0.4), m:TM(0,0.05,0) }, { g:new THREE.SphereGeometry(0.28,10,8).toNonIndexed(), m:TM(-0.42,1.75,0, 0,0,0.2, 1,3.4,0.45) }, { g:new THREE.SphereGeometry(0.28,10,8).toNonIndexed(), m:TM(0.42,1.75,0, 0,0,-0.2, 1,3.4,0.45) }]);
  HT.hardhat = mergeParts([{ g:cap(1.2,0.5), m:TM(0,0.12,0) }, { g:brim(1.38,0.08), m:TM(0,0.28,0.06) }]);
  HT.chef = mergeParts([{ g:new THREE.CylinderGeometry(1.0,1.08,1.5,16).toNonIndexed(), m:TM(0,1.2,0) }, { g:new THREE.SphereGeometry(1.22,16,8).toNonIndexed(), m:TM(0,1.95,0, 0,0,0, 1,0.5,1) }]);
  HT.headscarf = mergeParts([{ g:new THREE.SphereGeometry(1.16,18,12, Math.PI/2+1.0, Math.PI*2-2.0).toNonIndexed(), m:TM(0,0.02,-0.02) }, { g:new THREE.CylinderGeometry(0.9,1.55,1.4,16,1,true).toNonIndexed(), m:TM(0,-1.25,-0.05) }]);
  const A = {};
  A.glasses = mergeParts([{ g:new THREE.TorusGeometry(0.25,0.03,4,14).toNonIndexed(), m:TM(-0.33,0,0, 0,0,0, 1,0.75,1) }, { g:new THREE.TorusGeometry(0.25,0.03,4,14).toNonIndexed(), m:TM(0.33,0,0, 0,0,0, 1,0.75,1) }, { g:new THREE.BoxGeometry(0.16,0.04,0.04).toNonIndexed(), m:TM(0,0.05,0) }]);
  A.guitar = mergeParts([{ g:new THREE.SphereGeometry(0.2,12,8).toNonIndexed(), m:TM(0,-0.12,0, 0,0,0, 1,1,0.35) }, { g:new THREE.SphereGeometry(0.15,12,8).toNonIndexed(), m:TM(0,0.1,0, 0,0,0, 1,1,0.4) }, { g:new THREE.BoxGeometry(0.05,0.55,0.03).toNonIndexed(), m:TM(0,0.45,0) }]);
  A.wings = mergeParts([{ g:new THREE.SphereGeometry(0.3,10,8).toNonIndexed(), m:TM(-0.25,0.1,0, 0,0,0.6, 1,1.6,0.08) }, { g:new THREE.SphereGeometry(0.3,10,8).toNonIndexed(), m:TM(0.25,0.1,0, 0,0,-0.6, 1,1.6,0.08) }]);
  A.canopy = new THREE.ConeGeometry(0.62,0.26,12,1,true).translate(0,-0.13,0).toNonIndexed();
  A.sign = mergeParts([{ g:new THREE.BoxGeometry(0.6,0.42,0.02).toNonIndexed(), m:TM(0,0.62,0) }, { g:new THREE.CylinderGeometry(0.012,0.012,0.7,5).toNonIndexed(), m:TM(0,0.1,-0.02) }]);
  A.skate = mergeParts([{ g:new THREE.BoxGeometry(0.21,0.025,0.8).toNonIndexed(), m:TM(0,0.075,0) }, ...[[-0.08,0.28],[0.08,0.28],[-0.08,-0.28],[0.08,-0.28]].map(([x,z])=>({ g:new THREE.CylinderGeometry(0.03,0.03,0.03,8).rotateZ(Math.PI/2).toNonIndexed(), m:TM(x,0.03,z), c:lin("#e9e6de") }))]);
  return { G:G_, H:H_, HT, A };
}

/* ---------------- clothing patterns (torso atlas: knit, stripes, plaid, suit, zip jacket, shirt) ---------------- */
function clothingAtlas(){
  const W = 256, RH = 128, c = document.createElement("canvas"); c.width = W; c.height = RH*6; const x = c.getContext("2d"), r = mulberry(606);
  const row = k => (5-k)*RH;   // canvas y for pattern k (texture v flips)
  const front = (fn) => { fn(0); fn(W); };   // the torso seam sits at the front: draw front details on both edges
  for (let k=0;k<6;k++){ const y0 = row(k); x.fillStyle = "#dcdcdc"; x.fillRect(0, y0, W, RH);
    for (let i=0;i<900;i++){ const v = 200 + r()*40|0; x.fillStyle = `rgba(${v},${v},${v},.35)`; x.fillRect(r()*W, y0 + r()*RH, 1.5, 1.5); } }
  // 0 knit ribs
  for (let i=0;i<W;i+=4){ x.fillStyle = "rgba(0,0,0,.06)"; x.fillRect(i, row(0), 2, RH); }
  // 1 breton stripes
  for (let j=0;j<RH;j+=14){ x.fillStyle = "rgba(20,20,20,.55)"; x.fillRect(0, row(1) + j, W, 6); }
  // 2 plaid
  for (let i=0;i<W;i+=32){ x.fillStyle = "rgba(0,0,0,.28)"; x.fillRect(i, row(2), 12, RH); x.fillStyle = "rgba(0,0,0,.12)"; x.fillRect(i+18, row(2), 3, RH); }
  for (let j=0;j<RH;j+=32){ x.fillStyle = "rgba(0,0,0,.24)"; x.fillRect(0, row(2) + j, W, 12); x.fillStyle = "rgba(255,255,255,.2)"; x.fillRect(0, row(2) + j + 20, W, 3); }
  // 3 suit: lapels, buttons, pockets, seams
  front(fx => { const y0 = row(3); x.strokeStyle = "rgba(0,0,0,.55)"; x.lineWidth = 3; x.beginPath(); x.moveTo(fx - 22, y0 + 2); x.lineTo(fx - 3, y0 + 70); x.lineTo(fx + 3, y0 + 70); x.lineTo(fx + 22, y0 + 2); x.stroke();
    x.fillStyle = "rgba(0,0,0,.25)"; x.beginPath(); x.moveTo(fx - 10, y0); x.lineTo(fx, y0 + 64); x.lineTo(fx + 10, y0); x.fill();
    x.fillStyle = "rgba(0,0,0,.7)"; for (const by of [82, 102]){ x.beginPath(); x.arc(fx + 5, y0 + by, 3, 0, 7); x.fill(); }
    x.fillStyle = "rgba(0,0,0,.4)"; x.fillRect(fx - 44, y0 + 96, 24, 3); x.fillRect(fx + 22, y0 + 96, 24, 3); x.fillRect(fx + 20, y0 + 36, 18, 2); });
  for (const sx of [64, 192]){ x.fillStyle = "rgba(0,0,0,.18)"; x.fillRect(sx, row(3), 2, RH); }
  // 4 zip jacket / hoodie: zipper, pockets, drawstrings, hem band
  front(fx => { const y0 = row(4); x.fillStyle = "rgba(0,0,0,.6)"; x.fillRect(fx - 2, y0, 4, RH); x.fillStyle = "rgba(255,255,255,.35)"; for (let j=0;j<RH;j+=4) x.fillRect(fx - 1, y0 + j, 2, 2);
    x.strokeStyle = "rgba(0,0,0,.4)"; x.lineWidth = 2; x.beginPath(); x.moveTo(fx + 10, y0 + 70); x.lineTo(fx + 40, y0 + 100); x.moveTo(fx - 10, y0 + 70); x.lineTo(fx - 40, y0 + 100); x.stroke();
    x.fillStyle = "rgba(240,240,240,.8)"; x.fillRect(fx - 9, y0 + 2, 2, 26); x.fillRect(fx + 7, y0 + 2, 2, 22); });
  x.fillStyle = "rgba(0,0,0,.25)"; x.fillRect(0, row(4) + RH - 10, W, 10);
  // 5 shirt: placket, buttons, collar points, chest pocket
  front(fx => { const y0 = row(5); x.fillStyle = "rgba(0,0,0,.18)"; x.fillRect(fx - 5, y0, 10, RH); x.fillStyle = "rgba(0,0,0,.6)"; for (let j=14;j<RH;j+=20){ x.beginPath(); x.arc(fx, y0 + j, 2.4, 0, 7); x.fill(); }
    x.strokeStyle = "rgba(0,0,0,.5)"; x.lineWidth = 2.5; x.beginPath(); x.moveTo(fx - 16, y0 + 2); x.lineTo(fx - 4, y0 + 16); x.moveTo(fx + 16, y0 + 2); x.lineTo(fx + 4, y0 + 16); x.stroke(); x.strokeRect(fx + 14, y0 + 30, 18, 20); });
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.anisotropy = 4; return t;
}
function patternFor(L){
  switch (L.outfit){ case "business": return 3; case "coat": case "elder": return r_(L, [3,0,4]); case "puffer": case "jogger": case "worker": return 4; case "hoodie": case "skater": return 4; case "hipster": return 2; case "tourist": return r_(L, [5,1]); case "nurse": case "chef": return 5; case "goth": case "punk": return r_(L, [4,0]); case "casual": return r_(L, [0,0,1,2,5,4]); default: return r_(L, [0,5,1]); }
}
function r_(L, a){ return a[Math.floor((L.h*997 + L.b*131) % a.length)]; }
/* ---------------- instancing ---------------- */
function shadeHex(hex, k, warm){ const c = new THREE.Color(hex); c.r = Math.min(1, c.r*k + warm); c.g *= k; c.b *= k*0.95; return "#"+c.getHexString(); }
function fabricTex(){
  const c = document.createElement("canvas"); c.width = c.height = 128; const x = c.getContext("2d"), im = x.createImageData(128,128), r = mulberry(31);
  for (let y=0;y<128;y++) for (let k=0;k<128;k++){ const w = ((k+y)%4<2 ? 6 : -6) + (r()-0.5)*26 + Math.sin(y*0.4)*4; const v = 225 + w; const o = (y*128+k)*4; im.data[o]=im.data[o+1]=im.data[o+2]=v; im.data[o+3]=255; }
  x.putImageData(im,0,0); const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(6,6); t.encoding = THREE.sRGBEncoding; return t;
}
const PI_ = {}, PCOL = {}, CNT = {};   // instanced meshes, per-part colours by person index, live instance counters (compacted each frame)
function partUsers(name, p){
  const L = p.look, a = L.acc;
  if (name.startsWith("h_")) return name === "h_beard" ? !!L.beard : L.hair === name.slice(2);
  if (name.startsWith("t_")) return L.hat === name.slice(2);
  switch (name){
    case "glasses": return !!L.glasses; case "belt": return false && (L.btype === "pants" || L.btype === "shorts") && !L.acc.banana && (L.outfit === "business" || L.outfit === "casual" || L.outfit === "worker" || L.outfit === "hipster" || L.outfit === "tourist" || L.outfit === "elder"); case "collar": return L.pat === 5 || L.pat === 3 || L.btype === "coat"; case "cig": case "ember": return true; case "tie": return !!a.tie; case "scarf": return !!a.scarf; case "backpack": return !!a.backpack; case "tote": return !!a.tote;
    case "shopbag": return !!a.shopBag; case "cup": return !!a.cup; case "camera": return !!a.camera; case "cane": return !!a.cane; case "cape": return !!a.cape;
    case "wings": return !!a.wings; case "sign": return !!a.sign || (!!p.pool && !p.role); case "skate": return !!a.skate; case "banana": return !!a.banana; case "tutu": return L.btype === "tutu";
    case "skirt": return L.btype === "skirt" || L.btype === "dress" || L.btype === "coat"; case "belly": return L.b > 1.12; case "guitar": return (!!p.performer && !L.statue) || !!p.pool; case "skate": return !!a.skate || !!p.pool;
  }
  return null;
}
function buildPeopleMeshes(scene){
  const N = Life.people.length, geo = peopleGeoms();
  const cloth = new THREE.MeshStandardMaterial({ color:0xffffff, roughness:0.9, map:fabricTex() });
  const skinM = new THREE.MeshStandardMaterial({ color:0xffffff, roughness:0.55 });
  const shiny = new THREE.MeshStandardMaterial({ color:0xffffff, roughness:0.3, metalness:0.1 });
  const mk = (name, g, mat, count, shadow) => {
    if (count === N && partUsers(name, Life.people[0]) !== null){ let k = 0; Life.people.forEach(p=>{ if (partUsers(name, p)) k++; }); count = Math.max(1, k); }
    const m = new THREE.InstancedMesh(g, mat, count); m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); m.castShadow = !!shadow; m.receiveShadow = true; m.frustumCulled = false; scene.add(m); PI_[name] = m; for (let i=0;i<count;i++) m.setMatrixAt(i, HIDE); return m; };
  const torsoMat = new THREE.MeshStandardMaterial({ color:0xffffff, roughness:0.9, map:clothingAtlas() });
  torsoMat.onBeforeCompile = sh => { sh.vertexShader = sh.vertexShader.replace("#include <common>", "#include <common>\nattribute float aPat;").replace("#include <uv_vertex>", "#include <uv_vertex>\nvUv.y = (clamp(vUv.y, 0.01, 0.99) + aPat)/6.0;"); };
  geo.G.torso.setAttribute("aPat", new THREE.InstancedBufferAttribute(new Float32Array(N), 1).setUsage(THREE.DynamicDrawUsage));
  mk("torso", geo.G.torso, torsoMat, N, true); PI_.torso.userData.pat = geo.G.torso.attributes.aPat;
  Life.people.forEach(p => { p.look.pat = patternFor(p.look); });
  mk("belt", geo.G.torus, skinM, N, false); mk("collar", geo.G.torus, cloth, N, false); mk("pelvis", geo.G.sphLo, cloth, N, true); mk("belly", geo.G.sph, cloth, N, true);
  mk("thigh", geo.G.limb, cloth, 2*N, true); mk("shin", geo.G.limb, cloth, 2*N, true); mk("shoe", geo.G.sphLo, shiny, 2*N, false);
  mk("uarm", geo.G.limb, cloth, 2*N, true); mk("farm", geo.G.limb, cloth, 2*N, false); mk("hand", geo.G.sphLo, skinM, 2*N, false);
  mk("neck", geo.G.cyl, skinM, N, false); mk("head", geo.G.sph, skinM, N, true); mk("nose", geo.G.nose, skinM, N, false); mk("eye", geo.G.sphLo, shiny, 2*N, false);
  mk("skirt", geo.G.skirt, cloth, N, true); mk("tutu", geo.G.tutu, cloth, N, false); mk("banana", geo.G.banana, shiny, N, true);
  for (const k in geo.H) mk("h_"+k, geo.H[k], cloth, N, false);
  for (const k in geo.HT) mk("t_"+k, geo.HT[k], cloth, N, true);
  mk("glasses", geo.A.glasses, shiny, N, false); mk("cig", geo.G.cyl, skinM, N, false); mk("ember", geo.G.sphLo, new THREE.MeshBasicMaterial({ color:0xffffff }), N, false); mk("brow", geo.G.box, cloth, 2*N, false); mk("mArc", new THREE.TorusGeometry(1, 0.28, 4, 10, Math.PI).toNonIndexed(), skinM, N, false); mk("ear", geo.G.sphLo, skinM, 2*N, false); mk("mouth", geo.G.sphLo, skinM, N, false); mk("tie", geo.G.box, cloth, N, false); mk("scarf", geo.G.torus, cloth, N, false);
  mk("backpack", geo.G.sph, cloth, N, true); mk("tote", geo.G.box, cloth, N, false); mk("shopbag", geo.G.box, cloth, N, false);
  mk("cup", geo.G.cyl, shiny, N, false); mk("phone", geo.G.box, shiny, N, false); mk("camera", geo.G.box, shiny, N, false); mk("cane", geo.G.cyl, shiny, N, false);
  mk("cape", geo.G.boxDown, cloth, N, true); mk("wings", geo.A.wings, shiny, N, false); mk("sign", geo.A.sign, cloth, N, true); mk("skate", geo.A.skate, shiny, N, true);
  mk("canopy", geo.A.canopy, cloth, N, true); mk("pole", geo.G.cyl, shiny, N, false); mk("guitar", geo.A.guitar, shiny, N, true);
  const c = new THREE.Color(), set = (name, i, hex) => { (PCOL[name] = PCOL[name] || [])[i] = lin(hex || "#808080"); };
  Life.people.forEach((p, i) => {
    const L = p.look, skin = L.skin, shortLegs = L.btype === "shorts" || L.btype === "skirt" || L.btype === "dress" || L.btype === "tutu";
    set("torso", i, L.top); set("belly", i, L.top); set("pelvis", i, L.btype==="dress" ? L.skirt : L.bottom);
    for (const k of [0,1]){
      set("thigh", 2*i+k, L.btype==="dress"||L.btype==="skirt" ? (L.fem && L.skin) || L.bottom : L.bottom);
      set("shin", 2*i+k, shortLegs ? (L.outfit==="goth" ? "#15151a" : skin) : L.bottom);
      set("shoe", 2*i+k, L.shoes);
      set("uarm", 2*i+k, L.sleeve === "none" ? skin : L.top);
      set("farm", 2*i+k, L.sleeve === "long" ? L.top : skin);
      set("hand", 2*i+k, L.costume === "gorilla" ? "#2a2422" : skin);
      set("eye", 2*i+k, shadeHex(skin, 0.35, 0));
    }
    set("neck", i, skin); set("head", i, skin); set("nose", i, L.noseColor || skin);
    set("skirt", i, L.skirt || L.top); set("tutu", i, L.skirt || L.top); set("banana", i, "#f2d02b");
    for (const k in geo.H) set("h_"+k, i, L.hairColor);
    for (const k in geo.HT) set("t_"+k, i, L.hatColor);
    set("h_beard", i, L.beardColor);
    set("glasses", i, "#141414"); set("belt", i, RPc(["#1d1916","#3a2618","#2a2622"], i)); set("collar", i, L.pat === 3 ? "#e9e6de" : L.top); set("cig", i, "#f2efe6"); (PCOL.ember = PCOL.ember || [])[i] = new THREE.Color(4,0.9,0.2); set("brow", 2*i, L.hairColor); set("brow", 2*i+1, L.hairColor); set("ear", 2*i, skin); set("ear", 2*i+1, skin); set("mouth", i, L.costume==="clown" ? "#e0241b" : shadeHex(skin, 0.5, 0.04)); set("mArc", i, L.costume==="clown" ? "#e0241b" : shadeHex(skin, 0.55, 0.05)); set("tie", i, L.acc.tie); set("scarf", i, L.acc.scarf);
    set("backpack", i, L.acc.backpack); set("tote", i, L.acc.tote); set("shopbag", i, L.acc.shopBag); set("cup", i, L.acc.cup); set("phone", i, "#1a1c20"); set("camera", i, "#1d1d1c"); set("cane", i, L.acc.cane);
    set("cape", i, L.acc.cape); set("wings", i, "#f4f2ec"); set("sign", i, L.acc.sign || ["#f4f2ec","#ffd24a","#f28cb1","#5cc4ff","#e9e6de"][i%5]); set("skate", i, L.acc.skate);
    set("canopy", i, p.umbrellaColor || "#26231f"); set("pole", i, "#222222"); set("guitar", i, "#9a5b2e");
  });
  for (const k in PI_){ if (!PI_[k].instanceColor) PI_[k].setColorAt(0, c.set(0x808080)); PI_[k].count = 0; }
}

/* ---------------- posing ---------------- */
const _pq = new THREE.Quaternion(), _pe = new THREE.Euler(), _pv = new THREE.Vector3(), _ps = new THREE.Vector3(), _pt = new THREE.Matrix4(), _pm = new THREE.Matrix4(), ONE3 = new THREE.Vector3(1,1,1);
const FR = Array.from({length:16}, ()=>new THREE.Matrix4());
function jf(out, parent, x,y,z, rx=0,ry=0,rz=0){ _pe.set(rx,ry,rz,"YXZ"); _pq.setFromEuler(_pe); _pt.compose(_pv.set(x,y,z), _pq, ONE3); return out.multiplyMatrices(parent, _pt); }
function spM(name, idx, m){ const mesh = PI_[name], cols = PCOL[name], col = cols && cols[idx]; if (!col) return; const slot = CNT[name] = (CNT[name]||0); if (slot >= mesh.instanceMatrix.count) return; CNT[name]++; mesh.setMatrixAt(slot, m); mesh.setColorAt(slot, col); if (mesh.userData.pat){ const p = Life.people[idx]; mesh.userData.pat.setX(slot, p && p.look ? (p.look.pat||0) : 0); } }
function RPc(a, i){ return a[i % a.length]; }
function sp(name, idx, frame, x,y,z, sx,sy,sz, rx=0,ry=0,rz=0){ _pe.set(rx,ry,rz,"YXZ"); _pq.setFromEuler(_pe); _pt.compose(_pv.set(x,y,z), _pq, _ps.set(sx,sy,sz)); _pm.multiplyMatrices(frame, _pt); spM(name, idx, _pm); }
function hide(){}
const HAIRS = ["short","long","bun","pony","afro","mohawk"], HATS = ["beanie","cap","fedora","tophat","sunhat","beret","bunny","hardhat","chef","headscarf"];
function posePerson(p, i, moving, dist, pl, aware, t){
  const L = p.look, H = L.h, b = L.b, wb = 0.8 + 0.3*b;
  const [base, hipF, torF, headF, hdF, shL, shR, elL, elR, thL, thR, knL, knR, handL, handR, tmp] = FR;
  // cheap LOD: skip far people most frames
  if (p.hidden || dist > 150) return;
  p.gesture = null; p.gPeak = 0; p.eyeC = false;
  if (dist > 7 && ((p.x-pl.pos.x)*pl.fwd.x + (p.z-pl.pos.z)*pl.fwd.z)/dist < -0.35) return;
  base.makeRotationY(p.heading).setPosition(p.x, p.y, p.z);
  const anim = p.performer ? (L.statue ? "statue" : "play") : p.watcher ? "watch" : L.anim;
  const ph = p.phase, sn = Math.sin(ph), cs = Math.cos(ph);
  const stride = anim === "jog" ? 0.72 : anim === "elder" ? 0.26 : anim === "skate" ? 0 : 0.42 + 0.05*(L.fem?0:1);
  const mv = moving ? 1 : 0;
  let lean = (anim === "elder" ? 0.3 : anim === "jog" ? 0.14 : 0.03) * (mv || anim==="elder" ? 1 : 0.4);
  let bob = mv * (anim === "jog" ? 0.03 : 0.012) * H * Math.abs(cs), twist = mv * sn * (anim === "jog" ? 0.12 : 0.07);
  if (L.b > 1.3 && mv) twist += Math.sin(ph*2)*0.03;   // heavier walk sway
  let hipY = 0.53*H;
  let thA = [-sn*stride*mv, sn*stride*mv], knA = [mv*((anim==="jog"?1.2:0.55)*Math.max(0,cs) + 0.06), mv*((anim==="jog"?1.2:0.55)*Math.max(0,-cs) + 0.06)];
  let arA = [sn*(anim==="jog"?0.7:0.42)*mv, -sn*(anim==="jog"?0.7:0.42)*mv], arZ = [-0.08 - 0.04*b, 0.08 + 0.04*b], elA = [anim==="jog"?-1.5:-0.22, anim==="jog"?-1.5:-0.22];
  let hipYaw = null;
  if (mv && (anim === "walk" || anim === "elder" || anim === "jog")){
    const m = mocapSample(anim === "jog" ? MOCAP.run : MOCAP.walk, ph), k = anim === "elder" ? 0.55 : (L.b > 1.35 ? 0.85 : 1);
    thA = [m[0]*k, m[1]*k]; knA = [m[2]*k, m[3]*k]; arA = [m[4]*k, m[5]*k]; arZ = [m[6] - 0.03*b, m[7] + 0.03*b]; elA = [m[8], m[9]];
    lean += m[10]; hipYaw = m[11]*k; twist = m[12]*k; bob = (m[13] + 0.022)*k*H/1.75;
  }
  if (!mv && anim !== "statue"){ const sway = Math.sin(t*0.6 + i)*0.03; twist = sway; }
  if (anim === "skate"){ thA = [-0.25, 0.3]; knA = [0.45, 0.4]; arA = [-0.3, 0.2]; arZ = [-0.7, 0.6]; elA = [-0.3, -0.4]; twist = 1.1; lean = 0.12; bob = 0; }
  if (anim === "statue"){ thA = [0,0]; knA = [0,0]; arA = [-2.6, -1.6]; arZ = [-0.15, 0.9]; elA = [-0.4, -0.2]; lean = 0; twist = 0; if (dist < 3 && pl.raised){ const k = Math.sin(t*3)*0.4; arA[1] += k; } }
  if (anim === "play"){ arA = [-1.0, -0.6 + Math.sin(t*9)*0.25]; arZ = [0.45, -0.3]; elA = [-1.2, -0.9]; lean = 0.05 + Math.sin(t*2)*0.03; }
  if (anim === "watch"){ const clap = ((t + i*1.7) % 7) < 1.2; if (clap){ const c = Math.sin(t*18)*0.2; arA = [-0.8, -0.8]; arZ = [0.35 + c, -0.35 - c]; elA = [-1.2, -1.2]; } }
  if (p.act === "phone" && !mv){ arA[1] = -0.5; elA[1] = -1.6; arZ[1] = -0.15; }
  if (p.act === "phone" && mv){ arA[1] = -0.35; elA[1] = -1.4; arZ[1] = -0.1; }
  if (p.act === "stare" && dist < 2.6 && pl.raised && !p.performer){ arA[1] = -1.35; elA[1] = -0.35; arZ[1] = -0.2; }
  if (p.umbrella){ arA[1] = -0.95; elA[1] = -1.0; arZ[1] = 0.05; }
  if (L.acc.sign || p.evSign){ arA = [-2.6, -2.6]; elA = [-0.2, -0.2]; arZ = [0.15, -0.15]; }
  if (L.acc.cane && !L.acc.sign && !p.umbrella){ arA[1] = -0.25 + sn*0.1*mv; elA[1] = -0.35; }
  if (L.acc.cup && p.act !== "phone" && !p.umbrella && !L.smoke){ elA[1] = -1.3; arA[1] = -0.1 + sn*0.1*mv; }
  let nod = 0;
  if (anim === "talk"){ const gc = (t*0.8 + i*1.3) % 5.5, side = (Math.floor((t*0.8+i*1.3)/5.5) + i) % 2; if (gc < 2.4 && !(side===1 && L.smoke)){ arA[side] = -0.5 + Math.sin(t*4.5+i)*0.28; elA[side] = -1.15 + Math.sin(t*3.1+i)*0.35; arZ[side] = (side ? -1 : 1)*0.12; } twist = Math.sin(t*0.35+i)*0.1; nod = Math.sin(t*2.3+i)*0.05; }
  if (anim === "lean"){ thA = [-0.15, 0.4]; knA = [0.2, 1.1]; lean = -0.07; arA[0] = -0.2; elA[0] = -1.35; arZ[0] = 0.4; }
  if (anim === "sitground"){ hipY = 0.1 + 0.03*H; thA = [-1.45, -1.3]; knA = [0.3, 0.7]; lean = -0.22; bob = 0; if (p.act !== "phone"){ arA = [-0.6, -0.5]; elA = [-0.9, -1.2]; arZ = [0.1, -0.1]; } }
  if (anim === "sit"){ hipY = (p.seatH ?? 0.5) + 0.035*H; thA = [-1.5, -1.42]; knA = [1.48, 1.35]; lean = -0.08; bob = 0; if (p.act !== "phone"){ arA = [-0.45, -0.4]; elA = [-0.7, -0.8]; arZ = [0.05, -0.05]; } }
  if (p.dog){ arA[0] = -0.35 + sn*0.08*mv; elA[0] = -0.5; arZ[0] = -0.1; }
  // smoking: bring the cigarette up every ten seconds, exhale after
  let smokeCyc = -1;
  if (L.smoke && p.act !== "phone" && !p.umbrella && !L.acc.sign){
    smokeCyc = (t + i*3.7) % 10;
    const k = smokeCyc < 1.8 ? Math.min(1, smokeCyc/0.45, (1.8-smokeCyc)/0.4) : 0;
    const restA = anim==="sit" ? -0.5 : -0.12 + sn*0.1*mv, restE = anim==="sit" ? -1.0 : -0.6;
    arA[1] = lerp(restA, -0.5, k); elA[1] = lerp(restE, -2.5, k); arZ[1] = lerp(0.06, -0.45, k);
  }
  // ---- personality: expressions, reactions to the camera, idle habits ----
  const mood = L.mood || "neutral";
  let ex = mood === "cheerful" ? "smile" : mood === "grumpy" ? "frown" : "neutral", yawFx = 0, tilt = 0, pitchFx = 0;
  const noticed = (p.aware||0) > 1 && pl.raised && dist < 3.0 && !p.performer;
  if (anim === "talk"){ const gc = (t*0.8 + i*1.3) % 5.5, speaking = gc < 2.4; if (speaking) ex = "talk"; if (((t*0.23 + i*0.71) % 7) < 1.2){ ex = "laugh"; pitchFx -= 0.18; bob += Math.abs(Math.sin(t*13))*0.006*H; } }
  if (p.act === "phone" && ((t*0.3 + i) % 9) < 1.6) ex = "smile";
  if (noticed){
    if (mood === "cheerful"){ ex = "smile"; if (dist < 11 && !p.umbrella && !L.acc.sign){ arA[1] = -2.75; elA[1] = -0.35 + Math.sin(t*9)*0.45; arZ[1] = -0.35; } }
    else if (mood === "poser"){ ex = "smile"; tilt = 0.18; if (!p.umbrella && !L.acc.sign){ arA[1] = -2.3; elA[1] = -1.7; arZ[1] = -0.55; } }
    else if (mood === "grumpy"){ ex = "frown"; if (dist < 5 && !p.umbrella){ arA[1] = -1.4; elA[1] = -0.3; arZ[1] = -0.15; } }
    else if (mood === "shy"){ ex = "neutral"; yawFx = -2*p.headYaw; pitchFx += 0.35; if (!p.umbrella){ arA[0] = -1.1; elA[0] = -2.3; arZ[0] = 0.35; } }
    else if (mood === "curious"){ ex = "surprised"; tilt = 0.22; }
    else if (mood === "anxious"){ ex = "surprised"; if (!p.umbrella && !L.smoke){ arA = [-0.5, -0.5]; elA = [-1.9, -1.9]; arZ = [0.5, -0.5]; } }
  } else if (!mv && p.stationary !== true && anim === "walk" || (!mv && (anim === "lean" || anim === "sit") && !L.smoke)){
    // little habits while standing around
    const hc = (t + i*3.3) % 16, which = (Math.floor((t + i*3.3)/16) + i) % 5;
    if (hc < 2.6 && p.act !== "phone" && !p.umbrella){
      if (which === 0){ arA[0] = -1.25; elA[0] = -1.55; arZ[0] = 0.55; pitchFx += 0.35; }             // checks watch
      else if (which === 1){ arA[1] = -2.5; elA[1] = -2.3; arZ[1] = -0.45; tilt = -0.12; }           // scratches head
      else if (which === 2 && anim !== "sit"){ arA = [-2.9, -2.9]; elA = [-0.3, -0.3]; arZ = [0.2, -0.2]; pitchFx -= 0.2; ex = "yawn"; } // stretches
      else if (which === 3){ arZ = [0.75, -0.75]; elA = [-1.5, -1.5]; arA = [0.2, 0.2]; }             // hands on hips
    }
  }
  if (mood === "grumpy") pitchFx += 0.08; if (mood === "cheerful" && mv) bob *= 1.25;
  const G_ = (name, pk) => { if (pk >= p.gPeak){ p.gesture = name; p.gPeak = pk; } };
  if (noticed){ if (mood === "cheerful") G_("wave", 0.5 + 0.5*Math.sin(t*9)); else if (mood === "poser") G_("pose", 0.9); else if (mood === "grumpy" && dist < 5) G_("block", 0.9); else if (mood === "shy") G_("turn", 0.7); }
  if (ex === "laugh") G_("laugh", Math.abs(Math.sin(((t*0.23 + i*0.71) % 7)/1.2*Math.PI)));
  else if (anim === "talk" && ex === "talk") G_("gesture", Math.abs(Math.sin(t*4.5+i))*0.8);
  if (smokeCyc >= 0){ if (smokeCyc > 0.45 && smokeCyc < 1.4) G_("drag", Math.sin((smokeCyc-0.45)/0.95*Math.PI)); else if (smokeCyc > 2 && smokeCyc < 3) G_("exhale", Math.sin((smokeCyc-2)*Math.PI)); }
  { const hc = (t + i*3.3) % 16, which = (Math.floor((t + i*3.3)/16) + i) % 5; if (hc < 2.6 && !mv && !noticed && anim !== "talk") G_(["watch","scratch","stretch","hips","adjust"][which], Math.sin(hc/2.6*Math.PI)); }
  switch (p.evPose){
    case "give": arA=[-.95,-1.1];elA=[-.3,-.45];arZ=[.13,-.16];lean=.08;G_("give",.8);break;
    case "take": arA=[-.85,-.85];elA=[-.6,-.6];arZ=[.2,-.2];pitchFx=.15;G_("take",.8);break;
    case "wave": arA[1]=-2.5;elA[1]=-.45;arZ[1]=-.25+Math.sin(t*8)*.25;ex="smile";G_("wave",.85);break;
    case "watch": arA=[.08,-.05];elA=[-.15,-.2];pitchFx=-.04;break;
    case "pose": arA=[.2,-.45];elA=[-1.5,-.9];arZ=[.7,-.3];hipYaw=.12;tilt=.09;G_("pose",.9);break;
    case "talk": arA=[-.3+Math.sin(t*3)*.2,-.7];elA=[-.6,-1.1];ex="talk";G_("gesture",.65);break;
    case "shout": arA = [-0.7 + 0.3*Math.sin(t*6), -1.0 + 0.4*Math.sin(t*7+1)]; elA = [-1.0, -0.8]; arZ = [0.35, -0.35]; ex = "shout"; G_("argue", Math.abs(Math.sin(t*6))); break;
    case "point": arA[1] = -1.5; elA[1] = -0.05; arZ[1] = -0.15; ex = "frown"; G_("point", 1); break;
    case "handsup": arA = [-1.9, -1.9]; elA = [-1.2, -1.2]; arZ = [0.5, -0.5]; ex = "surprised"; G_("shrug", 0.8); break;
    case "handsface": arA = [-0.9, -0.9]; elA = [-2.35, -2.35]; arZ = [0.35, -0.35]; ex = "surprised"; G_("reaction", 1); break;
    case "kneel": hipY = 0.53*H*0.62; thA = [-1.45, 0.25]; knA = [1.45, 1.75]; arA[1] = -1.3; elA[1] = -0.5; lean = -0.05; ex = "smile"; G_("kneel", 1); break;
    case "hug": arA = [-1.35, -1.35]; elA = [-1.1, -1.1]; arZ = [0.6, -0.6]; ex = "smile"; G_("hug", 1); break;
    case "clap": { const c = Math.sin(t*18)*0.2; arA = [-0.8, -0.8]; arZ = [0.35 + c, -0.35 - c]; elA = [-1.2, -1.2]; ex = "smile"; G_("clap", 0.6); break; }
    case "dance": arA = [-2.6 + Math.sin(t*5)*0.6, -1.0 + Math.sin(t*5+2)*1.2]; arZ = [0.9*Math.sin(t*3), -0.9*Math.sin(t*3+1)]; elA = [-0.5, -1.0]; thA = [-0.4 + 0.3*Math.sin(t*6), -0.4 - 0.3*Math.sin(t*6)]; knA = [0.8, 0.8]; bob = Math.abs(Math.sin(t*6))*0.05*H; ex = "laugh"; G_("dance", Math.abs(Math.sin(t*2.5))); break;
    case "band": arA = [-1.0, -0.9]; elA = [-1.3, -1.1]; arZ = [0.35, -0.35]; ex = "talk"; G_("band", 0.7); break;
    case "fist": arA[1] = -2.9; elA[1] = -0.15; arZ[1] = -0.1; ex = "shout"; G_("fist", 0.9); break;
    case "cheer": arA = [-2.7, -2.7]; elA = [-0.3, -0.3]; arZ = [0.35, -0.35]; ex = "laugh"; G_("cheer", 0.8); break;
    case "radio": arA[0] = -0.9; elA[0] = -2.4; arZ[0] = 0.55; pitchFx += 0.15; G_("radio", 0.5); break;
    case "hose": arA = [-1.3, -1.1]; elA = [-0.5, -0.7]; arZ = [0.25, -0.15]; lean = 0.15; G_("hose", 0.8); break;
    case "duck": arA = [-2.3, -2.3]; elA = [-2.0, -2.0]; arZ = [0.45, -0.45]; lean = 0.45; ex = "surprised"; G_("duck", 1); break;
    case "run": ex = "surprised"; G_("run", 0.7); break;
    case "ollie": arZ = [-0.9, 0.9]; arA = [-0.4, -0.4]; knA = [1.1, 1.1]; thA = [-0.8, -0.6]; G_("ollie", clamp((p.evY||0)/0.5, 0, 1)); break;
  }
  const hx = 0.052*H*(0.85+0.3*b), sw = 0.105*H*(0.92 + 0.12*b)*(L.fem?0.93:1), dep = 0.07*H*(0.8+0.35*b), tl = 0.29*H;
  jf(hipF, base, 0, hipY + bob, 0, 0, hipYaw !== null ? hipYaw : twist*0.4, 0);
  jf(torF, hipF, 0, 0.005*H, 0, lean, twist, 0);
  // torso & hips
  const bananaOn = !!L.acc.banana;
  if (bananaOn){ hide("torso", i); hide("pelvis", i); hide("belly", i); sp("banana", i, hipF, 0, -0.12*H, 0, sw*1.45, 0.62*H, dep*1.9, lean*0.5, twist); }
  else {
    hide("banana", i);
    sp("torso", i, torF, 0, 0, 0, sw, tl, dep);
    sp("pelvis", i, hipF, 0, 0.025*H, -0.004*H, hx*1.95, 0.06*H, dep*0.86);
    if (b > 1.12) sp("belly", i, torF, 0, 0.36*tl, dep*0.45, 0.085*H*(b-0.55), 0.085*H*(b-0.5), 0.055*H*(b-0.6)); else hide("belly", i);
  }
  // legs
  for (const s of [0,1]){
    const sx = s ? hx : -hx, th = s ? thR : thL, kn = s ? knR : knL;
    jf(th, hipF, sx, 0, 0, thA[s], 0, 0); jf(kn, th, 0, -0.245*H, 0, knA[s], 0, 0);
    const rT = 0.043*H*wb*(L.fem?1.03:1), rS = 0.029*H*wb;
    sp("thigh", 2*i+s, th, 0, 0.01*H, 0, rT, 0.25*H, rT*1.05);
    sp("shin", 2*i+s, kn, 0, 0, 0, rS, 0.245*H, rS);
    jf(tmp, kn, 0, -0.245*H, 0, -(thA[s]+knA[s]), 0, 0);
    sp("shoe", 2*i+s, tmp, 0, -0.018*H, 0.03*H, 0.031*H, 0.022*H, 0.07*H);
  }
  // arms
  for (const s of [0,1]){
    const sh = s ? shR : shL, el = s ? elR : elL, hd = s ? handR : handL;
    jf(sh, torF, (s?1:-1)*sw*0.93, tl*0.9, 0, arA[s], 0, arZ[s]); jf(el, sh, 0, -0.165*H, 0, elA[s], 0, 0); jf(hd, el, 0, -0.155*H, 0);
    const rA = 0.024*H*(0.8+0.3*b)*(L.btype==="coat"||L.outfit==="puffer"?1.2:1);
    sp("uarm", 2*i+s, sh, 0, 0.01*H, 0, rA, 0.17*H, rA);
    sp("farm", 2*i+s, el, 0, 0, 0, rA*0.82, 0.16*H, rA*0.82);
    sp("hand", 2*i+s, hd, 0, -0.016*H, 0.002*H, 0.016*H, 0.027*H, 0.01*H);
  }
  // neck & head
  sp("neck", i, torF, 0, tl + 0.02*H, 0, 0.027*H*(0.9+0.15*b), 0.06*H, 0.027*H*(0.9+0.15*b));
  const hp = p.headPitch + nod + (anim==="elder" ? -0.15 : 0) + (anim==="play" ? Math.sin(t*4)*0.08 : 0) + (smokeCyc > 0 && smokeCyc < 1.8 ? -0.12 : 0);
  if (pl.raised && dist < 3.0 && !p.performer && mood !== "shy" && noticed){
    const want = Math.atan2(pl.pos.x - p.x, pl.pos.z - p.z) - p.heading, w = Math.atan2(Math.sin(want), Math.cos(want)); if (Math.abs(w) < 1.45) yawFx = w - p.headYaw; }
  jf(headF, torF, 0, tl + 0.045*H, 0, hp + pitchFx, p.headYaw + yawFx, tilt);
  { const hw = p.heading + p.headYaw + yawFx + twist*0.9, tc = Math.atan2(pl.pos.x - p.x, pl.pos.z - p.z), dd = Math.atan2(Math.sin(hw - tc), Math.cos(hw - tc)); p.eyeC = Math.abs(dd) < 0.24 && Math.abs(hp + pitchFx) < 0.35 && dist < 25; }
  const hr = 0.071*H*L.hs;
  sp("head", i, headF, 0, hr*0.95, 0, hr*0.88*(L.faceWidth||1), hr*1.16, hr*1.0);
  sp("nose", i, headF, 0, hr*0.84, hr*0.9, hr*0.6*L.nose, hr*0.75*L.nose, hr*0.6*L.nose);
  if(p.scExpression) ex=p.scExpression;
  if(ex==="curious") ex="surprised"; if(ex==="sad") ex="frown";
  p.expression=ex;
  const blink = ((t*0.9 + i*1.37) % 4.3) < 0.13;
  const eyeY = hr*0.088*(blink ? 0.12 : (ex === "laugh" || ex === "yawn") ? 0.35 : ex === "smile" ? 0.7 : ex === "surprised" ? 1.6 : (ex === "tired" || ex === "thoughtful") ? .48 : ex === "frown" ? 0.8 : 1);
  sp("eye", 2*i, headF, -hr*(L.eyeSpacing||.34), hr*1.06, hr*0.86, hr*0.14, eyeY, hr*0.07); sp("eye", 2*i+1, headF, hr*(L.eyeSpacing||.34), hr*1.06, hr*0.86, hr*0.14, eyeY, hr*0.07);
  const browUp = ex === "surprised" ? hr*0.13 : ex === "laugh" ? hr*0.05 : (ex === "frown" || ex === "shout") ? -hr*0.05 : 0;
  for (const s_ of [0,1]){ const sx = s_ ? 1 : -1, bz = (ex === "frown" || ex === "shout") ? sx*0.38 : ex === "surprised" ? -sx*0.2 : ex === "smile" ? -sx*0.05 : sx*-0.12;
    sp("brow", 2*i+s_, headF, sx*hr*0.33, hr*1.3 + browUp, hr*0.86, hr*0.3, hr*0.06, hr*0.08, 0, 0, bz); sp("ear", 2*i+s_, headF, sx*hr*0.9, hr*0.98, 0, hr*0.12, hr*0.22, hr*0.16); }
  if (ex === "smile") sp("mArc", i, headF, 0, hr*0.58, hr*0.86, hr*0.17, hr*0.09, hr*0.1, 0, 0, Math.PI);
  else if (ex === "frown") sp("mArc", i, headF, 0, hr*0.44, hr*0.86, hr*0.15, hr*0.07, hr*0.1);
  else if (ex === "talk") sp("mouth", i, headF, 0, hr*0.5, hr*0.84, hr*0.2, hr*(0.035 + 0.06*Math.abs(Math.sin(t*11 + i))), hr*0.08);
  else if (ex === "laugh") sp("mouth", i, headF, 0, hr*0.49, hr*0.84, hr*0.26, hr*(0.1 + 0.03*Math.abs(Math.sin(t*14))), hr*0.09);
  else if (ex === "shout") sp("mouth", i, headF, 0, hr*0.49, hr*0.84, hr*0.22, hr*(0.09 + 0.05*Math.abs(Math.sin(t*9))), hr*0.09);
  else if (ex === "surprised") sp("mouth", i, headF, 0, hr*0.48, hr*0.85, hr*0.11, hr*0.12, hr*0.08);
  else if (ex === "yawn") sp("mouth", i, headF, 0, hr*0.46, hr*0.84, hr*0.15, hr*0.17, hr*0.09);
  else sp("mouth", i, headF, 0, hr*0.5, hr*0.84, hr*0.2, hr*0.03, hr*0.08);
  jf(hdF, headF, 0, hr*0.95, 0);
  for (const h of HAIRS) if (h === L.hair && !(L.hat && (L.hat==="tophat"||L.hat==="chef"||L.hat==="headscarf") && h!=="long")) sp("h_"+h, i, hdF, 0,0,0, hr,hr,hr); else hide("h_"+h, i);
  if (L.beard) sp("h_beard", i, hdF, 0,0,0, hr,hr,hr); else hide("h_beard", i);
  for (const h of HATS) if (h === L.hat) sp("t_"+h, i, hdF, 0,0,0, hr,hr,hr); else hide("t_"+h, i);
  if (L.glasses) sp("glasses", i, hdF, 0, hr*0.1, hr*0.96, hr, hr, hr); else hide("glasses", i);
  // clothing extras
  if (L.btype === "skirt" || L.btype === "dress" || L.btype === "coat"){ const len = L.btype==="coat" ? L.skirtLen*H : L.skirtLen*H; sp("skirt", i, L.btype==="coat" ? torF : hipF, 0, L.btype==="coat" ? 0.02*H : 0.035*H, 0, hx*1.95, len, dep*1.12); } else hide("skirt", i);
  if (L.btype === "tutu") sp("tutu", i, hipF, 0, 0.02*H, 0, hx*1.3, 0.25*H*0.25, dep*1.3); else hide("tutu", i);
  sp("belt", i, hipF, 0, 0.055*H, 0, hx*1.95, 0.03*H, dep*0.9);
  sp("collar", i, torF, 0, tl*0.99, 0, 0.035*H*(0.9+0.15*b), 0.03*H, 0.034*H*(0.9+0.15*b));
  if (L.acc.tie) sp("tie", i, torF, 0, tl*0.66, dep*0.93, 0.022*H, 0.2*H, 0.006*H); else hide("tie", i);
  if (L.acc.scarf) sp("scarf", i, torF, 0, tl*0.98, 0, 0.042*H, 0.035*H, 0.04*H); else hide("scarf", i);
  if (L.acc.backpack) sp("backpack", i, torF, 0, tl*0.58, -dep - 0.035*H, sw*0.85, 0.12*H, 0.055*H); else hide("backpack", i);
  if (L.acc.tote) sp("tote", i, torF, sw*1.05, tl*0.32, 0.01*H, 0.05*H, 0.2*H, 0.2*H*0.9); else hide("tote", i);
  if (L.acc.camera) sp("camera", i, torF, 0, tl*0.62, dep*1.05, 0.07*H, 0.04*H, 0.035*H); else hide("camera", i);
  if (L.acc.cape){ const sw_ = 0.2 + mv*0.35 + Math.sin(t*3+i)*0.06; sp("cape", i, torF, 0, tl*0.97, -dep*0.95, sw*2.1, 0.52*H, 0.012*H, sw_); } else hide("cape", i);
  if (L.acc.wings) sp("wings", i, torF, 0, tl*0.72, -dep - 0.02*H, H*0.9, H*0.9, H*0.9, 0, 0, Math.sin(t*5+i)*0.05); else hide("wings", i);
  if (L.acc.skate || (p.pool && L.anim === "skate")) sp("skate", i, base, 0, 0, 0, 1, 1, 1, (p.evY||0) > 0.05 ? -0.35 : 0, 0, 0);
  // hand-held things
  if (p.dog){ if (!p.handL) p.handL = new THREE.Vector3(); p.handL.setFromMatrixPosition(handL); }
  if (smokeCyc >= 0){
    sp("cig", i, handR, 0.004*H, -0.03*H, 0.012*H, 0.0045, 0.08, 0.0045, Math.PI/2 - 0.2);
    sp("ember", i, handR, 0.004*H, -0.03*H - 0.008, 0.012*H + 0.041, 0.0065, 0.0065, 0.0065);
    if (dist < 45){
      if (Math.random() < 0.3){ _pv.set(0.004*H, -0.03*H - 0.008, 0.012*H + 0.045).applyMatrix4(handR); Smoke.emit(_pv.x, _pv.y + 0.01, _pv.z, 0, 0.12, 0, 0.018, 2.4, 0.22); }
      if (smokeCyc > 2.0 && smokeCyc < 3.0 && Math.random() < 0.6){ _pv.set(0, hr*0.55, hr*1.15).applyMatrix4(headF); const fx = Math.sin(p.heading + p.headYaw), fz = Math.cos(p.heading + p.headYaw); Smoke.emit(_pv.x, _pv.y, _pv.z, fx*0.55 + (Math.random()-0.5)*0.15, 0.12 + Math.random()*0.1, fz*0.55 + (Math.random()-0.5)*0.15, 0.05, 3.2, 0.4); }
    }
  } else { hide("cig", i); hide("ember", i); }
  const handPos = (hd) => _pv.setFromMatrixPosition(hd).clone();
  if (p.act === "phone") sp("phone", i, handR, 0, -0.04*H, 0.012*H, 0.04*H, 0.08*H, 0.008*H, -0.3); else hide("phone", i);
  if (L.acc.cup && p.act !== "phone" && !p.umbrella) sp("cup", i, handR, 0, -0.035*H, 0.02*H, 0.022*H, 0.055*H, 0.022*H); else hide("cup", i);
  if (L.acc.shopBag) sp("shopbag", i, handL, 0, -0.1*H, 0, 0.09*H, 0.14*H, 0.05*H); else hide("shopbag", i);
  if (L.acc.sign || p.evSign) sp("sign", i, torF, 0, tl + 0.2*H, 0.06*H, 1, 1, 1); else hide("sign", i);
  if (L.acc.cane && !L.acc.sign && !p.umbrella){ const hpv = handPos(handR); const gy = p.y; const len = Math.max(0.3, hpv.y - gy); tmp.makeTranslation(hpv.x, gy + len/2, hpv.z); sp("cane", i, tmp, 0,0,0, 0.012, len, 0.012); } else hide("cane", i);
  if (p.umbrella){ const hpv = handPos(handR); tmp.makeTranslation(hpv.x, hpv.y, hpv.z); sp("pole", i, tmp, 0, 0.45, 0, 0.012, 0.95, 0.012); sp("canopy", i, tmp, 0, 1.05, 0, 1.1, 1, 1.1, 0.08); } else { hide("pole", i); hide("canopy", i); }
  if (p.evPose === "band") sp("guitar", i, torF, 0.02*H, tl*0.5, dep + 0.08, 1.0, 1.0, 1.0, -0.4, 0, 0.35);
  else if (anim === "play") sp("guitar", i, torF, 0.02*H, tl*0.42, dep + 0.05, 1.15, 1.15, 1.15, 0, 0, 1.15); else hide("guitar", i);
}
function flushPeople(){ for (const k in PI_){ const m = PI_[k]; m.count = CNT[k]||0; CNT[k] = 0; m.instanceMatrix.needsUpdate = true; if (m.userData.pat) m.userData.pat.needsUpdate = true; if (m.instanceColor) m.instanceColor.needsUpdate = true; } }
