/* =========================================================
   Global bridge
   The core game objects are top-level let/const in classic scripts.
   Those live in the global scope but are NOT properties of window, so
   patches that test `window.S`, `window.G` etc. always saw undefined and
   silently skipped their work (patches 27–31, 37 and 38).
   These getters make window.X resolve to the real object. Loaded first;
   the getters are lazy, so declaration order doesn't matter.
   ========================================================= */
(function(){
  "use strict";
  const read = {
    S:      function(){ return typeof S      !== "undefined" ? S      : undefined; },
    G:      function(){ return typeof G      !== "undefined" ? G      : undefined; },
    World:  function(){ return typeof World  !== "undefined" ? World  : undefined; },
    Player: function(){ return typeof Player !== "undefined" ? Player : undefined; },
    Game:   function(){ return typeof Game   !== "undefined" ? Game   : undefined; },
    Life:   function(){ return typeof Life   !== "undefined" ? Life   : undefined; },
    UI:     function(){ return typeof UI     !== "undefined" ? UI     : undefined; },
    GP:     function(){ return typeof GP     !== "undefined" ? GP     : undefined; },
    WIND:   function(){ return typeof WIND   !== "undefined" ? WIND   : undefined; },
    Refl:   function(){ return typeof Refl   !== "undefined" ? Refl   : undefined; },
    Cam:    function(){ return typeof Cam    !== "undefined" ? Cam    : undefined; },
    VF:     function(){ return typeof VF     !== "undefined" ? VF     : undefined; }
  };
  Object.keys(read).forEach(function(name){
    if (Object.prototype.hasOwnProperty.call(window, name)) return;
    Object.defineProperty(window, name, {
      configurable: true,   // must stay configurable so the real let/const can still be declared
      enumerable: false,
      get: read[name],
      // `S` is the only one that is reassigned (let S). Writes go to the real binding.
      set: name === "S" ? function(v){ S = v; } : undefined
    });
  });
})();
