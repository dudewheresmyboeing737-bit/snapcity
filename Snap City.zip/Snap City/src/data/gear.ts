// Gear data tables extracted from 01-legacy.js.
// All data is pure — no THREE dependency.

import type { Body, Film, Flash, Format, Lens, Skill, TimeOfDay } from "../types/gear";

/* ---------- gear: film formats ---------- */
export const FORMATS: Record<string, Format> = {
  "135":   { n: "35mm", w: 36, h: 24, film: "135", frames: 36 },
  half:    { n: "Half frame", w: 18, h: 24, film: "135", frames: 72 },
  xpan:    { n: "Panoramic 24×65", w: 65, h: 24, film: "135", frames: 21 },
};

/* ---------- film stocks ---------- */
// look: sat, con, warm, tint(+ = green), fade, grain, gs = grain size, lat = [under, over] stops of latitude, hal = halation
export const FILMS: Record<string, Film> = {
  gold200:  { n: "Kodak Gold 200", iso: 200, k: "neg", f: ["135"], sat: 1.1, con: 1.02, warm: 0.05, tint: 0, fade: 0.02, grain: 0.9, lat: [1.5, 3], hal: 0.06, p: 9, d: "Warm, cheerful consumer film. Sunny-day yellows and skin that glows." },
  ultramax: { n: "Kodak UltraMax 400", iso: 400, k: "neg", f: ["135"], sat: 1.15, con: 1.05, warm: 0.03, tint: 0, fade: 0.01, grain: 1.1, lat: [1.5, 3], hal: 0.06, p: 10, d: "Punchy all-rounder. Forgiving and fast enough for shade." },
  colorplus:{ n: "Kodak ColorPlus 200", iso: 200, k: "neg", f: ["135"], sat: 1.0, con: 0.97, warm: 0.065, tint: -0.005, fade: 0.035, grain: 1.0, lat: [1.5, 3], hal: 0.06, p: 7, d: "The cheapest roll in the shop, with a soft nostalgic warmth." },
  portra160:{ n: "Kodak Portra 160", iso: 160, k: "neg", f: ["135"], sat: 0.86, con: 0.9, warm: 0.025, tint: 0, fade: 0.02, grain: 0.45, lat: [1.5, 4], hal: 0.05, p: 15, d: "Fine grain, gentle colour, flattering skin. Best in good light." },
  portra400:{ n: "Kodak Portra 400", iso: 400, k: "neg", f: ["135"], sat: 0.92, con: 0.93, warm: 0.03, tint: 0, fade: 0.015, grain: 0.7, lat: [2, 4.5], hal: 0.05, p: 16, d: "The professional's default: huge latitude and pastel, creamy colour." },
  portra800:{ n: "Kodak Portra 800", iso: 800, k: "neg", f: ["135"], sat: 0.96, con: 0.95, warm: 0.04, tint: 0, fade: 0.02, grain: 1.0, lat: [1.5, 3.5], hal: 0.07, p: 19, d: "Portra for dusk and interiors. Rich, a little grainier." },
  ektar:    { n: "Kodak Ektar 100", iso: 100, k: "neg", f: ["135"], sat: 1.38, con: 1.12, warm: 0.01, tint: 0, fade: 0, grain: 0.35, lat: [1, 2.5], hal: 0.04, p: 14, d: "The world's finest-grain colour negative. Saturated reds and blues." },
  superia:  { n: "Fujifilm Superia X-TRA 400", iso: 400, k: "neg", f: ["135"], sat: 1.08, con: 1.04, warm: -0.01, tint: 0.025, fade: 0.01, grain: 1.0, lat: [1.5, 3], hal: 0.06, p: 10, d: "Fuji greens and cool shadows. A street classic." },
  c200:     { n: "Fujicolor C200", iso: 200, k: "neg", f: ["135"], sat: 1.0, con: 1.0, warm: -0.015, tint: 0.02, fade: 0.02, grain: 0.9, lat: [1.5, 3], hal: 0.05, p: 8, d: "Budget Fuji with a slight green tilt." },
  lomo800:  { n: "Lomography 800", iso: 800, k: "neg", f: ["135"], sat: 1.25, con: 1.1, warm: 0.04, tint: -0.02, fade: 0.01, grain: 1.4, lat: [1.5, 3], hal: 0.08, p: 14, d: "Loud, grainy and saturated. Made for neon and night buses." },
  cine800:  { n: "CineStill 800T", iso: 800, k: "neg", f: ["135"], sat: 1.02, con: 1.05, warm: -0.07, tint: 0, fade: 0.01, grain: 1.1, lat: [1.5, 3], hal: 0.95, p: 18, d: "Tungsten-balanced cinema film. Red halos around every streetlight; cool in daylight." },
  cine50:   { n: "CineStill 50D", iso: 50, k: "neg", f: ["135"], sat: 1.06, con: 1.05, warm: 0, tint: 0, fade: 0, grain: 0.35, lat: [1, 3], hal: 0.55, p: 16, d: "Slow daylight cinema stock. Clean with a soft glow on highlights." },
  aero:     { n: "Aerochrome III (expired)", iso: 400, k: "neg", f: ["135"], sat: 1.3, con: 1.12, warm: 0, tint: 0, fade: 0.03, grain: 1.1, lat: [1, 2], hal: 0.1, ir: true, p: 85, d: "Rare false-colour infrared. Trees turn crimson and pink." },
  e100:     { n: "Kodak Ektachrome E100", iso: 100, k: "slide", f: ["135"], sat: 1.15, con: 1.22, warm: -0.02, tint: 0, fade: 0, grain: 0.3, lat: [0.5, 0.6], hal: 0.03, p: 22, d: "Clean, cool slide film. Nail the exposure or lose it." },
  velvia:   { n: "Fujifilm Velvia 50", iso: 50, k: "slide", f: ["135"], sat: 1.55, con: 1.32, warm: 0.01, tint: 0.02, fade: 0, grain: 0.25, lat: [0.5, 0.5], hal: 0.03, p: 24, d: "Electric colour and deep blacks. Unforgiving, gorgeous." },
  provia:   { n: "Fujifilm Provia 100F", iso: 100, k: "slide", f: ["135"], sat: 1.12, con: 1.16, warm: 0, tint: 0.005, fade: 0, grain: 0.3, lat: [0.6, 0.7], hal: 0.03, p: 22, d: "Neutral, accurate slide film." },
  trix:     { n: "Kodak Tri-X 400", iso: 400, k: "bw", f: ["135"], con: 1.16, fade: 0, grain: 1.3, gs: 1, lat: [1.5, 3], hal: 0.04, p: 11, d: "The street photographer's film for seventy years. Gritty and alive." },
  hp5:      { n: "Ilford HP5 Plus", iso: 400, k: "bw", f: ["135"], con: 1.05, fade: 0.01, grain: 1.2, gs: 1, lat: [2, 3], hal: 0.04, p: 10, d: "Soft, forgiving and happy to be pushed." },
  tmax100:  { n: "Kodak T-Max 100", iso: 100, k: "bw", f: ["135"], con: 1.12, fade: 0, grain: 0.4, gs: 1, lat: [1, 2.5], hal: 0.03, p: 12, d: "Modern tabular grain. Clinically sharp." },
  delta3200:{ n: "Ilford Delta 3200", iso: 3200, k: "bw", f: ["135"], con: 1.0, fade: 0.035, grain: 2.4, gs: 2, lat: [1.5, 2.5], hal: 0.05, p: 16, d: "For the darkest streets. Grain like sand." },
  fp4:      { n: "Ilford FP4 Plus 125", iso: 125, k: "bw", f: ["135"], con: 1.08, fade: 0, grain: 0.5, gs: 1, lat: [1.5, 3], hal: 0.03, p: 10, d: "Classic medium-speed black and white." },
  panf:     { n: "Ilford Pan F Plus 50", iso: 50, k: "bw", f: ["135"], con: 1.22, fade: 0, grain: 0.25, gs: 1, lat: [0.8, 1.5], hal: 0.02, p: 11, d: "Slow, silky, deep blacks. Bring light." },
  xp2:      { n: "Ilford XP2 Super", iso: 400, k: "bw", f: ["135"], con: 0.97, fade: 0.015, grain: 0.6, gs: 1, lat: [1.5, 4.5], hal: 0.03, p: 12, d: "Chromogenic black and white. Smooth and very forgiving." },
  foma:     { n: "Fomapan 100", iso: 100, k: "bw", f: ["135"], con: 1.1, fade: 0.01, grain: 0.8, gs: 1, lat: [1, 2], hal: 0.04, p: 7, d: "Cheap Czech film with an old-fashioned look." },
};

export const isMono = (fm: Film): boolean => fm.k === "bw" || !!fm.bw;

/* ---------- mounts ---------- */
export const MOUNTS: Record<string, string> = {
  M: "Leica M", F: "Nikon F", FD: "Canon FD", OM: "Olympus OM", K: "Pentax K",
  M42: "M42 screw", LTM: "Leica screw / M39", XP: "XPan",
};

export const MOUNT_COMPAT: Record<string, string[]> = { K: ["K", "M42"], M: ["M", "LTM"] };

/* ---------- lenses ---------- */
// lenses: f focal (real mm), f2 zoom end, a max aperture, sh sharpness, vig vignette, glow bloom, min smallest aperture
export const LENSES: Record<string, Lens> = {
  ltm_50: { n: "Canon 50mm f/1.8 LTM", m:"LTM", f:50, a:1.8, min:16, sh:.88, vig:.22, p:180 },
  m_rokkor40: { n: "M-Rokkor 40mm f/2", m:"M", f:40, a:2, min:16, sh:.94, vig:.17, p:380 },
  // ---- built-in lenses (fixed) ----
  fx_disp:{ n: "30mm f/10 plastic", f: 30, a: 10, fixed: true, sh: 0.72, vig: 0.35, glow: 0.15 },
  fx_lca:{ n: "Minitar 32mm f/2.8", f: 32, a: 2.8, fixed: true, sh: 0.8, vig: 0.6, glow: 0.12 },
  fx_pen:{ n: "D.Zuiko 28mm f/3.5", f: 28, a: 3.5, fixed: true, sh: 0.84, vig: 0.2 },
  fx_demi:{ n: "SH 30mm f/1.7", f: 30, a: 1.7, fixed: true, sh: 0.84, vig: 0.2 },
  fx_mju:{ n: "35mm f/2.8", f: 35, a: 2.8, fixed: true, sh: 0.9, vig: 0.25 },
  fx_t2:{ n: "Sonnar 38mm f/2.8 T*", f: 38, a: 2.8, fixed: true, sh: 0.95, vig: 0.18 },
  fx_t3:{ n: "Sonnar 35mm f/2.8 T*", f: 35, a: 2.8, fixed: true, sh: 0.97, vig: 0.15 },
  fx_t4:{ n: "Tessar 35mm f/3.5 T*", f: 35, a: 3.5, fixed: true, sh: 0.92, vig: 0.2 },
  fx_gr1:{ n: "GR 28mm f/2.8", f: 28, a: 2.8, fixed: true, sh: 0.96, vig: 0.18 },
  fx_35ti:{ n: "Nikkor 35mm f/2.8", f: 35, a: 2.8, fixed: true, sh: 0.94, vig: 0.15 },
  fx_bigmini:{ n: "Hexanon 35mm f/3.5", f: 35, a: 3.5, fixed: true, sh: 0.9, vig: 0.2 },
  fx_tc1:{ n: "G-Rokkor 28mm f/3.5", f: 28, a: 3.5, fixed: true, sh: 0.95, vig: 0.2 },
  fx_minilux:{ n: "Summarit 40mm f/2.4", f: 40, a: 2.4, fixed: true, sh: 0.93, vig: 0.15 },
  fx_r35:{ n: "Sonnar 40mm f/2.8", f: 40, a: 2.8, fixed: true, sh: 0.92, vig: 0.22 },
  fx_xa:{ n: "F.Zuiko 35mm f/2.8", f: 35, a: 2.8, fixed: true, sh: 0.88, vig: 0.25 },
  fx_ql17:{ n: "Canon 40mm f/1.7", f: 40, a: 1.7, fixed: true, sh: 0.86, vig: 0.22, glow: 0.08 },
  fx_hexar:{ n: "Hexanon 35mm f/2", f: 35, a: 2, fixed: true, sh: 0.95, vig: 0.15 },
  fx_klasse:{ n: "Super-EBC 28mm f/2.8", f: 28, a: 2.8, fixed: true, sh: 0.93, vig: 0.18 },
  fx_gsn:{ n: "Color-Yashinon 45mm f/1.7", f: 45, a: 1.7, fixed: true, sh: 0.84, vig: 0.22, glow: 0.1 },
  // ---- Leica M ----
  m_cron35:{ n: "Summicron 35mm f/2 ASPH", m: "M", f: 35, a: 2, sh: 0.97, vig: 0.2, p: 2400 },
  m_lux35:{ n: "Summilux 35mm f/1.4 (pre-ASPH)", m: "M", f: 35, a: 1.4, sh: 0.85, vig: 0.3, glow: 0.35, p: 2900, d: "The 'king of bokeh' glows wide open." },
  m_cron50:{ n: "Summicron 50mm f/2", m: "M", f: 50, a: 2, sh: 0.95, vig: 0.15, p: 1500 },
  m_nocti:{ n: "Noctilux 50mm f/1", m: "M", f: 50, a: 1, sh: 0.82, vig: 0.45, glow: 0.3, p: 7500, d: "Paper-thin focus and a halo on everything." },
  m_elm28:{ n: "Elmarit 28mm f/2.8", m: "M", f: 28, a: 2.8, sh: 0.93, vig: 0.25, p: 1300 },
  m_skopar21:{ n: "Voigtländer Color-Skopar 21mm f/4", m: "M", f: 21, a: 4, sh: 0.9, vig: 0.4, p: 450 },
  m_nokton40:{ n: "Voigtländer Nokton 40mm f/1.4", m: "M", f: 40, a: 1.4, sh: 0.86, vig: 0.3, glow: 0.2, p: 420 },
  m_elmar90:{ n: "Elmar-M 90mm f/4", m: "M", f: 90, a: 4, sh: 0.92, vig: 0.12, p: 600 },
  m_summarit75:{ n: "Summarit 75mm f/2.4", m: "M", f: 75, a: 2.4, sh: 0.93, vig: 0.15, p: 1100 },
  m_jupiter12:{ n: "Jupiter-12 35mm f/2.8", m: "M", f: 35, a: 2.8, sh: 0.8, vig: 0.3, glow: 0.1, p: 120, d: "Soviet Biogon copy. Cheap and characterful." },
  // ---- Nikon F ----
  f_20:{ n: "Nikkor 20mm f/3.5 AI", m: "F", f: 20, a: 3.5, sh: 0.88, vig: 0.35, p: 260 },
  f_24:{ n: "Nikkor 24mm f/2.8 AI-S", m: "F", f: 24, a: 2.8, sh: 0.9, vig: 0.25, p: 200 },
  f_35:{ n: "Nikkor 35mm f/2 AI-S", m: "F", f: 35, a: 2, sh: 0.9, vig: 0.2, p: 180 },
  f_50:{ n: "Nikkor 50mm f/1.4 AI-S", m: "F", f: 50, a: 1.4, sh: 0.88, vig: 0.25, glow: 0.12, p: 150 },
  f_85:{ n: "Nikkor 85mm f/1.8 AI-S", m: "F", f: 85, a: 1.8, sh: 0.92, vig: 0.15, p: 320 },
  f_105:{ n: "Nikkor 105mm f/2.5 AI-S", m: "F", f: 105, a: 2.5, sh: 0.95, vig: 0.12, p: 230, d: "The lens from the Afghan Girl cover." },
  f_180:{ n: "Nikkor 180mm f/2.8 ED", m: "F", f: 180, a: 2.8, sh: 0.94, vig: 0.1, p: 350 },
  f_2885:{ n: "Nikkor 28–85mm f/3.5 zoom", m: "F", f: 28, f2: 85, a: 3.5, sh: 0.84, vig: 0.22, p: 140 },
  // ---- Canon FD ----
  fd_24:{ n: "FD 24mm f/2.8", m: "FD", f: 24, a: 2.8, sh: 0.88, vig: 0.28, p: 170 },
  fd_28:{ n: "FD 28mm f/2.8", m: "FD", f: 28, a: 2.8, sh: 0.86, vig: 0.25, p: 60 },
  fd_50:{ n: "FD 50mm f/1.4", m: "FD", f: 50, a: 1.4, sh: 0.87, vig: 0.25, glow: 0.12, p: 90 },
  fd_55:{ n: "FD 55mm f/1.2 S.S.C.", m: "FD", f: 55, a: 1.2, sh: 0.8, vig: 0.35, glow: 0.3, p: 380 },
  fd_85:{ n: "FD 85mm f/1.8", m: "FD", f: 85, a: 1.8, sh: 0.9, vig: 0.18, p: 190 },
  fd_135:{ n: "FD 135mm f/2.8", m: "FD", f: 135, a: 2.8, sh: 0.86, vig: 0.12, p: 50 },
  fd_35105:{ n: "FD 35–105mm f/3.5 zoom", m: "FD", f: 35, f2: 105, a: 3.5, sh: 0.84, vig: 0.2, p: 110 },
  // ---- Olympus OM ----
  om_21:{ n: "Zuiko 21mm f/3.5", m: "OM", f: 21, a: 3.5, sh: 0.9, vig: 0.32, p: 300 },
  om_28:{ n: "Zuiko 28mm f/2.8", m: "OM", f: 28, a: 2.8, sh: 0.87, vig: 0.25, p: 90 },
  om_50:{ n: "Zuiko 50mm f/1.8", m: "OM", f: 50, a: 1.8, sh: 0.88, vig: 0.22, p: 50 },
  om_85:{ n: "Zuiko 85mm f/2", m: "OM", f: 85, a: 2, sh: 0.92, vig: 0.15, p: 260 },
  om_100:{ n: "Zuiko 100mm f/2.8", m: "OM", f: 100, a: 2.8, sh: 0.9, vig: 0.12, p: 120 },
  // ---- Pentax K ----
  k_28:{ n: "SMC Pentax-M 28mm f/2.8", m: "K", f: 28, a: 2.8, sh: 0.86, vig: 0.25, p: 80 },
  k_50:{ n: "SMC Pentax-M 50mm f/1.7", m: "K", f: 50, a: 1.7, sh: 0.88, vig: 0.22, p: 45 },
  k_77:{ n: "FA 77mm f/1.8 Limited", m: "K", f: 77, a: 1.8, sh: 0.95, vig: 0.15, glow: 0.08, p: 700 },
  k_135:{ n: "SMC Pentax-M 135mm f/3.5", m: "K", f: 135, a: 3.5, sh: 0.87, vig: 0.1, p: 60 },
  // ---- M42 ----
  m42_helios:{ n: "Helios 44-2 58mm f/2", m: "M42", f: 58, a: 2, sh: 0.78, vig: 0.45, glow: 0.25, swirl: 1, p: 40, d: "Soviet swirl. Backgrounds melt into spirals." },
  m42_tak50:{ n: "Super-Takumar 50mm f/1.4", m: "M42", f: 50, a: 1.4, sh: 0.85, vig: 0.25, glow: 0.18, warm: 0.03, p: 130, d: "Thorium glass with a faint warm cast." },
  m42_jup9:{ n: "Jupiter-9 85mm f/2", m: "M42", f: 85, a: 2, sh: 0.82, vig: 0.25, glow: 0.2, p: 110 },
  m42_mir:{ n: "Mir-1B 37mm f/2.8", m: "M42", f: 37, a: 2.8, sh: 0.84, vig: 0.3, p: 70 },
  m42_tak135:{ n: "Super-Takumar 135mm f/3.5", m: "M42", f: 135, a: 3.5, sh: 0.87, vig: 0.1, p: 45 },
  // ---- 35mm panoramic ----
  xp_45:{ n: "XPan 45mm f/4", m: "XP", f: 45, a: 4, sh: 0.95, vig: 0.3, min: 22, p: 900 },
  xp_30:{ n: "XPan 30mm f/5.6", m: "XP", f: 30, a: 5.6, sh: 0.93, vig: 0.45, min: 22, p: 2200 },
};

/* ---------- camera bodies ---------- */
export const BODIES: Record<string, Body> = {
  disp:   { n: "Kodak FunSaver", t: "Disposable", fmt: "135", L: "fx_disp", md: "P", fx: [10, 0.008], ff: 2.5, fl: 10, mt: 0, wt: 0.1, snd: "leaf", film: "superia", frames: 27, p: 15, d: "A little yellow box, a flash and 27 chances. No dials to hide behind. Get close, find good light, and trust your eye." },
  lca:    { n: "Lomo LC-A", t: "Toy", fmt: "135", L: "fx_lca", md: "P", zone: true, mt: 1, ts: 500, wt: 0.25, snd: "leaf", leak: 0.08, p: 180, d: "A pocket-sized Soviet eccentric with a 32mm Minitar. Dark corners, bold color, and absolutely no interest in behaving politely." },
  pen:    { n: "Olympus Pen EE-3", t: "Point & shoot", fmt: "half", L: "fx_pen", md: "P", ff: 3, mt: 1, ts: 250, wt: 0.35, snd: "leaf", p: 90, d: "A selenium-eyed half-frame companion. Seventy-two small stories on one 35mm roll; let one frame answer the next." },
  demi:   { n: "Canon Demi EE17", t: "Point & shoot", fmt: "half", L: "fx_demi", md: "PSM", zone: true, mt: 1, ts: 500, wt: 0.4, snd: "leaf", p: 140, d: "Half the negative, plenty of ambition. A fast 30mm f/1.7 and shutter-priority control make this little Canon a night-walk accomplice." },
  mju:    { n: "Olympus mju-II", t: "Point & shoot", fmt: "135", L: "fx_mju", md: "P", af: 7, mt: 1, ts: 1000, fl: 10, wt: 0.14, snd: "leaf", p: 250, d: "A sliding shell, a 35mm f/2.8, and almost nothing to think about. The good picture is already happening. Open it and go." },
  t2:     { n: "Contax T2", t: "Point & shoot", fmt: "135", L: "fx_t2", md: "PA", af: 6, mt: 1, ts: 500, fl: 9, wt: 0.3, snd: "leaf", p: 900, d: "Titanium on the outside, a 38mm Sonnar inside. A pocket jewel with aperture control and a taste for late-afternoon light." },
  t3:     { n: "Contax T3", t: "Point & shoot", fmt: "135", L: "fx_t3", md: "PA", af: 7, mt: 1, ts: 500, fl: 9, wt: 0.23, snd: "leaf", p: 1300, d: "A slimmer titanium notebook with a 35mm Sonnar. Quiet confidence for days when you want the picture to do the talking." },
  t4:     { n: "Yashica T4 Super", t: "Point & shoot", fmt: "135", L: "fx_t4", md: "P", af: 6, mt: 1, ts: 700, fl: 9, wt: 0.19, snd: "leaf", p: 350, d: "A black plastic coat conceals a Zeiss Tessar. The Super’s top-view finder lets you watch the street from a different angle." },
  gr1v:   { n: "Ricoh GR1v", t: "Point & shoot", fmt: "135", L: "fx_gr1", md: "PA", af: 7, mt: 1, ts: 500, fl: 7, wt: 0.18, snd: "leaf", p: 800, d: "A remarkably thin 28mm companion with snap-focus thinking. Step into the scene, keep the edges alive, and walk another block." },
  ti35:   { n: "Nikon 35Ti", t: "Point & shoot", fmt: "135", L: "fx_35ti", md: "PA", af: 6, mt: 1, ts: 500, fl: 8, wt: 0.28, snd: "leaf", p: 700, d: "A 35mm Nikkor beneath a dashboard of tiny analog needles. Equal parts pocket camera and miniature observatory." },
  bigmini:{ n: "Konica Big Mini", t: "Point & shoot", fmt: "135", L: "fx_bigmini", md: "P", af: 6, mt: 1, ts: 400, fl: 9, wt: 0.17, snd: "leaf", p: 180, d: "Unassuming silver, an honest 35mm Hexanon, and room left in your pocket. Sometimes the quietest camera gets the loudest picture." },
  tc1:    { n: "Minolta TC-1", t: "Point & shoot", fmt: "135", L: "fx_tc1", md: "PA", af: 6, mt: 1, ts: 750, fl: 7, wt: 0.19, snd: "leaf", p: 1000, d: "A tiny titanium body wrapped around a 28mm G-Rokkor. Circular apertures and a stubborn belief that small can be serious." },
  minilux:{ n: "Leica Minilux", t: "Point & shoot", fmt: "135", L: "fx_minilux", md: "PA", af: 6, mt: 1, ts: 400, fl: 9, wt: 0.33, snd: "leaf", p: 500, d: "A 40mm Summarit in a substantial little titanium shell. The perspective between wide and normal, for the moments between the obvious ones." },
  hexar:  { n: "Konica Hexar AF", t: "Point & shoot", fmt: "135", L: "fx_hexar", md: "PAM", af: 6, mt: 1, ts: 250, wt: 0.49, snd: "quiet", p: 650, d: "A fast 35mm f/2 and a famously discreet manner. Slip into the room, wait for the glance, leave the scene as you found it." },
  klasse: { n: "Fujifilm Klasse W", t: "Point & shoot", fmt: "135", L: "fx_klasse", md: "PA", af: 6, mt: 1, ts: 500, fl: 9, wt: 0.2, snd: "leaf", p: 700, d: "A wide-angle compact with a 28mm Fujinon and real exposure control. Make space for the whole story, including the thing at the edge." },
  rollei35:{ n: "Rollei 35 S", t: "Point & shoot", fmt: "135", L: "fx_r35", md: "M", zone: true, mt: 1, ts: 500, wt: 0.33, snd: "leaf", p: 300, d: "Two front dials, a collapsible Sonnar and no autofocus rescue. Judge the distance. Choose the exposure. Make this tiny machine yours." },
  xa:     { n: "Olympus XA", t: "Rangefinder", fmt: "135", L: "fx_xa", md: "A", af: 0, mt: 1, ts: 500, wt: 0.23, snd: "quiet", p: 150, d: "A true rangefinder behind a sliding clamshell. Maitani’s pocket trick: a 35mm f/2.8, aperture priority and very little fuss." },
  ql17:   { n: "Canonet QL17 GIII", t: "Rangefinder", fmt: "135", L: "fx_ql17", md: "SM", af: 0, mt: 1, ts: 500, wt: 0.62, snd: "leaf", p: 200, d: "A bright 40mm f/1.7, quick loading and a leaf shutter. A small, capable partner for a very long walk." },
  gsn:    { n: "Yashica Electro 35 GSN", t: "Rangefinder", fmt: "135", L: "fx_gsn", md: "A", af: 0, mt: 1, ts: 500, wt: 0.75, snd: "leaf", p: 120, d: "A silver-shouldered rangefinder with a 45mm f/1.7 and aperture-priority exposure. The evening has not finished with you yet." },
  m3:     { n: "Leica M3", t: "Rangefinder", fmt: "135", m: "M", kit: "m_cron50", md: "M", mt: 0, ts: 1000, sync: 50, wt: 0.6, snd: "mech", p: 1900, d: "Three windows, a bright finder and no meter. A mechanical rangefinder that asks you to learn the light before it disappears." },
  m6:     { n: "Leica M6", t: "Rangefinder", fmt: "135", m: "M", kit: "m_cron35", md: "M", mt: 1, ts: 1000, sync: 50, wt: 0.56, snd: "mech", p: 2900, d: "The familiar M silhouette, a discreet meter and a mechanical shutter. Set your distance and keep one eye on the next corner." },
  mp:     { n: "Leica MP", t: "Rangefinder", fmt: "135", m: "M", kit: "m_cron35", md: "M", mt: 1, ts: 1000, sync: 50, wt: 0.6, snd: "mech", p: 4200, d: "Black paint over brass, a meter and a wind lever. Built for the long relationship between a photographer and a well-worn tool." },
  bessa:  { n: "Voigtländer Bessa R2A", t: "Rangefinder", fmt: "135", m: "M", kit: "m_nokton40", md: "AM", mt: 1, ts: 2000, sync: 125, wt: 0.43, snd: "mech", p: 650, d: "An M-mount rangefinder with aperture priority and a 1/2000 ceiling. Old-school handling with a little breathing room." },
  cle:    { n: "Minolta CLE", t: "Rangefinder", fmt: "135", m: "M", kit: "m_rokkor40", md: "AM", mt: 1, ts: 1000, sync: 60, wt: 0.38, snd: "quiet", p: 900, d: "A compact M-mount body paired with a 40mm M-Rokkor. Small enough to forget until something worth remembering happens." },
  canonp: { n: "Canon P", t: "Rangefinder", fmt: "135", m: "LTM", kit: "ltm_50", md: "M", mt: 0, ts: 1000, sync: 55, wt: 0.68, snd: "mech", p: 420, d: "The Populaire: a life-size finder and a Leica-thread mount. No meter, no hurry; just bright glass and the scene in front of you." },
  zm:     { n: "Zeiss Ikon ZM", t: "Rangefinder", fmt: "135", m: "M", kit: "m_cron35", md: "AM", mt: 1, ts: 2000, sync: 125, wt: 0.5, snd: "mech", p: 1400, d: "A long-base M-mount rangefinder with a generous finder and aperture priority. Give a complicated street a beautifully simple frame." },
  k1000:  { n: "Pentax K1000", t: "SLR", fmt: "135", m: "K", kit: "k_50", md: "M", mt: 1, ts: 1000, sync: 60, wt: 0.62, snd: "mech", p: 150, d: "A needle, a shutter dial and a K mount. The classroom workhorse graduates to the street. Everything you need; every mistake is yours." },
  mx:     { n: "Pentax MX", t: "SLR", fmt: "135", m: "K", kit: "k_50", md: "M", mt: 1, ts: 1000, sync: 60, wt: 0.5, snd: "mech", p: 200, d: "Mechanical timing and LED metering in a compact Pentax body. A small camera for the days that turn into long walks." },
  lx:     { n: "Pentax LX", t: "SLR", fmt: "135", m: "K", kit: "k_50", md: "AM", mt: 1, ts: 2000, sync: 75, wt: 0.57, snd: "mech", p: 600, d: "Pentax’s professional system body with off-the-film metering. From a sunlit crossing to a dim café, it follows the light." },
  ae1:    { n: "Canon AE-1 Program", t: "SLR", fmt: "135", m: "FD", kit: "fd_50", md: "PSM", mt: 1, ts: 1000, sync: 60, wt: 0.58, snd: "mech", p: 250, d: "Program, shutter priority or manual: choose how much to hand over. A familiar silver prism and an FD lens ready for the weekend." },
  f1:     { n: "Canon F-1", t: "SLR", fmt: "135", m: "FD", kit: "fd_50", md: "M", mt: 1, ts: 2000, sync: 90, wt: 0.82, snd: "mech", p: 400, d: "A substantial professional Canon with an FD mount and mechanical timing. A camera that feels ready before the assignment arrives." },
  nikonf: { n: "Nikon F", t: "SLR", fmt: "135", m: "F", kit: "f_50", md: "M", mt: 0, ts: 1000, sync: 60, wt: 0.7, snd: "mech", p: 450, d: "The plain-prism original. No meter, no battery-dependent shutter, just a mechanical Nikon and the light you learned to read." },
  f2:     { n: "Nikon F2", t: "SLR", fmt: "135", m: "F", kit: "f_50", md: "M", mt: 1, ts: 2000, sync: 80, wt: 0.84, snd: "mech", p: 420, d: "A mechanical professional body with a Photomic finder. A satisfying handful of metal for photographers who stay until the story is over." },
  fm2:    { n: "Nikon FM2n", t: "SLR", fmt: "135", m: "F", kit: "f_50", md: "M", mt: 1, ts: 4000, sync: 250, wt: 0.54, snd: "mech", p: 350, d: "A compact mechanical Nikon with 1/4000 timing and 1/250 sync. The FM2n brings a little more daylight into your wide-open plans." },
  f3:     { n: "Nikon F3", t: "SLR", fmt: "135", m: "F", kit: "f_50", md: "AM", mt: 1, ts: 2000, sync: 80, wt: 0.7, snd: "mech", p: 450, d: "A black body, a red stripe and aperture priority. Giugiaro’s classic silhouette looks particularly at home on the last train out." },
  f100:   { n: "Nikon F100", t: "SLR", fmt: "135", m: "F", kit: "f_35", md: "PASM", af: 9, mt: 1, ts: 8000, sync: 250, wt: 0.79, snd: "mech", p: 320, d: "A late-generation film SLR with autofocus and a 1/8000 shutter. The street moves quickly. This one can keep up." },
  om1:    { n: "Olympus OM-1", t: "SLR", fmt: "135", m: "OM", kit: "om_50", md: "M", mt: 1, ts: 1000, sync: 60, wt: 0.51, snd: "mech", p: 220, d: "A small mechanical SLR with a big, bright finder. Less weight on the shoulder, more reason to take the long way home." },
  om2:    { n: "Olympus OM-2", t: "SLR", fmt: "135", m: "OM", kit: "om_50", md: "AM", mt: 1, ts: 1000, sync: 60, wt: 0.52, snd: "mech", p: 250, d: "The compact OM idea with aperture-priority automation and off-the-film metering. Keep your attention on the person, not the needle." },
  mtl5:   { n: "Praktica MTL 5", t: "SLR", fmt: "135", m: "M42", kit: "m42_tak50", md: "M", mt: 1, ts: 1000, sync: 125, wt: 0.64, snd: "mech", p: 60, d: "An East German M42 body with stop-down metering. Unpretentious, solid and perfectly happy with an inexpensive piece of interesting glass." },
  zenit:  { n: "Zenit-E", t: "SLR", fmt: "135", m: "M42", kit: "m42_helios", md: "M", mt: 1, ts: 500, sync: 30, wt: 0.97, snd: "mech", p: 40, d: "A heavy Soviet SLR, a selenium meter and a Helios lens. A little unruly in the hand; wonderfully unruly in the background." },
  spotmatic:{ n: "Pentax Spotmatic", t: "SLR", fmt: "135", m: "M42", kit: "m42_tak50", md: "M", mt: 1, ts: 1000, sync: 60, wt: 0.63, snd: "mech", p: 120, d: "A classic M42 body with stop-down TTL metering and a Takumar. Brass-era character without needing a brass-era budget." },
  xpan:   { n: "Hasselblad XPan", t: "Panoramic", fmt: "xpan", m: "XP", kit: "xp_45", md: "AM", mt: 1, ts: 1000, sync: 125, wt: 0.75, snd: "quiet", p: 3000, d: "A 24×65mm panoramic frame on ordinary 35mm film. Let two stories share one negative. The edge is suddenly much farther away." },
};

// Post-processing: set defaults on body records
for (const k in BODIES) {
  const b = BODIES[k];
  b.id = k;
  if (!b.sync) b.sync = b.ts || 125;
  if (!b.ts) b.ts = 125;
  if (b.fx) b.ts = Math.round(1 / b.fx[1]);
}

export const BODY_TYPES = ["Disposable", "Toy", "Point & shoot", "Rangefinder", "SLR", "Panoramic"];

/* ---------- flashes ---------- */
export const FLASHES: Record<string, Flash> = {
  none:   { name: "No flash", gn: 0, price: 0 },
  pocket: { name: "Vivitar 283 (half power)", gn: 14, price: 60, desc: "A tiny hot-shoe flash. Fills faces within a few metres." },
  speed:  { name: "Metz 45 handle-mount", gn: 45, price: 180, desc: "Powerful and hard. The flash-in-your-face night look." },
  ring:   { name: "Ring flash", gn: 22, soft: true, price: 320, desc: "Shadowless, even light wrapped around the lens." },
};

/* ---------- aperture and shutter scales ---------- */
export const APERTURES = [1, 1.2, 1.4, 1.7, 1.8, 2, 2.4, 2.8, 3.5, 4, 4.5, 5.6, 8, 11, 16, 22, 32];
export const SHUTTERS = [1/8000, 1/4000, 1/2000, 1/1000, 1/500, 1/250, 1/125, 1/60, 1/30, 1/15, 1/8, 1/4, 1/2, 1];

export const fmtShutter = (t: number): string => t >= 1 ? t.toFixed(0) + "s" : "1/" + Math.round(1 / t);
export const fmtA = (n: number): string => "f/" + (n % 1 === 0 ? n.toFixed(0) : n.toFixed(1));

/* ---------- skills ---------- */
export const SKILLS: Record<string, Skill> = {
  steady:  { name: "Steady hands", max: 3, desc: "Each rank cuts handheld shake by a third. Slow shutters and heavy cameras become usable." },
  ghost:   { name: "Invisible", max: 3, desc: "People notice your camera from shorter distances. More candid frames." },
  quickpick: { name: "Quick pick", max:2, desc:"Carry a wide, normal and tele camera. Rank 1 opens a second ready body; rank 2 opens all three. Buy ranks with earned XP." },
  quick:   { name: "Quick draw", max: 2, desc: "Raise the camera and focus faster." },
  zone:    { name: "Zone master", max: 1, desc: "Press X to snap focus to the hyperfocal distance. Shows a depth-of-field band on the focus scale." },
  light:   { name: "Eye for light", max: 1, desc: "The viewfinder shows the light's EV, even on cameras without a meter, and rates its quality." },
  night:   { name: "Night owl", max: 2, desc: "Push film further in the darkroom: each rank adds a stop of push (, and . keys) and cuts pushed grain." },
  breath:  { name: "Hold breath", max: 1, desc: "While the camera is raised, hold Shift to slow the street for a few seconds." },
  scout:   { name: "Scout", max: 1, desc: "The map marks the performers, pigeon flocks, dog walkers and the tram." },
  darkroom:{ name: "Darkroom", max: 2, desc: "Rank 1 unlocks film-look presets in the editor. Rank 2 unlocks clarity and split toning." },
};

/* ---------- time-of-day presets ---------- */
export const TIMES: TimeOfDay[] = [
  { id: "morning", name: "Morning fog", elev: 10, azim: 95,  sun: "#ffe4c4", sunI: 1.1, sky: "#c3ccd4", gnd: "#6e6a62", hemiI: 1.55, fog: "#c7cdd1", fogD: 0.0125, top: "#aeb9c3", bot: "#d4d8d9", ev: 13, win: 0.15, lamps: 0.15, shadow: 0.35, quality: 0.85, qname: "soft and diffuse" },
  { id: "noon",    name: "Midday",      elev: 64, azim: 170, sun: "#fff6e8", sunI: 3.1, sky: "#a3c5e8", gnd: "#8a7e6c", hemiI: 0.95, fog: "#b9cbe0", fogD: 0.0022, top: "#4a82c4", bot: "#bcd3ea", ev: 15, win: 0.0, lamps: 0, shadow: 1, quality: 0.45, qname: "harsh overhead" },
  { id: "golden",  name: "Golden hour", elev: 7,  azim: 262, sun: "#ffb262", sunI: 2.7, sky: "#8ea8c9", gnd: "#7d5a42", hemiI: 1.05, fog: "#e3c6a3", fogD: 0.0035, top: "#6a8cc0", bot: "#f2c18b", ev: 12, win: 0.25, lamps: 0.2, shadow: 1, quality: 1.0, qname: "warm and raking" },
  { id: "blue",    name: "Blue hour",   elev: -5, azim: 275, sun: "#6d7fa8", sunI: 0.0, sky: "#46629a", gnd: "#2c2733", hemiI: 0.85, fog: "#34456a", fogD: 0.0055, top: "#1d2e58", bot: "#6a7aa6", ev: 8, win: 0.8, lamps: 1, shadow: 0, quality: 0.95, qname: "cool and glowing" },
  { id: "night",   name: "Night",       elev: -25, azim: 0,   sun: "#000000", sunI: 0.0, sky: "#1c2542", gnd: "#1b1714", hemiI: 0.45, fog: "#10141f", fogD: 0.0075, top: "#04060c", bot: "#18203a", ev: 5, win: 0.7, lamps: 1, shadow: 0, quality: 0.8, qname: "neon and sodium" },
];
