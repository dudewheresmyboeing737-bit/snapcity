import type { GameSettings } from "../types/game";

export const DEFAULT_SETTINGS: GameSettings = {
  masterVolume: 0.8,
  musicVolume: 0.65,
  effectsVolume: 0.8,
  mouseSensitivity: 1,
  fieldOfView: 75,
  qualityPreset: "high",
  showEditorOverlays: true,
  enableDynamicEvents: true,
  reduceMotion: false,
  perfectExposureMode: "off",
  exposurePriority: "balanced",
  protectHighlights: true
};
