// Types for the gear data tables extracted from 01-legacy.js

export interface Format {
  n: string;
  w: number;
  h: number;
  film: string;
  frames: number;
}

export type FilmKind = "neg" | "slide" | "bw" | "instant";

export interface Film {
  n: string;
  iso: number;
  k: FilmKind;
  f: string[];
  sat?: number;
  con: number;
  warm?: number;
  tint?: number;
  fade: number;
  grain: number;
  gs?: number;
  lat: [number, number];
  hal: number;
  p: number;
  d: string;
  ir?: boolean;
  bw?: boolean;
}

export interface Lens {
  n: string;
  f: number;
  f2?: number;
  a: number;
  fixed?: boolean;
  sh: number;
  vig: number;
  glow?: number;
  min?: number;
  m?: string;
  p?: number;
  d?: string;
  swirl?: number;
  warm?: number;
}

export interface Body {
  n: string;
  t: string;
  fmt: string;
  L?: string;
  m?: string;
  kit?: string;
  md: string;
  fx?: [number, number];
  zone?: boolean;
  ff?: number;
  af?: number;
  mt: number;
  ts?: number;
  sync?: number;
  fl?: number;
  wt: number;
  snd: string;
  leak?: number;
  film?: string;
  frames?: number;
  p: number;
  d: string;
  id?: string;
}

export interface Flash {
  name: string;
  gn: number;
  price: number;
  desc?: string;
  soft?: boolean;
  builtin?: boolean;
}

export interface Skill {
  name: string;
  max: number;
  desc: string;
}

export interface TimeOfDay {
  id: string;
  name: string;
  elev: number;
  azim: number;
  sun: string;
  sunI: number;
  sky: string;
  gnd: string;
  hemiI: number;
  fog: string;
  fogD: number;
  top: string;
  bot: string;
  ev: number;
  win: number;
  lamps: number;
  shadow: number;
  quality: number;
  qname: string;
}
