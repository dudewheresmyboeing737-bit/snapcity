import type { PhotoScore } from "../types/game";

export interface PhotoScoreInputs {
  composition: number;
  light: number;
  timing: number;
  subject: number;
  technical: number;
}

function clampScore(value: number): number {
  return Math.max(0, Math.min(100, value));
}

export function scorePhoto(inputs: PhotoScoreInputs): PhotoScore {
  const composition = clampScore(inputs.composition);
  const light = clampScore(inputs.light);
  const timing = clampScore(inputs.timing);
  const subject = clampScore(inputs.subject);
  const technical = clampScore(inputs.technical);

  const total =
    composition * 0.28 +
    light * 0.22 +
    timing * 0.22 +
    subject * 0.18 +
    technical * 0.10;

  return {
    composition,
    light,
    timing,
    subject,
    technical,
    total: Math.round(total)
  };
}
