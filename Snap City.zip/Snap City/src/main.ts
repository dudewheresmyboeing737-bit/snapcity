import "./style.css";
import "./snap-city.css";

// Typed modules migrated from 01-legacy.js
import { $, $$, clamp, lerp, smooth, rand, pick, mulberry } from "./utils/math";
import {
  FORMATS, FILMS, isMono, MOUNTS, MOUNT_COMPAT, LENSES, BODIES, BODY_TYPES,
  FLASHES, APERTURES, SHUTTERS, fmtShutter, fmtA, SKILLS, TIMES
} from "./data/gear";

// Expose migrated globals on window so the remaining legacy scripts
// (loaded below) can access them as bare identifiers, exactly as before.
interface Window {
  THREE?: unknown;
  $?: typeof $;
  $$?: typeof $$;
  clamp?: typeof clamp;
  lerp?: typeof lerp;
  smooth?: typeof smooth;
  rand?: typeof rand;
  pick?: typeof pick;
  mulberry?: typeof mulberry;
  FORMATS?: typeof FORMATS;
  FILMS?: typeof FILMS;
  isMono?: typeof isMono;
  MOUNTS?: typeof MOUNTS;
  MOUNT_COMPAT?: typeof MOUNT_COMPAT;
  LENSES?: typeof LENSES;
  BODIES?: typeof BODIES;
  BODY_TYPES?: typeof BODY_TYPES;
  FLASHES?: typeof FLASHES;
  APERTURES?: typeof APERTURES;
  SHUTTERS?: typeof SHUTTERS;
  fmtShutter?: typeof fmtShutter;
  fmtA?: typeof fmtA;
  SKILLS?: typeof SKILLS;
  TIMES?: typeof TIMES;
}

Object.assign(window, {
  $, $$, clamp, lerp, smooth, rand, pick, mulberry,
  FORMATS, FILMS, isMono, MOUNTS, MOUNT_COMPAT, LENSES, BODIES, BODY_TYPES,
  FLASHES, APERTURES, SHUTTERS, fmtShutter, fmtA, SKILLS, TIMES
});

// Dynamically load legacy scripts in their original order.
// They are classic scripts (not modules) that share global scope.
const LEGACY_SCRIPTS = [
  "00-global-bridge.js",
  "01-legacy.js", "02-legacy.js", "03-legacy.js", "04-legacy.js",
  "05-legacy.js", "06-legacy.js", "07-legacy.js", "08-legacy.js",
  "09-legacy.js", "10-legacy.js", "11-legacy.js", "12-legacy.js",
  "13-legacy.js", "14-legacy.js", "15-legacy.js", "16-legacy.js",
  "17-legacy.js", "18-legacy.js", "19-legacy.js", "20-legacy.js",
  "21-legacy.js", "22-legacy.js", "23-legacy.js", "24-legacy.js",
  "25-legacy.js", "26-legacy.js", "27-legacy.js", "28-legacy.js",
  "29-legacy.js", "30-legacy.js", "31-legacy.js", "32-legacy.js",
  "33-legacy.js", "34-legacy.js", "35-legacy.js", "36-legacy.js",
  "37-real-world-exposure.js",
  "38-stylized-graphics-overhaul.js",
  "39-street-life-and-architecture.js",
  "41-snap-city.js",
  "42-snap-city-world.js",
  "43-snap-city-quotes.js",
  "44-snap-city-life.js",
  "45-snap-city-streets.js",
  "46-snap-city-fixes.js"
];

function loadScript(src: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = src;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error(`Failed to load ${src}`));
    document.body.appendChild(s);
  });
}

async function loadLegacyScripts(): Promise<void> {
  for (const name of LEGACY_SCRIPTS) {
    try {
      await loadScript(`./legacy/${name}`);
    } catch (e) {
      console.error(`[Snap City] Error loading ${name}:`, e);
      document.querySelector("#loadmsg")!.textContent = `Could not load ${name}. Reload to retry.`;
      return;
    }
  }
  console.info("[Snap City] All legacy scripts loaded. TypeScript migration active.");

  // Start the game only once every patch is loaded. (36-legacy.js used to call
  // boot() mid-way through loading, so later patches missed the start-up.)
  const boot = (window as unknown as { boot?: () => unknown }).boot;
  if (typeof boot === "function") boot();
  else console.error("[Snap City] boot() not found — legacy scripts failed to load.");
}

// Start loading legacy scripts after globals are set up.
loadLegacyScripts();
