// Pure utility functions extracted from 01-legacy.js.
// No THREE dependency — safe to use anywhere.

export const $ = <T extends Element = HTMLElement>(s: string, r: ParentNode = document): T | null =>
  r.querySelector(s) as T | null;

export const $$ = <T extends Element = HTMLElement>(s: string, r: ParentNode = document): T[] =>
  Array.from(r.querySelectorAll(s)) as T[];

export const clamp = (v: number, a: number, b: number): number => Math.max(a, Math.min(b, v));

export const lerp = (a: number, b: number, t: number): number => a + (b - a) * t;

export const smooth = (e0: number, e1: number, x: number): number => {
  const t = clamp((x - e0) / (e1 - e0), 0, 1);
  return t * t * (3 - 2 * t);
};

export const rand = (a = 0, b = 1): number => a + Math.random() * (b - a);

export const pick = <T>(arr: T[]): T => arr[(Math.random() * arr.length) | 0];

// Seedable PRNG (mulberry32)
export function mulberry(seed: number): () => number {
  return function () {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
