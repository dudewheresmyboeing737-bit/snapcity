"""Build original, model-specific faceted SVG illustrations for the 35mm catalog.
The silhouettes, viewfinder layouts, prisms, covers and controls are parameterized
per body. Reference photographs are linked in CAMERA-REFERENCES.md, not embedded.
Run: python scripts/build-camera-art.py
"""
from pathlib import Path
from html import escape
import math, re, json
ROOT=Path(__file__).resolve().parents[1]
# id: family, width, height, top colour, covering, distinctive fittings
PROFILES={
 'disp':('compact',268,124,'#dba52b','#e9b631','disposable'),
 'lca':('compact',239,133,'#383d3e','#202a2c','lca'),
 'pen':('range',233,123,'#b4bdb4','#262f30','selenium'),
 'demi':('range',247,139,'#b6b9ae','#263137','demi'),
 'mju':('compact',250,125,'#344348','#233237','clamshell'),
 't2':('compact',260,145,'#bfbba5','#aaa58e','t2'),
 't3':('compact',246,123,'#bdc1b4','#a4b1a8','t3'),
 't4':('compact',275,134,'#363d43','#273337','superscope'),
 'gr1v':('compact',271,121,'#35464b','#233338','grip'),
 'ti35':('compact',260,144,'#c3c0a7','#252b2c','analog'),
 'bigmini':('compact',261,128,'#b4c5c3','#a3b0ac','bigmini'),
 'tc1':('compact',223,129,'#b8b6a3','#333b3a','tc1'),
 'minilux':('compact',259,150,'#c2baa4','#a19c8c','minilux'),
 'hexar':('range',275,153,'#323a3b','#192b2c','hexar'),
 'klasse':('compact',248,142,'#b8bcb2','#b1b3a9','klasse'),
 'rollei35':('range',228,134,'#bdc4bb','#1d292c','twindial'),
 'xa':('compact',231,127,'#354045','#263337','xa'),
 'ql17':('range',259,151,'#c1c5ba','#243133','ql'),
 'gsn':('range',286,156,'#bdc5ba','#233437','electro'),
 'm3':('range',299,153,'#b6c3be','#253337','m3'),
 'm6':('range',300,151,'#3b4441','#263230','leica'),
 'mp':('range',300,148,'#2e393c','#18282c','mp'),
 'bessa':('range',279,154,'#3e4643','#283737','bessa'),
 'cle':('range',269,142,'#35413f','#1e2d30','cle'),
 'canonp':('range',300,153,'#bec8c0','#263639','canonp'),
 'zm':('range',311,158,'#bdc5bd','#233739','zeiss'),
 'k1000':('slr',295,151,'#c1c8bd','#243034','k1000'),
 'mx':('slr',266,143,'#c0c6bb','#243638','mx'),
 'lx':('slr',280,149,'#414b49','#233235','lx'),
 'ae1':('slr',291,150,'#bdc8bf','#283437','ae1'),
 'f1':('slr',307,156,'#3b4947','#243236','f1'),
 'nikonf':('slr',310,151,'#bdc7bf','#273436','nikonf'),
 'f2':('slr',311,158,'#b7c1b6','#273338','photomic'),
 'fm2':('slr',283,149,'#bdc6b9','#293637','fm2'),
 'f3':('slr',309,150,'#3c4543','#1c3034','redstripe'),
 'f100':('slr',316,178,'#39454a','#24343b','motor'),
 'om1':('slr',272,144,'#c3c8bc','#2a393a','om1'),
 'om2':('slr',274,146,'#b9c1b9','#293438','om2'),
 'mtl5':('slr',292,154,'#b4c2b9','#29363a','praktica'),
 'zenit':('slr',310,156,'#b9c4b9','#293338','zenit'),
 'spotmatic':('slr',288,151,'#c0c8be','#273638','spotmatic'),
 'xpan':('range',335,142,'#344841','#26372f','panoramic'),
}
DESCRIPTIONS={
 'disp':'A little yellow box, a flash and 27 chances. No dials to hide behind. Get close, find good light, and trust your eye.',
 'lca':'A pocket-sized Soviet eccentric with a 32mm Minitar. Dark corners, bold color, and absolutely no interest in behaving politely.',
 'pen':'A selenium-eyed half-frame companion. Seventy-two small stories on one 35mm roll; let one frame answer the next.',
 'demi':'Half the negative, plenty of ambition. A fast 30mm f/1.7 and shutter-priority control make this little Canon a night-walk accomplice.',
 'mju':'A sliding shell, a 35mm f/2.8, and almost nothing to think about. The good picture is already happening. Open it and go.',
 't2':'Titanium on the outside, a 38mm Sonnar inside. A pocket jewel with aperture control and a taste for late-afternoon light.',
 't3':'A slimmer titanium notebook with a 35mm Sonnar. Quiet confidence for days when you want the picture to do the talking.',
 't4':'A black plastic coat conceals a Zeiss Tessar. The Super’s top-view finder lets you watch the street from a different angle.',
 'gr1v':'A remarkably thin 28mm companion with snap-focus thinking. Step into the scene, keep the edges alive, and walk another block.',
 'ti35':'A 35mm Nikkor beneath a dashboard of tiny analog needles. Equal parts pocket camera and miniature observatory.',
 'bigmini':'Unassuming silver, an honest 35mm Hexanon, and room left in your pocket. Sometimes the quietest camera gets the loudest picture.',
 'tc1':'A tiny titanium body wrapped around a 28mm G-Rokkor. Circular apertures and a stubborn belief that small can be serious.',
 'minilux':'A 40mm Summarit in a substantial little titanium shell. The perspective between wide and normal, for the moments between the obvious ones.',
 'hexar':'A fast 35mm f/2 and a famously discreet manner. Slip into the room, wait for the glance, leave the scene as you found it.',
 'klasse':'A wide-angle compact with a 28mm Fujinon and real exposure control. Make space for the whole story, including the thing at the edge.',
 'rollei35':'Two front dials, a collapsible Sonnar and no autofocus rescue. Judge the distance. Choose the exposure. Make this tiny machine yours.',
 'xa':'A true rangefinder behind a sliding clamshell. Maitani’s pocket trick: a 35mm f/2.8, aperture priority and very little fuss.',
 'ql17':'A bright 40mm f/1.7, quick loading and a leaf shutter. A small, capable partner for a very long walk.',
 'gsn':'A silver-shouldered rangefinder with a 45mm f/1.7 and aperture-priority exposure. The evening has not finished with you yet.',
 'm3':'Three windows, a bright finder and no meter. A mechanical rangefinder that asks you to learn the light before it disappears.',
 'm6':'The familiar M silhouette, a discreet meter and a mechanical shutter. Set your distance and keep one eye on the next corner.',
 'mp':'Black paint over brass, a meter and a wind lever. Built for the long relationship between a photographer and a well-worn tool.',
 'bessa':'An M-mount rangefinder with aperture priority and a 1/2000 ceiling. Old-school handling with a little breathing room.',
 'cle':'A compact M-mount body paired with a 40mm M-Rokkor. Small enough to forget until something worth remembering happens.',
 'canonp':'The Populaire: a life-size finder and a Leica-thread mount. No meter, no hurry; just bright glass and the scene in front of you.',
 'zm':'A long-base M-mount rangefinder with a generous finder and aperture priority. Give a complicated street a beautifully simple frame.',
 'k1000':'A needle, a shutter dial and a K mount. The classroom workhorse graduates to the street. Everything you need; every mistake is yours.',
 'mx':'Mechanical timing and LED metering in a compact Pentax body. A small camera for the days that turn into long walks.',
 'lx':'Pentax’s professional system body with off-the-film metering. From a sunlit crossing to a dim café, it follows the light.',
 'ae1':'Program, shutter priority or manual: choose how much to hand over. A familiar silver prism and an FD lens ready for the weekend.',
 'f1':'A substantial professional Canon with an FD mount and mechanical timing. A camera that feels ready before the assignment arrives.',
 'nikonf':'The plain-prism original. No meter, no battery-dependent shutter, just a mechanical Nikon and the light you learned to read.',
 'f2':'A mechanical professional body with a Photomic finder. A satisfying handful of metal for photographers who stay until the story is over.',
 'fm2':'A compact mechanical Nikon with 1/4000 timing and 1/250 sync. The FM2n brings a little more daylight into your wide-open plans.',
 'f3':'A black body, a red stripe and aperture priority. Giugiaro’s classic silhouette looks particularly at home on the last train out.',
 'f100':'A late-generation film SLR with autofocus and a 1/8000 shutter. The street moves quickly. This one can keep up.',
 'om1':'A small mechanical SLR with a big, bright finder. Less weight on the shoulder, more reason to take the long way home.',
 'om2':'The compact OM idea with aperture-priority automation and off-the-film metering. Keep your attention on the person, not the needle.',
 'mtl5':'An East German M42 body with stop-down metering. Unpretentious, solid and perfectly happy with an inexpensive piece of interesting glass.',
 'zenit':'A heavy Soviet SLR, a selenium meter and a Helios lens. A little unruly in the hand; wonderfully unruly in the background.',
 'spotmatic':'A classic M42 body with stop-down TTL metering and a Takumar. Brass-era character without needing a brass-era budget.',
 'xpan':'A 24×65mm panoramic frame on ordinary 35mm film. Let two stories share one negative. The edge is suddenly much farther away.',
}
def shade(c,k):
 v=[int(c[i:i+2],16) for i in (1,3,5)];return '#'+''.join(f'{min(255,max(0,round(n*k))):02x}' for n in v)
def render(id,name,profile):
 family,w,h,top,body,tag=profile
 x=(480-w)/2-12;y=100+(158-h)/2
 def rect(x,y,w,h,c,rx=0):return f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="{rx}" fill="{c}"/>'
 def poly(points,c):return '<polygon points="'+' '.join(f'{a:.1f},{b:.1f}' for a,b in points)+f'" fill="{c}"/>'
 def text(x,y,t,size=12,c='#d5dfd3',anchor='start'):return f'<text x="{x}" y="{y}" font-family="Arial,sans-serif" font-size="{size}" font-weight="700" letter-spacing=".7" fill="{c}" text-anchor="{anchor}">{escape(t)}</text>'
 def disk(cx,cy,r,c):return f'<ellipse cx="{cx}" cy="{cy}" rx="{r}" ry="{r*.36}" fill="{c}"/>'
 def lens(cx,cy,r,depth=16):
  out='';n=12
  for j in range(n):
   a=j*2*math.pi/n;b=(j+1)*2*math.pi/n
   out+=poly([(cx+r*math.cos(a),cy+r*math.sin(a)),(cx+r*math.cos(b),cy+r*math.sin(b)),(cx-7+r*math.cos(b),cy+depth+r*math.sin(b)),(cx-7+r*math.cos(a),cy+depth+r*math.sin(a))],['#273b40','#1b2d34','#3d4e4f','#182b31'][j%4])
  cx-=7;cy+=depth
  for rr,c in [(r,'#091b22'),(r-3,'#7b8e86'),(r-6,'#142c34'),(r*.71,'#0a1c24'),(r*.57,'#243c4d'),(r*.46,'#304f61'),(r*.36,'#142b3b')]:
   out+=poly([(cx+rr*math.cos(j*math.pi/6),cy+rr*math.sin(j*math.pi/6)) for j in range(12)],c)
  out+=poly([(cx-r*.3,cy-r*.25),(cx+r*.15,cy-r*.39),(cx+r*.35,cy-r*.17),(cx-r*.1,cy+r*.03)],'#7696a0')
  out+=poly([(cx+r*.15,cy+r*.2),(cx+r*.34,cy+r*.05),(cx+r*.17,cy+r*.35)],'#aa868c')
  for j in range(12):
   a=j*math.pi/6;rr=r-4
   out+=rect(cx+math.cos(a)*rr-1,cy+math.sin(a)*rr-1,2,3,'#bdc4ac')
  return out
 s=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 480 320" role="img"><title>{escape(name)} — original Snap City illustration</title>'
 s+=f'<ellipse cx="240" cy="277" rx="{w*.52}" ry="12" fill="#040d13" opacity=".28"/>'
 s+=poly([(x,y),(x+26,y-22),(x+w+26,y-22),(x+w,y)],shade(top,1.16))
 s+=poly([(x+w,y),(x+w+26,y-22),(x+w+26,y+h-18),(x+w,y+h)],shade(top,.6))
 s+=rect(x,y,w,h,body,12 if tag in ['clamshell','xa','motor','superscope'] else 3)
 if family!='compact' or tag in ['analog','tc1']:
  s+=rect(x,y,w,38,top,2)+rect(x,y+h-8,w,8,shade(top,.8))
  s+=rect(x+9,y+43,w-18,h-58,body,3)
 else:s+=rect(x+4,y+4,w-8,18,shade(top,1.03),4)
 s+=poly([(x+1,y+h-10),(x+w-1,y+h-10),(x+w-1,y+h),(x+1,y+h)],shade(top,.73))
 # Fine leather checks, quiet enough to survive reduction.
 if family!='compact' or tag in ['grip','lca','tc1','analog']:
  for yy in range(int(y+46),int(y+h-12),6):
   for xx in range(int(x+10),int(x+w-8),7):s+=rect(xx,yy,2,1,shade(body,1.24))
 brand=name.split()[0].upper();model=name[len(name.split()[0])+1:]
 lx=x+w*.55;ly=y+h*.59;r=44 if family=='slr' else 37 if family=='range' else 29
 if tag in ['grip','motor']:s+=rect(x+9,y+31,w*.22,h-40,shade(body,.73),8)
 if tag=='motor':lx+=7;r=50;s+=poly([(x+16,y+10),(x+57,y-5),(x+72,y+30),(x+68,y+h-10),(x+15,y+h-17)],shade(body,.85))
 if family=='slr':
  ph=tag in ['photomic','lx']
  s+=poly([(lx-48,y+31),(lx-42,y-19 if ph else y-4),(lx-16,y-42),(lx+21,y-42),(lx+45,y-10),(lx+48,y+31)],shade(top,.9))
  s+=poly([(lx-16,y-42),(lx+21,y-42),(lx+32,y-57),(lx-5,y-57)],shade(top,1.2))
  s+=poly([(lx+21,y-42),(lx+32,y-57),(lx+59,y-24),(lx+45,y-10)],shade(top,.64))
  s+=text(lx,y+5,brand,15,'#e4e4cc' if int(top[1:3],16)<100 else '#24373b','middle')
  s+=text(x+14,y+27,{'nikonf':'F','photomic':'F2','fm2':'FM2','redstripe':'F3','motor':'F100'}.get(tag,model).upper(),10,'#e0dfc8' if int(top[1:3],16)<100 else '#25383d')
  if tag=='zenit':s+=rect(lx-28,y+13,57,13,'#263632');s+=text(lx,y+23,'••••••••',9,'#9dbea5','middle')
 else:
  s+=text(x+15,y+26,brand,12,'#e2e5cc' if int(top[1:3],16)<100 else '#1d3239')
  wy=y+7 if family=='range' else y+31
  if tag not in ['disposable','lca','xa','clamshell','twindial']:
   s+=rect(x+w-48,wy,34,19,'#10242a',2)+rect(x+w-43,wy+3,23,12,'#738e90',1)
   s+=rect(x+w-108,wy+2,32 if tag in ['m3','leica','mp','zeiss','canonp'] else 17,14,'#456370',1)
  if tag in ['m3','leica','mp','canonp','zeiss','bessa','cle']:s+=rect(x+74,y+9,24,18,'#758981')
  if tag in ['leica','minilux']:s+=f'<circle cx="{x+51}" cy="{y+49}" r="8" fill="#b94839"/>'
  if tag=='m3':s+=rect(x+w-53,y+2,43,28,shade(top,1.19),4)+rect(x+w-48,y+7,33,19,'#34515c')
  s+=text(x+w-12,y+h-18,model.upper(),9,shade(top,1.4),'end')
 # Flash and camera-specific mechanisms.
 if family=='compact' and tag not in ['lca','xa']:
  s+=rect(x+14,y+33,47,22,'#1c2a31',2)+rect(x+18,y+36,39,15,'#c7d4c2')
  for i in range(6):s+=rect(x+21+i*6,y+37,2,12,'#768f85')
 if tag in ['clamshell','xa']:
  lx=x+w*.67;r=27
  s+=poly([(x+9,y+54),(x+24,y+19),(x+w*.48,y+12),(x+w*.47,y+h-17),(x+26,y+h-8),(x+9,y+h-24)],shade(body,1.1))
  s+=text(x+31,y+h-28,'μ II' if tag=='clamshell' else 'XA',17,'#c6d2c8')
  if tag=='xa':s+=rect(x+w*.52,y+15,46,17,'#0c1c24');s+=rect(x+55,y-22,28,10,'#aa4e3d')
 if tag=='lca':lx=x+w*.64;ly=y+87;r=27;s+=rect(lx-38,ly-37,77,77,'#162c35',5)+rect(x+26,y+18,45,26,'#617d7a');s+=text(x+15,y+63,'LOMO',13)
 if tag=='disposable':r=27;lx=x+w*.62;s+=poly([(x+3,y+65),(x+w*.4,y+65),(x+w*.45,y+h-10),(x+3,y+h-10)],'#af3a35')+text(x+16,y+97,'Kodak',22,'#f6d361')+text(x+15,y+117,'FunSaver',10,'#f7e9b3')
 if tag=='twindial':
  lx=x+w*.5;r=31
  for cx in [x+34,x+w-37]:s+=lens(cx,y+74,23,0)
 if tag=='selenium':r=39;lx=x+w*.6
 if tag=='electro':r=43;s+=text(x+17,y+62,'ELECTRO 35',9)+f'<circle cx="{x+31}" cy="{y+88}" r="10" fill="#28372f"/><path d="M{x+29} {y+80}l6 8h-5l5 8" stroke="#cdaa60" fill="none" stroke-width="2"/>'
 if tag=='panoramic':lx=x+w*.64;r=39;s+=rect(x+14,y+40,50,h-54,'#725648',9)+text(x+87,y+26,'XPAN',10,'#d8e1cb')
 if tag=='redstripe':s+=poly([(x+23,y+37),(x+27,y+37),(x+29,y+h-10),(x+25,y+h-10)],'#c04734')
 if tag=='tc1':s+=rect(x+7,y+72,48,42,'#334544',3)
 if tag=='superscope':s+=rect(x+w-82,y-16,27,12,'#101f2a')
 s+=lens(lx,ly,r,20 if family=='slr' else 12)
 if tag=='selenium':
  for i in range(18):
   a=i*math.pi/9;cx=lx-7+34*math.cos(a);cy=ly+12+34*math.sin(a);s+=rect(cx-2,cy-3,4,6,'#87977d')
 # Rewind and shutter-speed dials on the top plane.
 if family!='compact' or tag in ['analog','t2','klasse']:
  for cx,rad in [(x+33,17),(x+w-42,22)]:
   s+=disk(cx+11,y-16,rad,'#1a2a2c')+rect(cx+11-rad,y-22,rad*2,7,shade(top,.6))+disk(cx+11,y-23,rad,shade(top,1.14))
   for j in range(9):a=j*math.pi*2/9;s+=rect(cx+11+math.cos(a)*rad*.8-1,y-24+math.sin(a)*rad*.28,2,2,'#223b3a')
  s+=poly([(x+w-53,y-7),(x+w-12,y-9),(x+w+2,y-17),(x+w-4,y-21),(x+w-51,y-15)],shade(top,1.22))
 else:s+=disk(x+w-18,y-12,11,'#7d8d80')
 if tag=='analog':
  s+=rect(x+74,y-27,91,22,'#202d32',4)
  for j in range(3):s+=disk(x+89+j*28,y-16,11,'#d4c8a9')+f'<path d="M{x+89+j*28} {y-16}l5 -3" stroke="#233836" stroke-width="1.5"/>'
 s+=rect(x-7,y+46,8,15,'#8c9d95',2)+rect(x+w-1,y+46,9,15,'#8c9d95',2)
 s+='</svg>'
 return s
def main():
 data=(ROOT/'src/data/gear.ts').read_text();start=data.index('export const BODIES:');end=data.index('// Post-processing:',start)
 names=dict(re.findall(r'^\s*(\w+):\s*\{ n: "([^"]+)"',data[start:end],re.M))
 assert set(names)==set(PROFILES)==set(DESCRIPTIONS),(set(names)^set(PROFILES))
 out=ROOT/'public/cameras';out.mkdir(parents=True,exist_ok=True)
 for id,name in names.items():
  (out/(id+'.svg')).write_text(render(id,name,PROFILES[id]))
  pattern=r'(^\s*'+id+r':\s*\{[^\n]*?\bd: )"[^"\n]*"'
  data=re.sub(pattern,lambda m:m[1]+json.dumps(DESCRIPTIONS[id],ensure_ascii=False),data,flags=re.M)
 (ROOT/'src/data/gear.ts').write_text(data)
 (out/'catalog.json').write_text(json.dumps([{'id':i,'name':n,'art':i+'.svg','description':DESCRIPTIONS[i]} for i,n in names.items()],indent=2,ensure_ascii=False))
 print(f'Built {len(names)} individual camera illustrations and descriptions.')
if __name__=='__main__':main()
