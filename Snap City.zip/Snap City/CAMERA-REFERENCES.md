# Camera art and reference notes

42 original faceted SVG illustrations represent the retained game catalog. These are stylized illustrations, not photographic reproductions or engineering-exact replicas. Camera prices and handling are game balance values. Half-frame and XPan remain because both use 35mm film.

The links below include manufacturer histories, museum records and manual indexes. Family-level references are labeled where they do not document a particular body. No reference photographs are bundled.

| Body | Reference |
|---|---|
| Kodak FunSaver | [Reference](https://kodak.photosys.com/products/funsaver-35mm-single-use-film-camera) |
| Lomo LC-A | [Reference](https://www.lomography.com/magazine/311143-introducing-the-lomo-lca-minitar-1-art-lens) |
| Olympus Pen EE-3 | [Reference](https://mail.butkus.org/chinon/olympus.htm) |
| Canon Demi EE17 | [Reference](https://global.canon/en/c-museum/product/film64.html) |
| Olympus mju-II | [Reference](https://mail.butkus.org/chinon/olympus.htm) |
| Contax T2 | [Reference](https://www.butkus.org/chinon/contax.htm) |
| Contax T3 | [Reference](https://www.butkus.org/chinon/contax.htm) |
| Yashica T4 Super | [Reference](https://www.butkus.org/chinon/yashica.htm) |
| Ricoh GR1v | [Reference](https://www.butkus.org/chinon/ricoh/ricoh_gr1/ricoh_gr1.htm) |
| Nikon 35Ti | [Reference](https://imaging.nikon.com/imaging/information/products_history/1990/) |
| Konica Big Mini | [Reference](https://www.butkus.org/chinon/konica/konica_big_mini/konica_big_mini.htm) |
| Minolta TC-1 | [Reference](https://butkus.org/chinon/minolta_off-line_manuals.htm) |
| Leica Minilux | [Reference](https://www.butkus.org/chinon/leica/leica_minilux/leica_minilux.htm) |
| Konica Hexar AF | [Reference](https://butkus.org/chinon/konica.htm) |
| Fujifilm Klasse W | [Reference](https://www.itmedia.co.jp/news/article/0610/30/1061030075/) |
| Rollei 35 S | [Reference](https://www.butkus.org/chinon/rollei/rollei_35/rollei_35-splash.htm) |
| Olympus XA | [Reference](https://mail.butkus.org/chinon/olympus.htm) |
| Canonet QL17 GIII | [Reference](https://global.canon/en/c-museum/product/film84.html) |
| Yashica Electro 35 GSN | [Reference](https://www.butkus.org/chinon/yashica.htm) |
| Leica M3 | [Reference](https://www.butkus.org/chinon/leica/leica_m3/leica_m3.htm) |
| Leica M6 | [Reference](https://leica-camera.com/en-US/photography/cameras/m/m6) |
| Leica MP | [Reference](https://leica-camera.com/en-US/photography/cameras/m/mp-black-lacquered/downloads) |
| Voigtländer Bessa R2A | [Reference](https://www.cosina.co.jp/discontinued/bessa-r2a/) |
| Minolta CLE | [Reference](https://butkus.org/chinon/minolta_off-line_manuals.htm) |
| Canon P | [Reference](https://global.canon/en/c-museum/product/film37.html) |
| Zeiss Ikon ZM | [Reference](https://www.butkus.org/chinon/zeiss_ikon.htm) |
| Pentax K1000 | [Reference](https://mail.butkus.org/chinon/pentax.htm) |
| Pentax MX | [Reference](https://mail.butkus.org/chinon/pentax.htm) |
| Pentax LX | [Reference](https://mail.butkus.org/chinon/pentax.htm) |
| Canon AE-1 Program | [Reference](https://global.canon/en/c-museum/product/film103.html) |
| Canon F-1 | [Reference](https://global.canon/en/c-museum/product/film78.html) |
| Nikon F | [Reference](https://imaging.nikon.com/imaging/information/chronicle/history-f/) |
| Nikon F2 | [Reference](https://imaging.nikon.com/imaging/information/chronicle/history-f2/) |
| Nikon FM2n | [Reference](https://imaging.nikon.com/imaging/information/chronicle/) |
| Nikon F3 | [Reference](https://imaging.nikon.com/imaging/information/chronicle/) |
| Nikon F100 | [Reference](https://imaging.nikon.com/imaging/information/products_history/1990/) |
| Olympus OM-1 | [Reference](https://mail.butkus.org/chinon/olympus.htm) |
| Olympus OM-2 | [Reference](https://mail.butkus.org/chinon/olympus.htm) |
| Praktica MTL 5 | [Reference](https://www.praktica.com/pages/vintage-manuals) |
| Zenit-E | [Reference](https://www.butkus.org/chinon/russian/zenith-e/zenith-e.htm) |
| Pentax Spotmatic | [Reference](https://mail.butkus.org/chinon/pentax.htm) |
| Hasselblad XPan | [Reference](https://www.hasselblad.com/about/history/xpan/) |
