# Snap City

**The city never poses. Be ready.**

## Play

Unzip this folder and open **Snap-City.html** in Chrome, Edge, or Firefox with hardware acceleration enabled. No installation or internet connection is needed for the game. Keep the same browser and file location for your local save. Export photographs you want to keep; browser storage is not a backup.

**Start New** begins a career with a disposable 35mm camera and $250. **Free Play** unlocks all equipment and skills, with unlimited spending.

## What's changed

- PSX Enhanced, PSX Classic, and Clean presentation options; revised light palettes and faceted characters.
- Camera-themed workbench with individual original illustrations for all 42 retained 35mm bodies and rewritten descriptions. Medium-format and instant equipment removed. Half-frame and XPan use 35mm film and remain.
- Quick pick: three distinct loaded bodies for wide (under 40mm), normal (40–70mm), and tele (over 70mm). Set them in Gear. Keys **1 / 2 / 3** switch; each body retains its roll and exposure settings. Career ranks cost **180 / 360 XP**; Free Play starts mastered. **Alt + 1–5** selects focus zones.
- Responsive photo processing uses 1080px output and fewer rendering passes. Fine detail uses 1500px. Capture requests are serialized and rendering state is restored on errors.
- Manual fog persists independently of precipitation. Storms include rain, lightning, and delayed thunder. Automatic weather is optional.
- Expanded developed blocks, anchored rooftop silhouettes, more expressive faces, and 22 additional street stories, including six larger gatherings.
- 100 short, attributed quotations by 49 photographers. One appears on startup; immediate repeats are avoided. Click the credit for its source.

## Update 2 — a living, fictional city

- **Fictional city, new every session.** No real-world references. Street and district names are dealt from a pool of invented names, and the layout is re-seeded each time. 121 blocks (was 49).
- **Architecture.** Art Deco, bay-window flats, stucco, glass towers, cast-iron fronts and boarded-up derelicts; stepped tower tops, bay columns, corner turrets; walkable service alleys through many blocks.
- **Not just shops.** Libraries, fire stations, police, post offices, churches, schools, clinics, community halls, theatres, gyms, galleries and museums. Shop types no longer repeat along a street.
- **Inside shops.** Deeper rooms, bigger windows, a counter with a clerk, and customers who eat, sip, read, browse and wait. Coffee and drinks are ordered at the counter only.
- **Street life.** 30 more street stories; "Frequent" now starts one every 12–22 s (up to four at once). An event feed under the map shows what started, how far and which direction. A map key explains the symbols.
- **Getting around.** Hop on and off buses and trams whenever you like.
- **Exposure.** Filters (ND, colour, polarizer) now count in the exposure reading and in auto-exposure; flash photos are judged on flash + ambient light at the focus distance.
- **Gear.** Every lens has a description; lenses, flashes and filters have drawings.
- **Cars and people.** Rarer paint colours, stripes, spoilers, bull bars, racks and more; wider clothing and hair palettes. The belt ring on some pedestrians is gone.
- **Settings.** Regrouped into clear categories; new options for start weather, event notices, map key, location label, minimap size, centre dot, interface size, people in shops and car details. Defaults: medium quality, photo preview on, random start weather.
- **Performance.** City geometry is split into large chunks so off-screen areas are skipped.

## Update 3 — busier streets, fewer collisions

- **Low graphics by default** (applied once to existing saves; change anytime). New **City size** setting: Compact (25 blocks), Standard (49, default), Large (81) — the biggest performance lever.
- **Fixes:** traffic no longer teleports onto other cars mid-city; walkers and cyclists slide along buildings instead of through them; turrets, bays and civic steps stay clear of the sidewalk path; parked cars get more room and never block alley mouths (bollards keep cars out); the market arch spans the street with its pillars on the curbs.
- **Variety:** pocket parks, car parks, vacant lots and gaps between buildings; mansard, gabled, garden and domed roofs; more building widths.
- **Construction:** up to four building sites with turning cranes, scaffolding, crews in hard hats and night work lamps, plus road works with cones and a worker.
- **Alleys:** murals, fire escapes, AC units, back doors with lamps, bins and bags, pallets, laundry lines, bike racks, a cook or smoker on break, and the odd cat.
- **Skills:** Speed loader, Bulk loader, Storm chaser, Street sense (mastered in Free Play).
- **Weather:** new Sky options — Overcast, Drizzle, Sunshower (with matching light levels for the meter).
- **Customisation:** date stamp on photos, photo border (film rebate / white print), HUD accent colour, construction crews and alley people on/off.
- **Settings:** aligned rows, filler text removed, every setting filed into a category.

## Controls

WASD moves; mouse looks after clicking the street. V toggles arrow-key looking. Right mouse or Z raises the camera; left mouse or Space shoots. Tab opens the camera bag. P opens photographs. L reloads. See Controls for the full set.

## Development

Requires Node.js and npm. Run `npm install`, then `npm run dev`. `npm run build` creates the served build in `dist`; `npm run standalone` rebuilds the self-contained HTML. `npm run release` builds both. The active gameplay remains classic JavaScript with typed gear and utility modules; this is not a Godot or Android port.

Camera art is editable SVG, generated by `scripts/build-camera-art.py`. Quotes are generated by `scripts/build-quotes.py`. See CAMERA-REFERENCES.md and QUOTE-SOURCES.md for sources. Illustrations are stylized interpretations, not engineering-exact replicas. Existing gear behavior is a simulation rather than a complete emulation of every real camera's controls.

## Validation

Production TypeScript/Vite build and Chromium smoke checks cover all seven menu tabs, 35mm catalog constraints, Free Play unlocks, Quick pick roll/settings retention, XP costs, old-save migration, weather transitions, stable fog, lightning, event cleanup, and JPEG storage without duplicate captures. Software-rendered test timings are not representative of hardware-accelerated play. Android performance and a native port remain future work.
