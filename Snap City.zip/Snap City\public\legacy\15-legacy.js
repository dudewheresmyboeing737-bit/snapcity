
/* ---------- side exposure panel (from the v5 photographer HUD) ---------- */
function adjustCameraSide(action){
  const st = S.set, b = curBody();
  if (b.fx){ toast("This camera's exposure is fixed.", 900); return; }
  if (action[0] === "a"){ if (st.mode === "P" || st.mode === "S") st.mode = modesFor(b).includes("A") ? "A" : "M"; const as = apertures(); st.A = cycle(as, snapA(st.A), action.endsWith("+") ? 1 : -1); }
  else if (action[0] === "t"){ if (st.mode === "P" || st.mode === "A") st.mode = modesFor(b).includes("S") ? "S" : "M"; const ts = SHUTTERS.filter(t => t >= 1/b.ts - 1e-9), cur = ts.reduce((a,t)=>Math.abs(Math.log(t/st.T)) < Math.abs(Math.log(a/st.T)) ? t : a, ts[0]); st.T = cycle(ts, cur, action.endsWith("+") ? -1 : 1); }
  else if (action[0] === "i"){ const r = curRoll(), full = b.frames || curFormat().frames; if (r.left < full){ toast("Push and pull apply to the whole roll. Change it when you load the next.", 1800); return; } const [pl, ph] = pushRange(); st.push = clamp((st.push||0) + (action.endsWith("+") ? 1 : -1), pl, ph); r.push = st.push; }
  if (!modesFor(b).includes(st.mode)) st.mode = modesFor(b)[0];
  computeExposure(); saveState(); UI.hudT = 0;
}
addEventListener("click", ev => { const b = ev.target.closest && ev.target.closest("#camSide [data-camadj]"); if (!b) return; ev.preventDefault(); ev.stopPropagation(); Audio.init(); adjustCameraSide(b.dataset.camadj); }, true);

/* ---------- graphics quality (v5) ---------- */
function applyGraphicsQuality(){
  if (!S || !G.renderer) return;
  const q = S.custom.renderQuality || "balanced", sz = q === "ultra" ? 4096 : q === "cinematic" ? 3072 : q === "balanced" ? 2048 : 1536;
  if (World.sun){ const use = Math.min(sz, G.renderer.capabilities.maxTextureSize || 4096); if (World.sun.shadow.mapSize.x !== use){ World.sun.shadow.mapSize.set(use, use); if (World.sun.shadow.map){ World.sun.shadow.map.dispose(); World.sun.shadow.map = null; } } }
  const ss = S.custom.captureQuality === "detail" ? 1.35 : 1; if (CAP.SS !== ss){ CAP.SS = ss; CAP.key = ""; }
  if (Refl.rt){ const w = S.custom.reflections === "high" ? (q === "ultra" ? 1280 : 960) : 640; if (Refl.rt.width !== w){ Refl.rt.setSize(w, Math.round(w*9/16)); } }
  resize();
}
function polishWorldMaterials(){
  if (!G.renderer || !G.scene) return; const maxAn = G.renderer.capabilities.getMaxAnisotropy ? G.renderer.capabilities.getMaxAnisotropy() : 8, an = (S && S.custom && S.custom.renderQuality === "ultra") ? maxAn : Math.min(12, maxAn);
  G.scene.traverse(o => { if (!o.material) return; for (const m of (Array.isArray(o.material) ? o.material : [o.material])) for (const k of ["map","roughnessMap","emissiveMap"]) if (m[k] && m[k].anisotropy !== an){ m[k].anisotropy = an; m[k].needsUpdate = true; } });
}

/* ---------- photo essays: sequences judged as a body of work ---------- */
const THEMES = {
  sequence:{ n:"Street Chronicle", d:"No trick. Build a beginning, middle and end from ordinary public life." },
  gesture:{ n:"Gesture", d:"Hands, glances, posture, touch, laughter and the instant a body says something." },
  gaze:{ n:"Strangers Looking Back", d:"Direct gaze, awareness and the strange negotiation between subject and camera." },
  layers:{ n:"Layers", d:"Foreground, middle distance and background coexisting instead of becoming clutter." },
  transit:{ n:"In Transit", d:"Buses, trams, traffic, windows and people moving through the city." },
  rain:{ n:"Weather", d:"Rain, umbrellas, fog, reflections and people adapting to the street." },
  night:{ n:"After Dark", d:"Streetlights, lit windows and the people who stay out." },
  oneblock:{ n:"One Block", d:"Stay geographically tight and find variety without leaving a small patch of city." },
  event:{ n:"Witness", d:"Follow one happening from its first sign to its end." },
};
function essayState(){ S.essays = S.essays || []; if (!S.activeEssay) S.activeEssay = { id:Date.now(), title:"Untitled street study", theme:"sequence", photos:[] }; return S.activeEssay; }
function primOf(m){ const ss = (m.subjects||[]).filter(s=>s.vis > 0.3 && s.kind !== "car"); return ss.sort((a,b)=>b.area - a.area)[0] || null; }
function themeHit(p, theme, first){
  const m = p.meta, pr = primOf(m), subs = m.subjects || [];
  switch (theme){
    case "gesture": return !!(pr && (pr.gpeak > 0.5 || pr.stride > 0.75));
    case "gaze": return subs.some(s => s.eye || s.aware);
    case "layers": { const bands = new Set(subs.filter(s=>s.vis>0.35).map(s=> s.dist<5?0: s.dist<14?1: s.dist<35?2:3)); return bands.size >= 3 || (m.fgEdge > 0.05 && m.fgEdge < 0.4); }
    case "transit": return !!m.riding || subs.some(s => s.kind === "cablecar" || s.bus || s.taxi);
    case "rain": return !!(m.rain || m.fog || subs.some(s=>s.umbrella));
    case "night": return m.time === "night" || m.time === "blue";
    case "oneblock": return m.street === first;
    case "event": return subs.some(s=>s.ev) || Object.keys(m.events||{}).length > 0;
    default: return true;
  }
}
function evaluateEssay(ps, theme){
  const n = ps.length, first = ps[0].meta.street, hits = ps.filter(p=>themeHit(p, theme, first)).length;
  const avg = ps.reduce((a,p)=>a + p.score, 0)/n;
  const keys = {}; ps.forEach(p => { const pr = primOf(p.meta); if (pr && pr.kind === "person") keys[pr.key] = (keys[pr.key]||0) + 1; });
  const recurring = Math.max(0, ...Object.values(keys));
  const hoods = new Set(ps.map(p=>p.meta.hood)).size, films = new Set(ps.map(p=>p.meta.filmId)).size, lenses = new Set(ps.map(p=>p.meta.feq)).size;
  const dists = new Set(ps.map(p=>{ const pr = primOf(p.meta); return !pr ? 3 : pr.dist < 3 ? 0 : pr.dist < 8 ? 1 : 2; })).size;
  const evs = {}; ps.forEach(p => (p.meta.subjects||[]).forEach(s => { if (s.ev) evs[s.ev] = (evs[s.ev]||0) + 1; }));
  const evRun = Math.max(0, ...Object.values(evs));
  // near-duplicates: same spot, same direction, within 20 seconds
  let dup = 0; for (let i=1;i<n;i++){ const a = ps[i-1].meta, b = ps[i].meta; if (a.px !== undefined && b.px !== undefined && Math.hypot(a.px-b.px, a.pz-b.pz) < 2 && Math.abs(Math.atan2(Math.sin(a.yaw-b.yaw), Math.cos(a.yaw-b.yaw))) < 0.25 && Math.abs(ps[i].ts - ps[i-1].ts) < 20000) dup++; }
  const notes = [];
  let coherence = hits/n*34; notes.push(`${hits} of ${n} frames serve the theme "${THEMES[theme].n}".`);
  if (films === 1){ coherence += 5; notes.push("One film stock throughout gives the essay a single voice."); } else if (films > 2) notes.push("Several film looks pull the sequence in different directions.");
  if (recurring >= 2){ coherence += 6 + Math.min(6, (recurring-2)*3); notes.push(`The same person appears in ${recurring} frames: the sequence follows a life, not just a street.`); }
  if (evRun >= 2){ coherence += 8; notes.push(`You stayed with ${EVENTS[Object.keys(evs).find(k=>evs[k]===evRun)]?.name || "the event"} across ${evRun} frames.`); }
  if (theme !== "oneblock" && hoods > 3) coherence -= 4;
  let variety = clamp((lenses - 1)*2 + (dists - 1)*3, 0, 12); if (dists >= 3) notes.push("Wide, middle and close views give it rhythm.");
  if (dup){ variety -= dup*4; notes.push(`${dup} frame${dup>1?"s":""} repeat${dup>1?"":"s"} its neighbour; an editor would cut ${dup>1?"them":"it"}.`); }
  if (theme === "oneblock") variety = Math.max(variety, 10 - new Set(ps.map(p=>p.meta.street)).size*2 + Math.min(5, lenses*1.5));
  let arc = 0; const opener = primOf(ps[0].meta), closer = ps[n-1];
  if (!opener || opener.dist > 8){ arc += 4; notes.push("It opens wide and sets the scene."); }
  if (closer.score >= avg){ arc += 3; notes.push("It ends on one of its strongest frames."); } else notes.push("The last frame is weaker than the rest; end on a strong image.");
  if (n >= 5 && n <= 8) arc += 3; else if (n > 8) notes.push("Tighten it: every extra frame has to earn its place.");
  const quality = avg*0.42, score = Math.round(clamp(coherence + quality + variety + arc, 1, 99));
  return { score, notes, hits };
}
async function openEssay(){ essayState(); showPanel("#essayPanel"); await renderEssay(); }
async function renderEssay(){
  const e = essayState(), all = await DB.all(); UI.essayAll = all;
  $("#essayTitle").value = e.title;
  $("#essayThemes").innerHTML = Object.entries(THEMES).map(([id,t])=>`<button data-theme="${id}" aria-pressed="${e.theme===id}">${t.n}</button>`).join("");
  $$("#essayThemes button").forEach(b=>b.onclick=()=>{ e.theme = b.dataset.theme; saveState(); renderEssay(); });
  $("#essayBrief").textContent = THEMES[e.theme].d + " Choose 3–10 frames; the order is the order you add them.";
  const chosen = e.photos.map(id=>all.find(p=>p.id===id)).filter(Boolean);
  $("#essayStrip").innerHTML = chosen.length ? chosen.map((p,i)=>`<button class="frame" data-rm="${p.id}"><img src="${p.editedThumb||p.thumb}" alt=""><span class="num">${i+1}</span><span class="sc">${p.judged?p.score:"—"}</span></button>`).join("") : `<p class="note">No frames yet. Add them below or from a photo's page.</p>`;
  $$("#essayStrip [data-rm]").forEach(b=>b.onclick=()=>{ e.photos = e.photos.filter(id=>String(id)!==String(b.dataset.rm)); saveState(); renderEssay(); });
  const used = new Set((S.essays||[]).flatMap(x=>x.photos));
  const pool = all.filter(p=>!e.photos.includes(p.id)).sort((a,b)=>b.ts - a.ts).slice(0, 60);
  $("#essayPick").innerHTML = pool.map(p=>`<button class="frame" data-add="${p.id}" title="${used.has(p.id)?"Already in a published essay":""}" style="${used.has(p.id)?"opacity:.45":""}"><img src="${p.editedThumb||p.thumb}" alt=""><span class="sc">${p.judged?p.score:"—"}</span></button>`).join("");
  $$("#essayPick [data-add]").forEach(b=>b.onclick=()=>{ const id = isNaN(+b.dataset.add) ? b.dataset.add : +b.dataset.add; if (e.photos.length >= 10){ toast("Ten frames is the limit."); return; } e.photos.push(id); saveState(); renderEssay(); });
  $("#essayPast").innerHTML = (S.essays||[]).length ? `<div class="sectionhead">Published essays</div>` + S.essays.slice().reverse().map(x=>`<p class="note"><b>${x.title}</b> · ${THEMES[x.theme].n} · ${x.photos.length} frames · <b>${x.score}</b>/99</p>`).join("") : "";
}
async function submitEssay(){
  const e = essayState(), all = UI.essayAll || await DB.all(), ps = e.photos.map(id=>all.find(p=>p.id===id)).filter(Boolean);
  if (ps.length < 3){ toast("A sequence needs at least three frames."); return; }
  for (const p of ps) if (!p.judged){ const res = judgePhoto(p); p.judged = true; p.score = res.total; p.result = res; await DB.put(p); }
  const r = evaluateEssay(ps, e.theme);
  const used = new Set((S.essays||[]).flatMap(x=>x.photos)), fresh = ps.filter(p=>!used.has(p.id)).length;
  const pay = S.free ? 0 : Math.round(r.score*r.score/40 * (fresh/ps.length) * Math.min(1.6, ps.length/5));
  $("#essayResult").innerHTML = `<strong style="font-size:22px">${r.score}/99</strong> — ${r.score>=82?"A coherent body of work.":r.score>=68?"The sequence is beginning to speak.":"Good frames, but they don't need each other yet."}<ul>${r.notes.map(n=>`<li>${n}</li>`).join("")}</ul>${pay ? `<p>An editor buys the essay for <b>$${pay}</b>.</p>` : fresh < ps.length && !S.free ? "<p>Frames already published in another essay earn nothing twice.</p>" : ""}`;
  S.essays.push({ id:e.id, title:e.title, theme:e.theme, photos:e.photos.slice(), score:r.score, ts:Date.now() });
  if (!S.free){ S.money += pay; S.xp += Math.round(r.score*0.6); }
  S.activeEssay = null; saveState(); await renderEssay();
}
function addEssayButton(p){
  const actions = $("#lbside .actions"); if (!actions || $("#lbEssay")) return;
  const b = document.createElement("button"); b.className = "btn small alt"; b.id = "lbEssay";
  const e = essayState(), has = () => e.photos.includes(p.id);
  b.textContent = has() ? "Remove from essay" : "Add to essay";
  b.onclick = () => { if (has()) e.photos = e.photos.filter(id=>id!==p.id); else if (e.photos.length < 10) e.photos.push(p.id); saveState(); b.textContent = has() ? "Remove from essay" : "Add to essay"; toast(has() ? `Added to "${e.title}" (${e.photos.length} frames).` : "Removed from the essay.", 1400); };
  actions.appendChild(b);
}
function initEssayUI(){
  $("#essayBtn").onclick = () => openEssay();
  $("#essayClose").onclick = () => onPanelClosed();
  $("#essayNew").onclick = () => { S.activeEssay = null; essayState(); saveState(); renderEssay(); $("#essayResult").innerHTML = ""; };
  $("#essaySubmit").onclick = () => submitEssay();
  $("#essayTitle").oninput = ev => { essayState().title = ev.target.value || "Untitled street study"; saveState(); };
}
